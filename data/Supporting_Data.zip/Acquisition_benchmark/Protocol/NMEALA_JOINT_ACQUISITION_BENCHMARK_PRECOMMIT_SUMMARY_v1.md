# NMe-Ala joint acquisition benchmark precommit summary v1

## Status

ACQUISITION BENCHMARK DESIGN FROZEN BEFORE NEW QM

## Fixed data roles

Initial QM/M0 training seeds:

54

Locked internal-validation states:

144

Acquisition pool:

1566

PPII:

sealed external off-grid validation.

## Acquisition strategies

1.

Periodic Gaussian-process active learning.

2.

Periodic-distance maximin.

3.

Fixed-seed random baseline.

## Matched cumulative budgets

24

48

96

192

new QM/M0 labels per arm.

GP active-learning batch size:

24

## GP acquisition

Kernel:

anisotropic periodic squared exponential on
phi/psi/omega.

Primary score:

SD[R(phi,psi,omega)]
+
SD[
R(phi,psi,omega)
-
R(phi,psi,180)
].

Thus uncertainty in both the trans-reference A surface
and omega-dependent joint J surface contributes.

No energy weighting enters the primary acquisition
score.

## Maximin

Complete 192-state sequence was selected before new QM
using only periodic angular coordinates and the 54
initial seed coordinates.

## Random

Complete 192-state sequence was selected before new QM
using fixed integer seed:

20260822

## Isolation

Validation states cannot enter any acquisition arm.

Cross-arm QM calculations may be computationally
de-duplicated, but labels remain logically unavailable
to an arm until selected by that arm.

## Current boundary

No new QM calculation has been run.

No validation label has been opened.

No GP active-learning point has yet been selected.

No production representation has been fitted.
