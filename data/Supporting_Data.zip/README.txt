Supporting numerical data

Figure_table_map.tsv links these data to the figures and tables in the submitted
manuscript. Tables/ contains tab-separated versions of the editable Word tables.
Original numeric records and coordinate files retain their supplied precision.
CONTROL and OLD denote M0; TEST and NEW denote Full in original data-field names.
A_ONLY denotes the backbone-only arm. Angles are in degrees; energies are in
kcal/mol; distances and RMSD values are in angstrom unless a table says otherwise.

Acquisition_benchmark/ includes all 24 prediction tables, 12 training tables,
frozen fit metadata, validation labels and protocol records for Table S5.
Native_QM_Inputs/ contains the supplied native NMe-Ala and NMe-Val input files,
initial and available optimized coordinates, and classical topologies.
TriNMe_Frame_Observables/ contains six production-derived per-frame arrays.
These arrays contain torsion/RMSD observables, not full coordinate trajectories.
TriNMe_Contacts/ contains representative structures and the contact summaries.

The TOC surface is a fitted local J correction at fixed psi, not the free-energy
surface of a cyclic peptide. Its grid and all figure data are unchanged.
The compact data supplement does not contain complete raw QM output archives
or production coordinate trajectories. Source code is hosted separately at
https://github.com/ZhuNing9527/nme-cyclic-peptide-reproducibility.
