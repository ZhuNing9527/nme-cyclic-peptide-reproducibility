Simulation inputs

md/inputs/ contains the physical OpenMM systems, solute geometry and atom
bindings, reference angles, ROE bounds, seeds and paired twelve-replica starting
arrays for mono-, di- and tri-NMe cyclic pentaalanines.
R1 and R2 starting NPZ files contain original boxed positions and velocities.

Production_Protocol/ contains recovered protocol and start-materialization
records. Run_Contracts/ contains the 12 original M0/Full production contracts
and the two recovery contracts. Original JSON fields retain their archival
identifiers: JACS1 = mono-NMe, JACS3 = di-NMe, JACS4 = tri-NMe;
CONTROL = M0 and TEST = Full. These identifiers are laboratory aliases.

The tri-NMe A-only XML was reconstructed from Full.xml by setting coefficients
with nonzero omega frequency to zero; it is not claimed to be the original
deployed A-only XML. The included construction report documents this distinction.
Complete production coordinate trajectories are not included in this archive.
