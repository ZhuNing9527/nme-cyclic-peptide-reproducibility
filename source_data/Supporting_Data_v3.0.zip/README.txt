Supporting numerical data for manuscript v3.0

Figure_1 retains the older 246 fitting / 144 representation-selection tables and adds the new independent 144-point test, now used in Figure 1d.
Independent_Ala_Test contains the frozen predictions, labels, coefficients, metrics, and calculation contract for the new test.
Retrospective_Val_Transfer contains the two physical reference contrasts, complete context metrics, source topology/charges and verification.
Figure_2 through Figure_6 and Figure_S1 through Figure_S6 retain the v2.5 ensemble, ROE, RMSD, PMF, contact, and Ramachandran values.
Scheme_1 contains the updated count and data verification: 685 earlier Ala + 144 new Ala + 72 historical Val = 901 reported fragment-panel geometries; 54 solvent single points are separate. The 246 fit points are part of the 535-point acquisition union.

Internal source names map to manuscript names as follows:
JACS1 / TIERA_JACS1 = mono-NMe, literature compound 1.
JACS3 / TIERA_JACS3 = di-NMe, literature compound 15.
JACS4 / TIERA_JACS4 = tri-NMe, literature compound 24.
CONTROL = M0; TEST = Full; A_ONLY = A only.
Internal identifiers and provenance paths are retained to preserve byte-level traceability. They are not additional systems.

The data here reproduce the reported summaries. Complete raw ORCA outputs and MD trajectories are not included in this compact ZIP; their actual archive location/access procedure must be finalized in the manuscript's Data and Software Availability statement. Code is in Reproducibility_Scripts_v3.0.zip and the figure directories.
