from pathlib import Path
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import csv
import hashlib
import math
import os
import re
import shutil
import subprocess
import numpy as np
import parmed as pmd
ROOT = Path('/mnt/lab/zn/mem-perm/P0_starter_v1')
DEV = ROOT / '07_nmeala_separability_pilot' / '13_joint_correction_development'
EXE = DEV / '07_acquisition_benchmark_execution'
PRE = EXE / '39_budget192_physical_batch06_precommit'
MANIFEST = PRE / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_22_STATES_v1.tsv'
PRE_PROTOCOL = PRE / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_QM_PRECOMMIT_v1.md'
PRE_SUMMARY = PRE / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_PRECOMMIT_SUMMARY_v1.md'
PRE_FREEZE = PRE / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_PRECOMMIT_FREEZE_v1.sha256'
PRE_QC = EXE / 'run_qc_budget192_physical_batch06_preexecution_v1.py'
PRE_QC_REPORT = EXE / '39_budget192_physical_batch06_preexec_qc' / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_PREEXECUTION_QC_v1.md'
PRE_QC_FREEZE = EXE / '39_budget192_physical_batch06_preexec_qc' / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_PREEXECUTION_FREEZE_v1.sha256'
PARENT = EXE / '23_budget192_physical_manifest'
NEW142 = PARENT / 'NMEALA_JOINT_BUDGET192_NEW142_QM_MANIFEST_v1.tsv'
PARENT_CLOSE_REPORT = PARENT / 'NMEALA_JOINT_BUDGET192_PHYSICAL_MANIFEST_CLOSURE_QC_v1.md'
PARENT_CLOSE_FREEZE = PARENT / 'NMEALA_JOINT_BUDGET192_PHYSICAL_MANIFEST_CLOSURE_FREEZE_v1.sha256'
VAL = DEV / '03_internal_validation_split' / 'NMEALA_JOINT_144_INTERNAL_VALIDATION_MANIFEST_v1.tsv'
POOL = DEV / '03_internal_validation_split' / 'NMEALA_JOINT_1566_ACQUISITION_POOL_MANIFEST_v1.tsv'
PRMTOP = ROOT / '06_m0_formal_resp' / '03_tleap_topology' / 'nmeala_resp_v1.prmtop'
OUT = EXE / '40_budget192_physical_batch06_qm'
JOBS = OUT / 'jobs'
PROTOCOL = OUT / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_QM_PROTOCOL_v1.md'
RESULTS = OUT / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_R2SCAN_RESULTS_v1.tsv'
ORCADIR = Path('/mnt/lab/zn/software/orca_6_1_1_linux_x86-64_shared_openmpi418_nodmrg')
MPIDIR = Path('/mnt/lab/zn/software/openmpi-4.1.8-local')
ORCA = ORCADIR / 'orca'
MPIRUN = MPIDIR / 'bin' / 'mpirun'
MAX_WORKERS = 2
TORSION_TOL = 0.1
EXPECTED = {MANIFEST: '3bf2ddf73978ce6d2f84f33cefea677b38f3db0eae1301dcb697d92047c6fedc', PRE_PROTOCOL: '4023963a2eaab0e7fd3a1397eead61109938c887ccc27c2d8a6bcb5902869f27', PRE_SUMMARY: '26fa00f806e15dcca58659c360c52665782212052630a43eb7828b5eb96fb2f3', PRE_FREEZE: '5277cea4638e591f10046f288d50e6b05d4d262194138f52bbcedee8227d2d14', PRE_QC: 'd437c510ca06eb5c22c672ccef7809c5d0d0b08fe2601da9e101ff0643d97c0b', PRE_QC_REPORT: '73e3e1cef0998b40913147387b7ddc10c25dca869e6a0a201601541c87c957aa', PRE_QC_FREEZE: '043c7f1e59fc1c40bcc0d46ad19a3ab4923ba9f92e93a4f7042d72436c54be3b', NEW142: '5345195c0f73788dfcbb01f210b9959bc6fec1b975577263f8f91037fa8b29c4', PARENT_CLOSE_REPORT: 'e08d4416a97d73f629df2a43840ab42e547bf6879e69916ce70c07576931991f', PARENT_CLOSE_FREEZE: 'cb1ff135284643b6e04999a406e20823c62529b0bc2198b70b19ce2673ec47a8', POOL: '42a64f2765a624a95a0c4a1e5a8af0cff57ed5b722be2237c4a7ffa98209bf3a', PRMTOP: '9b2c68fad482b03562a4b9c956dc57586bfc73384bb3a68b019e866c1275f5e6', VAL: 'f93fc7c2b2348f1629ad41a9327d66618f90d46b31520062eed20bdf876f7f66'}

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as fh:
        for block in iter(lambda: fh.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def load(path):
    with Path(path).open('r', encoding='utf-8', newline='') as fh:
        return list(csv.DictReader(fh, delimiter='\t'))

def resolve_input_path(value):
    path = Path(str(value))
    if path.is_absolute():
        return path
    return ROOT / path

def read_xyz(path):
    lines = Path(path).read_text(encoding='utf-8').splitlines()
    n = int(lines[0])
    symbols = []
    xyz = []
    for line in lines[2:2 + n]:
        fields = line.split()
        symbols.append(fields[0])
        xyz.append([float(fields[1]), float(fields[2]), float(fields[3])])
    if len(symbols) != n:
        raise RuntimeError(f'truncated XYZ: {path}')
    return (symbols, np.asarray(xyz, dtype=float))

def dih(xyz, i, j, k, l):
    p0 = xyz[i]
    p1 = xyz[j]
    p2 = xyz[k]
    p3 = xyz[l]
    b0 = p0 - p1
    b1 = p2 - p1
    b2 = p3 - p2
    b1_norm = np.linalg.norm(b1)
    if b1_norm < 1e-12:
        raise RuntimeError('zero central dihedral bond')
    b1 = b1 / b1_norm
    v = b0 - np.dot(b0, b1) * b1
    w = b2 - np.dot(b2, b1) * b1
    nv = np.linalg.norm(v)
    nw = np.linalg.norm(w)
    if nv < 1e-12 or nw < 1e-12:
        raise RuntimeError('degenerate dihedral geometry')
    v = v / nv
    w = w / nw
    xx = np.clip(np.dot(v, w), -1.0, 1.0)
    yy = np.dot(np.cross(b1, v), w)
    return math.degrees(math.atan2(yy, xx))

def periodic_error(value, target):
    return abs((value - target + 180.0) % 360.0 - 180.0)

def chirality(xyz):
    ca = xyz[5]
    return float(np.dot(np.cross(xyz[3] - ca, xyz[7] - ca), xyz[6] - ca))
print('===== B192 COMPARATOR PHYSICAL BATCH06 FRESH QM =====')
print('CONDA_DEFAULT_ENV =', os.environ.get('CONDA_DEFAULT_ENV'))
print('PYTHONPATH =', os.environ.get('PYTHONPATH'))
if os.environ.get('CONDA_DEFAULT_ENV') != 'nme-torsion-p0':
    raise SystemExit('[FAIL] wrong environment')
if os.environ.get('PYTHONPATH') is not None:
    raise SystemExit('[FAIL] PYTHONPATH must be unset')
print('===== 1. VERIFY FROZEN B192 PHYSICAL BATCH06 PROVENANCE =====')
for path, expected in EXPECTED.items():
    if not path.is_file():
        raise SystemExit('[FAIL] missing frozen artifact: ' + str(path))
    actual = sha(path)
    print(path.name)
    print(' expected =', expected)
    print(' actual   =', actual)
    if actual != expected:
        raise SystemExit('[FAIL] frozen artifact SHA mismatch: ' + path.name)
if not ORCA.is_file():
    raise SystemExit('[FAIL] ORCA executable missing: ' + str(ORCA))
if not MPIRUN.is_file():
    raise SystemExit('[FAIL] OpenMPI mpirun missing: ' + str(MPIRUN))
print('ORCA executable =', ORCA)
print('ORCA executable SHA256 =', sha(ORCA))
print('mpirun executable =', MPIRUN)
print('mpirun SHA256 =', sha(MPIRUN))
print('[PASS] exact frozen B192 physical Batch06 provenance verified')
print('===== 2. OUTPUT SAFETY CHECK =====')
if OUT.exists():
    raise SystemExit('[FAIL] QM output directory already exists: ' + str(OUT))
JOBS.mkdir(parents=True)
print('[PASS] clean B192 comparator physical Batch06 QM directory created')
print('===== 3. FREEZE FORMAL QM EXECUTION PROTOCOL BEFORE RESULTS =====')
protocol_text = f'# NMe-Ala budget-192 comparator physical Batch06 fresh QM protocol v1\n\nSTATUS:\nFROZEN AFTER PHYSICAL-BATCH06 PRE-EXECUTION CLOSURE\nAND BEFORE QM RESULTS.\n\nStates:\nexact 22 states from the frozen B192 physical Batch06 manifest.\n\nPhysical compute ranks:\n121 through 142.\n\nPhysical ordering does not alter Maximin or Random\nlogical arm rank or label availability.\n\nRunner:\n{Path(__file__).resolve()}\n\nRunner SHA256:\n{sha(Path(__file__))}\n\nORCA executable:\n{ORCA}\n\nORCA executable SHA256:\n{sha(ORCA)}\n\nOpenMPI mpirun:\n{MPIRUN}\n\nOpenMPI mpirun SHA256:\n{sha(MPIRUN)}\n\nFormal topology:\n{PRMTOP}\n\nFormal topology SHA256:\n{sha(PRMTOP)}\n\nSystem:\nNMe-Ala\nAc-N(CH3)-CH(CH3)-C(O)-NHCH3\ncharge 0\nmultiplicity 1\n25 atoms.\n\nQM:\nORCA 6.1.1\nr2SCAN-3c\nTightSCF\nTightOpt\nCPCM(Water)\n\nConstraints, ORCA zero-based:\nomega = 0 1 3 5\nphi   = 1 3 5 7\npsi   = 3 5 7 9\n\nAll remaining coordinates relax.\n\nResources:\n8 ORCA processes per state\nmaxcore 2500 MB per ORCA process\nMaxIter 300\nat most 2 states concurrently.\n\nAcceptance:\nexit code 0;\nnormal ORCA termination;\noptimization converged;\nfinal XYZ and electronic energy present;\nmaximum torsion-target error <= 0.10 degree;\nC-alpha chirality sign preserved;\nmaximum formal bond < 1.90 A;\nminimum nonlocal distance excluding 1-2 and 1-3 >= 0.75 A.\n\nNo state substitution.\n\nA failed state remains failed.\nIt is not replaced by another comparator state.\n\nFresh QM only.\nNo M0.\nNo comparator label generation.\nNo model fitting.\nNo validation label.\nPPII sealed.\nNo production fit.\n'
PROTOCOL.write_text(protocol_text, encoding='utf-8')
print('QM protocol SHA256 =', sha(PROTOCOL))
print('[PASS] formal QM execution protocol frozen before results')
print('===== 4. LOAD EXACT 22 FROZEN PHYSICAL-BATCH06 STATES =====')
rows = load(MANIFEST)
if len(rows) != 22:
    raise SystemExit(f'[FAIL] manifest rows={len(rows)}')
if len({row['state_id'] for row in rows}) != 22:
    raise SystemExit('[FAIL] duplicate Batch06 state IDs')
rows = sorted(rows, key=lambda row: int(row['physical_compute_rank']))
if [int(row['physical_compute_rank']) for row in rows] != list(range(121, 143)):
    raise SystemExit('[FAIL] physical ranks not121..142')
if [int(row['within_compute_batch_rank']) for row in rows] != list(range(1, 23)):
    raise SystemExit('[FAIL] within-batch ranks not1..22')
if {row['physical_compute_batch'] for row in rows} != {'6'}:
    raise SystemExit('[FAIL] physical_compute_batch !=2')
if Counter((row['membership'] for row in rows)) != Counter({'MAXIMIN_ONLY': 12, 'RANDOM_ONLY': 10}):
    raise SystemExit('[FAIL] physical Batch06 membership changed')
val_ids = {row['state_id'] for row in load(VAL)}
for row in rows:
    sid = row['state_id']
    if sid in val_ids:
        raise SystemExit('[FAIL] validation identity leakage: ' + sid)
    if row['physical_action'] != 'NEW_QM_M0_REQUIRED':
        raise SystemExit('[FAIL] Batch06 state is not fresh-QM state: ' + sid)
    if row['existing_label_available'].strip().lower() != 'false':
        raise SystemExit('[FAIL] Batch06 state unexpectedly already labeled: ' + sid)
    source = resolve_input_path(row['start_xyz'])
    if not source.is_file():
        raise SystemExit('[FAIL] start geometry missing: ' + sid)
    if sha(source) != row['start_xyz_sha256']:
        raise SystemExit('[FAIL] start geometry SHA changed: ' + sid)
print('[PASS] exact24 frozen B192 physical Batch06 geometries loaded')
print('[PASS] membership = 11 Random-only + 12 Maximin-only + 1 shared')
print('[PASS] zero validation-state leakage')
print('===== 5. LOAD FORMAL CONNECTIVITY =====')
parm = pmd.load_file(str(PRMTOP))
if len(parm.atoms) != 25 or len(parm.bonds) != 24:
    raise SystemExit('[FAIL] formal topology must contain25 atoms /22 bonds')
bonded = {tuple(sorted((bond.atom1.idx, bond.atom2.idx))) for bond in parm.bonds}
graph = {index: set() for index in range(25)}
for i, j in bonded:
    graph[i].add(j)
    graph[j].add(i)
one_three = set()
for center in range(25):
    neighbors = sorted(graph[center])
    for a in range(len(neighbors)):
        for b in range(a + 1, len(neighbors)):
            one_three.add(tuple(sorted((neighbors[a], neighbors[b]))))
z_to_symbol = {1: 'H', 6: 'C', 7: 'N', 8: 'O'}
formal_symbols = [z_to_symbol[atom.atomic_number] for atom in parm.atoms]
print('[PASS] formal25-atom /22-bond topology loaded')
print('===== 6. GENERATE EXACT 22 ORCA INPUTS =====')
for row in rows:
    sid = row['state_id']
    job_dir = JOBS / sid
    job_dir.mkdir()
    source = resolve_input_path(row['start_xyz'])
    destination = job_dir / 'start.xyz'
    shutil.copy2(source, destination)
    if sha(destination) != row['start_xyz_sha256']:
        raise SystemExit('[FAIL] copied start geometry changed: ' + sid)
    symbols, xyz = read_xyz(destination)
    if len(xyz) != 25:
        raise SystemExit('[FAIL] start XYZ atom count !=25: ' + sid)
    if symbols != formal_symbols:
        raise SystemExit('[FAIL] formal atom-order mismatch: ' + sid)
    phi = float(row['phi_target_deg'])
    psi = float(row['psi_target_deg'])
    omega = float(row['omega_target_deg'])
    (job_dir / 'job.inp').write_text(f'! r2SCAN-3c TightSCF TightOpt CPCM(Water)\n%pal nprocs 8 end\n%maxcore 2500\n%geom\n MaxIter 300\n Constraints\n  {{ D 0 1 3 5 {omega:9.3f} C }}\n  {{ D 1 3 5 7 {phi:9.3f} C }}\n  {{ D 3 5 7 9 {psi:9.3f} C }}\n end\nend\n* xyzfile 0 1 start.xyz\n', encoding='utf-8')
print('[PASS] exact24 B192 comparator physical Batch06 ORCA inputs generated')
print('===== 7. RUN 22 FRESH COMPARATOR QM OPTIMIZATIONS =====')
environment = os.environ.copy()
environment['PATH'] = f"{ORCADIR}:{MPIDIR / 'bin'}:" + environment.get('PATH', '')
environment['LD_LIBRARY_PATH'] = f"{ORCADIR}:{MPIDIR / 'lib'}:" + environment.get('LD_LIBRARY_PATH', '')
for variable in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'BLIS_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    environment[variable] = '1'
environment.pop('DISPLAY', None)
environment.pop('XAUTHORITY', None)
environment.pop('WAYLAND_DISPLAY', None)

def run_one(row):
    sid = row['state_id']
    job_dir = JOBS / sid
    with (job_dir / 'job.out').open('w', encoding='utf-8') as output:
        process = subprocess.run([str(ORCA), 'job.inp'], cwd=job_dir, stdout=output, stderr=subprocess.STDOUT, env=environment, check=False)
    (job_dir / 'exitcode.txt').write_text(str(process.returncode) + '\n', encoding='utf-8')
    return (sid, process.returncode)
completed = 0
with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
    futures = {executor.submit(run_one, row): row['state_id'] for row in rows}
    for future in as_completed(futures):
        sid = futures[future]
        try:
            _, return_code = future.result()
            tag = 'EXIT0' if return_code == 0 else f'EXIT{return_code}'
        except Exception as exc:
            tag = 'EXCEPTION:' + repr(exc)
        completed += 1
        print(f'[PROGRESS] {completed:2d}/22 {sid} {tag}')
print('===== 8. FINAL B192 COMPARATOR PHYSICAL BATCH06 QM QC =====')
result = []
for row in rows:
    sid = row['state_id']
    job_dir = JOBS / sid
    output_path = job_dir / 'job.out'
    final_xyz_path = job_dir / 'job.xyz'
    start_xyz_path = job_dir / 'start.xyz'
    exitcode_path = job_dir / 'exitcode.txt'
    text = output_path.read_text(encoding='utf-8', errors='ignore') if output_path.exists() else ''
    exitcode = exitcode_path.read_text(encoding='utf-8').strip() if exitcode_path.exists() else 'MISSING'
    normal = 'ORCA TERMINATED NORMALLY' in text.upper()
    converged = 'THE OPTIMIZATION HAS CONVERGED' in text.upper()
    energy_hits = re.findall('FINAL SINGLE POINT ENERGY\\s+(-?\\d+\\.\\d+)', text)
    energy = energy_hits[-1] if energy_hits else ''
    reasons = []
    phi = None
    psi = None
    omega = None
    max_error = None
    start_chirality = None
    final_chirality = None
    max_bond = None
    min_nonlocal = None
    chirality_ok = False
    if final_xyz_path.exists() and start_xyz_path.exists():
        symbols, final_xyz = read_xyz(final_xyz_path)
        start_symbols, start_xyz = read_xyz(start_xyz_path)
        if symbols != start_symbols or symbols != formal_symbols:
            reasons.append('ATOM_ORDER_MISMATCH')
        if len(final_xyz) == 25 and len(start_xyz) == 25:
            omega = dih(final_xyz, 0, 1, 3, 5)
            phi = dih(final_xyz, 1, 3, 5, 7)
            psi = dih(final_xyz, 3, 5, 7, 9)
            max_error = max(periodic_error(omega, float(row['omega_target_deg'])), periodic_error(phi, float(row['phi_target_deg'])), periodic_error(psi, float(row['psi_target_deg'])))
            start_chirality = chirality(start_xyz)
            final_chirality = chirality(final_xyz)
            chirality_ok = abs(start_chirality) > 1e-06 and abs(final_chirality) > 1e-06 and (start_chirality * final_chirality > 0)
            max_bond = max((float(np.linalg.norm(final_xyz[i] - final_xyz[j])) for i, j in bonded))
            nonlocal_distances = []
            for i in range(25):
                for j in range(i + 1, 25):
                    pair = (i, j)
                    if pair in bonded:
                        continue
                    if pair in one_three:
                        continue
                    nonlocal_distances.append(float(np.linalg.norm(final_xyz[i] - final_xyz[j])))
            min_nonlocal = min(nonlocal_distances)
    if exitcode != '0':
        reasons.append('NONZERO_EXIT')
    if not normal:
        reasons.append('NO_NORMAL_TERMINATION')
    if not converged:
        reasons.append('OPT_NOT_CONVERGED')
    if not final_xyz_path.exists():
        reasons.append('NO_FINAL_XYZ')
    if not energy:
        reasons.append('NO_FINAL_ENERGY')
    if max_error is None or max_error > TORSION_TOL:
        reasons.append('TORSION_GATE')
    if not chirality_ok:
        reasons.append('CHIRALITY_NOT_PRESERVED')
    if max_bond is None or max_bond >= 1.9:
        reasons.append('FORMAL_BOND_GATE')
    if min_nonlocal is None or min_nonlocal < 0.75:
        reasons.append('NONLOCAL_GATE')
    status = 'PASS' if not reasons else 'HOLD'
    result.append({'physical_compute_rank': row['physical_compute_rank'], 'within_compute_batch_rank': row['within_compute_batch_rank'], 'state_id': sid, 'membership': row['membership'], 'maximin_rank': row['maximin_rank'], 'random_rank': row['random_rank'], 'phi_target_deg': row['phi_target_deg'], 'psi_target_deg': row['psi_target_deg'], 'omega_target_deg': row['omega_target_deg'], 'start_xyz': str(start_xyz_path), 'start_xyz_sha256': sha(start_xyz_path), 'exitcode': exitcode, 'normal_termination': str(normal), 'optimization_converged': str(converged), 'final_energy_Eh': energy, 'final_phi_deg': '' if phi is None else f'{phi:+.8f}', 'final_psi_deg': '' if psi is None else f'{psi:+.8f}', 'final_omega_deg': '' if omega is None else f'{omega:+.8f}', 'max_constraint_error_deg': '' if max_error is None else f'{max_error:.8f}', 'chirality_sign_preserved': str(chirality_ok), 'max_formal_bond_A': '' if max_bond is None else f'{max_bond:.8f}', 'min_final_nonlocal_A': '' if min_nonlocal is None else f'{min_nonlocal:.8f}', 'final_xyz': str(final_xyz_path) if final_xyz_path.exists() else '', 'final_xyz_sha256': sha(final_xyz_path) if final_xyz_path.exists() else '', 'status': status, 'failure_reason': ','.join(reasons)})
with RESULTS.open('w', encoding='utf-8', newline='') as fh:
    writer = csv.DictWriter(fh, fieldnames=list(result[0]), delimiter='\t', lineterminator='\n')
    writer.writeheader()
    writer.writerows(result)
print('rank\tstate\tmembership\tstatus\tenergy_Eh\tphi\tpsi\tomega\tmaxerr\tchirality\tmaxbond\tmin_nonlocal')
for row in result:
    print(f"{row['physical_compute_rank']}\t{row['state_id']}\t{row['membership']}\t{row['status']}\t{row['final_energy_Eh'] or 'NA'}\t{row['final_phi_deg'] or 'NA'}\t{row['final_psi_deg'] or 'NA'}\t{row['final_omega_deg'] or 'NA'}\t{row['max_constraint_error_deg'] or 'NA'}\t{row['chirality_sign_preserved']}\t{row['max_formal_bond_A'] or 'NA'}\t{row['min_final_nonlocal_A'] or 'NA'}")
    if row['failure_reason']:
        print('  FAILURE:', row['failure_reason'])
counts = Counter((row['status'] for row in result))
npass = counts.get('PASS', 0)
passed = [row for row in result if row['status'] == 'PASS']
print('===== 9. FINAL RESULT =====')
print('status counts =', dict(counts))
print(f"[{('PASS' if npass == 22 else 'HOLD')}] accepted comparator B192 physical Batch06 QM = {npass}/22")
if passed:
    print('maximum accepted constraint error =', max((float(row['max_constraint_error_deg']) for row in passed)), 'deg')
    print('maximum accepted formal bond =', max((float(row['max_formal_bond_A']) for row in passed)), 'A')
    print('minimum accepted final nonlocal distance =', min((float(row['min_final_nonlocal_A']) for row in passed)), 'A')
print('results =', RESULTS)
print('results SHA256 =', sha(RESULTS))
print('QM protocol SHA256 =', sha(PROTOCOL))
print('[PASS] physical Batch06 identities were not changed')
print('[PASS] logical Maximin/Random ranks retained')
print('[PASS] no state substitution')
print('[PASS] no M0 calculation performed')
print('[PASS] no comparator model fitting performed')
print('[PASS] no validation label opened')
print('[PASS] PPII remained sealed')
print('[PASS] no production fitting')
if npass != 22:
    print('[HOLD] one or more formal QM states failed acceptance')
    print('[HOLD] preserve the complete Batch06 QM output tree')
    print('[HOLD] do not rerun this formal runner')
    raise SystemExit(2)
print('===== B192 COMPARATOR PHYSICAL BATCH06 FRESH QM STAGE COMPLETE =====')
