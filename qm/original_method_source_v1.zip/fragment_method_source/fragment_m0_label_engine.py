from pathlib import Path
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import csv
import hashlib
import math
import os
import re
import subprocess
import numpy as np
import parmed as pmd
ROOT = Path('/mnt/lab/zn/mem-perm/P0_starter_v1')
DEV = ROOT / '07_nmeala_separability_pilot' / '13_joint_correction_development'
EXE = DEV / '07_acquisition_benchmark_execution'
PRE = EXE / '39_budget192_physical_batch06_precommit'
MANIFEST = PRE / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_22_STATES_v1.tsv'
QM = EXE / '40_budget192_physical_batch06_qm'
QM_RESULTS = QM / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_R2SCAN_RESULTS_v1.tsv'
QM_PROTOCOL = QM / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_QM_PROTOCOL_v1.md'
QM_POST_QC = QM / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_POST_QM_QC_v1.md'
QM_RAW_INVENTORY = QM / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_RAW_OUTPUT_INVENTORY_v1.tsv'
QM_CLOSURE_FREEZE = QM / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_QM_CLOSURE_FREEZE_v1.sha256'
QM_POST_QC_SCRIPT = EXE / 'run_qc_budget192_physical_batch06_qm_postexec_v1.py'
QM_RUNNER = EXE / 'run_budget192_physical_batch06_qm_v1.py'
QM_WRAPPER = EXE / 'run_execute_budget192_physical_batch06_qm_v1.py'
PARENT = EXE / '23_budget192_physical_manifest'
NEW142 = PARENT / 'NMEALA_JOINT_BUDGET192_NEW142_QM_MANIFEST_v1.tsv'
PARSER = DEV / '06_gp_active_learning' / '04_batch01_label_acceptance' / 'NMEALA_JOINT_GP_BATCH01_M0_PARSER_QC_AMENDMENT_v1.md'
VAL = DEV / '03_internal_validation_split' / 'NMEALA_JOINT_144_INTERNAL_VALIDATION_MANIFEST_v1.tsv'
PRMTOP = ROOT / '06_m0_formal_resp' / '03_tleap_topology' / 'nmeala_resp_v1.prmtop'
PMEMD = Path('/home/dlab/software/pmemd24/bin/pmemd')
OUT = EXE / '41_budget192_physical_batch06_m0_labels'
RUNS = OUT / 'runs'
MDIN = OUT / 'budget192_physical_batch06_same_geometry_zero_step_v1.in'
PROTOCOL = OUT / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_M0_PROTOCOL_v1.md'
M0_RESULTS = OUT / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_ACCEPTED_M0_RESULTS_v1.tsv'
LABELS = OUT / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_22_LABELS_v1.tsv'
SUMMARY = OUT / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_LABEL_SUMMARY_v1.md'
FREEZE = OUT / 'NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_LABEL_GENERATION_FREEZE_v1.sha256'
EXPECTED = {MANIFEST: '3bf2ddf73978ce6d2f84f33cefea677b38f3db0eae1301dcb697d92047c6fedc', QM_RESULTS: 'a8f33ebd83b93237ed7fcf32c5ce39f2b36fb1bc02e4b1134a40a7d968664614', QM_PROTOCOL: '0f4adf7d1796fb198a221513cfe2591fd6280f02843fba419d4a884da9822310', QM_POST_QC: 'dba0391589890348cf094f3295ba71893ba2010526060c2f7df96dec03d43d94', QM_RAW_INVENTORY: '4e856c46541cfcee6c82842cf8c354e0c8646734f29df49a6b34d76e4564a5c6', QM_CLOSURE_FREEZE: '0d9350ae3ab7bd0ca4ac5f2bd7ab4468bc61d3a61477a675b6457c7dc588cd9c', QM_POST_QC_SCRIPT: '52260ad2d13547a4fc1b466645ea9c3f9aedf066843507828511e7d2859496a3', QM_RUNNER: '86af3b80892a4b5643a416f607cdbe3b294b48b09288314a04eb541e9a7ee73e', QM_WRAPPER: 'a61553ca62a5ab17391d836be1a8c0781bb20837bc4085b42683c888745e571f', NEW142: '5345195c0f73788dfcbb01f210b9959bc6fec1b975577263f8f91037fa8b29c4', PARSER: '70a9e747c6f2eef62d0ddcbff44362af45cebcdb28bd56f16a009888d5f73c63', VAL: 'f93fc7c2b2348f1629ad41a9327d66618f90d46b31520062eed20bdf876f7f66', PRMTOP: '9b2c68fad482b03562a4b9c956dc57586bfc73384bb3a68b019e866c1275f5e6', PMEMD: 'd86788a7e398f704c0a3f7e8c752a25ca3a7a56bd19cb602dfa8b80f790d1193'}
H2K = 627.509474
SER_TOL = 1e-06
MAX_WORKERS = 4
COMPONENTS = ['BOND', 'ANGLE', 'DIHED', 'VDWAALS', 'EEL', 'HBOND', '1-4 VDW', '1-4 EEL', 'RESTRAINT']

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as fh:
        for block in iter(lambda: fh.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def load(path):
    with Path(path).open('r', encoding='utf-8', newline='') as fh:
        return list(csv.DictReader(fh, delimiter='\t'))

def write_tsv(path, rows):
    if not rows:
        raise RuntimeError('no rows: ' + str(path))
    fields = list(rows[0])
    with Path(path).open('w', encoding='utf-8', newline='') as fh:
        writer = csv.DictWriter(fh, fieldnames=fields, delimiter='\t', lineterminator='\n', extrasaction='raise')
        writer.writeheader()
        writer.writerows(rows)

def read_xyz(path):
    lines = Path(path).read_text(encoding='utf-8').splitlines()
    n = int(lines[0])
    symbols = []
    xyz = []
    for line in lines[2:2 + n]:
        fields = line.split()
        symbols.append(fields[0])
        xyz.append([float(fields[1]), float(fields[2]), float(fields[3])])
    if len(symbols) != n:
        raise RuntimeError('truncated XYZ: ' + str(path))
    arr = np.asarray(xyz, dtype=float)
    if not np.isfinite(arr).all():
        raise RuntimeError('nonfinite XYZ: ' + str(path))
    return (symbols, arr)

def write_rst7(path, xyz, title):
    flat = np.asarray(xyz, dtype=float).reshape(-1)
    with Path(path).open('w', encoding='utf-8') as fh:
        fh.write(title[:80] + '\n')
        fh.write(f'{len(xyz):6d}{0.0:15.7E}\n')
        for index in range(0, len(flat), 6):
            fh.write(''.join((f'{value:12.7f}' for value in flat[index:index + 6])) + '\n')

def read_rst7(path, natom):
    lines = Path(path).read_text(encoding='utf-8').splitlines()
    if int(lines[1].split()[0]) != natom:
        raise RuntimeError('rst7 atom count mismatch')
    values = []
    for line in lines[2:]:
        for index in range(0, len(line), 12):
            token = line[index:index + 12]
            if token.strip():
                values.append(float(token))
        if len(values) >= 3 * natom:
            break
    if len(values) < 3 * natom:
        raise RuntimeError('short rst7')
    return np.asarray(values[:3 * natom], dtype=float).reshape(natom, 3)

def last_component(text, key):
    number = '([-+]?(?:\\d+\\.\\d*|\\d*\\.\\d+|\\d+)(?:[Ee][-+]?\\d+)?)'
    patterns = {'BOND': f'\\bBOND\\s*=\\s*{number}', 'ANGLE': f'\\bANGLE\\s*=\\s*{number}', 'DIHED': f'\\bDIHED\\s*=\\s*{number}', 'VDWAALS': f'\\bVDWAALS\\s*=\\s*{number}', 'EEL': f'(?<!1-4 )\\bEEL\\s*=\\s*{number}', 'HBOND': f'\\bHBOND\\s*=\\s*{number}', '1-4 VDW': f'1-4\\s+VDW\\s*=\\s*{number}', '1-4 EEL': f'1-4\\s+EEL\\s*=\\s*{number}', 'RESTRAINT': f'\\bRESTRAINT\\s*=\\s*{number}'}
    hits = re.findall(patterns[key], text, re.I)
    if not hits:
        raise RuntimeError('missing ' + key)
    return float(hits[-1])

def nonfinite_audit(text):
    lines = text.splitlines()
    nan_lines = [(index, line) for index, line in enumerate(lines) if re.search('\\bNaN\\b', line, re.I)]
    benign = []
    bad = []
    for index, line in nan_lines:
        previous = lines[index - 1] if index else ''
        allowed = re.match('^\\s*\\|\\s*Direct force subcell size\\s*=\\s*NaN\\s+NaN\\s+NaN\\s*$', line, re.I) and re.search('Coordinate Index Table dimensions:\\s*0\\s+0\\s+0', previous, re.I)
        if allowed:
            benign.append((index + 1, line))
        else:
            bad.append((index + 1, line))
    infinities = re.findall('(?<![A-Za-z])[-+]?Inf(?:inity)?(?![A-Za-z])', text, re.I)
    overflow_stars = re.findall('=\\s*\\*{5,}', text)
    return (nan_lines, benign, bad, infinities, overflow_stars)
print('===== B192 COMPARATOR PHYSICAL BATCH06 SAME-GEOMETRY M0 / LABEL STAGE =====')
print('CONDA_DEFAULT_ENV =', os.environ.get('CONDA_DEFAULT_ENV'))
print('PYTHONPATH =', os.environ.get('PYTHONPATH'))
if os.environ.get('CONDA_DEFAULT_ENV') != 'nme-torsion-p0':
    raise SystemExit('[FAIL] wrong environment')
if os.environ.get('PYTHONPATH') is not None:
    raise SystemExit('[FAIL] PYTHONPATH must be unset')
print('===== 1. VERIFY CLOSED QM / FORMAL M0 AUTHORITIES =====')
for path, expected in EXPECTED.items():
    if not path.is_file():
        raise SystemExit('[FAIL] required authority missing: ' + str(path))
    actual = sha(path)
    print(path.name)
    print(' expected =', expected)
    print(' actual   =', actual)
    if actual != expected:
        raise SystemExit('[FAIL] authority SHA mismatch: ' + path.name)
print('[PASS] scientifically CLOSED QM and formal M0 authorities exact')
print('===== 2. OUTPUT SAFETY CHECK =====')
if OUT.exists():
    raise SystemExit('[FAIL] M0/label output already exists: ' + str(OUT))
RUNS.mkdir(parents=True)
print('[PASS] clean B192 comparator Batch06 M0/label directory created')
print('===== 3. FREEZE SAME-GEOMETRY ZERO-STEP M0 PROTOCOL =====')
MDIN.write_text('B192 comparator physical Batch06 exact same-geometry M0 zero-step\n &cntrl\n  imin=1,\n  maxcyc=0,\n  ncyc=0,\n  ntmin=0,\n  ntb=0,\n  igb=0,\n  cut=999.0,\n  ntpr=1,\n  ntxo=2,\n /\n', encoding='utf-8')
PROTOCOL.write_text('# NMe-Ala budget-192 comparator physical Batch06 same-geometry M0 protocol v1\n\nSTATUS:\nFROZEN AFTER SCIENTIFIC CLOSURE OF 24/24 FRESH QM.\nFROZEN BEFORE B192 BATCH06 M0 RESULTS.\n\nExactly the 24 accepted final QM geometries from\nB192 comparator physical Batch06 are used.\n\nNo state substitution.\nNo QM rerun.\nNo MM geometry optimization.\n\nFormal baseline:\nfrozen NMe-Ala GAFF2 + RESP prmtop.\n\nPMEMD:\nfrozen /home/dlab/software/pmemd24/bin/pmemd binary.\n\nZero-step protocol:\nimin=1\nmaxcyc=0\nncyc=0\nntmin=0\nntb=0\nigb=0\ncut=999.0\nntpr=1\nntxo=2\n\nQM final job.xyz is serialized directly into AMBER\nrestart coordinates.\n\nMaximum allowed QM-to-AMBER serialization deviation:\n1e-6 A.\n\nFrozen benign zero-step NaN exception:\nonly\nDirect force subcell size = NaN NaN NaN\nimmediately preceded by\nCoordinate Index Table dimensions: 0 0 0\nis permitted.\n\nAll other NaN, Inf/Infinity, or overflow-star\nassignments fail.\n\nAuthoritative M0:\nsum of the nine printed PMEMD components:\nBOND\nANGLE\nDIHED\nVDWAALS\nEEL\nHBOND\n1-4 VDW\n1-4 EEL\nRESTRAINT\n\nOrdinary EEL parsing explicitly excludes 1-4 EEL.\n\nRESTRAINT must be numerically zero within 1e-8 kcal/mol.\n\nResidual label:\nR = E_QM * 627.509474 - E_M0_component_sum.\n\nPrecision convention:\nPMEMD_PRINTED_NINE_COMPONENT_SUM.\n\nLogical Maximin and Random ranks are retained unchanged.\nPhysical computation does not change logical arm availability.\n\nCurrent B192 fresh physical universe:\n142 states.\n\nAfter successful Batch06:\n72 fresh physical labels completed;\n70 fresh physical labels remain.\n\nNo comparator model fitting.\nNo evaluator fitting.\nNo validation label.\nPPII sealed.\nNo production fit.\n', encoding='utf-8')
print('mdin SHA256 =', sha(MDIN))
print('M0 protocol SHA256 =', sha(PROTOCOL))
print('[PASS] zero-step same-geometry M0 protocol materialized before results')
print('===== 4. LOAD / SERIALIZE EXACT24 ACCEPTED QM FINAL GEOMETRIES =====')
qm_rows = load(QM_RESULTS)
manifest = load(MANIFEST)
if len(qm_rows) != 22 or len(manifest) != 22:
    raise SystemExit('[FAIL] QM/manifest row counts are not22/22')
if any((row['status'] != 'PASS' for row in qm_rows)):
    raise SystemExit('[FAIL] CLOSED Batch06 QM contains non-PASS row')
if {row['state_id'] for row in qm_rows} != {row['state_id'] for row in manifest}:
    raise SystemExit('[FAIL] QM/manifest identity mismatch')
if [int(row['physical_compute_rank']) for row in manifest] != list(range(121, 143)):
    raise SystemExit('[FAIL] Batch06 physical ranks !=121..142')
if [int(row['within_compute_batch_rank']) for row in manifest] != list(range(1, 23)):
    raise SystemExit('[FAIL] Batch06 within-batch ranks !=1..22')
if {row['physical_compute_batch'] for row in manifest} != {'6'}:
    raise SystemExit('[FAIL] Batch06 physical_compute_batch !=2')
if Counter((row['membership'] for row in manifest)) != Counter({'MAXIMIN_ONLY': 12, 'RANDOM_ONLY': 10}):
    raise SystemExit('[FAIL] Batch06 membership changed')
Q = {row['state_id']: row for row in qm_rows}
parm = pmd.load_file(str(PRMTOP))
if len(parm.atoms) != 25 or len(parm.bonds) != 24:
    raise SystemExit('[FAIL] formal topology !=25 atoms/24 bonds')
z_to_symbol = {1: 'H', 6: 'C', 7: 'N', 8: 'O'}
formal_symbols = [z_to_symbol[atom.atomic_number] for atom in parm.atoms]
prepared = []
for manifest_row in sorted(manifest, key=lambda row: int(row['physical_compute_rank'])):
    sid = manifest_row['state_id']
    qm_row = Q[sid]
    if qm_row['membership'] != manifest_row['membership']:
        raise SystemExit('[FAIL] membership changed: ' + sid)
    if qm_row['maximin_rank'] != manifest_row['maximin_rank']:
        raise SystemExit('[FAIL] Maximin rank changed: ' + sid)
    if qm_row['random_rank'] != manifest_row['random_rank']:
        raise SystemExit('[FAIL] Random rank changed: ' + sid)
    source_xyz = Path(qm_row['final_xyz'])
    if not source_xyz.is_file():
        raise SystemExit('[FAIL] accepted final QM geometry missing: ' + sid)
    if sha(source_xyz) != qm_row['final_xyz_sha256']:
        raise SystemExit('[FAIL] accepted final QM geometry SHA changed: ' + sid)
    symbols, xyz = read_xyz(source_xyz)
    if symbols != formal_symbols:
        raise SystemExit('[FAIL] QM/prmtop atom ordering mismatch: ' + sid)
    run_dir = RUNS / sid
    run_dir.mkdir()
    amber_coordinate = run_dir / 'exact_qm.rst7'
    write_rst7(amber_coordinate, xyz, 'NMe-Ala B192 comparator physical Batch06 ' + sid)
    roundtrip = read_rst7(amber_coordinate, 25)
    serialization_delta = float(np.max(np.linalg.norm(roundtrip - xyz, axis=1)))
    print(f'{sid}\tserialization_delta={serialization_delta:.12e} A')
    if serialization_delta > SER_TOL:
        raise SystemExit('[FAIL] QM-to-AMBER serialization gate: ' + sid)
    prepared.append({'physical_compute_rank': int(manifest_row['physical_compute_rank']), 'within_compute_batch_rank': int(manifest_row['within_compute_batch_rank']), 'state_id': sid, 'membership': manifest_row['membership'], 'maximin_rank': manifest_row['maximin_rank'], 'random_rank': manifest_row['random_rank'], 'phi_target_deg': manifest_row['phi_target_deg'], 'psi_target_deg': manifest_row['psi_target_deg'], 'omega_target_deg': manifest_row['omega_target_deg'], 'qm_energy_Eh': float(qm_row['final_energy_Eh']), 'qm_xyz': source_xyz, 'qm_xyz_sha256': qm_row['final_xyz_sha256'], 'amber_coordinate': amber_coordinate, 'amber_coordinate_sha256': sha(amber_coordinate), 'serialization_delta': serialization_delta})
print('[PASS] exact22 accepted QM final geometries serialized within1e-6 A')
print('===== 5. RUN EXACT24 ZERO-STEP PMEMD M0 EVALUATIONS =====')
environment = os.environ.copy()
for variable in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'BLIS_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    environment[variable] = '1'
environment.pop('DISPLAY', None)
environment.pop('XAUTHORITY', None)
environment.pop('WAYLAND_DISPLAY', None)

def run_one(item):
    run_dir = RUNS / item['state_id']
    output = run_dir / 'm0.out'
    with (run_dir / 'pmemd_stdout.txt').open('w', encoding='utf-8') as stdout:
        process = subprocess.run([str(PMEMD), '-O', '-i', str(MDIN), '-o', str(output), '-p', str(PRMTOP), '-c', str(item['amber_coordinate']), '-r', str(run_dir / 'restrt'), '-inf', str(run_dir / 'mdinfo')], cwd=run_dir, stdout=stdout, stderr=subprocess.STDOUT, env=environment, check=False)
    (run_dir / 'exitcode.txt').write_text(str(process.returncode) + '\n', encoding='utf-8')
    return (item['state_id'], process.returncode)
completed = 0
with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
    futures = {executor.submit(run_one, item): item['state_id'] for item in prepared}
    for future in as_completed(futures):
        sid = futures[future]
        try:
            _, returncode = future.result()
            tag = 'EXIT0' if returncode == 0 else f'EXIT{returncode}'
        except Exception as exc:
            tag = 'EXCEPTION:' + repr(exc)
        completed += 1
        print(f'[PROGRESS] {completed:2d}/24 {sid} {tag}')
print('===== 6. PARSE / QC / GENERATE B192 PHYSICAL BATCH06 LABELS =====')
m0_rows = []
labels = []
for item in sorted(prepared, key=lambda row: row['physical_compute_rank']):
    sid = item['state_id']
    run_dir = RUNS / sid
    output = run_dir / 'm0.out'
    exitcode_file = run_dir / 'exitcode.txt'
    reasons = []
    exitcode = exitcode_file.read_text(encoding='utf-8').strip() if exitcode_file.exists() else 'MISSING'
    if exitcode != '0':
        reasons.append('NONZERO_EXIT')
    text = output.read_text(encoding='utf-8', errors='ignore') if output.exists() else ''
    if not text:
        reasons.append('NO_M0_OUTPUT')
    components = {}
    total = None
    benign_count = 0
    unexpected_count = 0
    if text:
        nan_lines, benign, bad_nan, infinities, overflow_stars = nonfinite_audit(text)
        benign_count = len(benign)
        unexpected_count = len(bad_nan) + len(infinities) + len(overflow_stars)
        if len(nan_lines) != 1 or benign_count != 1:
            reasons.append('BENIGN_NAN_NOT_UNIQUE')
        if bad_nan:
            reasons.append('UNEXPECTED_NAN')
        if infinities:
            reasons.append('INF_INFINITY')
        if overflow_stars:
            reasons.append('OVERFLOW_STARS')
        try:
            components = {component: last_component(text, component) for component in COMPONENTS}
        except Exception as exc:
            reasons.append('COMPONENT_PARSE:' + str(exc))
        if len(components) == 9:
            if not all((math.isfinite(value) for value in components.values())):
                reasons.append('NONFINITE_COMPONENT')
            else:
                total = float(sum((components[component] for component in COMPONENTS)))
                if not math.isfinite(total):
                    reasons.append('NONFINITE_TOTAL')
                if abs(components['RESTRAINT']) > 1e-08:
                    reasons.append('NONZERO_RESTRAINT')
    status = 'PASS' if not reasons else 'HOLD'
    residual = item['qm_energy_Eh'] * H2K - total if status == 'PASS' and total is not None else None
    row = {'physical_compute_rank': item['physical_compute_rank'], 'within_compute_batch_rank': item['within_compute_batch_rank'], 'state_id': sid, 'membership': item['membership'], 'maximin_rank': item['maximin_rank'], 'random_rank': item['random_rank'], 'phi_target_deg': item['phi_target_deg'], 'psi_target_deg': item['psi_target_deg'], 'omega_target_deg': item['omega_target_deg'], 'qm_energy_Eh': f"{item['qm_energy_Eh']:.12f}", 'qm_xyz': str(item['qm_xyz']), 'qm_xyz_sha256': item['qm_xyz_sha256'], 'amber_coordinate': str(item['amber_coordinate']), 'amber_coordinate_sha256': item['amber_coordinate_sha256'], 'serialization_max_atom_delta_A': f"{item['serialization_delta']:.12e}", 'm0_total_component_sum_kcal_mol': '' if total is None else f'{total:.4f}', 'absolute_QM_minus_M0_residual_kcal_mol': '' if residual is None else f'{residual:.12f}', 'allowed_zero_step_diagnostic_NaN_count': benign_count, 'unexpected_nonfinite_output_count': unexpected_count, 'pmemd_output': str(output) if output.exists() else '', 'pmemd_output_sha256': sha(output) if output.exists() else '', 'status': status, 'failure_reason': ';'.join(reasons)}
    for component in COMPONENTS:
        row['m0_' + component.replace(' ', '_') + '_kcal_mol'] = '' if component not in components else f'{components[component]:.4f}'
    m0_rows.append(row)
    if status == 'PASS':
        labels.append({'physical_compute_rank': item['physical_compute_rank'], 'within_compute_batch_rank': item['within_compute_batch_rank'], 'state_id': sid, 'membership': item['membership'], 'maximin_rank': item['maximin_rank'], 'random_rank': item['random_rank'], 'phi_deg': item['phi_target_deg'], 'psi_deg': item['psi_target_deg'], 'omega_deg': item['omega_target_deg'], 'QM_energy_Eh': f"{item['qm_energy_Eh']:.12f}", 'M0_energy_component_sum_kcal_mol': f'{total:.4f}', 'absolute_QM_minus_M0_residual_kcal_mol': f'{residual:.12f}', 'QM_xyz_sha256': item['qm_xyz_sha256'], 'M0_coordinate_sha256': item['amber_coordinate_sha256'], 'M0_output_sha256': sha(output), 'label_precision_convention': 'PMEMD_PRINTED_NINE_COMPONENT_SUM', 'label_status': 'ACCEPTED_COMPARATOR_B192_PHYSICAL_BATCH06_LABEL'})
write_tsv(M0_RESULTS, m0_rows)
if labels:
    write_tsv(LABELS, labels)
print('rank\tstate\tmembership\tstatus\tM0\tR\tNaN_allowed\tunexpected')
for row in m0_rows:
    print(f"{row['physical_compute_rank']}\t{row['state_id']}\t{row['membership']}\t{row['status']}\t{row['m0_total_component_sum_kcal_mol'] or 'NA'}\t{row['absolute_QM_minus_M0_residual_kcal_mol'] or 'NA'}\t{row['allowed_zero_step_diagnostic_NaN_count']}\t{row['unexpected_nonfinite_output_count']}")
    if row['failure_reason']:
        print('  FAILURE:', row['failure_reason'])
counts = Counter((row['status'] for row in m0_rows))
npass = counts.get('PASS', 0)
print('status counts =', dict(counts))
print(f"[{('PASS' if npass == 22 else 'HOLD')}] B192 physical Batch06 M0 accepted = {npass}/24")
print('===== 7. LABEL NUMERICAL QC =====')
if npass != 22 or len(labels) != 22:
    print('[HOLD] B192 comparator Batch06 label generation incomplete')
    print('[HOLD] preserve complete M0 output tree')
    print('[HOLD] DO NOT rerun this formal runner')
    raise SystemExit(2)
residuals = np.asarray([float(row['absolute_QM_minus_M0_residual_kcal_mol']) for row in labels], dtype=float)
m0_values = np.asarray([float(row['M0_energy_component_sum_kcal_mol']) for row in labels], dtype=float)
max_serialization = max((float(row['serialization_max_atom_delta_A']) for row in m0_rows))
print('physical Batch06 labels =', len(labels))
print('M0 total range =', f'{m0_values.min():.4f} to {m0_values.max():.4f} kcal/mol')
print('residual range =', f'{residuals.min():.8f} to {residuals.max():.8f} kcal/mol')
print('residual mean =', f'{residuals.mean():.8f} kcal/mol')
print('residual SD =', f'{residuals.std():.8f} kcal/mol')
print('maximum serialization delta =', f'{max_serialization:.12e} A')
print('allowed diagnostic NaN count-set =', {int(row['allowed_zero_step_diagnostic_NaN_count']) for row in m0_rows})
print('unexpected nonfinite count-set =', {int(row['unexpected_nonfinite_output_count']) for row in m0_rows})
print('[PASS] 22/22 B192 comparator physical Batch06 labels accepted')
print('===== 8. WRITE SUMMARY / DATA-GENERATION FREEZE =====')
membership = Counter((row['membership'] for row in labels))
SUMMARY.write_text(f"# NMe-Ala budget-192 comparator physical Batch06 label summary v1\n\nSTATUS:\nPHYSICAL BATCH06 DATA GENERATION COMPLETE.\nINDEPENDENT POST-M0 CLOSURE QC REQUIRED.\n\nPhysical compute ranks:\n49 through 72.\n\nFresh QM accepted:\n24.\n\nSame-geometry M0 accepted:\n24.\n\nPhysical residual labels accepted:\n24.\n\nMembership:\nMAXIMIN_ONLY = {membership.get('MAXIMIN_ONLY', 0)}\nRANDOM_ONLY = {membership.get('RANDOM_ONLY', 0)}\nMAXIMIN_AND_RANDOM = {membership.get('MAXIMIN_AND_RANDOM', 0)}\n\nAuthoritative M0:\nPMEMD printed nine-component sum.\n\nM0 range:\n{m0_values.min():.4f} to {m0_values.max():.4f} kcal/mol.\n\nResidual range:\n{residuals.min():.8f} to {residuals.max():.8f} kcal/mol.\n\nResidual mean:\n{residuals.mean():.8f} kcal/mol.\n\nResidual SD:\n{residuals.std():.8f} kcal/mol.\n\nMaximum QM-to-AMBER serialization delta:\n{max_serialization:.12e} A.\n\nExpected benign zero-step diagnostic NaN:\nexactly one per output.\n\nUnexpected nonfinite output:\n0.\n\nB192 fresh comparator physical labels completed:\n142 of 142.\n\nRemaining fresh comparator physical labels:\n70.\n\nNo QM rerun was performed.\nNo MM geometry optimization was performed.\nNo comparator model/evaluator fitting was performed.\nNo validation label was opened.\nPPII remained sealed.\nNo production fit was performed.\n\nREQUIRED NEXT:\nindependent same-geometry M0 / residual reconstruction and closure QC.\n", encoding='utf-8')
freeze_paths = [MANIFEST, QM_RESULTS, QM_PROTOCOL, QM_POST_QC, QM_RAW_INVENTORY, QM_CLOSURE_FREEZE, QM_POST_QC_SCRIPT, QM_RUNNER, QM_WRAPPER, NEW142, PARSER, PRMTOP, PMEMD, VAL, MDIN, PROTOCOL, M0_RESULTS, LABELS, SUMMARY, Path(__file__)]
for item in prepared:
    freeze_paths.extend([item['qm_xyz'], item['amber_coordinate']])
for row in m0_rows:
    output = Path(row['pmemd_output'])
    if output.is_file():
        freeze_paths.append(output)
unique = []
seen = set()
for path in freeze_paths:
    path = Path(path).resolve()
    if path in seen:
        continue
    seen.add(path)
    unique.append(path)
for path in unique:
    if not path.is_file():
        raise SystemExit('[FAIL] data-generation freeze member missing: ' + str(path))
FREEZE.write_text('\n'.join((sha(path) + '  ' + str(path) for path in unique)) + '\n', encoding='utf-8')
for path in (MDIN, PROTOCOL, M0_RESULTS, LABELS, SUMMARY):
    print(sha(path), path)
print('data-generation freeze entries =', len(unique))
print('data-generation freeze SHA256 =', sha(FREEZE))
print('===== 9. FINAL FORMAL RESULT =====')
print('[PASS] B192 comparator physical Batch06 same-geometry M0 = 22/22')
print('[PASS] B192 comparator physical Batch06 labels = 22/22')
print('[PASS] within-batch ranks1..22 retained')
print('[PASS] logical Maximin/Random ranks retained')
print('[PASS] one benign zero-step NaN per output only')
print('[PASS] no MM geometry optimization')
print('[PASS] fresh comparator labels completed =142/142')
print('[PASS] no comparator model/evaluator fitting')
print('[PASS] validation/PPII remain SEALED')
print('[HOLD] independent post-M0 closure QC required before B192 evaluator-manifest construction')
print('[AUTHORIZED-NEXT] independent post-M0 reconstruction/QC after formal execution')
print('===== B192 COMPARATOR PHYSICAL BATCH06 M0 / LABEL STAGE COMPLETE =====')
