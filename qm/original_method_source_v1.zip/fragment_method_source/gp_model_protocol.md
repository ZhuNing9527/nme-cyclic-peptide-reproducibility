# NMe-Ala joint periodic-GP numerical implementation precommit v1

## Status

FROZEN AFTER ACQUISITION-BENCHMARK DESIGN

FROZEN BEFORE FIRST GP ACTIVE-LEARNING SELECTION

FROZEN BEFORE ANY NEW VALIDATION OR ACQUISITION QM

## Target

The GP target is the existing same-geometry residual:

R =
E_QM * 627.509474
-
E_M0

in kcal/mol.

The absolute residual contains an arbitrary large
constant associated with the molecular QM reference.

For numerical conditioning, every GP fit subtracts the
arithmetic mean of only that arm's currently labeled
training residuals.

The same mean is added back to posterior mean
predictions.

The acquisition variance is invariant to this constant
mean removal.

No validation information enters the centering mean.

## Angular coordinates

Input order is exactly:

phi

psi

omega.

Angles are stored externally in degrees and converted
internally to radians using numpy.deg2rad.

## Kernel

Anisotropic periodic squared-exponential:

k(x,x')
=
sigma_f^2
*
exp[
-2 * (
sin^2((phi-phi')/2)/ell_phi^2
+
sin^2((psi-psi')/2)/ell_psi^2
+
sin^2((omega-omega')/2)/ell_omega^2
)
].

All kernel angular differences are in radians.

## Hyperparameter bounds

sigma_f:

0.10 to 20.00 kcal/mol.

ell_phi:

0.15 to 3.00.

ell_psi:

0.15 to 3.00.

ell_omega:

0.15 to 3.00.

Optimization is performed in natural-log parameter
space.

## Numerical nugget

Fixed nugget variance:

1.0e-08 kcal^2/mol^2.

It is numerical regularization only.

It is not optimized.

It is not interpreted as experimental or QM noise.

## Deterministic hyperparameter starts

There are exactly 17 length-scale starting triples.

They are frozen in the accompanying TSV.

For every start, sigma_f begins at:

sqrt(mean((R - mean(R))^2))

clipped to the frozen sigma_f bounds.

No random hyperparameter start is permitted.

## Optimizer

scipy.optimize.minimize

method:

L-BFGS-B

Objective:

exact zero-mean GP negative log marginal likelihood
after training-set constant-mean removal.

Options:

maxiter = 1000

maxls = 50

ftol = 1.0e-12

gtol = 1.0e-08

All 17 deterministic starts are attempted.

Only finite successful optimizations are eligible.

The lowest NLL is selected.

If final NLL values differ by no more than:

1.0e-10

the lexicographically smaller final tuple:

sigma_f,
ell_phi,
ell_psi,
ell_omega

is selected.

## Linear algebra

Kernel matrices are factorized using numpy.linalg.cholesky.

Triangular solves use scipy.linalg.solve_triangular.

No explicit matrix inverse is used.

Posterior variances are clipped to zero only when a
negative value arises from floating-point roundoff.

## Joint acquisition variance

For candidate x:

x_T is constructed analytically as:

(phi_x, psi_x, 180 degrees).

The validation manifest is NOT queried to construct
x_T.

If this mathematical trans-reference coordinate happens
to share coordinates with a locked validation state,
no validation identity, geometry, or label is accessed.

The covariance is evaluated only from the GP kernel and
the arm's labeled/fantasy conditioning coordinates.

Therefore validation labels remain completely isolated.

The acquisition quantities are:

Var[R(x)]

and

Var[J(x)]
=
Var[R(x)]
+
Var[R(x_T)]
-
2 Cov[R(x),R(x_T)].

Score:

SD[R(x)]
+
SD[J(x)].

At omega=180 degrees, x=x_T and Var[J] must be zero up
to numerical roundoff.

## Batch fantasy conditioning

Within a 24-state batch, hyperparameters remain fixed.

After a point is selected, only its coordinate is added
to the conditioning set for subsequent variance
calculation.

No invented residual value is created.

The fantasy point therefore changes posterior
covariance but not the fitted posterior mean.

## Batch tie handling

Acquisition scores differing by <=
1.0e-12
are treated as tied.

For tied scores:

larger minimum periodic angular distance to the current
labeled-plus-selected coordinate set wins.

Distances differing by <=
1.0e-10
degree are treated as tied.

Final tie:

lexicographically smaller state ID.

## Seed-only implementation test

This precommit is permitted to fit the GP to the already
available 54 identifiability QM/M0 seed labels.

This is a numerical implementation diagnostic only.

It does NOT score the 1566 acquisition candidates.

It does NOT select any acquisition point.

It does NOT open any validation label.

## Reproducibility

The implementation source code itself is frozen and
SHA256 hashed before the first acquisition selection.

Python, NumPy, and SciPy versions are recorded in the
self-test artifact.

## Current boundary

No acquisition-pool state is scored in this step.

No GP active-learning state is selected.

No validation QM is run.

No acquisition QM is run.

No PPII information is accessed.

No production Fourier or spline model is fitted.
