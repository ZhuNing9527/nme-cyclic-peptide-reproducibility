from pathlib import Path
from collections import Counter

import ast
import csv
import hashlib
import math
import os


ROOT = Path(
    "/mnt/lab/zn/mem-perm/P0_starter_v1"
)

DEV = (
    ROOT
    / "07_nmeala_separability_pilot"
    / "13_joint_correction_development"
)

EXE = (
    DEV
    / "07_acquisition_benchmark_execution"
)


# ----------------------------------------------------------------------
# CLOSED pre-label prediction authority
# ----------------------------------------------------------------------

PRED = (
    EXE
    / "44_budget192_prelabel_evaluator_predictions"
)

PRED_FORMAL_FREEZE = (
    PRED
    / "NMEALA_JOINT_BUDGET192_PRELABEL_PREDICTION_FREEZE_v1.sha256"
)

PRED_CLOSE_REPORT = (
    PRED
    / "NMEALA_JOINT_BUDGET192_PRELABEL_PREDICTION_CLOSURE_QC_v1.md"
)

PRED_CLOSE_FREEZE = (
    PRED
    / "NMEALA_JOINT_BUDGET192_PRELABEL_PREDICTION_CLOSURE_FREEZE_v1.sha256"
)

PRED_CLOSE_QC = (
    EXE
    / "run_qc_budget192_prelabel_evaluator_postexec_v1.py"
)

FIT_METADATA = (
    PRED
    / "NMEALA_JOINT_BUDGET192_PRELABEL_FIT_METADATA_v1.tsv"
)

PRED_INDEX = (
    PRED
    / "NMEALA_JOINT_BUDGET192_PRELABEL_PREDICTION_INDEX_v1.tsv"
)


# ----------------------------------------------------------------------
# Frozen validation split
# ----------------------------------------------------------------------

SPLIT = (
    DEV
    / "03_internal_validation_split"
)

SPLIT_RULE = (
    SPLIT
    / "NMEALA_JOINT_INTERNAL_VALIDATION_SPLIT_RULE_v1.md"
)

VAL = (
    SPLIT
    / "NMEALA_JOINT_144_INTERNAL_VALIDATION_MANIFEST_v1.tsv"
)

ROLE = (
    SPLIT
    / "NMEALA_JOINT_1728_DATA_ROLE_MANIFEST_v1.tsv"
)

SPLIT_SUMMARY = (
    SPLIT
    / "NMEALA_JOINT_INTERNAL_VALIDATION_SPLIT_SUMMARY_v1.md"
)

SPLIT_FREEZE = (
    SPLIT
    / "NMEALA_JOINT_INTERNAL_VALIDATION_SPLIT_FREEZE_v1.sha256"
)


# ----------------------------------------------------------------------
# Acquisition / evaluation contracts
# ----------------------------------------------------------------------

ACQ = (
    DEV
    / "04_acquisition_benchmark_precommit"
)

ACQ_PROTOCOL = (
    ACQ
    / "NMEALA_JOINT_ACQUISITION_BENCHMARK_PRECOMMIT_v1.md"
)

ACQ_FREEZE = (
    ACQ
    / "NMEALA_JOINT_ACQUISITION_BENCHMARK_PRECOMMIT_FREEZE_v1.sha256"
)


EVAL = (
    DEV
    / "08_acquisition_evaluation_precommit"
)

EVAL_PROTOCOL = (
    EVAL
    / "NMEALA_JOINT_ACQUISITION_EVALUATION_PRECOMMIT_v1.md"
)

EVAL_FREEZE = (
    EVAL
    / "NMEALA_JOINT_ACQUISITION_EVALUATION_PRECOMMIT_FREEZE_v1.sha256"
)


# ----------------------------------------------------------------------
# CLOSED formal acquisition-QM scientific implementation authority
# ----------------------------------------------------------------------

SOURCE_QM_RUNNER = (
    EXE
    / "run_budget192_physical_batch06_qm_v1.py"
)

SOURCE_QM_POST_QC_SCRIPT = (
    EXE
    / "run_qc_budget192_physical_batch06_qm_postexec_v1.py"
)

SOURCE_QM = (
    EXE
    / "40_budget192_physical_batch06_qm"
)

SOURCE_QM_PROTOCOL = (
    SOURCE_QM
    / "NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_QM_PROTOCOL_v1.md"
)

SOURCE_QM_POST_QC = (
    SOURCE_QM
    / "NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_POST_QM_QC_v1.md"
)

SOURCE_QM_CLOSE = (
    SOURCE_QM
    / "NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_QM_CLOSURE_FREEZE_v1.sha256"
)


ORCA = Path(
    "/mnt/lab/zn/software/"
    "orca_6_1_1_linux_x86-64_shared_openmpi418_nodmrg/"
    "orca"
)

MPIRUN = Path(
    "/mnt/lab/zn/software/"
    "openmpi-4.1.8-local/bin/mpirun"
)


# ----------------------------------------------------------------------
# This stage
# ----------------------------------------------------------------------

OUT = (
    EXE
    / "45_internal_validation144_qm_precommit"
)

MANIFEST_OUT = (
    OUT
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_EXECUTION_MANIFEST_v1.tsv"
)

PROTOCOL_OUT = (
    OUT
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_LABEL_OPENING_PRECOMMIT_v1.md"
)

SUMMARY_OUT = (
    OUT
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_PRECOMMIT_SUMMARY_v1.md"
)

FREEZE_OUT = (
    OUT
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_PRECOMMIT_FREEZE_v1.sha256"
)

QMOUT = (
    EXE
    / "46_internal_validation144_qm"
)


EXPECTED = {
    PRED_FORMAL_FREEZE:
        "c394a1e9720cb4e00dfd7924d2d63204058e550a156bf75c2f69c49d3244409f",

    PRED_CLOSE_REPORT:
        "95ab92d7436573e8fe112d7b9e4236ff3d526b955786c978cd5e5670fb409010",

    PRED_CLOSE_FREEZE:
        "24dcd9e6f4b18e3c6518c2526ae3af913e42db92d86ee56f701a165165081ba6",

    PRED_CLOSE_QC:
        "4aa364652fa318eaaaec129264504e2337d461a97c53821da509b27d8be26ea4",

    FIT_METADATA:
        "0edd6294ae591a0b340bd73bfa376ca85af43f9bcb28302e968defbaa679210d",

    PRED_INDEX:
        "6e69cca666783cd49a557ddd57cee7662e9bc6d76913f1fe9995c3d26119d738",

    SPLIT_RULE:
        "31ab1f865f5e566030f5f954fa6716ef20d785c8961f2134a3aecbe0cc462a2e",

    VAL:
        "f93fc7c2b2348f1629ad41a9327d66618f90d46b31520062eed20bdf876f7f66",

    ROLE:
        "1621c4f8ccb6dae48ec4571cfc6484801a4c88b175b04553aa57ba107740e5e9",

    SPLIT_SUMMARY:
        "16c0ff2efa5ef0ba80134bbad57e06e2b45776ea553e9494594b61aad5683b57",

    SPLIT_FREEZE:
        "85fe871bb67ff2c1ffc644cc99627f09dea900940a087b4e4211ec0d5e2b0984",

    ACQ_PROTOCOL:
        "ade57d9e8d2e38033ac40292f5004018eb037d074dc438df586797930dc2dee7",

    ACQ_FREEZE:
        "638bd46c98cb6d2dca725f3d7dca55322119f3de1b101194d518c3118852ff05",

    EVAL_PROTOCOL:
        "fadce5c50e36f0e5ad61fbdd2a556ad728cb35457a3bd29581a6fa1a25660761",

    EVAL_FREEZE:
        "cb33373cf47620333c369247db77fc3657dfa50d87ac0d88008fc7d65c69fb0c",

    SOURCE_QM_RUNNER:
        "86af3b80892a4b5643a416f607cdbe3b294b48b09288314a04eb541e9a7ee73e",

    SOURCE_QM_POST_QC_SCRIPT:
        "52260ad2d13547a4fc1b466645ea9c3f9aedf066843507828511e7d2859496a3",

    SOURCE_QM_PROTOCOL:
        "0f4adf7d1796fb198a221513cfe2591fd6280f02843fba419d4a884da9822310",

    SOURCE_QM_POST_QC:
        "dba0391589890348cf094f3295ba71893ba2010526060c2f7df96dec03d43d94",

    SOURCE_QM_CLOSE:
        "0d9350ae3ab7bd0ca4ac5f2bd7ab4468bc61d3a61477a675b6457c7dc588cd9c",

    ORCA:
        "38b5f057452fef275c0a1b98d270ad03d0411dab70453820d1c678bd732f6c83",

    MPIRUN:
        "98208ee7654b64d4073525ccca2719c0ea6fc3beef371fede3f5847d26ed4959",
}


EXPECTED_QM_FUNCTIONS = {
    "chirality",
    "dih",
    "load",
    "periodic_error",
    "read_xyz",
    "resolve_input_path",
    "run_one",
    "sha",
}


OUT_FIELDS = [
    "validation_rank",
    "state_id",
    "phi_target_deg",
    "psi_target_deg",
    "omega_target_deg",
    "start_xyz",
    "start_xyz_sha256",
    "phi_index",
    "psi_index",
    "omega_index",
]


def sha(path):
    h = hashlib.sha256()

    with Path(path).open(
        "rb"
    ) as fh:
        for block in iter(
            lambda: fh.read(1048576),
            b"",
        ):
            h.update(block)

    return h.hexdigest()


def rel(path):
    path = Path(path)

    try:
        return str(
            path.relative_to(ROOT)
        )

    except ValueError:
        return str(path)


def resolve(raw):
    path = Path(
        str(raw).strip()
    )

    if path.is_absolute():
        return path

    return ROOT / path


def read_tsv(path):
    with Path(path).open(
        "r",
        encoding="utf-8",
        newline="",
    ) as fh:

        reader = csv.DictReader(
            fh,
            delimiter="\t",
        )

        return (
            list(reader.fieldnames),
            list(reader),
        )


def write_tsv(
    path,
    fields,
    rows,
):
    with Path(path).open(
        "w",
        encoding="utf-8",
        newline="",
    ) as fh:

        writer = csv.DictWriter(
            fh,
            fieldnames=fields,
            delimiter="\t",
            lineterminator="\n",
            extrasaction="raise",
        )

        writer.writeheader()
        writer.writerows(rows)


def rehash_freeze(
    path,
    expected_count=None,
):
    rows = []

    for line in Path(path).read_text(
        encoding="utf-8"
    ).splitlines():

        if not line.strip():
            continue

        parts = line.split(
            maxsplit=1
        )

        if len(parts) != 2:
            raise RuntimeError(
                "malformed freeze line: "
                + str(path)
            )

        recorded, raw_path = parts

        member = resolve(
            raw_path
        ).resolve()

        if not member.is_file():
            raise RuntimeError(
                "freeze member missing: "
                + str(member)
            )

        if sha(member) != recorded:
            raise RuntimeError(
                "freeze member changed: "
                + str(member)
            )

        rows.append(
            (
                recorded,
                member,
            )
        )

    if (
        expected_count is not None
        and
        len(rows) != expected_count
    ):
        raise RuntimeError(
            "freeze entry count differs: "
            + str(path)
        )

    if len({
        member
        for _, member in rows
    }) != len(rows):
        raise RuntimeError(
            "duplicate freeze member: "
            + str(path)
        )

    return rows


def xyz_atom_count(path):
    with Path(path).open(
        "r",
        encoding="utf-8",
    ) as fh:
        first = fh.readline().strip()

    return int(first)


def top_level_assignments(tree):
    result = {}

    for node in tree.body:

        if not (
            isinstance(
                node,
                ast.Assign,
            )
            and
            len(node.targets) == 1
            and
            isinstance(
                node.targets[0],
                ast.Name,
            )
        ):
            continue

        result[
            node.targets[0].id
        ] = node.value

    return result


print(
    "===== 401KR INTERNAL-VALIDATION144 QM LABEL-OPENING PRECOMMIT ====="
)

print(
    "CONDA_DEFAULT_ENV =",
    os.environ.get(
        "CONDA_DEFAULT_ENV"
    ),
)

print(
    "PYTHONPATH =",
    os.environ.get(
        "PYTHONPATH"
    ),
)

if os.environ.get(
    "CONDA_DEFAULT_ENV"
) != "nme-torsion-p0":
    raise SystemExit(
        "[FAIL] wrong environment"
    )

if os.environ.get(
    "PYTHONPATH"
) is not None:
    raise SystemExit(
        "[FAIL] PYTHONPATH must be unset"
    )

if OUT.exists():
    raise SystemExit(
        "[FAIL] validation-QM precommit output already exists"
    )

if QMOUT.exists():
    raise SystemExit(
        "[FAIL] validation-QM downstream output already exists"
    )


print(
    "===== 1. VERIFY EXACT CLOSED AUTHORITIES ====="
)

for path, expected in EXPECTED.items():

    if not path.is_file():
        raise SystemExit(
            "[FAIL] required authority missing: "
            + str(path)
        )

    actual = sha(path)

    print(path.name)
    print(" expected =", expected)
    print(" actual   =", actual)

    if actual != expected:
        raise SystemExit(
            "[FAIL] authority SHA mismatch: "
            + path.name
        )

if not os.access(
    ORCA,
    os.X_OK,
):
    raise SystemExit(
        "[FAIL] ORCA is not executable"
    )

if not os.access(
    MPIRUN,
    os.X_OK,
):
    raise SystemExit(
        "[FAIL] mpirun is not executable"
    )

print(
    "[PASS] prediction closure / validation split / QM method authorities exact"
)


print(
    "===== 2. REHASH CLOSED PREDICTION / SPLIT / METHOD LINEAGES ====="
)

prediction_closure_rows = rehash_freeze(
    PRED_CLOSE_FREEZE,
    63,
)

split_freeze_rows = rehash_freeze(
    SPLIT_FREEZE
)

acq_freeze_rows = rehash_freeze(
    ACQ_FREEZE
)

eval_freeze_rows = rehash_freeze(
    EVAL_FREEZE,
    20,
)

source_qm_closure_rows = rehash_freeze(
    SOURCE_QM_CLOSE,
    348,
)

print(
    "prediction closure entries =",
    len(prediction_closure_rows),
)

print(
    "validation split freeze entries =",
    len(split_freeze_rows),
)

print(
    "acquisition precommit freeze entries =",
    len(acq_freeze_rows),
)

print(
    "evaluation precommit freeze entries =",
    len(eval_freeze_rows),
)

print(
    "source QM closure entries =",
    len(source_qm_closure_rows),
)

print(
    "[PASS] all frozen upstream lineages independently rehashed"
)


print(
    "===== 3. VERIFY VALIDATION MANIFEST IS LABEL-FREE EXACT144 ====="
)

val_fields, val_rows = read_tsv(
    VAL
)

print(
    "validation rows =",
    len(val_rows),
)

print(
    "validation fields =",
    val_fields,
)

if len(val_rows) != 144:
    raise SystemExit(
        "[FAIL] validation manifest rows !=144"
    )

if len({
    row["state_id"]
    for row in val_rows
}) != 144:
    raise SystemExit(
        "[FAIL] validation state IDs not unique144"
    )

required_fields = {
    "state_id",
    "phi_target_deg",
    "psi_target_deg",
    "omega_target_deg",
    "final_start_xyz",
    "final_start_xyz_sha256",
    "phi_index",
    "psi_index",
    "omega_index",
}

missing = (
    required_fields
    -
    set(val_fields)
)

print(
    "missing required validation fields =",
    sorted(missing),
)

if missing:
    raise SystemExit(
        "[FAIL] validation execution fields missing"
    )

label_like = [
    field
    for field in val_fields
    if any(
        token in field.lower()
        for token in (
            "residual",
            "qm_energy",
            "m0_energy",
            "label_status",
        )
    )
]

print(
    "validation label-like fields =",
    label_like,
)

if label_like:
    raise SystemExit(
        "[FAIL] pre-QM validation manifest exposes label-like data"
    )

print(
    "[PASS] frozen validation manifest remains coordinate/geometry-only"
)


print(
    "===== 4. VERIFY EXACT144 START GEOMETRIES / TARGET TORSIONS ====="
)

output_rows = []

phi_values = []
psi_values = []
omega_values = []

geometry_failures = []

for rank, row in enumerate(
    val_rows,
    start=1,
):

    sid = row[
        "state_id"
    ]

    phi = float(
        row[
            "phi_target_deg"
        ]
    )

    psi = float(
        row[
            "psi_target_deg"
        ]
    )

    omega = float(
        row[
            "omega_target_deg"
        ]
    )

    for label, value in (
        ("phi", phi),
        ("psi", psi),
        ("omega", omega),
    ):

        if not math.isfinite(value):
            raise SystemExit(
                "[FAIL] nonfinite target torsion: "
                + sid
                + " "
                + label
            )

        if value < -180.0 or value > 180.0:
            raise SystemExit(
                "[FAIL] target torsion outside [-180,180]: "
                + sid
            )

    start_xyz = resolve(
        row[
            "final_start_xyz"
        ]
    ).resolve()

    expected_xyz_sha = row[
        "final_start_xyz_sha256"
    ].strip()

    if not start_xyz.is_file():
        geometry_failures.append(
            (
                sid,
                "missing",
            )
        )

    else:

        actual_xyz_sha = sha(
            start_xyz
        )

        if actual_xyz_sha != expected_xyz_sha:
            geometry_failures.append(
                (
                    sid,
                    "sha",
                )
            )

        elif xyz_atom_count(
            start_xyz
        ) != 25:
            geometry_failures.append(
                (
                    sid,
                    "atom_count",
                )
            )

    phi_values.append(phi)
    psi_values.append(psi)
    omega_values.append(omega)

    output_rows.append(
        {
            "validation_rank":
                str(rank),

            "state_id":
                sid,

            "phi_target_deg":
                row[
                    "phi_target_deg"
                ],

            "psi_target_deg":
                row[
                    "psi_target_deg"
                ],

            "omega_target_deg":
                row[
                    "omega_target_deg"
                ],

            "start_xyz":
                row[
                    "final_start_xyz"
                ],

            "start_xyz_sha256":
                expected_xyz_sha,

            "phi_index":
                row[
                    "phi_index"
                ],

            "psi_index":
                row[
                    "psi_index"
                ],

            "omega_index":
                row[
                    "omega_index"
                ],
        }
    )


print(
    "geometry failures =",
    geometry_failures,
)

if geometry_failures:
    raise SystemExit(
        "[FAIL] one or more locked validation start geometries invalid"
    )


phi_counts = Counter(phi_values)
psi_counts = Counter(psi_values)
omega_counts = Counter(omega_values)

print(
    "unique phi levels =",
    len(phi_counts),
)

print(
    "unique psi levels =",
    len(psi_counts),
)

print(
    "unique omega levels =",
    len(omega_counts),
)

print(
    "phi level count-set =",
    sorted(
        set(
            phi_counts.values()
        )
    ),
)

print(
    "psi level count-set =",
    sorted(
        set(
            psi_counts.values()
        )
    ),
)

print(
    "omega level count-set =",
    sorted(
        set(
            omega_counts.values()
        )
    ),
)


if len(phi_counts) != 12:
    raise SystemExit(
        "[FAIL] validation phi levels !=12"
    )

if len(psi_counts) != 12:
    raise SystemExit(
        "[FAIL] validation psi levels !=12"
    )

if len(omega_counts) != 12:
    raise SystemExit(
        "[FAIL] validation omega levels !=12"
    )

if set(phi_counts.values()) != {12}:
    raise SystemExit(
        "[FAIL] validation phi level occupancy !=12 each"
    )

if set(psi_counts.values()) != {12}:
    raise SystemExit(
        "[FAIL] validation psi level occupancy !=12 each"
    )

if set(omega_counts.values()) != {12}:
    raise SystemExit(
        "[FAIL] validation omega level occupancy !=12 each"
    )


if len({
    (
        row["phi_target_deg"],
        row["psi_target_deg"],
    )
    for row in val_rows
}) != 144:
    raise SystemExit(
        "[FAIL] phi/psi validation pairs not unique144"
    )

if len({
    (
        row["phi_target_deg"],
        row["omega_target_deg"],
    )
    for row in val_rows
}) != 144:
    raise SystemExit(
        "[FAIL] phi/omega validation pairs not unique144"
    )

if len({
    (
        row["psi_target_deg"],
        row["omega_target_deg"],
    )
    for row in val_rows
}) != 144:
    raise SystemExit(
        "[FAIL] psi/omega validation pairs not unique144"
    )


cis_count = sum(
    abs(value - 0.0) < 1e-12
    for value in omega_values
)

trans_count = sum(
    abs(value - 180.0) < 1e-12
    for value in omega_values
)

intermediate_count = (
    144
    -
    cis_count
    -
    trans_count
)


print(
    "cis/trans/intermediate =",
    cis_count,
    trans_count,
    intermediate_count,
)


if (
    cis_count != 12
    or
    trans_count != 12
    or
    intermediate_count != 120
):
    raise SystemExit(
        "[FAIL] frozen validation omega-region partition changed"
    )


print(
    "[PASS] exact144 locked start geometries and orthogonal-array targets verified"
)


print(
    "===== 5. VERIFY SOURCE QM SCIENTIFIC IMPLEMENTATION ====="
)

source_text = SOURCE_QM_RUNNER.read_text(
    encoding="utf-8"
)

source_tree = ast.parse(
    source_text,
    filename=str(
        SOURCE_QM_RUNNER
    ),
)

function_names = {
    node.name
    for node in source_tree.body
    if isinstance(
        node,
        ast.FunctionDef,
    )
}

print(
    "source QM function names =",
    sorted(function_names),
)

if function_names != EXPECTED_QM_FUNCTIONS:
    raise SystemExit(
        "[FAIL] source QM scientific function surface !=exact8"
    )


assignments = top_level_assignments(
    source_tree
)

for name in (
    "MAX_WORKERS",
    "TORSION_TOL",
):

    if name not in assignments:
        raise SystemExit(
            "[FAIL] source QM assignment missing: "
            + name
        )


max_workers = ast.literal_eval(
    assignments[
        "MAX_WORKERS"
    ]
)

torsion_tol = ast.literal_eval(
    assignments[
        "TORSION_TOL"
    ]
)


print(
    "source MAX_WORKERS =",
    max_workers,
)

print(
    "source TORSION_TOL =",
    torsion_tol,
)


if max_workers != 2:
    raise SystemExit(
        "[FAIL] source QM MAX_WORKERS !=2"
    )

if float(
    torsion_tol
) != 0.1:
    raise SystemExit(
        "[FAIL] source QM TORSION_TOL !=0.1"
    )


required_method_tokens = (
    "r2SCAN-3c",
    "TightSCF",
    "TightOpt",
    "CPCM(Water)",
    "%pal nprocs 8 end",
    "%maxcore 2500",
    "MaxIter 300",
    "{ D 0 1 3 5",
    "{ D 1 3 5 7",
    "{ D 3 5 7 9",
    "* xyzfile 0 1 start.xyz",
)


missing_method_tokens = [
    token
    for token in required_method_tokens
    if token not in source_text
]


print(
    "missing source QM method tokens =",
    missing_method_tokens,
)

if missing_method_tokens:
    raise SystemExit(
        "[FAIL] source QM method contract incomplete"
    )


run_one = next(
    node
    for node in source_tree.body
    if (
        isinstance(
            node,
            ast.FunctionDef,
        )
        and
        node.name == "run_one"
    )
)


subprocess_calls = [
    node
    for node in ast.walk(
        run_one
    )
    if (
        isinstance(
            node,
            ast.Call,
        )
        and
        isinstance(
            node.func,
            ast.Attribute,
        )
        and
        isinstance(
            node.func.value,
            ast.Name,
        )
        and
        node.func.value.id == "subprocess"
        and
        node.func.attr == "run"
    )
]


print(
    "source run_one subprocess.run count =",
    len(subprocess_calls),
)

if len(subprocess_calls) != 1:
    raise SystemExit(
        "[FAIL] source QM run_one subprocess count !=1"
    )


print(
    "[PASS] validation QM method locked to CLOSED acquisition exact8 implementation"
)


print(
    "===== 6. MATERIALIZE LABEL-FREE VALIDATION-QM EXECUTION MANIFEST ====="
)

OUT.mkdir(
    parents=True,
    exist_ok=False,
)

write_tsv(
    MANIFEST_OUT,
    OUT_FIELDS,
    output_rows,
)

out_fields_check, out_rows_check = read_tsv(
    MANIFEST_OUT
)

if out_fields_check != OUT_FIELDS:
    raise SystemExit(
        "[FAIL] validation execution manifest schema differs"
    )

if out_rows_check != output_rows:
    raise SystemExit(
        "[FAIL] validation execution manifest content differs"
    )

if len(
    out_rows_check
) != 144:
    raise SystemExit(
        "[FAIL] validation execution manifest rows !=144"
    )


print(
    "execution manifest SHA256 =",
    sha(
        MANIFEST_OUT
    ),
)

print(
    "[PASS] exact144 label-free validation-QM execution identities frozen"
)


print(
    "===== 7. WRITE FORMAL VALIDATION-QM LABEL-OPENING PRECOMMIT ====="
)

protocol_lines = [
    "# NMe-Ala internal-validation144 QM label-opening precommit v1",
    "",
    "STATUS: FINAL PRECOMMIT BEFORE FIRST INTERNAL-VALIDATION QM.",
    "",
    "Scientific authorization:",
    "- the B192 three-arm training registry is already scientifically closed;",
    "- all24 evaluator fits and all3456 validation-coordinate predictions are already scientifically closed;",
    "- the pre-label prediction closure freeze is established before any validation QM/M0 truth exists;",
    "- internal-validation truth generation is therefore now authorized;",
    "- PPII remains separately sealed.",
    "",
    "Validation identity contract:",
    "- exact locked states =144;",
    "- validation order = frozen manifest row order1-144;",
    "- all144 states are new-QM grid states;",
    "- no validation state may enter training or evaluator refitting;",
    "- no state substitution is permitted;",
    "- each state uses its frozen final_start_xyz and final_start_xyz_sha256;",
    "- all start geometries contain25 atoms.",
    "",
    "Frozen omega-region partition:",
    "- cis omega=0 =12 states;",
    "- trans omega=180 =12 states;",
    "- intermediate omega =120 states.",
    "",
    "Formal QM method:",
    "- identical scientific implementation to the CLOSED acquisition-QM runner;",
    "- r2SCAN-3c;",
    "- TightSCF;",
    "- TightOpt;",
    "- CPCM(Water);",
    "- charge=0 / multiplicity=1;",
    "- %pal nprocs8;",
    "- %maxcore2500;",
    "- MaxIter300;",
    "- constrained omega atoms0-1-3-5;",
    "- constrained phi atoms1-3-5-7;",
    "- constrained psi atoms3-5-7-9;",
    "- target torsion acceptance <=0.10 degrees;",
    "- C-alpha chirality preservation gate unchanged;",
    "- formal bond/nonlocal geometry gates unchanged;",
    "- MAX_WORKERS=2;",
    "- exactly one ORCA subprocess per validation state;",
    "- no state retry, replacement, or adaptive scientific repair.",
    "",
    "Method provenance:",
    "- source scientific implementation = run_budget192_physical_batch06_qm_v1.py;",
    "- only its exact8 scientific functions are authorized for inheritance;",
    "- historical Batch06 human-readable metadata strings are not scientific method authority;",
    "- a fresh validation-specific top-level runner must be constructed and independently frozen before execution.",
    "",
    "Truth-opening sequence:",
    "1. prepare validation144 formal QM runner;",
    "2. independently semantic/SHA-freeze that runner;",
    "3. execute validation144 QM exactly once;",
    "4. independently reconstruct and close validation QM;",
    "5. prepare and execute same-geometry formal RESP M0;",
    "6. independently reconstruct and close validation residual labels;",
    "7. only then compare the already-frozen predictions to observed residuals.",
    "",
    "Evaluation boundary:",
    "- no RMSE/MAE/MaxAbs/AULC is calculated in this stage;",
    "- no low-energy identity is calculated in this stage because constrained validation QM energies do not yet exist;",
    "- after QM/M0 labels are closed, low-energy is defined once from E_QM-Emin_validation <=5.0 kcal/mol;",
    "- cis/trans/intermediate diagnostics remain frozen;",
    "- evaluator refitting, retuning, model repair, and prediction regeneration are permanently forbidden.",
    "",
    "PPII:",
    "- PPII_OFFGRID_HOLDOUT remains SEALED;",
    "- PPII does not enter validation QM generation or the acquisition benchmark evaluation.",
]

PROTOCOL_OUT.write_text(
    "\n".join(
        protocol_lines
    )
    + "\n",
    encoding="utf-8",
)


print(
    "precommit protocol SHA256 =",
    sha(
        PROTOCOL_OUT
    ),
)


print(
    "===== 8. WRITE PRECOMMIT SUMMARY ====="
)

summary_lines = [
    "# NMe-Ala internal-validation144 QM precommit summary v1",
    "",
    "STATUS: QM LABEL OPENING PRECOMMITTED; NO VALIDATION QM EXECUTED.",
    "",
    "Locked validation states:",
    "- total =144;",
    "- cis =12;",
    "- trans =12;",
    "- intermediate omega =120;",
    "- start geometries SHA-verified =144/144;",
    "- atom count =25 for all144.",
    "",
    "Closed pre-label benchmark:",
    "- model cells =24;",
    "- frozen predictions =3456;",
    "- prediction closure freeze entries =63;",
    "- no evaluator may be refit after this point.",
    "",
    "Authorized QM:",
    "- r2SCAN-3c/TightSCF/TightOpt/CPCM(Water);",
    "- exact frozen phi/psi/omega restraints;",
    "- nprocs8 per state;",
    "- MAX_WORKERS2;",
    "- target tolerance0.10 degrees;",
    "- source exact8 scientific implementation inherited from CLOSED acquisition QM.",
    "",
    "Not performed:",
    "- no ORCA execution;",
    "- no M0;",
    "- no observed residual;",
    "- no validation RMSE/MAE/AULC;",
    "- no low-energy classification;",
    "- no PPII access.",
    "",
    "AUTHORIZED NEXT:",
    "construct the fresh validation144 formal QM runner from the frozen exact8 scientific implementation;",
    "then perform one independent semantic/SHA preexecution QC before any ORCA job is launched.",
]

SUMMARY_OUT.write_text(
    "\n".join(
        summary_lines
    )
    + "\n",
    encoding="utf-8",
)


print(
    "precommit summary SHA256 =",
    sha(
        SUMMARY_OUT
    ),
)


print(
    "===== 9. WRITE PRECOMMIT FREEZE ====="
)

freeze_members = [
    Path(
        __file__
    ).resolve(),

    PRED_FORMAL_FREEZE.resolve(),
    PRED_CLOSE_REPORT.resolve(),
    PRED_CLOSE_FREEZE.resolve(),
    PRED_CLOSE_QC.resolve(),
    FIT_METADATA.resolve(),
    PRED_INDEX.resolve(),

    SPLIT_RULE.resolve(),
    VAL.resolve(),
    ROLE.resolve(),
    SPLIT_SUMMARY.resolve(),
    SPLIT_FREEZE.resolve(),

    ACQ_PROTOCOL.resolve(),
    ACQ_FREEZE.resolve(),

    EVAL_PROTOCOL.resolve(),
    EVAL_FREEZE.resolve(),

    SOURCE_QM_RUNNER.resolve(),
    SOURCE_QM_POST_QC_SCRIPT.resolve(),
    SOURCE_QM_PROTOCOL.resolve(),
    SOURCE_QM_POST_QC.resolve(),
    SOURCE_QM_CLOSE.resolve(),

    ORCA.resolve(),
    MPIRUN.resolve(),

    MANIFEST_OUT.resolve(),
    PROTOCOL_OUT.resolve(),
    SUMMARY_OUT.resolve(),
]


print(
    "precommit freeze entries =",
    len(
        freeze_members
    ),
)

print(
    "precommit freeze unique paths =",
    len(
        set(
            freeze_members
        )
    ),
)


if len(
    freeze_members
) != 26:
    raise SystemExit(
        "[FAIL] validation-QM precommit freeze entries !=26"
    )

if len(
    set(
        freeze_members
    )
) != 26:
    raise SystemExit(
        "[FAIL] duplicate validation-QM precommit freeze member"
    )


for path in freeze_members:

    if not path.is_file():
        raise SystemExit(
            "[FAIL] precommit freeze member missing: "
            + str(path)
        )


FREEZE_OUT.write_text(
    "\n".join(
        sha(path)
        + "  "
        + rel(path)
        for path in freeze_members
    )
    + "\n",
    encoding="utf-8",
)


print(
    "precommit freeze SHA256 =",
    sha(
        FREEZE_OUT
    ),
)


print(
    "===== 10. FINAL IMMUTABILITY / NO-TRUTH-OPENING BOUNDARY ====="
)

for path, expected in EXPECTED.items():

    if sha(path) != expected:
        raise SystemExit(
            "[FAIL] frozen upstream authority changed during401KR: "
            + path.name
        )


for group in (
    prediction_closure_rows,
    split_freeze_rows,
    acq_freeze_rows,
    eval_freeze_rows,
    source_qm_closure_rows,
):

    for recorded, member in group:

        if sha(member) != recorded:
            raise SystemExit(
                "[FAIL] upstream freeze member changed during401KR: "
                + str(member)
            )


if QMOUT.exists():
    raise SystemExit(
        "[FAIL] validation QM output appeared during precommit"
    )


actual_files = {
    path.name
    for path in OUT.iterdir()
    if path.is_file()
}


expected_files = {
    MANIFEST_OUT.name,
    PROTOCOL_OUT.name,
    SUMMARY_OUT.name,
    FREEZE_OUT.name,
}


print(
    "validation-QM precommit directory files =",
    sorted(actual_files),
)


if actual_files != expected_files:
    raise SystemExit(
        "[FAIL] validation-QM precommit directory !=exact4 files"
    )

if any(
    path.is_dir()
    for path in OUT.iterdir()
):
    raise SystemExit(
        "[FAIL] unexpected validation-QM precommit subdirectory"
    )


print(
    "[PASS] INTERNAL-VALIDATION144 QM LABEL-OPENING PRECOMMIT CLOSED"
)

print(
    "[PASS] exact144 locked identities / target torsions / start geometries frozen"
)

print(
    "[PASS] prediction closure remains immutable before truth generation"
)

print(
    "[PASS] validation QM method locked to CLOSED r2SCAN-3c acquisition implementation"
)

print(
    "[PASS] exact8 scientific implementation provenance frozen"
)

print(
    "[PASS] no validation QM/M0/residual truth generated"
)

print(
    "[PASS] no validation metric calculated"
)

print(
    "[PASS] evaluator refit/retuning/prediction regeneration remains forbidden"
)

print(
    "[PASS] PPII remains SEALED"
)

print(
    "[AUTHORIZED-NEXT] construct fresh validation144 formal QM runner"
)

print(
    "[AUTHORIZED-NEXT] then one independent semantic/SHA preexecution QC before ORCA"
)

print(
    "401KR preparer SHA256 =",
    sha(
        Path(
            __file__
        )
    ),
)

print(
    "===== 401KR-INTERNAL-VALIDATION144-QM-LABEL-OPENING-FINAL-PRECOMMIT-v1 END ====="
)
