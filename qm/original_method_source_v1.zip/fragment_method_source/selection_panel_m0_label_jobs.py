from pathlib import Path
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed

import csv
import hashlib
import math
import os
import re
import subprocess

import numpy as np
import parmed as pmd

ROOT = Path(
    "/mnt/lab/zn/mem-perm/P0_starter_v1"
)

DEV = (
    ROOT
    / "07_nmeala_separability_pilot"
    / "13_joint_correction_development"
)

EXE = (
    DEV
    / "07_acquisition_benchmark_execution"
)

SOURCE_M0_RUNNER = (
    EXE
    / "run_budget192_physical_batch06_m0_labels_v1.py"
)

SOURCE_LABEL_CLOSURE = (
    EXE
    / "41_budget192_physical_batch06_m0_labels"
    / "NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_LABEL_CLOSURE_FREEZE_v1.sha256"
)

QM = (
    EXE
    / "46_internal_validation144_qm"
)

QM_PROTOCOL = (
    QM
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_PROTOCOL_v1.md"
)

QM_RESULTS = (
    QM
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_R2SCAN_RESULTS_v1.tsv"
)

QM_INVENTORY = (
    QM
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_RAW_OUTPUT_INVENTORY_v1.tsv"
)

QM_POST_QC = (
    QM
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_POST_QM_QC_v1.md"
)

QM_CLOSURE = (
    QM
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_CLOSURE_FREEZE_v1.sha256"
)

QM_POST_QC_SCRIPT = (
    EXE
    / "run_qc_internal_validation144_qm_postexec_v1.py"
)

PRMTOP = (
    ROOT
    / "06_m0_formal_resp"
    / "03_tleap_topology"
    / "nmeala_resp_v1.prmtop"
)

PMEMD = Path(
    "/home/dlab/software/pmemd24/bin/pmemd"
)

OUT = (
    EXE
    / "47_internal_validation144_m0"
)

RUNS = (
    OUT
    / "runs"
)

MDIN = (
    OUT
    / "internal_validation144_same_geometry_zero_step_v1.in"
)

PROTOCOL = (
    OUT
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_M0_PROTOCOL_v1.md"
)

M0_RESULTS = (
    OUT
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_ACCEPTED_M0_RESULTS_v1.tsv"
)

LABELS = (
    OUT
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_144_LABELS_v1.tsv"
)

SUMMARY = (
    OUT
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_LABEL_SUMMARY_v1.md"
)

FREEZE = (
    OUT
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_LABEL_GENERATION_FREEZE_v1.sha256"
)

SOURCE_MDIN_TEXT = 'Internal-validation144 exact same-geometry M0 zero-step\n &cntrl\n  imin=1,\n  maxcyc=0,\n  ncyc=0,\n  ntmin=0,\n  ntb=0,\n  igb=0,\n  cut=999.0,\n  ntpr=1,\n  ntxo=2,\n /\n'

EXPECTED = {
    SOURCE_M0_RUNNER:
        "9dcae0e37a146f8a3636066f904d7ef7f6e0624c4a9d88302d366e5191669f6f",

    SOURCE_LABEL_CLOSURE:
        "c33b623b34328bbe28b64b86d678e0509d5a2e6ec0815772c2278712b2285d26",

    QM_PROTOCOL:
        "dba3dfed70cf29532edd831e679035a4c4b5e93266f7ff7845f47adfb17d7775",

    QM_RESULTS:
        "346fc8e6388d70b2e9ea7b6dd9102f482236c8e98a28785940be9c71319e2ed5",

    QM_INVENTORY:
        "260dd84261a74ab6c585855836f0041a1e19a40820e71fb9cc0c93d8b9a7509c",

    QM_POST_QC:
        "dbad404083876246cebf9490e2e1a6ccc620928dbd773314347696f08627d15c",

    QM_CLOSURE:
        "82fe6018b095f0499f20fd18c485bab7b073cc1877263bf52a2ad2d66983c47e",

    QM_POST_QC_SCRIPT:
        "99a8845e5cd5ff371eabced105211cae9c5960fbe864e946d6e076ef6d0be6b7",

    PRMTOP:
        "9b2c68fad482b03562a4b9c956dc57586bfc73384bb3a68b019e866c1275f5e6",

    PMEMD:
        "d86788a7e398f704c0a3f7e8c752a25ca3a7a56bd19cb602dfa8b80f790d1193",
}

ROOT = Path('/mnt/lab/zn/mem-perm/P0_starter_v1')

DEV = ROOT / '07_nmeala_separability_pilot' / '13_joint_correction_development'

PARSER = DEV / '06_gp_active_learning' / '04_batch01_label_acceptance' / 'NMEALA_JOINT_GP_BATCH01_M0_PARSER_QC_AMENDMENT_v1.md'

H2K = 627.509474

SER_TOL = 1e-06

MAX_WORKERS = 4

COMPONENTS = ['BOND', 'ANGLE', 'DIHED', 'VDWAALS', 'EEL', 'HBOND', '1-4 VDW', '1-4 EEL', 'RESTRAINT']

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as fh:
        for block in iter(lambda: fh.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def load(path):
    with Path(path).open('r', encoding='utf-8', newline='') as fh:
        return list(csv.DictReader(fh, delimiter='\t'))

def write_tsv(path, rows):
    if not rows:
        raise RuntimeError('no rows: ' + str(path))
    fields = list(rows[0])
    with Path(path).open('w', encoding='utf-8', newline='') as fh:
        writer = csv.DictWriter(fh, fieldnames=fields, delimiter='\t', lineterminator='\n', extrasaction='raise')
        writer.writeheader()
        writer.writerows(rows)

def read_xyz(path):
    lines = Path(path).read_text(encoding='utf-8').splitlines()
    n = int(lines[0])
    symbols = []
    xyz = []
    for line in lines[2:2 + n]:
        fields = line.split()
        symbols.append(fields[0])
        xyz.append([float(fields[1]), float(fields[2]), float(fields[3])])
    if len(symbols) != n:
        raise RuntimeError('truncated XYZ: ' + str(path))
    arr = np.asarray(xyz, dtype=float)
    if not np.isfinite(arr).all():
        raise RuntimeError('nonfinite XYZ: ' + str(path))
    return (symbols, arr)

def write_rst7(path, xyz, title):
    flat = np.asarray(xyz, dtype=float).reshape(-1)
    with Path(path).open('w', encoding='utf-8') as fh:
        fh.write(title[:80] + '\n')
        fh.write(f'{len(xyz):6d}{0.0:15.7E}\n')
        for index in range(0, len(flat), 6):
            fh.write(''.join((f'{value:12.7f}' for value in flat[index:index + 6])) + '\n')

def read_rst7(path, natom):
    lines = Path(path).read_text(encoding='utf-8').splitlines()
    if int(lines[1].split()[0]) != natom:
        raise RuntimeError('rst7 atom count mismatch')
    values = []
    for line in lines[2:]:
        for index in range(0, len(line), 12):
            token = line[index:index + 12]
            if token.strip():
                values.append(float(token))
        if len(values) >= 3 * natom:
            break
    if len(values) < 3 * natom:
        raise RuntimeError('short rst7')
    return np.asarray(values[:3 * natom], dtype=float).reshape(natom, 3)

def last_component(text, key):
    number = '([-+]?(?:\\d+\\.\\d*|\\d*\\.\\d+|\\d+)(?:[Ee][-+]?\\d+)?)'
    patterns = {'BOND': f'\\bBOND\\s*=\\s*{number}', 'ANGLE': f'\\bANGLE\\s*=\\s*{number}', 'DIHED': f'\\bDIHED\\s*=\\s*{number}', 'VDWAALS': f'\\bVDWAALS\\s*=\\s*{number}', 'EEL': f'(?<!1-4 )\\bEEL\\s*=\\s*{number}', 'HBOND': f'\\bHBOND\\s*=\\s*{number}', '1-4 VDW': f'1-4\\s+VDW\\s*=\\s*{number}', '1-4 EEL': f'1-4\\s+EEL\\s*=\\s*{number}', 'RESTRAINT': f'\\bRESTRAINT\\s*=\\s*{number}'}
    hits = re.findall(patterns[key], text, re.I)
    if not hits:
        raise RuntimeError('missing ' + key)
    return float(hits[-1])

def nonfinite_audit(text):
    lines = text.splitlines()
    nan_lines = [(index, line) for index, line in enumerate(lines) if re.search('\\bNaN\\b', line, re.I)]
    benign = []
    bad = []
    for index, line in nan_lines:
        previous = lines[index - 1] if index else ''
        allowed = re.match('^\\s*\\|\\s*Direct force subcell size\\s*=\\s*NaN\\s+NaN\\s+NaN\\s*$', line, re.I) and re.search('Coordinate Index Table dimensions:\\s*0\\s+0\\s+0', previous, re.I)
        if allowed:
            benign.append((index + 1, line))
        else:
            bad.append((index + 1, line))
    infinities = re.findall('(?<![A-Za-z])[-+]?Inf(?:inity)?(?![A-Za-z])', text, re.I)
    overflow_stars = re.findall('=\\s*\\*{5,}', text)
    return (nan_lines, benign, bad, infinities, overflow_stars)

def run_one(item):
    run_dir = RUNS / item['state_id']
    output = run_dir / 'm0.out'
    with (run_dir / 'pmemd_stdout.txt').open('w', encoding='utf-8') as stdout:
        process = subprocess.run([str(PMEMD), '-O', '-i', str(MDIN), '-o', str(output), '-p', str(PRMTOP), '-c', str(item['amber_coordinate']), '-r', str(run_dir / 'restrt'), '-inf', str(run_dir / 'mdinfo')], cwd=run_dir, stdout=stdout, stderr=subprocess.STDOUT, env=environment, check=False)
    (run_dir / 'exitcode.txt').write_text(str(process.returncode) + '\n', encoding='utf-8')
    return (item['state_id'], process.returncode)

print(
    "===== FORMAL INTERNAL-VALIDATION144 SAME-GEOMETRY RESP-M0 RUNNER ====="
)

print(
    "CONDA_DEFAULT_ENV =",
    os.environ.get(
        "CONDA_DEFAULT_ENV"
    ),
)

print(
    "PYTHONPATH =",
    os.environ.get(
        "PYTHONPATH"
    ),
)


if os.environ.get(
    "CONDA_DEFAULT_ENV"
) != "nme-torsion-p0":
    raise SystemExit(
        "[FAIL] wrong environment"
    )


if os.environ.get(
    "PYTHONPATH"
) is not None:
    raise SystemExit(
        "[FAIL] PYTHONPATH must be unset"
    )


print(
    "===== 1. VERIFY FROZEN M0 / VALIDATION-QM AUTHORITIES ====="
)


for path, expected in EXPECTED.items():

    if not path.is_file():
        raise SystemExit(
            "[FAIL] required M0 authority missing: "
            + str(path)
        )

    actual = sha(
        path
    )

    print(
        path.name
    )

    print(
        " expected =",
        expected
    )

    print(
        " actual   =",
        actual
    )

    if actual != expected:
        raise SystemExit(
            "[FAIL] M0 authority SHA mismatch: "
            + path.name
        )


if not os.access(
    PMEMD,
    os.X_OK,
):
    raise SystemExit(
        "[FAIL] PMEMD not executable"
    )


print(
    "[PASS] exact CLOSED M0 implementation / CLOSED validation-QM authorities verified"
)


print(
    "===== 2. REHASH VALIDATION-QM SCIENTIFIC CLOSURE ====="
)


qm_closure_rows = []


for line in QM_CLOSURE.read_text(
    encoding="utf-8"
).splitlines():

    if not line.strip():
        continue

    recorded, raw = line.split(
        maxsplit=1
    )

    member = Path(
        raw
    )

    if not member.is_absolute():
        member = (
            ROOT
            /
            member
        )

    member = member.resolve()

    if not member.is_file():
        raise SystemExit(
            "[FAIL] validation-QM closure member missing: "
            + str(member)
        )

    if sha(
        member
    ) != recorded:
        raise SystemExit(
            "[FAIL] validation-QM closure member changed: "
            + str(member)
        )

    qm_closure_rows.append(
        (
            recorded,
            member,
        )
    )


if len(
    qm_closure_rows
) != 2170:
    raise SystemExit(
        "[FAIL] validation-QM closure entries !=2170"
    )


print(
    "[PASS] all2170 validation-QM closure members rehashed immediately before M0"
)


print(
    "===== 3. OUTPUT SAFETY / FREEZE ZERO-STEP MDIN ====="
)


if OUT.exists():
    raise SystemExit(
        "[FAIL] validation M0 output already exists"
    )


OUT.mkdir(
    parents=True,
    exist_ok=False,
)

RUNS.mkdir(
    parents=False,
    exist_ok=False,
)


MDIN.write_text(
    SOURCE_MDIN_TEXT,
    encoding="utf-8",
)


mdin_lines = MDIN.read_text(
    encoding="utf-8"
).splitlines()


if len(
    mdin_lines
) != 12:
    raise SystemExit(
        "[FAIL] validation M0 MDIN lines !=12"
    )


for token in (
    "maxcyc=0",
    "ncyc=0",
    "ntmin=0",
):

    if token not in "".join(
        mdin_lines[
            1:
        ]
    ).replace(
        " ",
        ""
    ):
        raise SystemExit(
            "[FAIL] zero-step MDIN token missing: "
            + token
        )


print(
    "[PASS] clean validation M0 output created"
)

print(
    "[PASS] exact zero-step same-geometry MDIN body frozen before PMEMD"
)


print(
    "===== 4. WRITE FORMAL VALIDATION M0 PROTOCOL ====="
)


PROTOCOL.write_text(
"""# NMe-Ala internal-validation144 formal same-geometry M0 protocol v1

STATUS:
FROZEN BEFORE PMEMD M0 RESULTS.

Inputs:
exact144 accepted and scientifically CLOSED validation constrained-QM final geometries.

M0:
GAFF2 + formal six-conformer RESP topology;
same exact QM final geometry;
PMEMD zero-step/single-point evaluation;
no MM minimization;
no MM geometry relaxation.

Zero-step control:
maxcyc=0;
ncyc=0;
ntmin=0.

Serialization:
QM XYZ -> AMBER rst7;
maximum Cartesian roundtrip displacement <=1e-6 A.

Authoritative printed components:
BOND;
ANGLE;
DIHED;
VDWAALS;
EEL;
HBOND;
1-4 VDW;
1-4 EEL;
RESTRAINT.

Energy convention:
M0 = sum of the nine authoritative PMEMD printed components;
ordinary EEL excludes 1-4 EEL;
RESTRAINT must be <=1e-8 kcal/mol in absolute magnitude;
QM-minus-M0 residual =
QM_Eh * 627.509474 - M0_component_sum_kcal_mol.

Precision convention:
PMEMD_PRINTED_NINE_COMPONENT_SUM.
Nine components and total are serialized to4 decimals;
residual is serialized to12 decimals.

Nonfinite policy:
exactly one permitted PMEMD direct-force diagnostic NaN line;
the benign line must correspond to the zero-subcell diagnostic context;
all other NaN/Inf/Infinity/overflow-star assignments fail.

Resources:
MAX_WORKERS=4;
one fixed PMEMD subprocess per validation state.

Boundary:
this runner generates M0 and residual labels only;
no acquisition benchmark RMSE/MAE/MaxAbs/AULC;
no evaluator refit;
no evaluator retuning;
no prediction regeneration;
PPII remains sealed.
""",
    encoding="utf-8",
)


print(
    "validation M0 protocol SHA256 =",
    sha(
        PROTOCOL
    ),
)


print(
    "[PASS] formal validation M0 protocol frozen before PMEMD"
)


print(
    "===== 5. LOAD EXACT144 CLOSED-QM FINAL GEOMETRIES ====="
)


qm_rows = load(
    QM_RESULTS
)


if len(
    qm_rows
) != 144:
    raise SystemExit(
        "[FAIL] validation QM rows !=144"
    )


qm_rows = sorted(
    qm_rows,
    key=lambda row:
        int(
            row[
                "validation_rank"
            ]
        ),
)


if [
    int(
        row[
            "validation_rank"
        ]
    )
    for row in qm_rows
] != list(
    range(
        1,
        145,
    )
):
    raise SystemExit(
        "[FAIL] validation ranks !=1..144"
    )


if len({
    row[
        "state_id"
    ]
    for row in qm_rows
}) != 144:
    raise SystemExit(
        "[FAIL] validation QM state IDs not unique144"
    )


if any(
    row[
        "status"
    ] != "PASS"
    for row in qm_rows
):
    raise SystemExit(
        "[FAIL] non-PASS validation QM row present"
    )


parm = pmd.load_file(
    str(
        PRMTOP
    )
)


if (
    len(
        parm.atoms
    ) != 25
    or
    len(
        parm.bonds
    ) != 24
):
    raise SystemExit(
        "[FAIL] formal RESP topology !=25 atoms /24 bonds"
    )


zsym = {
    1:
        "H",

    6:
        "C",

    7:
        "N",

    8:
        "O",
}


formal_symbols = [
    zsym[
        atom.atomic_number
    ]
    for atom in parm.atoms
]


prepared = []


for qm_row in qm_rows:

    sid = qm_row[
        "state_id"
    ]

    source_xyz = Path(
        qm_row[
            "final_xyz"
        ]
    )


    if not source_xyz.is_absolute():
        source_xyz = (
            ROOT
            /
            source_xyz
        )


    source_xyz = source_xyz.resolve()


    if not source_xyz.is_file():
        raise SystemExit(
            "[FAIL] accepted validation QM XYZ missing: "
            + sid
        )


    if sha(
        source_xyz
    ) != qm_row[
        "final_xyz_sha256"
    ]:
        raise SystemExit(
            "[FAIL] accepted validation QM XYZ SHA changed: "
            + sid
        )


    symbols, xyz = read_xyz(
        source_xyz
    )


    if symbols != formal_symbols:
        raise SystemExit(
            "[FAIL] validation QM/prmtop atom ordering mismatch: "
            + sid
        )


    run_dir = (
        RUNS
        /
        sid
    )


    run_dir.mkdir(
        parents=False,
        exist_ok=False,
    )


    amber_coordinate = (
        run_dir
        /
        "exact_qm.rst7"
    )


    write_rst7(
        amber_coordinate,
        xyz,
        "NMe-Ala internal-validation144 "
        + sid,
    )


    roundtrip = read_rst7(
        amber_coordinate,
        25,
    )


    serialization_delta = float(
        np.max(
            np.linalg.norm(
                roundtrip
                -
                xyz,
                axis=1,
            )
        )
    )


    print(
        f"{qm_row['validation_rank']}\t"
        f"{sid}\t"
        f"serialization_delta="
        f"{serialization_delta:.12e} A"
    )


    if serialization_delta > SER_TOL:
        raise SystemExit(
            "[FAIL] validation QM-to-AMBER serialization gate: "
            + sid
        )


    prepared.append(
        {
            "validation_rank":
                int(
                    qm_row[
                        "validation_rank"
                    ]
                ),

            "state_id":
                sid,

            "phi_target_deg":
                qm_row[
                    "phi_target_deg"
                ],

            "psi_target_deg":
                qm_row[
                    "psi_target_deg"
                ],

            "omega_target_deg":
                qm_row[
                    "omega_target_deg"
                ],

            "qm_energy_Eh":
                float(
                    qm_row[
                        "final_energy_Eh"
                    ]
                ),

            "qm_xyz":
                source_xyz,

            "qm_xyz_sha256":
                qm_row[
                    "final_xyz_sha256"
                ],

            "amber_coordinate":
                amber_coordinate,

            "amber_coordinate_sha256":
                sha(
                    amber_coordinate
                ),

            "serialization_delta":
                serialization_delta,
        }
    )


print(
    "[PASS] exact144 accepted QM final geometries serialized within1e-6 A"
)


print(
    "===== 6. RUN EXACT144 ZERO-STEP PMEMD M0 EVALUATIONS ====="
)


environment = os.environ.copy()


for variable in (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "BLIS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
):

    environment[
        variable
    ] = "1"


environment.pop(
    "DISPLAY",
    None,
)

environment.pop(
    "XAUTHORITY",
    None,
)

environment.pop(
    "WAYLAND_DISPLAY",
    None,
)


completed = 0


with ThreadPoolExecutor(
    max_workers=MAX_WORKERS
) as executor:

    futures = {
        executor.submit(
            run_one,
            item,
        ):
            item[
                "state_id"
            ]
        for item in prepared
    }


    for future in as_completed(
        futures
    ):

        sid = futures[
            future
        ]

        try:

            returned_sid, returncode = future.result()

            if returned_sid != sid:
                tag = "IDENTITY_MISMATCH"

            else:
                tag = (
                    "EXIT0"
                    if returncode == 0
                    else
                    f"EXIT{returncode}"
                )

        except Exception as exc:

            tag = (
                "EXCEPTION:"
                +
                repr(
                    exc
                )
            )


        completed += 1

        print(
            f"[PROGRESS] "
            f"{completed:3d}/144 "
            f"{sid} "
            f"{tag}"
        )


print(
    "===== 7. PARSE EXACT144 FORMAL M0 OUTPUTS / RESIDUAL LABELS ====="
)


m0_rows = []

label_rows = []


for item in prepared:

    sid = item[
        "state_id"
    ]

    run_dir = (
        RUNS
        /
        sid
    )


    pmemd_output = (
        run_dir
        /
        "m0.out"
    )

    exitcode_file = (
        run_dir
        /
        "exitcode.txt"
    )


    reasons = []


    exitcode = (
        exitcode_file.read_text(
            encoding="utf-8"
        ).strip()
        if exitcode_file.is_file()
        else "MISSING"
    )


    if exitcode != "0":
        reasons.append(
            "NONZERO_PMEMD_EXIT"
        )


    text = (
        pmemd_output.read_text(
            encoding="utf-8",
            errors="ignore",
        )
        if pmemd_output.is_file()
        else ""
    )


    (
        nan_lines,
        allowed_nan,
        bad_nan,
        inf_hits,
        star_hits,
    ) = nonfinite_audit(
        text
    )


    if len(
        nan_lines
    ) != 1:
        reasons.append(
            "NAN_LINE_COUNT"
        )


    if len(
        allowed_nan
    ) != 1:
        reasons.append(
            "BENIGN_NAN_COUNT"
        )


    if bad_nan:
        reasons.append(
            "UNEXPECTED_NAN"
        )


    if inf_hits:
        reasons.append(
            "INF_INFINITY"
        )


    if star_hits:
        reasons.append(
            "OVERFLOW_STARS"
        )


    components = None


    try:

        components = {
            name:
                last_component(
                    text,
                    name,
                )
            for name in COMPONENTS
        }

    except Exception:

        reasons.append(
            "COMPONENT_PARSE"
        )


    total = None


    if components is not None:

        if not all(
            math.isfinite(
                value
            )
            for value in components.values()
        ):
            reasons.append(
                "NONFINITE_COMPONENT"
            )


        if abs(
            components[
                "RESTRAINT"
            ]
        ) > 1.0e-8:
            reasons.append(
                "NONZERO_RESTRAINT"
            )


        total = float(
            sum(
                components[
                    name
                ]
                for name in COMPONENTS
            )
        )


        if not math.isfinite(
            total
        ):
            reasons.append(
                "NONFINITE_M0_TOTAL"
            )


    status = (
        "PASS"
        if not reasons
        else "HOLD"
    )


    residual = (
        item[
            "qm_energy_Eh"
        ]
        *
        H2K
        -
        total
        if (
            status == "PASS"
            and
            total is not None
        )
        else None
    )


    row = {
        "validation_rank":
            str(
                item[
                    "validation_rank"
                ]
            ),

        "state_id":
            sid,

        "phi_target_deg":
            item[
                "phi_target_deg"
            ],

        "psi_target_deg":
            item[
                "psi_target_deg"
            ],

        "omega_target_deg":
            item[
                "omega_target_deg"
            ],

        "qm_energy_Eh":
            f"{item['qm_energy_Eh']:.12f}",

        "qm_xyz":
            str(
                item[
                    "qm_xyz"
                ]
            ),

        "qm_xyz_sha256":
            item[
                "qm_xyz_sha256"
            ],

        "amber_coordinate":
            str(
                item[
                    "amber_coordinate"
                ]
            ),

        "amber_coordinate_sha256":
            item[
                "amber_coordinate_sha256"
            ],

        "serialization_delta_A":
            f"{item['serialization_delta']:.12e}",

        "pmemd_output":
            str(
                pmemd_output
            ),

        "pmemd_output_sha256":
            (
                sha(
                    pmemd_output
                )
                if pmemd_output.is_file()
                else ""
            ),

        "exitcode":
            exitcode,
    }


    for name in COMPONENTS:

        column = (
            "m0_"
            +
            name.replace(
                " ",
                "_",
            )
            +
            "_kcal_mol"
        )


        row[
            column
        ] = (
            ""
            if components is None
            else
            f"{components[name]:.4f}"
        )


    row[
        "m0_total_component_sum_kcal_mol"
    ] = (
        ""
        if total is None
        else
        f"{total:.4f}"
    )


    row[
        "absolute_QM_minus_M0_residual_kcal_mol"
    ] = (
        ""
        if residual is None
        else
        f"{residual:.12f}"
    )


    row[
        "allowed_zero_step_diagnostic_NaN_count"
    ] = str(
        len(
            allowed_nan
        )
    )


    row[
        "unexpected_nonfinite_output_count"
    ] = str(
        len(
            bad_nan
        )
        +
        len(
            inf_hits
        )
        +
        len(
            star_hits
        )
    )


    row[
        "status"
    ] = status


    row[
        "failure_reason"
    ] = ",".join(
        reasons
    )


    m0_rows.append(
        row
    )


    if status == "PASS":

        label_rows.append(
            {
                "validation_rank":
                    str(
                        item[
                            "validation_rank"
                        ]
                    ),

                "state_id":
                    sid,

                "phi_deg":
                    item[
                        "phi_target_deg"
                    ],

                "psi_deg":
                    item[
                        "psi_target_deg"
                    ],

                "omega_deg":
                    item[
                        "omega_target_deg"
                    ],

                "QM_energy_Eh":
                    f"{item['qm_energy_Eh']:.12f}",

                "QM_xyz_sha256":
                    item[
                        "qm_xyz_sha256"
                    ],

                "M0_energy_component_sum_kcal_mol":
                    f"{total:.4f}",

                "absolute_QM_minus_M0_residual_kcal_mol":
                    f"{residual:.12f}",

                "M0_coordinate_sha256":
                    item[
                        "amber_coordinate_sha256"
                    ],

                "label_precision_convention":
                    "PMEMD_PRINTED_NINE_COMPONENT_SUM",

                "label_status":
                    "ACCEPTED_INTERNAL_VALIDATION_LABEL",
            }
        )


write_tsv(
    M0_RESULTS,
    m0_rows,
)


if label_rows:

    write_tsv(
        LABELS,
        label_rows,
    )


status_counts = Counter(
    row[
        "status"
    ]
    for row in m0_rows
)


print(
    "formal validation M0 status counts =",
    dict(
        status_counts
    ),
)


print(
    "accepted validation residual labels =",
    len(
        label_rows
    ),
)


if status_counts != Counter(
    {
        "PASS":
            144
    }
):
    raise SystemExit(
        "[FAIL] validation same-geometry M0 !=PASS144"
    )


if len(
    label_rows
) != 144:
    raise SystemExit(
        "[FAIL] validation residual labels !=144"
    )


print(
    "[PASS] exact144 same-geometry zero-step RESP-M0 states accepted"
)

print(
    "[PASS] exact144 QM-minus-M0 residual labels generated"
)


print(
    "===== 8. WRITE LABEL SUMMARY / GENERATION FREEZE ====="
)


SUMMARY.write_text(
"""# NMe-Ala internal-validation144 M0/residual generation summary v1

STATUS:
FORMAL M0/RESIDUAL GENERATED; INDEPENDENT POST-M0 CLOSURE REQUIRED.

States:
144/144 validation states accepted.

M0:
GAFF2 + formal RESP;
same accepted constrained-QM final geometry;
zero-step PMEMD;
no MM relaxation.

Precision:
PMEMD_PRINTED_NINE_COMPONENT_SUM.

Residual:
QM_Eh * 627.509474 - nine-component printed M0 sum.

Scientific boundary:
no validation RMSE/MAE/MaxAbs/AULC calculated;
no evaluator refit/retuning/prediction regeneration;
PPII remains sealed.

AUTHORIZED NEXT:
one independent raw-PMEMD/component/residual reconstruction and validation-label closure.
""",
    encoding="utf-8",
)


generation_members = {
    path.resolve()
    for path in OUT.rglob(
        "*"
    )
    if path.is_file()
}


generation_members.update(
    {
        Path(
            __file__
        ).resolve(),

        QM_CLOSURE.resolve(),

        SOURCE_LABEL_CLOSURE.resolve(),

        PRMTOP.resolve(),

        PMEMD.resolve(),
    }
)


if FREEZE.resolve() in generation_members:
    generation_members.remove(
        FREEZE.resolve()
    )


FREEZE.write_text(
    "\n".join(
        sha(
            path
        )
        + "  "
        + (
            str(
                path.relative_to(
                    ROOT
                )
            )
            if (
                path == ROOT
                or
                ROOT in path.parents
            )
            else
            str(
                path
            )
        )
        for path in sorted(
            generation_members,
            key=lambda path:
                str(path),
        )
    )
    + "\n",
    encoding="utf-8",
)


print(
    "MDIN SHA256 =",
    sha(
        MDIN
    ),
)

print(
    "M0 protocol SHA256 =",
    sha(
        PROTOCOL
    ),
)

print(
    "M0 results SHA256 =",
    sha(
        M0_RESULTS
    ),
)

print(
    "validation labels SHA256 =",
    sha(
        LABELS
    ),
)

print(
    "summary SHA256 =",
    sha(
        SUMMARY
    ),
)

print(
    "generation freeze entries =",
    len(
        generation_members
    ),
)

print(
    "generation freeze SHA256 =",
    sha(
        FREEZE
    ),
)


print(
    "===== 9. FINAL FORMAL VALIDATION-M0 STATE ====="
)


for path, expected in EXPECTED.items():

    if sha(
        path
    ) != expected:
        raise SystemExit(
            "[FAIL] frozen authority changed during validation M0: "
            + path.name
        )


for recorded, member in qm_closure_rows:

    if sha(
        member
    ) != recorded:
        raise SystemExit(
            "[FAIL] validation-QM closure member changed during M0: "
            + str(member)
        )


final_out_files = [
    path
    for path in OUT.rglob(
        "*"
    )
    if path.is_file()
]


print(
    "formal validation M0 tree files =",
    len(
        final_out_files
    ),
)


if len(
    final_out_files
) != 870:
    raise SystemExit(
        "[FAIL] formal validation M0 tree !=870 files"
    )


print(
    "[PASS] FORMAL INTERNAL-VALIDATION144 SAME-GEOMETRY M0 EXECUTION COMPLETE"
)

print(
    "[PASS] exact144 PMEMD zero-step states accepted"
)

print(
    "[PASS] exact144 residual labels generated"
)

print(
    "[PASS] no benchmark evaluation metric calculated"
)

print(
    "[PASS] frozen24-model/3456-prediction set remains immutable"
)

print(
    "[PASS] PPII remains SEALED"
)

print(
    "[HOLD] validation M0/residual labels are not yet SCIENTIFICALLY CLOSED"
)

print(
    "[AUTHORIZED-NEXT] independent post-M0 component/residual reconstruction and final validation-label closure"
)

print(
    "===== FORMAL INTERNAL-VALIDATION144 SAME-GEOMETRY RESP-M0 RUNNER END ====="
)
