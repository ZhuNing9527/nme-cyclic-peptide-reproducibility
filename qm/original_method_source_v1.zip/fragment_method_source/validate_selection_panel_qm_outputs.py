from pathlib import Path
from collections import Counter

import csv
import hashlib
import math
import os
import re

import numpy as np
import parmed as pmd


ROOT = Path(
    "/mnt/lab/zn/mem-perm/P0_starter_v1"
)

DEV = (
    ROOT
    / "07_nmeala_separability_pilot"
    / "13_joint_correction_development"
)

EXE = (
    DEV
    / "07_acquisition_benchmark_execution"
)


# ------------------------------------------------------------------
# Formal execution authorities
# ------------------------------------------------------------------

WRAPPER = (
    EXE
    / "run_execute_internal_validation144_qm_v1.py"
)

RUNNER = (
    EXE
    / "run_internal_validation144_qm_v1.py"
)

QC2 = (
    EXE
    / "run_qc_internal_validation144_qm_runner_v2.py"
)

PREEXEC = (
    EXE
    / "46_internal_validation144_qm_preexec"
)

QCREPORT = (
    PREEXEC
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_RUNNER_QC_v1.md"
)

RUNFREEZE = (
    PREEXEC
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_RUNNER_FREEZE_v1.sha256"
)


# ------------------------------------------------------------------
# Frozen validation identity authority
# ------------------------------------------------------------------

PRE = (
    EXE
    / "45_internal_validation144_qm_precommit"
)

MANIFEST = (
    PRE
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_EXECUTION_MANIFEST_v1.tsv"
)

VAL = (
    DEV
    / "03_internal_validation_split"
    / "NMEALA_JOINT_144_INTERNAL_VALIDATION_MANIFEST_v1.tsv"
)


# ------------------------------------------------------------------
# Formal topology
# ------------------------------------------------------------------

PRMTOP = (
    ROOT
    / "06_m0_formal_resp"
    / "03_tleap_topology"
    / "nmeala_resp_v1.prmtop"
)


# ------------------------------------------------------------------
# Formal QM output
# ------------------------------------------------------------------

OUT = (
    EXE
    / "46_internal_validation144_qm"
)

JOBS = (
    OUT
    / "jobs"
)

PROTOCOL = (
    OUT
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_PROTOCOL_v1.md"
)

RESULTS = (
    OUT
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_R2SCAN_RESULTS_v1.tsv"
)


INVENTORY = (
    OUT
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_RAW_OUTPUT_INVENTORY_v1.tsv"
)

REPORT = (
    OUT
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_POST_QM_QC_v1.md"
)

FREEZE = (
    OUT
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_CLOSURE_FREEZE_v1.sha256"
)


M0OUT = (
    EXE
    / "47_internal_validation144_m0"
)


EXPECTED = {
    WRAPPER:
        "41318deda9c3937e5b0a7fdaf51b698ec66724712ce6d8b5b94fbea1880aa80a",

    RUNNER:
        "b590d62f5317a48f346be80575a1d7382851fb10a1d50abe5b0fd1f45422f5d5",

    QC2:
        "438a3882f6fa58d7ddf92b2e62bfc3b76939e798dbcef9fa6d17bcadeb24f83f",

    QCREPORT:
        "8573393b2ccad2c03f0774022fae40d733a59a060d1611c85de0b7037511658a",

    RUNFREEZE:
        "f91035d76b56b2a5d4444f9f5cfec169226376918f536ffc46806cdce928cd13",

    MANIFEST:
        "5ca8cdd72c521e0b4e856d2bb39613058bf3fb9ed137e954ab346c2ed43a7821",

    VAL:
        "f93fc7c2b2348f1629ad41a9327d66618f90d46b31520062eed20bdf876f7f66",

    PRMTOP:
        "9b2c68fad482b03562a4b9c956dc57586bfc73384bb3a68b019e866c1275f5e6",

    PROTOCOL:
        "dba3dfed70cf29532edd831e679035a4c4b5e93266f7ff7845f47adfb17d7775",

    RESULTS:
        "346fc8e6388d70b2e9ea7b6dd9102f482236c8e98a28785940be9c71319e2ed5",
}


EXPECTED_JOB_FILES = {
    "exitcode.txt",
    "job.bibtex",
    "job.cpcm",
    "job.cpcm_corr",
    "job.densities",
    "job.densitiesinfo",
    "job.engrad",
    "job.gbw",
    "job.inp",
    "job.opt",
    "job.out",
    "job.property.txt",
    "job_trj.xyz",
    "job.xyz",
    "start.xyz",
}


RESULT_FIELDS = [
    "validation_rank",
    "state_id",
    "phi_target_deg",
    "psi_target_deg",
    "omega_target_deg",
    "start_xyz",
    "start_xyz_sha256",
    "exitcode",
    "normal_termination",
    "optimization_converged",
    "final_energy_Eh",
    "final_phi_deg",
    "final_psi_deg",
    "final_omega_deg",
    "max_constraint_error_deg",
    "start_chirality_scalar",
    "final_chirality_scalar",
    "chirality_sign_preserved",
    "max_formal_bond_A",
    "min_final_nonlocal_A",
    "final_xyz",
    "final_xyz_sha256",
    "status",
    "failure_reason",
]


ENERGY_RE = re.compile(
    r"FINAL SINGLE POINT ENERGY\s+(-?\d+\.\d+)"
)


def sha(path):
    h = hashlib.sha256()

    with Path(path).open(
        "rb"
    ) as fh:

        for block in iter(
            lambda: fh.read(
                1048576
            ),
            b"",
        ):
            h.update(
                block
            )

    return h.hexdigest()


def rel(path):
    path = Path(path)

    try:
        return str(
            path.relative_to(
                ROOT
            )
        )

    except ValueError:
        return str(path)


def resolve(raw):
    path = Path(
        str(raw).strip()
    )

    if path.is_absolute():
        return path

    return ROOT / path


def read_tsv(path):
    with Path(path).open(
        "r",
        encoding="utf-8",
        newline="",
    ) as fh:

        reader = csv.DictReader(
            fh,
            delimiter="\t",
        )

        return (
            list(reader.fieldnames),
            list(reader),
        )


def read_xyz(path):
    lines = Path(path).read_text(
        encoding="utf-8"
    ).splitlines()

    natoms = int(
        lines[
            0
        ].strip()
    )

    symbols = []
    coordinates = []

    for line in lines[
        2:
        2 + natoms
    ]:

        fields = line.split()

        symbols.append(
            fields[
                0
            ]
        )

        coordinates.append(
            [
                float(
                    fields[
                        1
                    ]
                ),
                float(
                    fields[
                        2
                    ]
                ),
                float(
                    fields[
                        3
                    ]
                ),
            ]
        )

    return (
        symbols,
        np.asarray(
            coordinates,
            dtype=float,
        ),
    )


def independent_dihedral(
    coordinates,
    i,
    j,
    k,
    l,
):
    p0 = coordinates[i]
    p1 = coordinates[j]
    p2 = coordinates[k]
    p3 = coordinates[l]

    b0 = p0 - p1
    b1 = p2 - p1
    b2 = p3 - p2

    b1 = (
        b1
        /
        np.linalg.norm(
            b1
        )
    )

    v = (
        b0
        -
        np.dot(
            b0,
            b1,
        )
        *
        b1
    )

    w = (
        b2
        -
        np.dot(
            b2,
            b1,
        )
        *
        b1
    )

    v = (
        v
        /
        np.linalg.norm(
            v
        )
    )

    w = (
        w
        /
        np.linalg.norm(
            w
        )
    )

    cosine = np.clip(
        np.dot(
            v,
            w,
        ),
        -1.0,
        1.0,
    )

    sine = np.dot(
        np.cross(
            b1,
            v,
        ),
        w,
    )

    return math.degrees(
        math.atan2(
            sine,
            cosine,
        )
    )


def periodic_error(
    observed,
    target,
):
    return abs(
        (
            observed
            -
            target
            +
            180.0
        )
        %
        360.0
        -
        180.0
    )


def independent_chirality(
    coordinates,
):
    ca = coordinates[
        5
    ]

    return float(
        np.dot(
            np.cross(
                coordinates[
                    3
                ]
                -
                ca,
                coordinates[
                    7
                ]
                -
                ca,
            ),
            coordinates[
                6
            ]
            -
            ca,
        )
    )


def rehash_freeze(
    path,
    expected_count,
):
    rows = []

    for line in Path(path).read_text(
        encoding="utf-8"
    ).splitlines():

        if not line.strip():
            continue

        parts = line.split(
            maxsplit=1
        )

        if len(parts) != 2:
            raise RuntimeError(
                "malformed freeze line: "
                + str(path)
            )

        recorded, raw = parts

        member = resolve(
            raw
        ).resolve()

        if not member.is_file():
            raise RuntimeError(
                "freeze member missing: "
                + str(member)
            )

        if sha(
            member
        ) != recorded:
            raise RuntimeError(
                "freeze member changed: "
                + str(member)
            )

        rows.append(
            (
                recorded,
                member,
            )
        )

    if len(
        rows
    ) != expected_count:
        raise RuntimeError(
            "freeze entry count differs: "
            + str(path)
        )

    if len({
        member
        for _, member
        in rows
    }) != expected_count:
        raise RuntimeError(
            "duplicate freeze member"
        )

    return rows


print(
    "===== 401KV INDEPENDENT INTERNAL-VALIDATION144 POST-QM CLOSURE ====="
)

print(
    "CONDA_DEFAULT_ENV =",
    os.environ.get(
        "CONDA_DEFAULT_ENV"
    ),
)

print(
    "PYTHONPATH =",
    os.environ.get(
        "PYTHONPATH"
    ),
)


if os.environ.get(
    "CONDA_DEFAULT_ENV"
) != "nme-torsion-p0":
    raise SystemExit(
        "[FAIL] wrong environment"
    )


if os.environ.get(
    "PYTHONPATH"
) is not None:
    raise SystemExit(
        "[FAIL] PYTHONPATH must be unset"
    )


if INVENTORY.exists():
    raise SystemExit(
        "[FAIL] raw inventory already exists"
    )

if REPORT.exists():
    raise SystemExit(
        "[FAIL] post-QM closure report already exists"
    )

if FREEZE.exists():
    raise SystemExit(
        "[FAIL] QM closure freeze already exists"
    )

if M0OUT.exists():
    raise SystemExit(
        "[FAIL] validation M0 exists before QM closure"
    )


print(
    "===== 1. VERIFY EXACT FORMAL EXECUTION AUTHORITIES ====="
)


for path, expected in EXPECTED.items():

    if not path.is_file():
        raise SystemExit(
            "[FAIL] formal authority missing: "
            + str(path)
        )

    actual = sha(
        path
    )

    print(path.name)
    print(" expected =", expected)
    print(" actual   =", actual)

    if actual != expected:
        raise SystemExit(
            "[FAIL] formal authority SHA mismatch: "
            + path.name
        )


print(
    "[PASS] exact formal execution/QM-result authorities verified"
)


print(
    "===== 2. REHASH31 PREEXECUTION EXECUTION AUTHORITIES ====="
)


runfreeze_rows = rehash_freeze(
    RUNFREEZE,
    31,
)


print(
    "execution-freeze entries =",
    len(
        runfreeze_rows
    ),
)


print(
    "[PASS] all31 frozen preexecution authorities independently rehashed"
)


print(
    "===== 3. SNAPSHOT PRE-CLOSURE FORMAL QM RAW TREE ====="
)


original_files = sorted(
    [
        path.resolve()
        for path in OUT.rglob(
            "*"
        )
        if path.is_file()
    ],
    key=lambda path:
        str(path),
)


print(
    "pre-closure formal QM tree files =",
    len(
        original_files
    ),
)


if len(
    original_files
) != 2162:
    raise SystemExit(
        "[FAIL] pre-closure validation QM tree !=2162 files"
    )


original_snapshot = {
    path:
        sha(
            path
        )
    for path in original_files
}


print(
    "[PASS] exact2162-file pre-closure raw tree SHA snapshot captured"
)


print(
    "===== 4. LOAD EXACT144 MANIFEST / FORMAL RESULTS ====="
)


manifest_fields, manifest_rows = read_tsv(
    MANIFEST
)

result_fields, formal_rows = read_tsv(
    RESULTS
)


if result_fields != RESULT_FIELDS:
    raise SystemExit(
        "[FAIL] formal validation RESULTS schema differs"
    )


if len(
    manifest_rows
) != 144:
    raise SystemExit(
        "[FAIL] execution manifest rows !=144"
    )


if len(
    formal_rows
) != 144:
    raise SystemExit(
        "[FAIL] formal QM results rows !=144"
    )


manifest_rows.sort(
    key=lambda row:
        int(
            row[
                "validation_rank"
            ]
        )
)

formal_rows.sort(
    key=lambda row:
        int(
            row[
                "validation_rank"
            ]
        )
)


expected_ranks = list(
    range(
        1,
        145,
    )
)


if [
    int(
        row[
            "validation_rank"
        ]
    )
    for row in manifest_rows
] != expected_ranks:
    raise SystemExit(
        "[FAIL] manifest ranks !=1..144"
    )


if [
    int(
        row[
            "validation_rank"
        ]
    )
    for row in formal_rows
] != expected_ranks:
    raise SystemExit(
        "[FAIL] result ranks !=1..144"
    )


manifest_ids = [
    row[
        "state_id"
    ]
    for row in manifest_rows
]


result_ids = [
    row[
        "state_id"
    ]
    for row in formal_rows
]


if manifest_ids != result_ids:
    raise SystemExit(
        "[FAIL] formal QM result identities/order differ from manifest"
    )


if len(
    set(
        manifest_ids
    )
) != 144:
    raise SystemExit(
        "[FAIL] duplicate validation identity"
    )


print(
    "[PASS] exact144 frozen validation identities/ranks recovered"
)


print(
    "===== 5. VERIFY EXACT144 JOB DIRECTORY / EXACT15-FILE SURFACE ====="
)


job_dirs = sorted(
    [
        path
        for path in JOBS.iterdir()
        if path.is_dir()
    ],
    key=lambda path:
        path.name,
)


if len(
    job_dirs
) != 144:
    raise SystemExit(
        "[FAIL] validation job directories !=144"
    )


if {
    path.name
    for path in job_dirs
} != set(
    manifest_ids
):
    raise SystemExit(
        "[FAIL] validation job identity set differs"
    )


files_directly_under_jobs = [
    path
    for path in JOBS.iterdir()
    if path.is_file()
]


print(
    "files directly under jobs/ =",
    [
        path.name
        for path in files_directly_under_jobs
    ],
)


if files_directly_under_jobs:
    raise SystemExit(
        "[FAIL] unexpected files directly under jobs/"
    )


per_job_counts = set()


for job_dir in job_dirs:

    actual = {
        path.name
        for path in job_dir.iterdir()
        if path.is_file()
    }

    per_job_counts.add(
        len(
            actual
        )
    )

    if actual != EXPECTED_JOB_FILES:

        print(
            "job artifact mismatch:",
            job_dir.name,
        )

        print(
            "missing =",
            sorted(
                EXPECTED_JOB_FILES
                -
                actual
            ),
        )

        print(
            "extra =",
            sorted(
                actual
                -
                EXPECTED_JOB_FILES
            ),
        )

        raise SystemExit(
            "[FAIL] exact ORCA job artifact set differs"
        )


print(
    "per-job file-count set =",
    sorted(
        per_job_counts
    ),
)


if per_job_counts != {
    15
}:
    raise SystemExit(
        "[FAIL] validation per-job file count !=15"
    )


print(
    "[PASS] exact144 job directories /15 files per job recovered"
)


print(
    "===== 6. LOAD FORMAL CONNECTIVITY INDEPENDENTLY ====="
)


parm = pmd.load_file(
    str(
        PRMTOP
    )
)


if len(
    parm.atoms
) != 25:
    raise SystemExit(
        "[FAIL] topology atoms !=25"
    )


if len(
    parm.bonds
) != 24:
    raise SystemExit(
        "[FAIL] topology bonds !=24"
    )


bonded = {
    tuple(
        sorted(
            (
                bond.atom1.idx,
                bond.atom2.idx,
            )
        )
    )
    for bond in parm.bonds
}


graph = {
    i:
        set()
    for i in range(
        25
    )
}


for i, j in bonded:

    graph[
        i
    ].add(
        j
    )

    graph[
        j
    ].add(
        i
    )


one3 = set()


for center in range(
    25
):

    neighbors = sorted(
        graph[
            center
        ]
    )

    for a in range(
        len(
            neighbors
        )
    ):

        for b in range(
            a + 1,
            len(
                neighbors
            ),
        ):

            one3.add(
                tuple(
                    sorted(
                        (
                            neighbors[
                                a
                            ],
                            neighbors[
                                b
                            ],
                        )
                    )
                )
            )


zsym = {
    1:
        "H",

    6:
        "C",

    7:
        "N",

    8:
        "O",
}


formal_symbols = [
    zsym[
        atom.atomic_number
    ]
    for atom in parm.atoms
]


print(
    "formal atoms =",
    len(
        formal_symbols
    ),
)

print(
    "formal bonds =",
    len(
        bonded
    ),
)


print(
    "[PASS] formal25-atom/24-bond topology independently loaded"
)


print(
    "===== 7. INDEPENDENTLY RECONSTRUCT ALL144 RAW QM RESULTS ====="
)


reconstructed = []

max_constraint = 0.0
max_bond_global = 0.0
min_nonlocal_global = math.inf

energy_deltas = []


for manifest_row, formal_row in zip(
    manifest_rows,
    formal_rows,
):

    rank = int(
        manifest_row[
            "validation_rank"
        ]
    )

    sid = manifest_row[
        "state_id"
    ]

    job_dir = (
        JOBS
        /
        sid
    )


    start_path = (
        job_dir
        /
        "start.xyz"
    )

    final_path = (
        job_dir
        /
        "job.xyz"
    )

    output_path = (
        job_dir
        /
        "job.out"
    )

    exitcode_path = (
        job_dir
        /
        "exitcode.txt"
    )

    input_path = (
        job_dir
        /
        "job.inp"
    )


    manifest_start = resolve(
        manifest_row[
            "start_xyz"
        ]
    ).resolve()


    if sha(
        manifest_start
    ) != manifest_row[
        "start_xyz_sha256"
    ]:
        raise SystemExit(
            "[FAIL] locked manifest start SHA changed: "
            + sid
        )


    if sha(
        start_path
    ) != manifest_row[
        "start_xyz_sha256"
    ]:
        raise SystemExit(
            "[FAIL] copied start differs from frozen source: "
            + sid
        )


    target_phi = float(
        manifest_row[
            "phi_target_deg"
        ]
    )

    target_psi = float(
        manifest_row[
            "psi_target_deg"
        ]
    )

    target_omega = float(
        manifest_row[
            "omega_target_deg"
        ]
    )


    expected_input = (
        "! r2SCAN-3c TightSCF TightOpt CPCM(Water)\n"
        "%pal nprocs 8 end\n"
        "%maxcore 2500\n"
        "%geom\n"
        " MaxIter 300\n"
        " Constraints\n"
        f"  {{ D 0 1 3 5 {target_omega:9.3f} C }}\n"
        f"  {{ D 1 3 5 7 {target_phi:9.3f} C }}\n"
        f"  {{ D 3 5 7 9 {target_psi:9.3f} C }}\n"
        " end\n"
        "end\n"
        "* xyzfile 0 1 start.xyz\n"
    )


    actual_input = input_path.read_text(
        encoding="utf-8"
    )


    if actual_input != expected_input:
        raise SystemExit(
            "[FAIL] ORCA input differs from frozen semantic template: "
            + sid
        )


    exitcode = exitcode_path.read_text(
        encoding="utf-8"
    ).strip()


    output_text = output_path.read_text(
        encoding="utf-8",
        errors="replace",
    )


    normal = (
        "ORCA TERMINATED NORMALLY"
        in output_text
    )

    converged = (
        "THE OPTIMIZATION HAS CONVERGED"
        in output_text
    )


    energy_hits = ENERGY_RE.findall(
        output_text
    )


    energy = (
        energy_hits[
            -1
        ]
        if energy_hits
        else ""
    )


    reasons = []

    phi = None
    psi = None
    omega = None

    maxerr = None

    start_chi = None
    final_chi = None
    chirality_ok = False

    max_bond = None
    min_nonlocal = None


    if (
        start_path.is_file()
        and
        final_path.is_file()
    ):

        start_symbols, start_xyz = read_xyz(
            start_path
        )

        final_symbols, final_xyz = read_xyz(
            final_path
        )


        if (
            start_symbols != formal_symbols
            or
            final_symbols != formal_symbols
            or
            start_symbols != final_symbols
        ):

            reasons.append(
                "ATOM_ORDER_MISMATCH"
            )


        if (
            len(
                start_xyz
            ) == 25
            and
            len(
                final_xyz
            ) == 25
        ):

            omega = independent_dihedral(
                final_xyz,
                0,
                1,
                3,
                5,
            )

            phi = independent_dihedral(
                final_xyz,
                1,
                3,
                5,
                7,
            )

            psi = independent_dihedral(
                final_xyz,
                3,
                5,
                7,
                9,
            )


            maxerr = max(
                periodic_error(
                    omega,
                    target_omega,
                ),
                periodic_error(
                    phi,
                    target_phi,
                ),
                periodic_error(
                    psi,
                    target_psi,
                ),
            )


            start_chi = independent_chirality(
                start_xyz
            )

            final_chi = independent_chirality(
                final_xyz
            )


            chirality_ok = (
                abs(
                    start_chi
                ) > 1.0e-6
                and
                abs(
                    final_chi
                ) > 1.0e-6
                and
                start_chi
                *
                final_chi
                > 0.0
            )


            max_bond = max(
                float(
                    np.linalg.norm(
                        final_xyz[
                            i
                        ]
                        -
                        final_xyz[
                            j
                        ]
                    )
                )
                for i, j
                in bonded
            )


            distances = []


            for i in range(
                25
            ):

                for j in range(
                    i + 1,
                    25,
                ):

                    pair = (
                        i,
                        j,
                    )

                    if pair in bonded:
                        continue

                    if pair in one3:
                        continue


                    distances.append(
                        float(
                            np.linalg.norm(
                                final_xyz[
                                    i
                                ]
                                -
                                final_xyz[
                                    j
                                ]
                            )
                        )
                    )


            min_nonlocal = min(
                distances
            )


    if exitcode != "0":
        reasons.append(
            "NONZERO_EXIT"
        )

    if not normal:
        reasons.append(
            "NO_NORMAL_TERMINATION"
        )

    if not converged:
        reasons.append(
            "OPT_NOT_CONVERGED"
        )

    if not final_path.is_file():
        reasons.append(
            "NO_FINAL_XYZ"
        )

    if not energy:
        reasons.append(
            "NO_FINAL_ENERGY"
        )

    if (
        maxerr is None
        or
        maxerr > 0.10
    ):
        reasons.append(
            "TORSION_GATE"
        )

    if not chirality_ok:
        reasons.append(
            "CHIRALITY_NOT_PRESERVED"
        )

    if (
        max_bond is None
        or
        max_bond >= 1.90
    ):
        reasons.append(
            "FORMAL_BOND_GATE"
        )

    if (
        min_nonlocal is None
        or
        min_nonlocal < 0.75
    ):
        reasons.append(
            "NONLOCAL_GATE"
        )


    status = (
        "PASS"
        if not reasons
        else
        "HOLD"
    )


    reconstructed_row = {
        "validation_rank":
            manifest_row[
                "validation_rank"
            ],

        "state_id":
            sid,

        "phi_target_deg":
            manifest_row[
                "phi_target_deg"
            ],

        "psi_target_deg":
            manifest_row[
                "psi_target_deg"
            ],

        "omega_target_deg":
            manifest_row[
                "omega_target_deg"
            ],

        "start_xyz":
            str(
                start_path
            ),

        "start_xyz_sha256":
            sha(
                start_path
            ),

        "exitcode":
            exitcode,

        "normal_termination":
            str(
                normal
            ),

        "optimization_converged":
            str(
                converged
            ),

        "final_energy_Eh":
            energy,

        "final_phi_deg":
            (
                ""
                if phi is None
                else
                f"{phi:+.8f}"
            ),

        "final_psi_deg":
            (
                ""
                if psi is None
                else
                f"{psi:+.8f}"
            ),

        "final_omega_deg":
            (
                ""
                if omega is None
                else
                f"{omega:+.8f}"
            ),

        "max_constraint_error_deg":
            (
                ""
                if maxerr is None
                else
                f"{maxerr:.8f}"
            ),

        "start_chirality_scalar":
            (
                ""
                if start_chi is None
                else
                f"{start_chi:+.10f}"
            ),

        "final_chirality_scalar":
            (
                ""
                if final_chi is None
                else
                f"{final_chi:+.10f}"
            ),

        "chirality_sign_preserved":
            str(
                chirality_ok
            ),

        "max_formal_bond_A":
            (
                ""
                if max_bond is None
                else
                f"{max_bond:.8f}"
            ),

        "min_final_nonlocal_A":
            (
                ""
                if min_nonlocal is None
                else
                f"{min_nonlocal:.8f}"
            ),

        "final_xyz":
            (
                str(
                    final_path
                )
                if final_path.is_file()
                else
                ""
            ),

        "final_xyz_sha256":
            (
                sha(
                    final_path
                )
                if final_path.is_file()
                else
                ""
            ),

        "status":
            status,

        "failure_reason":
            ",".join(
                reasons
            ),
    }


    reconstructed.append(
        reconstructed_row
    )


    if energy:

        parsed_energy = float(
            energy
        )

        formal_energy = float(
            formal_row[
                "final_energy_Eh"
            ]
        )

        delta = abs(
            parsed_energy
            -
            formal_energy
        )

        energy_deltas.append(
            delta
        )


    if maxerr is not None:

        max_constraint = max(
            max_constraint,
            maxerr,
        )


    if max_bond is not None:

        max_bond_global = max(
            max_bond_global,
            max_bond,
        )


    if min_nonlocal is not None:

        min_nonlocal_global = min(
            min_nonlocal_global,
            min_nonlocal,
        )


    print(
        "STATE",
        rank,
        sid,
        "status=",
        status,
        "E=",
        energy or "NA",
        "maxerr=",
        (
            "NA"
            if maxerr is None
            else
            f"{maxerr:.8e}"
        ),
    )


print(
    "[PASS] independently reconstructed144 QM rows directly from raw outputs"
)


print(
    "===== 8. COMPARE FORMAL RESULTS TSV FIELD-BY-FIELD ====="
)


mismatches = []


for formal_row, rebuilt_row in zip(
    formal_rows,
    reconstructed,
):

    sid = formal_row[
        "state_id"
    ]

    for field in RESULT_FIELDS:

        if (
            formal_row[
                field
            ]
            !=
            rebuilt_row[
                field
            ]
        ):

            mismatches.append(
                (
                    sid,
                    field,
                    formal_row[
                        field
                    ],
                    rebuilt_row[
                        field
                    ],
                )
            )


print(
    "field-level mismatches =",
    len(
        mismatches
    ),
)


if mismatches:

    for item in mismatches[
        :20
    ]:
        print(
            "MISMATCH",
            item,
        )

    raise SystemExit(
        "[FAIL] formal RESULTS differs from independent raw reconstruction"
    )


print(
    "[PASS] formal RESULTS TSV exactly equals independent reconstruction"
)


print(
    "===== 9. INDEPENDENT SCIENTIFIC ACCEPTANCE SUMMARY ====="
)


status_counts = Counter(
    row[
        "status"
    ]
    for row in reconstructed
)


print(
    "independent status counts =",
    dict(
        status_counts
    ),
)


print(
    "independent maximum torsion error =",
    f"{max_constraint:.12e}",
    "deg",
)


print(
    "independent maximum formal bond =",
    f"{max_bond_global:.8f}",
    "A",
)


print(
    "independent minimum nonlocal distance =",
    f"{min_nonlocal_global:.8f}",
    "A",
)


print(
    "maximum formal-vs-raw energy delta =",
    f"{max(energy_deltas):.12e}",
    "Eh",
)


if status_counts != Counter(
    {
        "PASS":
            144
    }
):
    raise SystemExit(
        "[FAIL] independent scientific acceptance !=PASS144"
    )


if max(
    energy_deltas
) > 5.0e-10:
    raise SystemExit(
        "[FAIL] formal energy differs from raw final energy"
    )


print(
    "[PASS] 144/144 raw ORCA outputs independently accepted"
)

print(
    "[PASS] 144/144 final energies independently reparsed"
)

print(
    "[PASS] 144/144 phi/psi/omega values independently recomputed"
)

print(
    "[PASS] 144/144 chirality/bond/nonlocal gates independently recomputed"
)

print(
    "[PASS] exact ORCA-input scientific semantics independently verified"
)


print(
    "===== 10. CLASSIFY NON-OPERATIVE PROGRESS-DISPLAY ANOMALY ====="
)


wrapper_logical_authority = (
    "Formal results and job exitcode files"
)


print(
    "observed progress-display anomaly = "
    "EXIT((state_id,0))-style tuple text instead of EXIT0"
)


print(
    "scientific authority for exit status =",
    wrapper_logical_authority,
)


if any(
    row[
        "exitcode"
    ] != "0"
    for row in reconstructed
):
    raise SystemExit(
        "[FAIL] progress anomaly cannot be classified because a raw exitcode is nonzero"
    )


print(
    "[CLASSIFICATION] progress-display tuple formatting is non-operative only"
)

print(
    "[PASS] all144 raw exitcode.txt values independently equal0"
)

print(
    "[PASS] no ORCA rerun is scientifically justified"
)


print(
    "===== 11. M0 / METRIC / PPII BOUNDARY ====="
)


if M0OUT.exists():
    raise SystemExit(
        "[FAIL] validation M0 appeared before QM closure"
    )


print(
    "[PASS] validation same-geometry M0 remains absent"
)

print(
    "[PASS] validation residual remains unavailable"
)

print(
    "[PASS] no RMSE/MAE/AULC evaluated"
)

print(
    "[PASS] frozen predictions remain untouched"
)

print(
    "[PASS] PPII remains SEALED"
)


print(
    "===== 12. WRITE EXACT2162 RAW-OUTPUT INVENTORY ====="
)


with INVENTORY.open(
    "w",
    encoding="utf-8",
    newline="",
) as fh:

    writer = csv.DictWriter(
        fh,
        fieldnames=[
            "relative_path",
            "sha256",
            "bytes",
        ],
        delimiter="\t",
        lineterminator="\n",
    )

    writer.writeheader()


    for path in original_files:

        writer.writerow(
            {
                "relative_path":
                    rel(
                        path
                    ),

                "sha256":
                    original_snapshot[
                        path
                    ],

                "bytes":
                    str(
                        path.stat().st_size
                    ),
            }
        )


inventory_fields, inventory_rows = read_tsv(
    INVENTORY
)


if inventory_fields != [
    "relative_path",
    "sha256",
    "bytes",
]:
    raise SystemExit(
        "[FAIL] raw inventory schema differs"
    )


if len(
    inventory_rows
) != 2162:
    raise SystemExit(
        "[FAIL] raw inventory rows !=2162"
    )


print(
    "raw inventory rows =",
    len(
        inventory_rows
    ),
)

print(
    "raw inventory SHA256 =",
    sha(
        INVENTORY
    ),
)


print(
    "[PASS] exact2162 pre-QC formal QM files inventoried"
)


print(
    "===== 13. PROVE ALL2162 ORIGINAL QM FILES REMAIN BYTE-IDENTICAL ====="
)


for path, expected_sha in original_snapshot.items():

    if not path.is_file():
        raise SystemExit(
            "[FAIL] original QM artifact disappeared: "
            + str(path)
        )

    if sha(
        path
    ) != expected_sha:
        raise SystemExit(
            "[FAIL] original QM artifact changed: "
            + str(path)
        )


print(
    "[PASS] all2162 original formal QM files remain byte-identical"
)


print(
    "===== 14. WRITE SCIENTIFIC POST-QM CLOSURE REPORT ====="
)


report_lines = [
    "# NMe-Ala internal-validation144 post-QM closure QC v1",
    "",
    "STATUS: SCIENTIFICALLY CLOSED / SAME-GEOMETRY M0 AUTHORIZED NEXT.",
    "",
    "Formal QM execution:",
    "- wrapper SHA256 = "
    + EXPECTED[
        WRAPPER
    ]
    + ";",
    "- runner SHA256 = "
    + EXPECTED[
        RUNNER
    ]
    + ";",
    "- preexecution runner freeze SHA256 = "
    + EXPECTED[
        RUNFREEZE
    ]
    + ";",
    "- protocol SHA256 = "
    + EXPECTED[
        PROTOCOL
    ]
    + ";",
    "- results SHA256 = "
    + EXPECTED[
        RESULTS
    ]
    + ".",
    "",
    "Formal state:",
    "- exact validation states =144;",
    "- formal PASS =144/144;",
    "- formal result order = validation ranks1-144;",
    "- no state substitution;",
    "- no retry or post-result scientific repair.",
    "",
    "Independent reconstruction:",
    "- all144 raw job.out files reparsed;",
    "- all144 exitcode.txt files independently verified;",
    "- all144 job.inp files compared to the frozen r2SCAN-3c restraint template;",
    "- all144 final energies independently reparsed;",
    "- all144 phi/psi/omega values independently recomputed;",
    "- all144 torsion-target errors independently recomputed;",
    "- all144 chirality signs independently recomputed;",
    "- all144 formal-bond and nonlocal-distance gates independently recomputed;",
    "- formal RESULTS TSV reproduced exactly field-by-field.",
    "",
    "Independent acceptance:",
    "- status = PASS144/144;",
    "- maximum torsion-target error = "
    + f"{max_constraint:.12e}"
    + " degree;",
    "- maximum formal bond = "
    + f"{max_bond_global:.8f}"
    + " A;",
    "- minimum nonlocal distance = "
    + f"{min_nonlocal_global:.8f}"
    + " A;",
    "- maximum raw/formal energy discrepancy = "
    + f"{max(energy_deltas):.12e}"
    + " Eh.",
    "",
    "Raw-output immutability:",
    "- ORCA job directories =144;",
    "- exact files per job =15;",
    "- original formal QM files before closure writes =2162;",
    "- all2162 original files SHA-snapshotted before QC writes;",
    "- all2162 remained byte-identical;",
    "- immutable raw-output inventory generated.",
    "",
    "Non-operative anomaly:",
    "- formal execution progress display rendered tuple-style EXIT((state_id,0)) text rather than EXIT0;",
    "- raw exitcode.txt values are independently0 for all144 states;",
    "- formal RESULTS and wrapper acceptance use the raw result surface;",
    "- this is therefore a progress-display formatting anomaly only;",
    "- it does not alter any QM energy, geometry, identity, acceptance gate, or frozen prediction;",
    "- no ORCA rerun is justified.",
    "",
    "Current scientific boundary:",
    "- constrained validation QM truth is now scientifically CLOSED;",
    "- same-geometry RESP M0 has not been generated;",
    "- QM-minus-M0 residual labels do not yet exist;",
    "- no benchmark RMSE/MAE/MaxAbs/AULC has been evaluated;",
    "- no evaluator refit/retuning/prediction regeneration is permitted;",
    "- PPII remains sealed.",
    "",
    "AUTHORIZED NEXT:",
    "- prepare the exact same-geometry zero-step RESP-M0 runner for all144 accepted QM final geometries;",
    "- independently freeze that M0 runner before PMEMD execution;",
    "- do not calculate acquisition benchmark metrics until M0/residual labels are scientifically closed.",
]


REPORT.write_text(
    "\n".join(
        report_lines
    )
    + "\n",
    encoding="utf-8",
)


print(
    "post-QM closure report SHA256 =",
    sha(
        REPORT
    ),
)


print(
    "===== 15. WRITE VALIDATION144 QM SCIENTIFIC CLOSURE FREEZE ====="
)


external_members = {
    WRAPPER.resolve(),
    RUNNER.resolve(),
    QC2.resolve(),
    QCREPORT.resolve(),
    RUNFREEZE.resolve(),
}


closure_members = set(
    original_files
)


closure_members.update(
    external_members
)


closure_members.update(
    {
        Path(
            __file__
        ).resolve(),

        INVENTORY.resolve(),

        REPORT.resolve(),
    }
)


print(
    "original raw members =",
    len(
        original_files
    ),
)

print(
    "external execution members =",
    len(
        external_members
    ),
)

print(
    "QM closure freeze entries =",
    len(
        closure_members
    ),
)


if len(
    closure_members
) != 2170:
    raise SystemExit(
        "[FAIL] validation144 QM closure freeze !=2170 entries"
    )


FREEZE.write_text(
    "\n".join(
        sha(
            path
        )
        + "  "
        + rel(
            path
        )
        for path in sorted(
            closure_members,
            key=lambda path:
                str(path),
        )
    )
    + "\n",
    encoding="utf-8",
)


print(
    "QM closure freeze SHA256 =",
    sha(
        FREEZE
    ),
)


print(
    "===== 16. FINAL IMMUTABILITY / SCIENTIFIC CLOSURE ====="
)


for path, expected in EXPECTED.items():

    if sha(
        path
    ) != expected:
        raise SystemExit(
            "[FAIL] formal authority changed during401KV: "
            + path.name
        )


for recorded, member in runfreeze_rows:

    if sha(
        member
    ) != recorded:
        raise SystemExit(
            "[FAIL] execution-freeze member changed during401KV: "
            + str(member)
        )


for path, expected_sha in original_snapshot.items():

    if sha(
        path
    ) != expected_sha:
        raise SystemExit(
            "[FAIL] original formal QM artifact changed during401KV: "
            + str(path)
        )


closure_rows = rehash_freeze(
    FREEZE,
    2170,
)


final_files = [
    path
    for path in OUT.rglob(
        "*"
    )
    if path.is_file()
]


print(
    "final validation QM directory files =",
    len(
        final_files
    ),
)


if len(
    final_files
) != 2165:
    raise SystemExit(
        "[FAIL] final validation QM directory !=2165 files"
    )


if M0OUT.exists():
    raise SystemExit(
        "[FAIL] validation M0 appeared during QM closure"
    )


print(
    "[PASS] INTERNAL-VALIDATION144 QM SCIENTIFICALLY CLOSED"
)

print(
    "[PASS] exact144 raw ORCA results independently reconstructed"
)

print(
    "[PASS] formal RESULTS TSV independently reproduced field-for-field"
)

print(
    "[PASS] energies/torsions/chirality/bonds/nonlocal metrics independently reproduced"
)

print(
    "[PASS] exact144 x15 ORCA job artifact surface verified"
)

print(
    "[PASS] exact2162 original formal QM files inventoried/frozen"
)

print(
    "[PASS] all2162 original formal QM files remained immutable"
)

print(
    "[PASS] progress-display tuple anomaly classified as non-operative only"
)

print(
    "[PASS] no ORCA/QM rerun occurred"
)

print(
    "[PASS] no M0/residual/benchmark metric execution occurred"
)

print(
    "[PASS] frozen evaluator predictions remain immutable"
)

print(
    "[PASS] PPII remains SEALED"
)

print(
    "[AUTHORIZED-NEXT] prepare/freeze exact144 same-geometry zero-step RESP-M0 runner"
)

print(
    "401KV QC script SHA256 =",
    sha(
        Path(
            __file__
        )
    ),
)

print(
    "===== 401KV-INTERNAL-VALIDATION144-INDEPENDENT-POST-QM-CLOSURE-v1 END ====="
)
