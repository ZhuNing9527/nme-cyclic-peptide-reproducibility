from pathlib import Path
import csv
import hashlib
import math
import os
import re

import numpy as np
import parmed as pmd

ROOT = Path("/mnt/lab/zn/mem-perm/P0_starter_v1")

DEV = (
    ROOT
    / "07_nmeala_separability_pilot"
    / "13_joint_correction_development"
)

AL = DEV / "06_gp_active_learning"

WRAP = AL / "run_execute_gp_batch08_qm_authorized_v1.py"
RUNNER = AL / "run_batch08_qm_v1.py"

QC2 = AL / "run_qc_gp_batch08_qm_preexecution_v2.py"
QC2_REPORT = AL / "NMEALA_JOINT_GP_BATCH08_QM_PREEXEC_QC_v2.md"
QC2_FREEZE = AL / "NMEALA_JOINT_GP_BATCH08_QM_PREEXEC_QC_FREEZE_v2.sha256"

PRE_PROTOCOL = AL / "NMEALA_JOINT_GP_BATCH08_QM_PROTOCOL_PRECOMMIT_v1.md"
PRECOMMIT = AL / "NMEALA_JOINT_GP_BATCH08_QM_PRECOMMIT_v1.sha256"

SEL = (
    AL
    / "30_batch08_selection"
    / "NMEALA_JOINT_GP_BATCH08_24_SELECTION_v1.tsv"
)

SEL_FREEZE = (
    AL
    / "30_batch08_selection"
    / "NMEALA_JOINT_GP_BATCH08_SELECTION_FREEZE_v1.sha256"
)

QM = AL / "31_batch08_qm"

PROTOCOL = QM / "NMEALA_JOINT_GP_BATCH08_QM_PROTOCOL_v1.md"
RESULTS = QM / "NMEALA_JOINT_GP_BATCH08_R2SCAN_RESULTS_v1.tsv"

PRMTOP = (
    ROOT
    / "06_m0_formal_resp"
    / "03_tleap_topology"
    / "nmeala_resp_v1.prmtop"
)

M0 = AL / "32_batch08_m0"

REPORT = AL / "NMEALA_JOINT_GP_BATCH08_QM_POSTEXEC_CLOSURE_v2.md"
FREEZE = AL / "NMEALA_JOINT_GP_BATCH08_QM_POSTEXEC_CLOSURE_FREEZE_v2.sha256"

EXPECTED = {
    WRAP:
        "33f2fe1f58943255dc544564c1c6af62d44b49b50a329eafa180683df3dd9118",

    RUNNER:
        "0d8fc7e5a1770097824f1f4777d7f27645dca13d471af3014b7de1b922acd5be",

    QC2:
        "808523979c55b09ea3420086e6e0742e277587cf81e9d5cccd35dd841db4290c",

    QC2_REPORT:
        "92b4186f96b524da5dd164f689ec0fe3beeead347dda0b3c9be3efe98a938020",

    QC2_FREEZE:
        "0779996c27b87de4277c28ac1b5e298e8964a7b75b1c6912dc2d6c9a32baaac5",

    PRE_PROTOCOL:
        "b0ee82abe82ed0429402bd413242d6244ce43a94f86e2cc8e410e1aa193742ab",

    PRECOMMIT:
        "4be5e791f92dd61c86570ffd0f4f63af076c66d7629f71c0174af87903aac48d",

    SEL:
        "4e274b1b8fcbaa88015d4481d20a72fb011a52a98773eb811acaec5713703171",

    SEL_FREEZE:
        "71cd2dcdad908b23547404184dc4aa1227e3c5672a070a6831a39fa82a1b8052",

    PRMTOP:
        "9b2c68fad482b03562a4b9c956dc57586bfc73384bb3a68b019e866c1275f5e6",

    PROTOCOL:
        "b0ee82abe82ed0429402bd413242d6244ce43a94f86e2cc8e410e1aa193742ab",

    RESULTS:
        "2436545ccb2fb0b53353465b714b8b9d2f04628478d6270c5125890585e13d12",
}

EXPECTED_JOB_FILES = {
    "exitcode.txt",
    "job.bibtex",
    "job.cpcm",
    "job.cpcm_corr",
    "job.densities",
    "job.densitiesinfo",
    "job.engrad",
    "job.gbw",
    "job.inp",
    "job.opt",
    "job.out",
    "job.property.txt",
    "job.xyz",
    "job_trj.xyz",
    "start.xyz",
}

OMEGA = (0, 1, 3, 5)
PHI = (1, 3, 5, 7)
PSI = (3, 5, 7, 9)

CA = 5
N_ATOM = 3
C_ATOM = 7

ENERGY_RE = re.compile(
    r"FINAL SINGLE POINT ENERGY\s+"
    r"([-+]?\d+(?:\.\d+)?(?:[Ee][-+]?\d+)?)"
)


def sha(path):
    return hashlib.sha256(
        Path(path).read_bytes()
    ).hexdigest()


def rel(path):
    path = Path(path)

    try:
        return str(
            path.relative_to(ROOT)
        )
    except ValueError:
        return str(path)


def read_tsv(path):
    with Path(path).open(
        "r",
        encoding="utf-8",
        newline="",
    ) as fh:
        reader = csv.DictReader(
            fh,
            delimiter="\t",
        )

        return (
            list(reader.fieldnames),
            list(reader),
        )


def read_xyz(path):
    lines = Path(path).read_text(
        encoding="utf-8"
    ).splitlines()

    if len(lines) < 2:
        raise RuntimeError(
            "invalid XYZ: " + str(path)
        )

    n = int(
        lines[0].strip()
    )

    atom_lines = lines[
        2:2 + n
    ]

    if len(atom_lines) != n:
        raise RuntimeError(
            "XYZ atom-line count mismatch: "
            + str(path)
        )

    symbols = []
    coords = []

    for line in atom_lines:
        parts = line.split()

        if len(parts) < 4:
            raise RuntimeError(
                "malformed XYZ atom line: "
                + line
            )

        symbols.append(
            parts[0]
        )

        coords.append(
            [
                float(parts[1]),
                float(parts[2]),
                float(parts[3]),
            ]
        )

    return symbols, np.asarray(
        coords,
        dtype=float,
    )


def dihedral_deg(coords, idx):
    p0, p1, p2, p3 = [
        coords[i]
        for i in idx
    ]

    b0 = -(p1 - p0)
    b1 = p2 - p1
    b2 = p3 - p2

    norm = np.linalg.norm(
        b1
    )

    if norm == 0:
        raise RuntimeError(
            "zero central bond in dihedral"
        )

    b1 = b1 / norm

    v = b0 - np.dot(
        b0,
        b1,
    ) * b1

    w = b2 - np.dot(
        b2,
        b1,
    ) * b1

    x = np.dot(
        v,
        w,
    )

    y = np.dot(
        np.cross(
            b1,
            v,
        ),
        w,
    )

    return math.degrees(
        math.atan2(
            y,
            x,
        )
    )


def periodic_error_deg(value, target):
    return abs(
        (
            value
            - target
            + 180.0
        )
        % 360.0
        - 180.0
    )


def distance(coords, i, j):
    return float(
        np.linalg.norm(
            coords[i]
            - coords[j]
        )
    )


print("===== 401GD BATCH08 INDEPENDENT POST-QM CLOSURE QC-v2 =====")
print(
    "CONDA_DEFAULT_ENV =",
    os.environ.get("CONDA_DEFAULT_ENV"),
)
print(
    "PYTHONPATH =",
    os.environ.get("PYTHONPATH"),
)

if os.environ.get("CONDA_DEFAULT_ENV") != "nme-torsion-p0":
    raise SystemExit(
        "[FAIL] wrong environment"
    )

if os.environ.get("PYTHONPATH") is not None:
    raise SystemExit(
        "[FAIL] PYTHONPATH must be unset"
    )

if REPORT.exists() or FREEZE.exists():
    raise SystemExit(
        "[FAIL] fresh post-QM closure destination already exists"
    )


print("===== 1. EXACT EXECUTED-QM AUTHORITIES =====")

for path, expected in EXPECTED.items():
    if not path.is_file():
        raise SystemExit(
            "[FAIL] required executed-QM artifact missing: "
            + str(path)
        )

    actual = sha(
        path
    )

    print(
        path.name
    )
    print(
        " expected =",
        expected,
    )
    print(
        " actual   =",
        actual,
    )

    if actual != expected:
        raise SystemExit(
            "[FAIL] executed-QM authority SHA mismatch: "
            + path.name
        )

if not QM.is_dir():
    raise SystemExit(
        "[FAIL] Batch08 QM directory missing"
    )

print(
    "[PASS] exact one-time Batch08 QM execution artifacts adopted"
)


print("===== 2. PROSPECTIVE PROTOCOL CONSISTENCY =====")

formal_protocol = PROTOCOL.read_bytes()
prospective_protocol = PRE_PROTOCOL.read_bytes()

print(
    "formal protocol bytes =",
    len(formal_protocol),
)

print(
    "precommit protocol bytes =",
    len(prospective_protocol),
)

print(
    "formal == prospective =",
    formal_protocol
    == prospective_protocol,
)

if formal_protocol != prospective_protocol:
    raise SystemExit(
        "[FAIL] executed QM protocol differs from prospective precommit"
    )

print(
    "[PASS] formal QM protocol remained prospectively frozen"
)


print("===== 3. SELECTION / RESULTS IDENTITY CONTRACT =====")

sel_fields, sel_rows = read_tsv(
    SEL
)

res_fields, res_rows = read_tsv(
    RESULTS
)

print(
    "selection rows =",
    len(sel_rows),
)

print(
    "results rows =",
    len(res_rows),
)

if len(sel_rows) != 24:
    raise SystemExit(
        "[FAIL] frozen selection row count !=24"
    )

if len(res_rows) != 24:
    raise SystemExit(
        "[FAIL] formal QM result row count !=24"
    )

sel_ids = [
    row["state_id"]
    for row in sel_rows
]

res_ids = [
    row["state_id"]
    for row in res_rows
]

if len(set(sel_ids)) != 24:
    raise SystemExit(
        "[FAIL] selection IDs are not unique24"
    )

if len(set(res_ids)) != 24:
    raise SystemExit(
        "[FAIL] result IDs are not unique24"
    )

print(
    "result identities/order == selection =",
    res_ids == sel_ids,
)

if res_ids != sel_ids:
    raise SystemExit(
        "[FAIL] result identities/order differ from frozen selection"
    )

sel_local = [
    int(row["selection_rank"])
    for row in sel_rows
]

res_local = [
    int(row["selection_rank"])
    for row in res_rows
]

sel_cum = [
    int(
        row["cumulative_GP_acquisition_rank"]
    )
    for row in sel_rows
]

res_cum = [
    int(
        row["cumulative_GP_acquisition_rank"]
    )
    for row in res_rows
]

print(
    "selection cumulative ranks =",
    sel_cum,
)

print(
    "result cumulative ranks =",
    res_cum,
)

if (
    sel_local
    != list(range(1, 25))
    or res_local
    != list(range(1, 25))
):
    raise SystemExit(
        "[FAIL] local ranks are not exact1-24"
    )

if (
    sel_cum
    != list(range(169, 193))
    or res_cum
    != list(range(169, 193))
):
    raise SystemExit(
        "[FAIL] cumulative ranks are not exact169-192"
    )

print(
    "[PASS] exact24 frozen identities preserved through QM"
)


print("===== 4. FORMAL CONNECTIVITY / INDEPENDENT GEOMETRY SETUP =====")

structure = pmd.load_file(
    str(PRMTOP)
)

natoms = len(
    structure.atoms
)

bonds = []

neighbors = {
    i: set()
    for i in range(natoms)
}

for bond in structure.bonds:
    i = bond.atom1.idx
    j = bond.atom2.idx

    pair = tuple(
        sorted(
            (
                i,
                j,
            )
        )
    )

    bonds.append(
        pair
    )

    neighbors[i].add(
        j
    )

    neighbors[j].add(
        i
    )

bonds = sorted(
    set(bonds)
)

print(
    "formal atoms =",
    natoms,
)

print(
    "formal bonds =",
    len(bonds),
)

if natoms != 25:
    raise SystemExit(
        "[FAIL] formal topology atom count !=25"
    )

if len(bonds) != 24:
    raise SystemExit(
        "[FAIL] formal topology bond count !=24"
    )

if (
    N_ATOM not in neighbors[CA]
    or C_ATOM not in neighbors[CA]
):
    raise SystemExit(
        "[FAIL] expected N/CA/C connectivity absent"
    )

side_candidates = sorted(
    neighbors[CA]
    - {
        N_ATOM,
        C_ATOM,
    }
)

print(
    "CA neighbor indices =",
    sorted(neighbors[CA]),
)

print(
    "CA side candidates =",
    side_candidates,
)

if not side_candidates:
    raise SystemExit(
        "[FAIL] no third CA substituent for chirality audit"
    )

# Prefer a carbon side-chain atom; if the topology has multiple non-N/C
# neighbors, heavy carbon is the chemically appropriate Ala side-chain vector.
carbon_side = [
    idx
    for idx in side_candidates
    if structure.atoms[idx].atomic_number == 6
]

print(
    "CA carbon-side candidates =",
    carbon_side,
)

if len(carbon_side) != 1:
    raise SystemExit(
        "[FAIL] unique Ala side-chain carbon at CA not recovered"
    )

CB = carbon_side[0]

print(
    "independent chirality atom order N/CA/C/CB =",
    N_ATOM,
    CA,
    C_ATOM,
    CB,
)

print(
    "[PASS] formal topology loaded for independent geometry QC"
)


print("===== 5. INDEPENDENT 24-STATE JOB / RESULT QC =====")

jobs_root = QM / "jobs"

if not jobs_root.is_dir():
    raise SystemExit(
        "[FAIL] jobs directory missing"
    )

job_dirs = sorted(
    path
    for path in jobs_root.iterdir()
    if path.is_dir()
)

job_names = [
    path.name
    for path in job_dirs
]

print(
    "job directories =",
    len(job_dirs),
)

print(
    "job names == selected identity set =",
    set(job_names)
    == set(sel_ids),
)

if len(job_dirs) != 24:
    raise SystemExit(
        "[FAIL] job directory count !=24"
    )

if set(job_names) != set(sel_ids):
    raise SystemExit(
        "[FAIL] job directory identity set differs from selection"
    )

max_constraint = 0.0
max_bond_global = 0.0
min_nonlocal_global = float(
    "inf"
)

energy_deltas = []

for selection_row, result_row in zip(
    sel_rows,
    res_rows,
):
    state = result_row[
        "state_id"
    ]

    rank = int(
        result_row[
            "selection_rank"
        ]
    )

    jd = jobs_root / state

    print(
        "STATE",
        rank,
        state,
    )

    if not jd.is_dir():
        raise SystemExit(
            "[FAIL] job directory missing: "
            + state
        )

    actual_job_files = {
        path.name
        for path in jd.iterdir()
        if path.is_file()
    }

    print(
        " job file count =",
        len(actual_job_files),
    )

    if actual_job_files != EXPECTED_JOB_FILES:
        missing = sorted(
            EXPECTED_JOB_FILES
            - actual_job_files
        )

        extra = sorted(
            actual_job_files
            - EXPECTED_JOB_FILES
        )

        print(
            " missing job files =",
            missing,
        )

        print(
            " extra job files =",
            extra,
        )

        raise SystemExit(
            "[FAIL] exact job artifact set differs: "
            + state
        )

    exitcode_text = (
        jd
        / "exitcode.txt"
    ).read_text(
        encoding="utf-8"
    ).strip()

    print(
        " exitcode.txt =",
        repr(exitcode_text),
    )

    if exitcode_text != "0":
        raise SystemExit(
            "[FAIL] nonzero ORCA exit code: "
            + state
        )

    out_path = jd / "job.out"

    out_text = out_path.read_text(
        encoding="utf-8",
        errors="replace",
    )

    normal_count = out_text.count(
        "ORCA TERMINATED NORMALLY"
    )

    print(
        " normal termination markers =",
        normal_count,
    )

    if normal_count < 1:
        raise SystemExit(
            "[FAIL] ORCA normal termination marker absent: "
            + state
        )

    energy_hits = ENERGY_RE.findall(
        out_text
    )

    print(
        " FINAL SINGLE POINT ENERGY count =",
        len(energy_hits),
    )

    if not energy_hits:
        raise SystemExit(
            "[FAIL] final ORCA energy marker absent: "
            + state
        )

    parsed_energy = float(
        energy_hits[-1]
    )

    result_energy = float(
        result_row[
            "final_energy_Eh"
        ]
    )

    energy_delta = abs(
        parsed_energy
        - result_energy
    )

    energy_deltas.append(
        energy_delta
    )

    print(
        " parsed final energy =",
        f"{parsed_energy:.12f}",
    )

    print(
        " result final energy =",
        f"{result_energy:.12f}",
    )

    print(
        " energy abs delta =",
        f"{energy_delta:.3e}",
    )

    if not (
        math.isfinite(
            parsed_energy
        )
        and math.isfinite(
            result_energy
        )
    ):
        raise SystemExit(
            "[FAIL] nonfinite QM energy: "
            + state
        )

    if energy_delta > 5.0e-10:
        raise SystemExit(
            "[FAIL] results energy differs from job.out final energy: "
            + state
        )

    if result_row[
        "status"
    ] != "PASS":
        raise SystemExit(
            "[FAIL] formal result status !=PASS: "
            + state
        )

    if result_row[
        "failure_reason"
    ].strip():
        raise SystemExit(
            "[FAIL] PASS row carries failure_reason: "
            + state
        )

    if int(
        result_row[
            "exitcode"
        ]
    ) != 0:
        raise SystemExit(
            "[FAIL] results exitcode !=0: "
            + state
        )

    for field in (
        "normal_termination",
        "optimization_converged",
        "chirality_sign_preserved",
    ):
        if result_row[
            field
        ] != "True":
            raise SystemExit(
                "[FAIL] results "
                + field
                + " !=True: "
                + state
            )

    selection_start = Path(
        selection_row[
            "start_xyz"
        ]
    )

    result_start = Path(
        result_row[
            "start_xyz"
        ]
    )

    if not selection_start.is_absolute():
        selection_start = ROOT / selection_start

    if not result_start.is_absolute():
        result_start = ROOT / result_start

    job_start = (
        jd
        / "start.xyz"
    ).resolve()

    if (
        result_start.resolve()
        != job_start
    ):
        raise SystemExit(
            "[FAIL] results start_xyz is not per-job start.xyz: "
            + state
        )

    if not (
        selection_start.read_bytes()
        == result_start.read_bytes()
        == job_start.read_bytes()
    ):
        raise SystemExit(
            "[FAIL] source/result/job start geometry bytes differ: "
            + state
        )

    expected_start_sha = selection_row[
        "start_xyz_sha256"
    ]

    result_start_sha = result_row[
        "start_xyz_sha256"
    ]

    actual_source_start_sha = sha(
        selection_start
    )

    actual_job_start_sha = sha(
        jd / "start.xyz"
    )

    print(
        " start SHA selected/result/source/job =",
        expected_start_sha,
        result_start_sha,
        actual_source_start_sha,
        actual_job_start_sha,
    )

    if not (
        expected_start_sha
        == result_start_sha
        == actual_source_start_sha
        == actual_job_start_sha
    ):
        raise SystemExit(
            "[FAIL] start geometry SHA chain mismatch: "
            + state
        )

    final_xyz = Path(
        result_row[
            "final_xyz"
        ]
    )

    if not final_xyz.is_absolute():
        final_xyz = ROOT / final_xyz

    if final_xyz.resolve() != (
        jd / "job.xyz"
    ).resolve():
        raise SystemExit(
            "[FAIL] result final_xyz is not job.xyz: "
            + state
        )

    if not final_xyz.is_file():
        raise SystemExit(
            "[FAIL] final XYZ missing: "
            + state
        )

    final_sha = sha(
        final_xyz
    )

    expected_final_sha = result_row[
        "final_xyz_sha256"
    ]

    print(
        " final XYZ SHA expected/actual =",
        expected_final_sha,
        final_sha,
    )

    if final_sha != expected_final_sha:
        raise SystemExit(
            "[FAIL] final XYZ SHA mismatch: "
            + state
        )

    start_symbols, start_coords = read_xyz(
        jd / "start.xyz"
    )

    final_symbols, final_coords = read_xyz(
        final_xyz
    )

    if len(start_symbols) != 25 or len(final_symbols) != 25:
        raise SystemExit(
            "[FAIL] start/final XYZ atom count !=25: "
            + state
        )

    if start_symbols != final_symbols:
        raise SystemExit(
            "[FAIL] atom symbol order changed during QM: "
            + state
        )

    target_phi = float(
        selection_row[
            "phi_target_deg"
        ]
    )

    target_psi = float(
        selection_row[
            "psi_target_deg"
        ]
    )

    target_omega = float(
        selection_row[
            "omega_target_deg"
        ]
    )

    final_phi = dihedral_deg(
        final_coords,
        PHI,
    )

    final_psi = dihedral_deg(
        final_coords,
        PSI,
    )

    final_omega = dihedral_deg(
        final_coords,
        OMEGA,
    )

    phi_err = periodic_error_deg(
        final_phi,
        target_phi,
    )

    psi_err = periodic_error_deg(
        final_psi,
        target_psi,
    )

    omega_err = periodic_error_deg(
        final_omega,
        target_omega,
    )

    independent_max_constraint = max(
        phi_err,
        psi_err,
        omega_err,
    )

    max_constraint = max(
        max_constraint,
        independent_max_constraint,
    )

    print(
        " independent torsions phi/psi/omega =",
        f"{final_phi:.8f}",
        f"{final_psi:.8f}",
        f"{final_omega:.8f}",
    )

    print(
        " independent max constraint error =",
        f"{independent_max_constraint:.8e}",
    )

    if independent_max_constraint > 0.10:
        raise SystemExit(
            "[FAIL] independent torsion acceptance failed: "
            + state
        )

    # Independent C-alpha chirality sign:
    # (N-CA) x (C-CA) dot (CB-CA).
    def chirality_scalar(coords):
        nvec = coords[N_ATOM] - coords[CA]
        cvec = coords[C_ATOM] - coords[CA]
        cbvec = coords[CB] - coords[CA]

        return float(
            np.dot(
                np.cross(
                    nvec,
                    cvec,
                ),
                cbvec,
            )
        )

    start_chiral = chirality_scalar(
        start_coords
    )

    final_chiral = chirality_scalar(
        final_coords
    )

    print(
        " independent chirality start/final =",
        f"{start_chiral:.12e}",
        f"{final_chiral:.12e}",
    )

    if (
        start_chiral == 0.0
        or final_chiral == 0.0
        or math.copysign(
            1.0,
            start_chiral,
        )
        != math.copysign(
            1.0,
            final_chiral,
        )
    ):
        raise SystemExit(
            "[FAIL] independent chirality sign changed: "
            + state
        )

    formal_bond_lengths = [
        distance(
            final_coords,
            i,
            j,
        )
        for i, j in bonds
    ]

    independent_max_bond = max(
        formal_bond_lengths
    )

    max_bond_global = max(
        max_bond_global,
        independent_max_bond,
    )

    excluded = set(
        bonds
    )

    for center in range(
        natoms
    ):
        neigh = sorted(
            neighbors[center]
        )

        for a in range(
            len(neigh)
        ):
            for b in range(
                a + 1,
                len(neigh),
            ):
                excluded.add(
                    tuple(
                        sorted(
                            (
                                neigh[a],
                                neigh[b],
                            )
                        )
                    )
                )

    nonlocal_distances = []

    for i in range(
        natoms
    ):
        for j in range(
            i + 1,
            natoms,
        ):
            pair = (
                i,
                j,
            )

            if pair in excluded:
                continue

            nonlocal_distances.append(
                distance(
                    final_coords,
                    i,
                    j,
                )
            )

    independent_min_nonlocal = min(
        nonlocal_distances
    )

    min_nonlocal_global = min(
        min_nonlocal_global,
        independent_min_nonlocal,
    )

    print(
        " independent max formal bond =",
        f"{independent_max_bond:.8f}",
    )

    print(
        " independent min nonlocal =",
        f"{independent_min_nonlocal:.8f}",
    )

    if independent_max_bond >= 1.90:
        raise SystemExit(
            "[FAIL] independent formal-bond acceptance failed: "
            + state
        )

    if independent_min_nonlocal < 0.75:
        raise SystemExit(
            "[FAIL] independent nonlocal-distance acceptance failed: "
            + state
        )

    row_max_constraint = float(
        result_row[
            "max_constraint_error_deg"
        ]
    )

    row_max_bond = float(
        result_row[
            "max_formal_bond_A"
        ]
    )

    row_min_nonlocal = float(
        result_row[
            "min_final_nonlocal_A"
        ]
    )

    if row_max_constraint > 0.10:
        raise SystemExit(
            "[FAIL] formal result constraint gate failed: "
            + state
        )

    if row_max_bond >= 1.90:
        raise SystemExit(
            "[FAIL] formal result bond gate failed: "
            + state
        )

    if row_min_nonlocal < 0.75:
        raise SystemExit(
            "[FAIL] formal result nonlocal gate failed: "
            + state
        )

print(
    "[PASS] independent per-state ORCA/geometry acceptance complete"
)


print("===== 6. AGGREGATE SCIENTIFIC RECEIPT =====")

print(
    "accepted rows =",
    sum(
        row["status"] == "PASS"
        for row in res_rows
    ),
)

print(
    "maximum independent constraint error =",
    f"{max_constraint:.12e}",
)

print(
    "maximum independent formal bond =",
    f"{max_bond_global:.12f}",
)

print(
    "minimum independent nonlocal distance =",
    f"{min_nonlocal_global:.12f}",
)

print(
    "maximum job.out/result energy delta =",
    f"{max(energy_deltas):.12e}",
)

if sum(
    row["status"] == "PASS"
    for row in res_rows
) != 24:
    raise SystemExit(
        "[FAIL] accepted QM state count !=24"
    )

print(
    "[PASS] Batch08 QM acceptance independently confirmed 24/24"
)


print("===== 7. COMPLETE QM TREE INTEGRITY =====")

qm_files = sorted(
    path
    for path in QM.rglob("*")
    if path.is_file()
)

print(
    "formal QM tree files =",
    len(qm_files),
)

if len(qm_files) != 362:
    raise SystemExit(
        "[FAIL] formal QM tree file count !=362"
    )

top_files = {
    path.name
    for path in QM.iterdir()
    if path.is_file()
}

print(
    "QM top-level files =",
    sorted(top_files),
)

if top_files != {
    PROTOCOL.name,
    RESULTS.name,
}:
    raise SystemExit(
        "[FAIL] unexpected formal QM top-level file set"
    )

print(
    "[PASS] exact 2 + 24x15 formal QM artifact layout verified"
)


print("===== 8. DOWNSTREAM BOUNDARY =====")

print(
    "Batch08 M0 directory exists =",
    M0.exists(),
)

if M0.exists():
    raise SystemExit(
        "[FAIL] Batch08 M0 exists before QM closure"
    )

print(
    "[PASS] no Batch08 M0 has been run"
)

print(
    "[PASS] no residual construction performed"
)

print(
    "[PASS] validation labels and PPII remain outside this stage"
)


print("===== 9. MATERIALIZE POST-QM CLOSURE / FULL TREE FREEZE =====")

report_lines = [
    "# NMe-Ala joint GP Batch08 fresh-QM post-execution closure v2",
    "",
    "Status: CLOSED / BATCH08 M0 MAY BE PREPARED.",
    "",
    "Formal QM execution wrapper SHA256: " + sha(WRAP),
    "Batch08 QM runner SHA256: " + sha(RUNNER),
    "Formal QM protocol SHA256: " + sha(PROTOCOL),
    "Formal QM results SHA256: " + sha(RESULTS),
    "Formal prmtop SHA256: " + sha(PRMTOP),
    "",
    "Independent scientific closure:",
    "- exact frozen Batch08 identities = 24;",
    "- cumulative GP acquisition ranks = 169-192;",
    "- formal result identities/order exactly match frozen selection;",
    "- status PASS = 24/24; failure_reason empty = 24/24;",
    "- every exitcode.txt = 0;",
    "- every job.out contains ORCA TERMINATED NORMALLY;",
    "- every final energy was independently recovered from the last ORCA FINAL SINGLE POINT ENERGY record and matched the formal results table;",
    "- start XYZ SHA chain matches selection, formal results, source geometry, and per-job start.xyz;",
    "- final XYZ SHA matches the formal results table for all 24 states;",
    "- phi/psi/omega target constraints were independently recomputed from final XYZ coordinates;",
    "- C-alpha chirality sign was independently checked from N-CA-C-CB geometry;",
    "- formal-bond and nonlocal-distance gates were independently recomputed using the frozen RESP prmtop connectivity;",
    "- maximum independent torsion-target error = " + f"{max_constraint:.12e}" + " degree;",
    "- maximum independent formal bond = " + f"{max_bond_global:.12f}" + " A;",
    "- minimum independent nonlocal distance = " + f"{min_nonlocal_global:.12f}" + " A;",
    "- maximum independent job.out/results energy discrepancy = " + f"{max(energy_deltas):.12e}" + " Eh;",
    "- exact formal QM tree layout = 362 files = 2 top-level files + 24 state directories x 15 files;",
    "- formal protocol is byte-identical to the prospective protocol precommit;",
    "- no Batch08 M0, residual construction, GP refit, evaluation, validation-label opening, or PPII access occurred.",
    "",
    "Next authorized stage:",
    "- prepare same-geometry M0 evaluation for the exact 24 accepted Batch08 final QM geometries;",
    "- use the frozen formal RESP prmtop and PMEMD_PRINTED_NINE_COMPONENT_SUM contract;",
    "- do not refit/evaluate the acquisition benchmark until Batch08 M0 labels are accepted.",
]

REPORT.write_text(
    "\n".join(
        report_lines
    )
    + "\n",
    encoding="utf-8",
)

freeze_members = [
    Path(__file__),
    REPORT,
    WRAP,
    RUNNER,
    QC2,
    QC2_REPORT,
    QC2_FREEZE,
    PRE_PROTOCOL,
    PRECOMMIT,
    SEL,
    SEL_FREEZE,
    PRMTOP,
] + qm_files

freeze_lines = [
    sha(path)
    + "  "
    + rel(path)
    for path in freeze_members
]

FREEZE.write_text(
    "\n".join(
        freeze_lines
    )
    + "\n",
    encoding="utf-8",
)

print(
    "post-QM closure report SHA256 =",
    sha(REPORT),
)

print(
    "post-QM closure freeze SHA256 =",
    sha(FREEZE),
)

print(
    "post-QM closure freeze entries =",
    len(freeze_members),
)


print("===== 10. FINAL IMMUTABILITY / AUTHORIZATION =====")

for path, expected in EXPECTED.items():
    if sha(path) != expected:
        raise SystemExit(
            "[FAIL] frozen executed-QM artifact changed during closure: "
            + path.name
        )

if M0.exists():
    raise SystemExit(
        "[FAIL] post-QM QC created Batch08 M0"
    )

print(
    "[PASS] Batch08 post-QM execution closure CLOSED"
)

print(
    "[PASS] exact24/24 QM states independently accepted"
)

print(
    "[PASS] results SHA =",
    sha(RESULTS),
)

print(
    "[PASS] complete 362-file QM tree frozen"
)

print(
    "[PASS] same-geometry M0 remains unrun"
)

print(
    "[PASS] validation labels and PPII remain SEALED"
)

print(
    "[AUTHORIZED-NEXT] Batch08 M0 inheritance/preparation and preexecution QC"
)

print(
    "[HOLD] do not run Batch08 M0 directly yet"
)

print(
    "QC script SHA256 =",
    sha(
        Path(__file__)
    ),
)

print(
    "===== 401GD-BATCH08-QM-POSTEXEC-CLOSURE-QC-v2 END ====="
)
