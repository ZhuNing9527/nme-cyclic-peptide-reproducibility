from pathlib import Path
import csv, hashlib, math, os, re, shutil, subprocess
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import numpy as np
import parmed as pmd
ROOT = Path('/mnt/lab/zn/mem-perm/P0_starter_v1')
DEV = ROOT / '07_nmeala_separability_pilot' / '13_joint_correction_development'
SEL = DEV / '06_gp_active_learning' / '30_batch08_selection'
SELECTION = SEL / 'NMEALA_JOINT_GP_BATCH08_24_SELECTION_v1.tsv'
SELECTION_PROTOCOL = SEL / 'NMEALA_JOINT_GP_BATCH08_SELECTION_EXECUTION_v1.md'
SELECTION_HYPER = SEL / 'NMEALA_JOINT_GP_BATCH08_HYPERPARAMETERS_v1.tsv'
SELECTION_ATTEMPTS = SEL / 'NMEALA_JOINT_GP_BATCH08_HYPERPARAMETER_ATTEMPTS_v1.tsv'
SELECTION_SCORES = SEL / 'NMEALA_JOINT_GP_BATCH08_INITIAL_1398_SCORE_AUDIT_v1.tsv'
SELECTION_SUMMARY = SEL / 'NMEALA_JOINT_GP_BATCH08_SELECTION_SUMMARY_v1.md'
SELECTION_FREEZE = SEL / 'NMEALA_JOINT_GP_BATCH08_SELECTION_FREEZE_v1.sha256'
TD = DEV / '06_gp_active_learning' / '29_batch08_training_set'
TRAIN198 = TD / 'NMEALA_JOINT_GP_BATCH08_INPUT_222_LABELS_v1.tsv'
TRAIN_FREEZE = TD / 'NMEALA_JOINT_GP_BATCH08_222LABEL_TRAININGSET_FREEZE_v1.sha256'
POOL_FREEZE = DEV / '02_candidate_pool_repair' / 'NMEALA_JOINT_1728_FINAL_CANDIDATE_POOL_FREEZE_v1.sha256'
PRMTOP = ROOT / '06_m0_formal_resp' / '03_tleap_topology' / 'nmeala_resp_v1.prmtop'
OUT = DEV / '06_gp_active_learning' / '31_batch08_qm'
JOBS = OUT / 'jobs'
PROTOCOL = OUT / 'NMEALA_JOINT_GP_BATCH08_QM_PROTOCOL_v1.md'
RESULTS = OUT / 'NMEALA_JOINT_GP_BATCH08_R2SCAN_RESULTS_v1.tsv'
ORCADIR = Path('/mnt/lab/zn/software/orca_6_1_1_linux_x86-64_shared_openmpi418_nodmrg')
MPIDIR = Path('/mnt/lab/zn/software/openmpi-4.1.8-local')
ORCA = ORCADIR / 'orca'
MAX_WORKERS = 2
TORSION_TOL = 0.1

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()

def read_xyz(p):
    z = Path(p).read_text().splitlines()
    n = int(z[0])
    sy = []
    xyz = []
    for line in z[2:2 + n]:
        f = line.split()
        sy.append(f[0])
        xyz.append([float(f[1]), float(f[2]), float(f[3])])
    return (sy, np.asarray(xyz, float))

def dih(x, i, j, k, l):
    p0, p1, p2, p3 = (x[i], x[j], x[k], x[l])
    b0 = p0 - p1
    b1 = p2 - p1
    b2 = p3 - p2
    b1 = b1 / np.linalg.norm(b1)
    v = b0 - np.dot(b0, b1) * b1
    w = b2 - np.dot(b2, b1) * b1
    v = v / np.linalg.norm(v)
    w = w / np.linalg.norm(w)
    a = np.clip(np.dot(v, w), -1.0, 1.0)
    b = np.dot(np.cross(b1, v), w)
    return math.degrees(math.atan2(b, a))

def perr(a, b):
    return abs((a - b + 180.0) % 360.0 - 180.0)

def chirality(x):
    ca = x[5]
    return float(np.dot(np.cross(x[3] - ca, x[7] - ca), x[6] - ca))
print('===== 1. VERIFY FROZEN BATCH08 SELECTION =====')
expected = {SELECTION: '4e274b1b8fcbaa88015d4481d20a72fb011a52a98773eb811acaec5713703171', SELECTION_PROTOCOL: '9ed257b41437e69c8e98d06d0933430d6f6cb9ab8b5f7605cecadbbb83382624', SELECTION_HYPER: 'ba4aa47f89a57e4fd0f32f4b619d62de3ce3a6568a9e0b0f7b249042a69d0c80', SELECTION_ATTEMPTS: '7e373a9b49373dca004b05a95505c8eb230d3134bd5d75939217d45d546e19db', SELECTION_SCORES: '7d35f6abc09e0fb0bcd98c688c3d3943cb87143137282d5f99357634d3552eed', SELECTION_SUMMARY: '96bc7f7a1a755c8d90936b03326f5c48b0c4b0525630bdfa64cb85fbe4c456c0', SELECTION_FREEZE: '71cd2dcdad908b23547404184dc4aa1227e3c5672a070a6831a39fa82a1b8052', TRAIN198: 'f66b88725f1d13cbf5be4ffb2e4be35eb65ebde9195e3094dd173c9b1d8d1b9d', TRAIN_FREEZE: '24c50df47563372e8f5ce2e143b0ce65bc1158f00d14f664d08a8cbc976e5fa2', POOL_FREEZE: 'e8e5ab2e72d8325fd22c245786acb0a57e14321f5c59376245763a5226acbd58', PRMTOP: '9b2c68fad482b03562a4b9c956dc57586bfc73384bb3a68b019e866c1275f5e6'}
for p, h in expected.items():
    if not p.exists():
        raise SystemExit(f'[FAIL] missing frozen artifact: {p}')
    a = sha(p)
    print(f'{p}\nexpected = {h}\nactual   = {a}')
    if a != h:
        raise SystemExit(f'[FAIL] frozen artifact changed: {p}')
if not ORCA.exists():
    raise SystemExit(f'[FAIL] ORCA missing: {ORCA}')
print('[PASS] exact Batch08 identities/provenance frozen before QM')
print('\n===== 2. OUTPUT SAFETY CHECK =====')
if OUT.exists():
    raise SystemExit(f'[FAIL] Batch08 QM directory already exists: {OUT}')
JOBS.mkdir(parents=True)
print('[PASS] clean Batch08 QM directory created')
print('\n===== 3. FREEZE BATCH08 QM PROTOCOL BEFORE RESULTS =====')
PROTOCOL.write_text('# NMe-Ala joint GP Batch08 fresh QM protocol v1\n\nSTATUS: FROZEN AFTER BATCH08 IDENTITIES AND BEFORE QM RESULTS.\n\nStates: exact frozen Batch08 24 states; cumulative acquisition ranks 169-192; no substitution.\n\nSystem: NMe-Ala, neutral singlet, 25 atoms.\n\nQM: ORCA 6.1.1; r2SCAN-3c; TightSCF; TightOpt; CPCM(Water).\n\nConstraints, zero-based:\nomega 0 1 3 5\nphi   1 3 5 7\npsi   3 5 7 9\n\nAll other coordinates relax.\n\nResources: 8 ORCA processes/state; maxcore 2500 MB/process; MaxIter 300; at most two states concurrently.\n\nAcceptance:\nexit code 0;\nnormal ORCA termination;\noptimization converged;\nfinal XYZ and energy present;\nmaximum torsion-target error <=0.10 degree;\nC-alpha chirality sign preserved;\nmaximum formal bond <1.90 A;\nminimum nonlocal distance excluding 1-2 and 1-3 pairs >=0.75 A.\n\nBoundary:\nfresh Batch08 QM only;\nno M0;\nno residual;\nno post-B192 fitting/evaluation;\nno validation label;\nPPII sealed;\nno production fit.\n')
print('QM protocol SHA256 =', sha(PROTOCOL))
print('[PASS] Batch08 QM protocol frozen before results')
print('\n===== 4. LOAD EXACT 24 FROZEN BATCH08 STATES =====')
with SELECTION.open() as f:
    rows = list(csv.DictReader(f, delimiter='\t'))
if len(rows) != 24:
    raise SystemExit(f'[FAIL] states={len(rows)}')
if len({r['state_id'] for r in rows}) != 24:
    raise SystemExit('[FAIL] duplicate state IDs')
if sorted((int(r['selection_rank']) for r in rows)) != list(range(1, 25)):
    raise SystemExit('[FAIL] selection ranks')
if sorted((int(r['cumulative_GP_acquisition_rank']) for r in rows)) != list(range(169, 193)):
    raise SystemExit('[FAIL] cumulative ranks')
for r in rows:
    p = Path(r['start_xyz'])
    if not p.exists() or sha(p) != r['start_xyz_sha256']:
        raise SystemExit(f"[FAIL] frozen start changed: {r['state_id']}")
print('[PASS] exact 24 frozen Batch08 geometries loaded')
print('\n===== 5. LOAD FORMAL CONNECTIVITY =====')
parm = pmd.load_file(str(PRMTOP))
if len(parm.atoms) != 25 or len(parm.bonds) != 24:
    raise SystemExit('[FAIL] formal topology size')
bonded = {tuple(sorted((b.atom1.idx, b.atom2.idx))) for b in parm.bonds}
graph = {i: set() for i in range(25)}
for i, j in bonded:
    graph[i].add(j)
    graph[j].add(i)
one3 = set()
for c in range(25):
    n = sorted(graph[c])
    for a in range(len(n)):
        for b in range(a + 1, len(n)):
            one3.add(tuple(sorted((n[a], n[b]))))
zsym = {1: 'H', 6: 'C', 7: 'N', 8: 'O'}
formal = [zsym[a.atomic_number] for a in parm.atoms]
print('[PASS] formal 25-atom / 24-bond topology loaded')
print('\n===== 6. GENERATE EXACT 24 ORCA INPUTS =====')
for r in rows:
    sid = r['state_id']
    jd = JOBS / sid
    jd.mkdir()
    src = Path(r['start_xyz'])
    dst = jd / 'start.xyz'
    shutil.copy2(src, dst)
    if sha(dst) != r['start_xyz_sha256']:
        raise SystemExit(f'[FAIL] copied start changed: {sid}')
    sy, _ = read_xyz(dst)
    if sy != formal:
        raise SystemExit(f'[FAIL] formal atom order mismatch: {sid}')
    phi = float(r['phi_target_deg'])
    psi = float(r['psi_target_deg'])
    om = float(r['omega_target_deg'])
    (jd / 'job.inp').write_text(f'! r2SCAN-3c TightSCF TightOpt CPCM(Water)\n%pal nprocs 8 end\n%maxcore 2500\n%geom\n MaxIter 300\n Constraints\n  {{ D 0 1 3 5 {om:9.3f} C }}\n  {{ D 1 3 5 7 {phi:9.3f} C }}\n  {{ D 3 5 7 9 {psi:9.3f} C }}\n end\nend\n* xyzfile 0 1 start.xyz\n')
print('[PASS] exact 24 Batch08 ORCA inputs generated')
print('\n===== 7. RUN 24 FRESH BATCH08 R2SCAN-3C OPTIMIZATIONS =====')
env = os.environ.copy()
env['PATH'] = f"{ORCADIR}:{MPIDIR / 'bin'}:" + env.get('PATH', '')
env['LD_LIBRARY_PATH'] = f"{ORCADIR}:{MPIDIR / 'lib'}:" + env.get('LD_LIBRARY_PATH', '')
for k in ('OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'BLIS_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    env[k] = '1'
env.pop('DISPLAY', None)
env.pop('XAUTHORITY', None)
env.pop('WAYLAND_DISPLAY', None)

def run(r):
    sid = r['state_id']
    jd = JOBS / sid
    with (jd / 'job.out').open('w') as f:
        p = subprocess.run([str(ORCA), 'job.inp'], cwd=jd, stdout=f, stderr=subprocess.STDOUT, env=env)
    (jd / 'exitcode.txt').write_text(str(p.returncode) + '\n')
    return (sid, p.returncode)
done = 0
with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
    fs = {ex.submit(run, r): r['state_id'] for r in rows}
    for fut in as_completed(fs):
        sid = fs[fut]
        try:
            _, rc = fut.result()
            tag = 'EXIT0' if rc == 0 else f'EXIT{rc}'
        except Exception as e:
            tag = f'EXCEPTION:{e!r}'
        done += 1
        print(f'[PROGRESS] {done:2d}/24 {sid} {tag}')
print('\n===== 8. FINAL BATCH08 QM QC =====')
result = []
for r in sorted(rows, key=lambda x: int(x['selection_rank'])):
    sid = r['state_id']
    jd = JOBS / sid
    op = jd / 'job.out'
    xp = jd / 'job.xyz'
    sp = jd / 'start.xyz'
    ep = jd / 'exitcode.txt'
    text = op.read_text(errors='ignore') if op.exists() else ''
    ec = ep.read_text().strip() if ep.exists() else 'MISSING'
    normal = 'ORCA TERMINATED NORMALLY' in text.upper()
    conv = 'THE OPTIMIZATION HAS CONVERGED' in text.upper()
    hits = re.findall('FINAL SINGLE POINT ENERGY\\s+(-?\\d+\\.\\d+)', text)
    ene = hits[-1] if hits else ''
    reasons = []
    phi = psi = om = maxerr = sc = fc = maxbond = minnl = None
    chiok = False
    if xp.exists() and sp.exists():
        sy, x = read_xyz(xp)
        ssy, sx = read_xyz(sp)
        if sy != ssy or sy != formal:
            reasons.append('ATOM_ORDER_MISMATCH')
        if len(x) == 25 and len(sx) == 25:
            om = dih(x, 0, 1, 3, 5)
            phi = dih(x, 1, 3, 5, 7)
            psi = dih(x, 3, 5, 7, 9)
            maxerr = max(perr(om, float(r['omega_target_deg'])), perr(phi, float(r['phi_target_deg'])), perr(psi, float(r['psi_target_deg'])))
            sc = chirality(sx)
            fc = chirality(x)
            chiok = abs(sc) > 1e-06 and abs(fc) > 1e-06 and (sc * fc > 0)
            maxbond = max((float(np.linalg.norm(x[i] - x[j])) for i, j in bonded))
            ds = []
            for i in range(25):
                for j in range(i + 1, 25):
                    if (i, j) not in bonded and (i, j) not in one3:
                        ds.append(float(np.linalg.norm(x[i] - x[j])))
            minnl = min(ds)
    if ec != '0':
        reasons.append('NONZERO_EXIT')
    if not normal:
        reasons.append('NO_NORMAL_TERMINATION')
    if not conv:
        reasons.append('OPT_NOT_CONVERGED')
    if not xp.exists():
        reasons.append('NO_FINAL_XYZ')
    if not ene:
        reasons.append('NO_FINAL_ENERGY')
    if maxerr is None or maxerr > TORSION_TOL:
        reasons.append('TORSION_GATE')
    if not chiok:
        reasons.append('CHIRALITY_NOT_PRESERVED')
    if maxbond is None or maxbond >= 1.9:
        reasons.append('FORMAL_BOND_GATE')
    if minnl is None or minnl < 0.75:
        reasons.append('NONLOCAL_GATE')
    status = 'PASS' if not reasons else 'HOLD'
    result.append({'selection_rank': r['selection_rank'], 'cumulative_GP_acquisition_rank': r['cumulative_GP_acquisition_rank'], 'state_id': sid, 'phi_target_deg': r['phi_target_deg'], 'psi_target_deg': r['psi_target_deg'], 'omega_target_deg': r['omega_target_deg'], 'start_xyz': str(sp), 'start_xyz_sha256': sha(sp), 'exitcode': ec, 'normal_termination': str(normal), 'optimization_converged': str(conv), 'final_energy_Eh': ene, 'final_phi_deg': '' if phi is None else f'{phi:+.8f}', 'final_psi_deg': '' if psi is None else f'{psi:+.8f}', 'final_omega_deg': '' if om is None else f'{om:+.8f}', 'max_constraint_error_deg': '' if maxerr is None else f'{maxerr:.8f}', 'start_chirality_scalar': '' if sc is None else f'{sc:+.10f}', 'final_chirality_scalar': '' if fc is None else f'{fc:+.10f}', 'chirality_sign_preserved': str(chiok), 'max_formal_bond_A': '' if maxbond is None else f'{maxbond:.8f}', 'min_final_nonlocal_A': '' if minnl is None else f'{minnl:.8f}', 'final_xyz': str(xp) if xp.exists() else '', 'final_xyz_sha256': sha(xp) if xp.exists() else '', 'status': status, 'failure_reason': ','.join(reasons)})
with RESULTS.open('w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(result[0]), delimiter='\t', lineterminator='\n')
    w.writeheader()
    w.writerows(result)
print('rank\tcumRank\tstate\tstatus\tenergy_Eh\tphi\tpsi\tomega\tmaxerr\tchirality\tmaxbond\tmin_nonlocal')
for r in result:
    print(f"{r['selection_rank']}\t{r['cumulative_GP_acquisition_rank']}\t{r['state_id']}\t{r['status']}\t{r['final_energy_Eh'] or 'NA'}\t{r['final_phi_deg'] or 'NA'}\t{r['final_psi_deg'] or 'NA'}\t{r['final_omega_deg'] or 'NA'}\t{r['max_constraint_error_deg'] or 'NA'}\t{r['chirality_sign_preserved']}\t{r['max_formal_bond_A'] or 'NA'}\t{r['min_final_nonlocal_A'] or 'NA'}")
    if r['failure_reason']:
        print('  FAILURE:', r['failure_reason'])
counts = Counter((r['status'] for r in result))
npass = counts.get('PASS', 0)
passed = [r for r in result if r['status'] == 'PASS']
print('\n===== 9. FINAL RESULT =====')
print('status counts =', dict(counts))
print(f"[{('PASS' if npass == 24 else 'HOLD')}] accepted Batch08 fresh QM states = {npass}/24")
if passed:
    print('maximum accepted constraint error =', max((float(r['max_constraint_error_deg']) for r in passed)), 'deg')
    print('maximum accepted formal bond =', max((float(r['max_formal_bond_A']) for r in passed)), 'A')
    print('minimum accepted final nonlocal distance =', min((float(r['min_final_nonlocal_A']) for r in passed)), 'A')
print('results =', RESULTS)
print('results SHA256 =', sha(RESULTS))
print('QM protocol SHA256 =', sha(PROTOCOL))
print('[PASS] Batch08 selection identities were not changed')
print('[PASS] no Batch08 state was substituted')
print('[PASS] no Batch08 M0 calculation was performed')
print('[PASS] no Batch08 GP fit/scoring was performed')
print('[PASS] no validation label was opened')
print('[PASS] PPII holdout remained sealed')
print('[PASS] no production fitting performed')
print('\n===== NME-ALA GP BATCH08 FRESH QM STAGE COMPLETE =====')
