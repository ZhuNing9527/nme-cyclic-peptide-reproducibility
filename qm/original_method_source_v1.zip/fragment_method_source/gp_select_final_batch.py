from pathlib import Path
import csv
import hashlib
import importlib.util
import math
import platform
from collections import Counter

import numpy as np
import scipy


ROOT = Path("/mnt/lab/zn/mem-perm/P0_starter_v1")
DEV = ROOT/"07_nmeala_separability_pilot"/"13_joint_correction_development"
AL = DEV/"06_gp_active_learning"

TRAIN_DIR = AL/"29_batch08_training_set"
TRAIN_PROTOCOL = TRAIN_DIR/"NMEALA_JOINT_GP_BATCH08_222LABEL_TRAININGSET_PROTOCOL_v1.md"
TRAIN222 = TRAIN_DIR/"NMEALA_JOINT_GP_BATCH08_INPUT_222_LABELS_v1.tsv"
TRAIN_AUDIT = TRAIN_DIR/"NMEALA_JOINT_GP_BATCH08_222LABEL_AUDIT_v1.tsv"
TRAIN_SUMMARY = TRAIN_DIR/"NMEALA_JOINT_GP_BATCH08_222LABEL_TRAININGSET_SUMMARY_v1.md"
TRAIN_FREEZE = TRAIN_DIR/"NMEALA_JOINT_GP_BATCH08_222LABEL_TRAININGSET_FREEZE_v1.sha256"

TRAIN_FINAL_QC = AL/"run_qc_gp_batch08_222label_training_provenance_closure_v1.py"

TRAIN_CLOSURE = TRAIN_DIR/"NMEALA_JOINT_GP_BATCH08_222LABEL_TRAININGSET_PROVENANCE_CLOSURE_v1.md"
TRAIN_CLOSURE_FREEZE = TRAIN_DIR/"NMEALA_JOINT_GP_BATCH08_222LABEL_TRAININGSET_PROVENANCE_CLOSURE_FREEZE_v1.sha256"

GP_DIR = DEV/"05_gp_implementation_precommit"
GP_PROTOCOL = GP_DIR/"NMEALA_JOINT_PERIODIC_GP_IMPLEMENTATION_PRECOMMIT_v1.md"
GP_MODULE = GP_DIR/"periodic_gp_v1.py"
GP_FREEZE = GP_DIR/"NMEALA_JOINT_PERIODIC_GP_IMPLEMENTATION_FREEZE_v1.sha256"

SPLIT = DEV/"03_internal_validation_split"
ACQUISITION = SPLIT/"NMEALA_JOINT_1566_ACQUISITION_POOL_MANIFEST_v1.tsv"
VALIDATION = SPLIT/"NMEALA_JOINT_144_INTERNAL_VALIDATION_MANIFEST_v1.tsv"
ROLE_MANIFEST = SPLIT/"NMEALA_JOINT_1728_DATA_ROLE_MANIFEST_v1.tsv"

B1_DIR = AL/"01_batch01_selection"
B1_SELECTION = B1_DIR/"NMEALA_JOINT_GP_BATCH01_24_SELECTION_v1.tsv"
B1_FREEZE = B1_DIR/"NMEALA_JOINT_GP_BATCH01_SELECTION_FREEZE_v1.sha256"

B2_DIR = AL/"06_batch02_selection"
B2_SELECTION = B2_DIR/"NMEALA_JOINT_GP_BATCH02_24_SELECTION_v1.tsv"
B2_FREEZE = B2_DIR/"NMEALA_JOINT_GP_BATCH02_SELECTION_FREEZE_v1.sha256"

B3_DIR = AL/"10_batch03_selection"
B3_SELECTION = B3_DIR/"NMEALA_JOINT_GP_BATCH03_24_SELECTION_v1.tsv"
B3_FREEZE = B3_DIR/"NMEALA_JOINT_GP_BATCH03_SELECTION_FREEZE_v1.sha256"

B4_DIR = AL/"14_batch04_selection"
B4_SELECTION = B4_DIR/"NMEALA_JOINT_GP_BATCH04_24_SELECTION_v1.tsv"
B4_FREEZE = B4_DIR/"NMEALA_JOINT_GP_BATCH04_SELECTION_FREEZE_v1.sha256"

B5_DIR = AL/"18_batch05_selection"
B5_SELECTION = B5_DIR/"NMEALA_JOINT_GP_BATCH05_24_SELECTION_v1.tsv"
B5_FREEZE = B5_DIR/"NMEALA_JOINT_GP_BATCH05_SELECTION_FREEZE_v1.sha256"

B6_DIR = AL/"22_batch06_selection"
B6_SELECTION = B6_DIR/"NMEALA_JOINT_GP_BATCH06_24_SELECTION_v1.tsv"
B6_FREEZE = B6_DIR/"NMEALA_JOINT_GP_BATCH06_SELECTION_FREEZE_v2.sha256"
B6_QC = AL/"run_qc_gp_batch06_selection_freeze_v2_closure_v1.py"
B7_DIR = AL/"26_batch07_selection"
B7_SELECTION = B7_DIR/"NMEALA_JOINT_GP_BATCH07_24_SELECTION_v1.tsv"
B7_FREEZE = B7_DIR/"NMEALA_JOINT_GP_BATCH07_SELECTION_FREEZE_v1.sha256"
B7_QC = AL/"run_qc_gp_batch07_selection_post_recovery_closure_v1.py"

ACQ_PRE = DEV/"04_acquisition_benchmark_precommit"
ACQ_PROTOCOL = ACQ_PRE/"NMEALA_JOINT_ACQUISITION_BENCHMARK_PRECOMMIT_v1.md"
ACQ_FREEZE = ACQ_PRE/"NMEALA_JOINT_ACQUISITION_BENCHMARK_PRECOMMIT_FREEZE_v1.sha256"

EVAL_PRE = DEV/"08_acquisition_evaluation_precommit"
EVAL_FREEZE = EVAL_PRE/"NMEALA_JOINT_ACQUISITION_EVALUATION_PRECOMMIT_FREEZE_v1.sha256"

OUT = AL/"30_batch08_selection"
EXEC_PROTOCOL = OUT/"NMEALA_JOINT_GP_BATCH08_SELECTION_EXECUTION_v1.md"
HYPERPARAMS = OUT/"NMEALA_JOINT_GP_BATCH08_HYPERPARAMETERS_v1.tsv"
HYPER_ATTEMPTS = OUT/"NMEALA_JOINT_GP_BATCH08_HYPERPARAMETER_ATTEMPTS_v1.tsv"
INITIAL_SCORES = OUT/"NMEALA_JOINT_GP_BATCH08_INITIAL_1398_SCORE_AUDIT_v1.tsv"
SELECTION = OUT/"NMEALA_JOINT_GP_BATCH08_24_SELECTION_v1.tsv"
SUMMARY = OUT/"NMEALA_JOINT_GP_BATCH08_SELECTION_SUMMARY_v1.md"
RECOVERY_AMENDMENT = AL/'NMEALA_JOINT_GP_BATCH08_SELECTION_RECOVERY_AMENDMENT_v1.md'
CONTINUATION_AMENDMENT = AL/'NMEALA_JOINT_GP_BATCH08_SELECTION_CONTINUATION_AMENDMENT_v1.md'
FREEZE = OUT/"NMEALA_JOINT_GP_BATCH08_SELECTION_FREEZE_v1.sha256"

BATCH_SIZE = 24


def sha(p):
    h = hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda: f.read(1048576), b""):
            h.update(b)
    return h.hexdigest()


def load(p):
    with Path(p).open() as f:
        return list(csv.DictReader(f, delimiter="\t"))


def write_tsv(p, rows):
    if not rows:
        raise RuntimeError(f"no rows: {p}")
    with Path(p).open("w", newline="") as f:
        w = csv.DictWriter(
            f,
            fieldnames=list(rows[0]),
            delimiter="\t",
            lineterminator="\n",
        )
        w.writeheader()
        w.writerows(rows)


print("===== 1. VERIFY FROZEN 222-LABEL TRAINING SET / GP IMPLEMENTATION =====")

expected = {
    TRAIN_PROTOCOL:
        "268006096daa3b123fe68f05ebe86bd1df5afaf9856f816a91d491822c8041e2",
    TRAIN222:
        "f66b88725f1d13cbf5be4ffb2e4be35eb65ebde9195e3094dd173c9b1d8d1b9d",
    TRAIN_AUDIT:
        "05b766add22133c4232311474114a05fe856ac423d95b464617d1f8dba3bf6b5",
    TRAIN_SUMMARY:
        "a1492a150a5a0baadb263a6a23daa73e01f78f821a5502dbd79dfecd9cedd342",
    TRAIN_FREEZE:
        "24c50df47563372e8f5ce2e143b0ce65bc1158f00d14f664d08a8cbc976e5fa2",
    TRAIN_FINAL_QC:
        "7c421d0300af96270c9baca179929ccc0a4e6d0de41663efa36049963ca7a761",

    TRAIN_CLOSURE:
        "c965884e816e6eef3c03b0d38ebdcc7161e35fc929d26e29ed927fd8b0760cbc",

    TRAIN_CLOSURE_FREEZE:
        "01750ccddd7787f22c4e6b8bcd298588f219323a2b104fb5c84ea8ccb6793677",

    GP_PROTOCOL:
        "ecadccb8150cfbb48b8d85677752b5345e6e90e0372a34a3fda580341362a669",
    GP_MODULE:
        "9dac884ab37aa03e45dd9156a9fa4b47adf715d8fc58b6c77057f5db91e54e5c",
    GP_FREEZE:
        "45d6950f7608163fdaa92842d4909fb19dafb9261c4a73c40eb862ef66b61d1e",

    ACQUISITION:
        "42a64f2765a624a95a0c4a1e5a8af0cff57ed5b722be2237c4a7ffa98209bf3a",
    VALIDATION:
        "f93fc7c2b2348f1629ad41a9327d66618f90d46b31520062eed20bdf876f7f66",
    ROLE_MANIFEST:
        "1621c4f8ccb6dae48ec4571cfc6484801a4c88b175b04553aa57ba107740e5e9",

    B1_SELECTION:
        "86e67d522d1452a60f39952cf24da6074c57abd9e5ea4cac8385a11e2d2042ff",
    B1_FREEZE:
        "b9750dbd21d494adfc71aadf2484e36b6f3c6269f1b111548045b75f890154db",

    B2_SELECTION:
        "d13f67debaa93720e84c5f229f437ea88aaaf8f52f74d025333a80a35d947c1f",
    B2_FREEZE:
        "f22c9bfa1d7b28b3a1b822f28d9368a042205a2187180d23e45ec902d23ae324",

    B3_SELECTION:
        "70c90a704ebf66754c8c604804dffbabd59b616a107681d49788e1676cb59de9",
    B3_FREEZE:
        "10387b02917d384e980b916ccc2071a0ea630b29f28f14040fa2b5cab8859484",
    B4_SELECTION:
        "eaf5bd51147dbff102f7f767e0a375c65273a0644c401a80285e8e6cf8186264",
    B4_FREEZE:
        "df132558994aaa606c378217ba8a5073bac45d8f71d94e013b0fe5633387795d",

    B5_SELECTION:
        "4e55cb91736d3dc65b62d53fbd8f75118bb03f731c3578550b416df0d3348f3f",
    B5_FREEZE:
        "0547660f00a6a67dac00b879cb47432975b472fbdcf8b4d79e985f44b9f2a6f3",

    B6_SELECTION:
        "0b5c48822c6634313c1905fc443b468b3574e0293c3c7e7d82841cb64c681a7b",

    B6_FREEZE:
        "f1523f4732b2dee15066847af40af8149fe6a34fa55f1c4c500262d688d71127",

    B6_QC:
        "17d17cbe794f0f6cd228232046ac5723f05853d6931c42039524c648c82ff937",

    ACQ_PROTOCOL:
        "ade57d9e8d2e38033ac40292f5004018eb037d074dc438df586797930dc2dee7",
    ACQ_FREEZE:
        "638bd46c98cb6d2dca725f3d7dca55322119f3de1b101194d518c3118852ff05",
    EVAL_FREEZE:
        "cb33373cf47620333c369247db77fc3657dfa50d87ac0d88008fc7d65c69fb0c",
    B7_SELECTION: "8acafeada58888a47c816af4339b600f29097b8579da96610a6d02eb85830ef1",
    B7_FREEZE: "b96879250569dc0b949fdd692bd84be618f0baadf5ab3ba76682fa4b89acf9b1",
    B7_QC: "579467b8b7e2259832acabbdba130efea1233ee0261094975345476a04e4f6ac",
}

for p, h in expected.items():
    if not p.exists():
        raise SystemExit(f"[FAIL] missing frozen artifact: {p}")
    a = sha(p)
    print(f"{p}\nexpected = {h}\nactual   = {a}")
    if a != h:
        raise SystemExit(f"[FAIL] frozen artifact changed: {p}")

print("[PASS] exact 222-label training set and frozen GP implementation verified")


print("\n===== 2. OUTPUT SAFETY CHECK / CONTINUATION ADOPTION =====")

if not OUT.is_dir():
    raise SystemExit("[FAIL] Batch08 failed OUT directory is absent")

existing_files = sorted(
    path
    for path in OUT.rglob("*")
    if path.is_file()
)

expected_existing = {
    EXEC_PROTOCOL,
    HYPERPARAMS,
    HYPER_ATTEMPTS,
}

if (
    set(existing_files) != expected_existing
    or len(existing_files) != 3
):
    raise SystemExit(
        "[FAIL] continuation requires exact EXEC+HYPER+ATTEMPTS state"
    )

_continuation_partial_sha = {
    EXEC_PROTOCOL: "9ed257b41437e69c8e98d06d0933430d6f6cb9ab8b5f7605cecadbbb83382624",
    HYPERPARAMS: "ba4aa47f89a57e4fd0f32f4b619d62de3ce3a6568a9e0b0f7b249042a69d0c80",
    HYPER_ATTEMPTS: "7e373a9b49373dca004b05a95505c8eb230d3134bd5d75939217d45d546e19db",
}

for _path, _expected in _continuation_partial_sha.items():
    if sha(_path) != _expected:
        raise SystemExit(
            "[FAIL] frozen continuation partial changed: "
            + _path.name
        )

for _path in (
    INITIAL_SCORES,
    SELECTION,
    SUMMARY,
):
    if _path.exists():
        raise SystemExit(
            "[FAIL] post-score Batch08 artifact already exists"
        )

print(
    "[PASS] adopted immutable EXEC+HYPER+ATTEMPTS "
    "post-refit/pre-score state"
)


print("\n===== 3. CONTINUATION AUTHORITY ADOPTION =====")

if sha(EXEC_PROTOCOL) != "9ed257b41437e69c8e98d06d0933430d6f6cb9ab8b5f7605cecadbbb83382624":
    raise SystemExit(
        "[FAIL] execution protocol changed before continuation"
    )

if sha(RECOVERY_AMENDMENT) != "23a4a8832c7c1c8abb87da3d7b2dc5b5cf845ea5068792ca0004b471c32be19e":
    raise SystemExit(
        "[FAIL] recovery amendment changed before continuation"
    )

if not CONTINUATION_AMENDMENT.is_file():
    raise SystemExit(
        "[FAIL] continuation amendment missing"
    )

if sha(CONTINUATION_AMENDMENT) != "e45c7620fec089621f14fb1802d7e3387b2993986cc91bfda2e5242fc80edd0a":
    raise SystemExit(
        "[FAIL] continuation amendment SHA mismatch"
    )

print(
    "continuation amendment SHA256 =",
    sha(CONTINUATION_AMENDMENT),
)

print(
    "[PASS] failed recovery preserved as provenance; "
    "continuation amendment controls execution"
)


print("\n===== 4. IMPORT EXACT FROZEN PERIODIC GP =====")

spec = importlib.util.spec_from_file_location(
    "periodic_gp_v1",
    GP_MODULE,
)
gp = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gp)

print("python =", platform.python_version())
print("numpy =", np.__version__)
print("scipy =", scipy.__version__)
print("[PASS] frozen GP module imported unchanged")


print("\n===== 5. LOAD EXACT 222-LABEL TRAINING SET =====")

training = load(TRAIN222)

if len(training) != 222:
    raise SystemExit(f"[FAIL] training labels={len(training)}")

if len({r["state_id"] for r in training}) != 222:
    raise SystemExit("[FAIL] duplicate training state ID")

coords = {
    (
        float(r["phi_deg"]),
        float(r["psi_deg"]),
        float(r["omega_deg"]),
    )
    for r in training
}

if len(coords) != 222:
    raise SystemExit("[FAIL] duplicate training angular coordinate")

if {r["label_precision_convention"] for r in training} != {
    "PMEMD_PRINTED_NINE_COMPONENT_SUM"
}:
    raise SystemExit("[FAIL] mixed training precision convention")

origins = Counter(r["training_origin"] for r in training)

wanted = Counter({
    "IDENTIFIABILITY_SEED54_HARMONIZED": 54,
    "PERIODIC_GP_ACTIVE_LEARNING": 168,
})

if origins != wanted:
    raise SystemExit(f"[FAIL] training-origin composition={dict(origins)}")

Xtrain = np.asarray([
    [
        float(r["phi_deg"]),
        float(r["psi_deg"]),
        float(r["omega_deg"]),
    ]
    for r in training
], dtype=float)

ytrain = np.asarray([
    float(r["absolute_QM_minus_M0_residual_kcal_mol"])
    for r in training
], dtype=float)

if not np.isfinite(ytrain).all():
    raise SystemExit("[FAIL] non-finite training label")

print("training labels =", len(training))
print("training-origin counts =", dict(origins))
print("training residual mean =", f"{np.mean(ytrain):.12f}", "kcal/mol")
print("training residual SD =", f"{np.std(ytrain):.12f}", "kcal/mol")
print("[PASS] exact frozen 222-label dataset loaded")


print("\n===== 6. DETERMINISTIC 222-LABEL GP HYPERPARAMETER REFIT =====")
_continuation_original_write_tsv = write_tsv
_continuation_captured_tsv = {}

def _continuation_capture_write_tsv(p, rows):
    _path = Path(p)

    if _path not in (
        HYPERPARAMS,
        HYPER_ATTEMPTS,
    ):
        raise SystemExit(
            "[FAIL] unexpected TSV write during in-memory refit: "
            + _path.name
        )

    if _path.name in _continuation_captured_tsv:
        raise SystemExit(
            "[FAIL] duplicate in-memory refit TSV capture: "
            + _path.name
        )

    if not rows:
        raise RuntimeError(
            "no rows in captured refit TSV: " + str(_path)
        )

    _continuation_captured_tsv[_path.name] = [
        dict(row)
        for row in rows
    ]

write_tsv = _continuation_capture_write_tsv


fit1 = gp.fit_hyperparameters(Xtrain, ytrain)
fit2 = gp.fit_hyperparameters(Xtrain, ytrain)

b1 = fit1["best"]
b2 = fit2["best"]

v1 = np.asarray([
    b1["nll"],
    b1["sigma_f"],
    b1["ell_phi"],
    b1["ell_psi"],
    b1["ell_omega"],
], dtype=float)

v2 = np.asarray([
    b2["nll"],
    b2["sigma_f"],
    b2["ell_phi"],
    b2["ell_psi"],
    b2["ell_omega"],
], dtype=float)

repeat_delta = float(np.max(np.abs(v1-v2)))

print(
    "successful starts =",
    sum(a["success"] for a in fit1["attempts"]),
    "/",
    len(fit1["attempts"]),
)
print("selected start index =", b1["start_index"])
print("target mean =", f"{fit1['target_mean']:.12f}", "kcal/mol")
print("centered RMS =", f"{fit1['centered_rms']:.12f}", "kcal/mol")
print("sigma_f =", f"{b1['sigma_f']:.12f}")
print("ell_phi =", f"{b1['ell_phi']:.12f}")
print("ell_psi =", f"{b1['ell_psi']:.12f}")
print("ell_omega =", f"{b1['ell_omega']:.12f}")
print("NLL =", f"{b1['nll']:.12f}")
print("repeat-fit maximum numeric difference =", f"{repeat_delta:.16e}")

if repeat_delta > 1e-10:
    raise SystemExit("[FAIL] 222-label GP refit not deterministic")

ell = np.asarray(
    [b1["ell_phi"], b1["ell_psi"], b1["ell_omega"]],
    dtype=float,
)

pred = gp.posterior_mean(
    Xtrain,
    ytrain,
    Xtrain,
    b1["sigma_f"],
    ell,
)

train_rmse = math.sqrt(
    float(np.mean((pred-ytrain)**2))
)

print(
    "222-label posterior-mean training RMSE =",
    f"{train_rmse:.12e}",
    "kcal/mol",
)

if not math.isfinite(train_rmse) or train_rmse > 1e-3:
    raise SystemExit("[FAIL] GP training interpolation QC")

write_tsv(
    HYPERPARAMS,
    [{
        "n_training_states": 222,
        "selected_start_index": b1["start_index"],
        "target_mean_kcal_mol": f"{fit1['target_mean']:.12f}",
        "centered_training_RMS_kcal_mol": f"{fit1['centered_rms']:.12f}",
        "sigma_f": f"{b1['sigma_f']:.12f}",
        "ell_phi": f"{b1['ell_phi']:.12f}",
        "ell_psi": f"{b1['ell_psi']:.12f}",
        "ell_omega": f"{b1['ell_omega']:.12f}",
        "NLL": f"{b1['nll']:.12f}",
        "repeat_fit_max_abs_numeric_difference": f"{repeat_delta:.16e}",
        "training_posterior_RMSE_kcal_mol": f"{train_rmse:.16e}",
    }],
)

attempt_rows = []

for a in fit1["attempts"]:
    attempt_rows.append({
        "start_index": a["start_index"],
        "success": str(a["success"]),
        "final_NLL": f"{a['nll']:.12f}",
        "final_sigma_f": f"{a['sigma_f']:.12f}",
        "final_ell_phi": f"{a['ell_phi']:.12f}",
        "final_ell_psi": f"{a['ell_psi']:.12f}",
        "final_ell_omega": f"{a['ell_omega']:.12f}",
        "optimizer_iterations": a["nit"],
        "optimizer_message": a["message"],
        "is_selected_start": str(
            a["start_index"] == b1["start_index"]
        ),
    })

write_tsv(HYPER_ATTEMPTS, attempt_rows)

print("[PASS] deterministic 222-label GP refit completed")




write_tsv = _continuation_original_write_tsv
del _continuation_original_write_tsv

print("\n===== 6C. CONTINUATION IN-MEMORY REFIT REPRODUCTION GATE =====")

for _path, _expected in {
    EXEC_PROTOCOL: "9ed257b41437e69c8e98d06d0933430d6f6cb9ab8b5f7605cecadbbb83382624",
    HYPERPARAMS: "ba4aa47f89a57e4fd0f32f4b619d62de3ce3a6568a9e0b0f7b249042a69d0c80",
    HYPER_ATTEMPTS: "7e373a9b49373dca004b05a95505c8eb230d3134bd5d75939217d45d546e19db",
}.items():

    if (
        not _path.is_file()
        or sha(_path) != _expected
    ):
        raise SystemExit(
            "[FAIL] frozen post-refit partial missing or changed: "
            + _path.name
        )

if set(_continuation_captured_tsv) != {
    HYPERPARAMS.name,
    HYPER_ATTEMPTS.name,
}:
    raise SystemExit(
        "[FAIL] independent refit capture set differs "
        "from HYPERPARAMS+ATTEMPTS"
    )

import io as _continuation_io

def _continuation_serialize_tsv(_rows):
    if not _rows:
        raise RuntimeError("no rows in continuation serialization")

    _buffer = _continuation_io.StringIO(
        newline=""
    )

    _writer = csv.DictWriter(
        _buffer,
        fieldnames=list(_rows[0]),
        delimiter="\t",
        lineterminator="\n",
    )

    _writer.writeheader()
    _writer.writerows(_rows)

    return _buffer.getvalue().encode(
        "utf-8"
    )

for _frozen in (
    HYPERPARAMS,
    HYPER_ATTEMPTS,
):
    _rows = _continuation_captured_tsv[
        _frozen.name
    ]

    _reproduced = _continuation_serialize_tsv(
        _rows
    )

    _frozen_bytes = _frozen.read_bytes()

    print(
        "independent refit reproduction:",
        _frozen.name,
    )

    print(
        " frozen sha     =",
        sha(_frozen),
    )

    print(
        " reproduced sha =",
        hashlib.sha256(
            _reproduced
        ).hexdigest(),
    )

    print(
        " byte-identical =",
        _reproduced == _frozen_bytes,
    )

    if _reproduced != _frozen_bytes:
        raise SystemExit(
            "[FAIL] independently reproduced refit TSV "
            "differs from frozen partial: "
            + _frozen.name
        )

print(
    "[PASS] independent 222-label/17-start refit "
    "reproduces frozen HYPERPARAMS and ATTEMPTS byte-for-byte"
)

print(
    "[PASS] CONTINUATION PRE-SCORE GATE PASSED; "
    "untouched Section7+ scoring is authorized"
)


print("\n===== 7. BUILD EXACT 1398-STATE REMAINING ACQUISITION UNIVERSE =====")

acq = load(ACQUISITION)
val = load(VALIDATION)
r1 = load(B1_SELECTION)
r2 = load(B2_SELECTION)
r3 = load(B3_SELECTION)
r4 = load(B4_SELECTION)
r5 = load(B5_SELECTION)
r6 = load(B6_SELECTION)
r7 = load(B7_SELECTION)

if len(acq) != 1566:
    raise SystemExit(f"[FAIL] acquisition rows={len(acq)}")
if len(val) != 144:
    raise SystemExit(f"[FAIL] validation rows={len(val)}")
if not (len(r1)==len(r2)==len(r3)==len(r4)==len(r5)==24):
    raise SystemExit("[FAIL] previous batch selection counts")

ids1 = {r["state_id"] for r in r1}
ids2 = {r["state_id"] for r in r2}
ids3 = {r["state_id"] for r in r3}
ids4 = {r["state_id"] for r in r4}
ids5 = {r["state_id"] for r in r5}
ids6 = {r["state_id"] for r in r6}
ids7 = {r["state_id"] for r in r7}

previous_sets = [ids1, ids2, ids3, ids4, ids5, ids6, ids7]

for i in range(7):
    for j in range(i+1,7):
        if previous_sets[i] & previous_sets[j]:
            raise SystemExit("[FAIL] overlap among previous GP batches")

selected168 = ids1 | ids2 | ids3 | ids4 | ids5 | ids6 | ids7

if len(selected168) != 168:
    raise SystemExit("[FAIL] cumulative previous identity count !=168")

acq_ids = {r["state_id"] for r in acq}
val_ids = {r["state_id"] for r in val}

if not selected168 <= acq_ids:
    raise SystemExit("[FAIL] previous GP state missing from acquisition pool")

remaining = [
    r for r in acq
    if r["state_id"] not in selected168
]

if len(remaining) != 1398:
    raise SystemExit(f"[FAIL] remaining candidates={len(remaining)}")

if {r["state_id"] for r in remaining} & val_ids:
    raise SystemExit("[FAIL] validation leakage")

candidates = []

for r in remaining:
    p = Path(r["final_start_xyz"])
    if not p.exists():
        raise SystemExit(f"[FAIL] candidate geometry missing: {r['state_id']}")
    if sha(p) != r["final_start_xyz_sha256"]:
        raise SystemExit(f"[FAIL] candidate geometry changed: {r['state_id']}")

    candidates.append({
        "state_id": r["state_id"],
        "phi": float(r["phi_target_deg"]),
        "psi": float(r["psi_target_deg"]),
        "omega": float(r["omega_target_deg"]),
        "start_xyz": str(p),
        "start_xyz_sha256": r["final_start_xyz_sha256"],
    })

candidates = sorted(candidates, key=lambda r: r["state_id"])

print("original acquisition pool =", len(acq))
print("already acquired identities =", len(selected168))
print("Batch08 selectable universe =", len(candidates))
print("[PASS] exact 1398-state post-Batch06 universe recovered")


print("\n===== 8. INITIAL 222-LABEL GP SCORE AUDIT OF ALL 1398 STATES =====")

Xcand = np.asarray([
    [r["phi"], r["psi"], r["omega"]]
    for r in candidates
], dtype=float)

initial = gp.acquisition_scores(
    Xtrain,
    Xcand,
    b1["sigma_f"],
    ell,
)

scores = np.asarray(initial["score"], dtype=float)
sdR = np.asarray(initial["sd_R"], dtype=float)
sdJ = np.asarray(initial["sd_J"], dtype=float)

score_rows = []

for i,r in enumerate(candidates):
    score_rows.append({
        "state_id": r["state_id"],
        "phi_deg": f"{r['phi']:+.1f}",
        "psi_deg": f"{r['psi']:+.1f}",
        "omega_deg": f"{r['omega']:+.1f}",
        "Batch08_initial_SD_R_kcal_mol": f"{sdR[i]:.12f}",
        "Batch08_initial_SD_J_kcal_mol": f"{sdJ[i]:.12f}",
        "Batch08_initial_acquisition_score": f"{scores[i]:.12f}",
    })

write_tsv(INITIAL_SCORES, score_rows)

print(
    "initial score range =",
    f"{scores.min():.12f}",
    "to",
    f"{scores.max():.12f}",
)
print(
    "initial SD[R] range =",
    f"{sdR.min():.12f}",
    "to",
    f"{sdR.max():.12f}",
    "kcal/mol",
)
print(
    "initial SD[J] range =",
    f"{sdJ.min():.12f}",
    "to",
    f"{sdJ.max():.12f}",
    "kcal/mol",
)

trans_idx = [
    i for i,r in enumerate(candidates)
    if abs(abs(r["omega"])-180.0) < 1e-12
]

max_trans_sdJ = float(np.max(sdJ[trans_idx]))

print(
    "maximum trans-state SD[J] =",
    f"{max_trans_sdJ:.16e}",
    "kcal/mol",
)

if max_trans_sdJ > 1e-6:
    raise SystemExit("[FAIL] trans-reference J behavior changed")

top15 = sorted(
    zip(candidates, scores, sdR, sdJ),
    key=lambda x: (-x[1], x[0]["state_id"]),
)[:15]

print("\nTOP 15 BATCH08 INITIAL SCORES")
print("rank\tstate\tphi\tpsi\tomega\tSD_R\tSD_J\tscore")

for i,(r,score,sr,sj) in enumerate(top15,1):
    print(
        f"{i}\t{r['state_id']}\t"
        f"{r['phi']:+.0f}\t{r['psi']:+.0f}\t{r['omega']:+.0f}\t"
        f"{sr:.8f}\t{sj:.8f}\t{score:.8f}"
    )

print("[PASS] all 1398 remaining coordinates scored without unseen labels")


print("\n===== 9. SELECT GREEDY FANTASY-CONDITIONED BATCH08 =====")

batch = gp.select_fantasy_batch(
    Xtrain,
    candidates,
    b1["sigma_f"],
    ell,
    BATCH_SIZE,
)

repeat = gp.select_fantasy_batch(
    Xtrain,
    candidates,
    b1["sigma_f"],
    ell,
    BATCH_SIZE,
)

ids_a = [r["state_id"] for r in batch]
ids_b = [r["state_id"] for r in repeat]

if ids_a != ids_b:
    raise SystemExit("[FAIL] independent Batch08 selection changed sequence")

if len(ids_a) != 24 or len(set(ids_a)) != 24:
    raise SystemExit("[FAIL] invalid Batch08 selection size/uniqueness")

if set(ids_a) & selected168:
    raise SystemExit("[FAIL] previous acquisition state reselected")

if set(ids_a) & val_ids:
    raise SystemExit("[FAIL] validation leakage into Batch08")

cmap = {r["state_id"]:r for r in candidates}
selection_rows = []

for s in batch:
    r = cmap[s["state_id"]]
    rank = int(s["selection_rank"])

    selection_rows.append({
        "selection_rank": rank,
        "cumulative_GP_acquisition_rank": 168 + rank,
        "state_id": s["state_id"],
        "phi_target_deg": f"{r['phi']:+.1f}",
        "psi_target_deg": f"{r['psi']:+.1f}",
        "omega_target_deg": f"{r['omega']:+.1f}",
        "selection_step_SD_R_kcal_mol": f"{s['sd_R']:.12f}",
        "selection_step_SD_J_kcal_mol": f"{s['sd_J']:.12f}",
        "selection_step_score": f"{s['score']:.12f}",
        "minimum_periodic_distance_to_labeled_plus_prior_selected_deg":
            f"{s['min_dist']:.12f}",
        "start_xyz": r["start_xyz"],
        "start_xyz_sha256": r["start_xyz_sha256"],
    })

if sorted(
    int(r["cumulative_GP_acquisition_rank"])
    for r in selection_rows
) != list(range(169,193)):
    raise SystemExit("[FAIL] cumulative ranks are not 169..192")

write_tsv(SELECTION, selection_rows)

print("Batch08 states =", len(selection_rows))
print(
    "rank\tcumRank\tstate\tphi\tpsi\tomega\t"
    "SD_R\tSD_J\tscore\tminDist"
)

for r in selection_rows:
    print(
        f"{r['selection_rank']}\t"
        f"{r['cumulative_GP_acquisition_rank']}\t"
        f"{r['state_id']}\t"
        f"{r['phi_target_deg']}\t"
        f"{r['psi_target_deg']}\t"
        f"{r['omega_target_deg']}\t"
        f"{r['selection_step_SD_R_kcal_mol']}\t"
        f"{r['selection_step_SD_J_kcal_mol']}\t"
        f"{r['selection_step_score']}\t"
        f"{r['minimum_periodic_distance_to_labeled_plus_prior_selected_deg']}"
    )

print("[PASS] Batch08 24-state sequence reproduced identically")


print("\n===== 10. COVERAGE / ISOLATION AUDIT =====")

phis = [float(r["phi_target_deg"]) for r in selection_rows]
psis = [float(r["psi_target_deg"]) for r in selection_rows]
oms = [float(r["omega_target_deg"]) for r in selection_rows]

cis = sum(abs(x)<1e-12 for x in oms)
trans = sum(abs(abs(x)-180.0)<1e-12 for x in oms)
intermediate = 24-cis-trans

print("unique phi levels =", len(set(phis)))
print("unique psi levels =", len(set(psis)))
print("unique omega levels =", len(set(oms)))
print("cis states =", cis)
print("trans states =", trans)
print("intermediate-omega states =", intermediate)

for r in selection_rows:
    p = Path(r["start_xyz"])
    if not p.exists() or sha(p) != r["start_xyz_sha256"]:
        raise SystemExit(f"[FAIL] selected geometry changed: {r['state_id']}")

print("[PASS] zero Batch01/02/03/04/05/06 reselection")
print("[PASS] zero validation leakage")
print("[PASS] all selected geometries match frozen candidate pool")


print("\n===== 11. WRITE BATCH08 SELECTION SUMMARY =====")

SUMMARY.write_text(f"""# NMe-Ala joint GP active-learning Batch08 selection summary v1

STATUS: BATCH08 IDENTITIES FROZEN BEFORE ANY BATCH08 QM.

Training labels at selection:
222.

Composition:
54 harmonized identifiability seeds;
168 accepted GP acquisition labels with cumulative ranks 1-168.

All labels use:
PMEMD_PRINTED_NINE_COMPONENT_SUM.

GP refit:
sigma_f = {b1['sigma_f']:.12f}
ell_phi = {b1['ell_phi']:.12f}
ell_psi = {b1['ell_psi']:.12f}
ell_omega = {b1['ell_omega']:.12f}
NLL = {b1['nll']:.12f}

Training posterior RMSE:
{train_rmse:.12e} kcal/mol.

Independent repeat-fit maximum difference:
{repeat_delta:.16e}.

Acquisition universe:
original = 1566
already selected before Batch08 = 168
selectable = 1398.

Batch08 selected:
24.

Cumulative GP acquisition identities:
192.

Batch08 labels visible during selection:
0.

Greedy fantasy-coordinate conditioning:
yes.

Invented residual labels:
none.

Repeated selection:
identical.

Coverage:
unique phi = {len(set(phis))}
unique psi = {len(set(psis))}
unique omega = {len(set(oms))}
cis = {cis}
trans = {trans}
intermediate = {intermediate}.

Overlap with Batch01/02/03/04/05/06/07:
0.

Validation overlap:
0.

PPII accessed:
no.

The GP arm now has 192 frozen acquisition identities.
The GP acquisition identity arm is now frozen through B192.
The B192 labeled-training checkpoint requires Batch08 QM/M0 labels
before any refit on the newly selected 24 states.

No Batch08 QM.
No Batch08 M0.
No validation label.
No production fit.
""")


print(SUMMARY.read_text())


print("\n===== 12. FINAL CHECKSUMS / BATCH08 SELECTION FREEZE =====")

freeze_paths = [
    TRAIN_PROTOCOL,
    TRAIN222,
    TRAIN_AUDIT,
    TRAIN_SUMMARY,
    TRAIN_FREEZE,
    TRAIN_FINAL_QC,
    TRAIN_CLOSURE,
    TRAIN_CLOSURE_FREEZE,
    GP_PROTOCOL,
    GP_MODULE,
    GP_FREEZE,
    ACQUISITION,
    VALIDATION,
    ROLE_MANIFEST,
    B1_SELECTION,
    B1_FREEZE,
    B2_SELECTION,
    B2_FREEZE,
    B3_SELECTION,
    B3_FREEZE,
    B4_SELECTION,
    B4_FREEZE,
    B5_SELECTION,
    B5_FREEZE,
    B6_SELECTION,
    B6_FREEZE,
    B6_QC,
    ACQ_PROTOCOL,
    ACQ_FREEZE,
    EVAL_FREEZE,
    EXEC_PROTOCOL,
    RECOVERY_AMENDMENT,
    CONTINUATION_AMENDMENT,
    HYPERPARAMS,
    HYPER_ATTEMPTS,
    INITIAL_SCORES,
    SELECTION,
    SUMMARY,
    Path(__file__),
    B7_SELECTION,
    B7_FREEZE,
]

FREEZE.write_text(
    "".join(
        f"{sha(p)}  {p}\n"
        for p in freeze_paths
    )
)

for p in (
    EXEC_PROTOCOL,
    HYPERPARAMS,
    HYPER_ATTEMPTS,
    INITIAL_SCORES,
    SELECTION,
    SUMMARY,
):
    print(sha(p), p)

print("freeze entries =", len(freeze_paths))
print("Batch08 selection freeze SHA256 =", sha(FREEZE))


print("\n===== FINAL RESULT =====")
print("[PASS] exact frozen 222-label GP training input used")
print("[PASS] frozen periodic-GP implementation unchanged")
print("[PASS] hyperparameters refitted only from 222 available labels")
print("[PASS] independent refit reproduced deterministically")
print("[PASS] exact 1398-state remaining acquisition universe used")
print("[PASS] all 1398 coordinates scored without unseen labels")
print("[PASS] exact 24-state Batch08 selected")
print("[PASS] Batch08 sequence repeated identically")
print("[PASS] cumulative identities now exactly 168")
print("[PASS] zero Batch01/02/03/04/05/06 reselection")
print("[PASS] zero validation leakage")
print("[PASS] PPII holdout remained sealed")
print("[PASS] Batch08 identities frozen before QM")
print("[PASS] no Batch08 QM calculation run")
print("[PASS] no Batch08 M0 calculation run")
print("[PASS] no validation label opened")
print("[PASS] no production fitting performed")
print("\n===== NME-ALA GP ACTIVE-LEARNING BATCH08 SELECTION FROZEN =====")
