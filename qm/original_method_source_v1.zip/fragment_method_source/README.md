# Original fragment-method source

This compact archive retains the original final-batch GP selection, ORCA input/job,
same-geometry M0 label and output-validation implementations. Source files are
byte-identical; descriptive aliases and their original identities are in MANIFEST.json.
The original lab drivers retain their project paths and guards. They are reference
implementations, not the portable entry points. Numerical reproduction uses qm/, 
acquisition/ and validation/; native fragment inputs are in validation/native_inputs_v3.0.zip.
GP kernels, fitting and fantasy-batch selection functions are in acquisition/code/periodic_gp_v1.py.
No archived job driver is executed during the portable checks.
