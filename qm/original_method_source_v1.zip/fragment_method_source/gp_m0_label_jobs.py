from pathlib import Path
import csv, hashlib, math, os, re, subprocess
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import numpy as np
import parmed as pmd
ROOT = Path('/mnt/lab/zn/mem-perm/P0_starter_v1')
DEV = ROOT / '07_nmeala_separability_pilot' / '13_joint_correction_development'
SEL = DEV / '06_gp_active_learning' / '30_batch08_selection'
SELECTION = SEL / 'NMEALA_JOINT_GP_BATCH08_24_SELECTION_v1.tsv'
SEL_FREEZE = SEL / 'NMEALA_JOINT_GP_BATCH08_SELECTION_FREEZE_v1.sha256'
QM = DEV / '06_gp_active_learning' / '31_batch08_qm'
QM_RESULTS = QM / 'NMEALA_JOINT_GP_BATCH08_R2SCAN_RESULTS_v1.tsv'
QM_PROTOCOL = QM / 'NMEALA_JOINT_GP_BATCH08_QM_PROTOCOL_v1.md'
POST_QM_QC = DEV / '06_gp_active_learning' / 'run_qc_gp_batch08_fresh_qm_execution_v2.py'
TRAIN = DEV / '06_gp_active_learning' / '29_batch08_training_set'
TRAIN198 = TRAIN / 'NMEALA_JOINT_GP_BATCH08_INPUT_222_LABELS_v1.tsv'
TRAIN_FREEZE = TRAIN / 'NMEALA_JOINT_GP_BATCH08_222LABEL_TRAININGSET_FREEZE_v1.sha256'
PARSER = DEV / '06_gp_active_learning' / '04_batch01_label_acceptance' / 'NMEALA_JOINT_GP_BATCH01_M0_PARSER_QC_AMENDMENT_v1.md'
PRMTOP = ROOT / '06_m0_formal_resp' / '03_tleap_topology' / 'nmeala_resp_v1.prmtop'
PMEMD = Path('/home/dlab/software/pmemd24/bin/pmemd')
OUT = DEV / '06_gp_active_learning' / '32_batch08_m0'
RUNS = OUT / 'runs'
MDIN = OUT / 'batch08_same_geometry_zero_step_v1.in'
PROTOCOL = OUT / 'NMEALA_JOINT_GP_BATCH08_SAME_GEOMETRY_M0_PROTOCOL_v1.md'
M0_RESULTS = OUT / 'NMEALA_JOINT_GP_BATCH08_ACCEPTED_M0_RESULTS_v1.tsv'
LABELS = OUT / 'NMEALA_JOINT_GP_BATCH08_24_LABELS_v1.tsv'
SUMMARY = OUT / 'NMEALA_JOINT_GP_BATCH08_LABEL_GENERATION_SUMMARY_v1.md'
FREEZE = OUT / 'NMEALA_JOINT_GP_BATCH08_LABEL_GENERATION_FREEZE_v1.sha256'
H2K = 627.509474
SER_TOL = 1e-06
MAX_WORKERS = 4
COMPONENTS = ['BOND', 'ANGLE', 'DIHED', 'VDWAALS', 'EEL', 'HBOND', '1-4 VDW', '1-4 EEL', 'RESTRAINT']

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()

def read_xyz(p):
    z = Path(p).read_text().splitlines()
    n = int(z[0])
    s = []
    x = []
    for line in z[2:2 + n]:
        a = line.split()
        s.append(a[0])
        x.append([float(a[1]), float(a[2]), float(a[3])])
    return (s, np.asarray(x, float))

def write_rst7(p, x, title):
    flat = np.asarray(x, float).reshape(-1)
    with Path(p).open('w') as f:
        f.write(title[:80] + '\n')
        f.write(f'{len(x):6d}{0.0:15.7E}\n')
        for i in range(0, len(flat), 6):
            f.write(''.join((f'{v:12.7f}' for v in flat[i:i + 6])) + '\n')

def read_rst7(p, n):
    lines = Path(p).read_text().splitlines()
    if int(lines[1].split()[0]) != n:
        raise RuntimeError('rst7 atom count')
    vals = []
    for line in lines[2:]:
        for i in range(0, len(line), 12):
            q = line[i:i + 12]
            if q.strip():
                vals.append(float(q))
        if len(vals) >= 3 * n:
            break
    if len(vals) < 3 * n:
        raise RuntimeError('short rst7')
    return np.asarray(vals[:3 * n], float).reshape(n, 3)

def last_component(text, key):
    num = '([-+]?(?:\\d+\\.\\d*|\\d*\\.\\d+|\\d+)(?:[Ee][-+]?\\d+)?)'
    pat = {'BOND': f'\\bBOND\\s*=\\s*{num}', 'ANGLE': f'\\bANGLE\\s*=\\s*{num}', 'DIHED': f'\\bDIHED\\s*=\\s*{num}', 'VDWAALS': f'\\bVDWAALS\\s*=\\s*{num}', 'EEL': f'(?<!1-4 )\\bEEL\\s*=\\s*{num}', 'HBOND': f'\\bHBOND\\s*=\\s*{num}', '1-4 VDW': f'1-4\\s+VDW\\s*=\\s*{num}', '1-4 EEL': f'1-4\\s+EEL\\s*=\\s*{num}', 'RESTRAINT': f'\\bRESTRAINT\\s*=\\s*{num}'}[key]
    hits = re.findall(pat, text, re.I)
    if not hits:
        raise RuntimeError(f'missing {key}')
    return float(hits[-1])

def nonfinite_audit(text):
    lines = text.splitlines()
    nh = [(i, l) for i, l in enumerate(lines) if re.search('\\bNaN\\b', l, re.I)]
    benign = []
    bad = []
    for i, l in nh:
        prev = lines[i - 1] if i else ''
        ok = re.match('^\\s*\\|\\s*Direct force subcell size\\s*=\\s*NaN\\s+NaN\\s+NaN\\s*$', l, re.I) and re.search('Coordinate Index Table dimensions:\\s*0\\s+0\\s+0', prev, re.I)
        (benign if ok else bad).append((i + 1, l))
    inf = re.findall('(?<![A-Za-z])[-+]?Inf(?:inity)?(?![A-Za-z])', text, re.I)
    stars = re.findall('=\\s*\\*{5,}', text)
    return (nh, benign, bad, inf, stars)
print('===== 1. VERIFY FROZEN BATCH08 QM / M0 PROVENANCE =====')
expected = {SELECTION: '4e274b1b8fcbaa88015d4481d20a72fb011a52a98773eb811acaec5713703171', SEL_FREEZE: '71cd2dcdad908b23547404184dc4aa1227e3c5672a070a6831a39fa82a1b8052', QM_RESULTS: '2436545ccb2fb0b53353465b714b8b9d2f04628478d6270c5125890585e13d12', QM_PROTOCOL: 'b0ee82abe82ed0429402bd413242d6244ce43a94f86e2cc8e410e1aa193742ab', POST_QM_QC: '849e85a811b86555a0b66934c761941b446d3ca49aa24e87b813c32d954b015f', TRAIN198: 'f66b88725f1d13cbf5be4ffb2e4be35eb65ebde9195e3094dd173c9b1d8d1b9d', TRAIN_FREEZE: '24c50df47563372e8f5ce2e143b0ce65bc1158f00d14f664d08a8cbc976e5fa2', PARSER: '70a9e747c6f2eef62d0ddcbff44362af45cebcdb28bd56f16a009888d5f73c63', PRMTOP: '9b2c68fad482b03562a4b9c956dc57586bfc73384bb3a68b019e866c1275f5e6'}
for p, h in expected.items():
    if not p.exists():
        raise SystemExit(f'[FAIL] missing {p}')
    a = sha(p)
    print(f'{p}\nexpected = {h}\nactual   = {a}')
    if a != h:
        raise SystemExit(f'[FAIL] frozen input changed: {p}')
if not PMEMD.exists():
    raise SystemExit('[FAIL] pmemd missing')
if sha(PMEMD) != 'd86788a7e398f704c0a3f7e8c752a25ca3a7a56bd19cb602dfa8b80f790d1193':
    raise SystemExit('[FAIL] pmemd binary changed')
print('[PASS] accepted Batch08 QM and formal M0 provenance verified')
print('\n===== 2. OUTPUT SAFETY CHECK =====')
if OUT.exists():
    raise SystemExit(f'[FAIL] output exists: {OUT}')
RUNS.mkdir(parents=True)
print('[PASS] clean Batch08 M0-label directory created')
print('\n===== 3. FREEZE SAME-GEOMETRY M0 PROTOCOL =====')
MDIN.write_text('Batch08 exact same-geometry M0 zero-step\n&cntrl\n imin=1,\n maxcyc=0,\n ncyc=0,\n ntmin=0,\n ntb=0,\n igb=0,\n cut=999.0,\n ntpr=1,\n ntxo=2,\n/\n')
PROTOCOL.write_text('# NMe-Ala GP Batch08 same-geometry M0 / label protocol v1\n\nFROZEN AFTER 24/24 BATCH08 QM PASS AND BEFORE M0 RESULTS.\n\nExactly the frozen 24 Batch08 QM final geometries are used.\nNo state substitution and no MM geometry optimization.\n\nFormal baseline:\nfrozen NMe-Ala GAFF2 + RESP prmtop.\n\nZero-step:\nimin=1; maxcyc=0; ncyc=0; ntmin=0;\nntb=0; igb=0; cut=999.0; ntpr=1; ntxo=2.\n\nQM job.xyz is serialized directly to AMBER coordinates.\nMaximum serialization error: 1e-6 A.\n\nThe frozen benign-NaN QC rule is retained:\nonly\nDirect force subcell size = NaN NaN NaN\npreceded by\nCoordinate Index Table dimensions: 0 0 0\nis allowed.\n\nAll other NaN, Inf/Infinity, and >=5-star numerical assignments fail.\n\nAuthoritative M0 is the printed nine-component sum:\nBOND + ANGLE + DIHED + VDWAALS + EEL + HBOND\n+ 1-4 VDW + 1-4 EEL + RESTRAINT.\n\nGP label:\nR = E_QM * 627.509474 - E_M0_component_sum.\n\nPrecision convention:\nPMEMD_PRINTED_NINE_COMPONENT_SUM.\n\nNo post-B192 GP fit/evaluation.\nNo validation labels.\nPPII sealed.\nNo production fit.\n')
print('mdin SHA256 =', sha(MDIN))
print('M0 protocol SHA256 =', sha(PROTOCOL))
print('[PASS] Batch08 M0 protocol frozen before results')
print('\n===== 4. LOAD / SERIALIZE 24 ACCEPTED QM GEOMETRIES =====')
with QM_RESULTS.open() as f:
    qrows = list(csv.DictReader(f, delimiter='\t'))
with SELECTION.open() as f:
    srows = list(csv.DictReader(f, delimiter='\t'))
if len(qrows) != 24 or len(srows) != 24:
    raise SystemExit('[FAIL] row count')
if any((r['status'] != 'PASS' for r in qrows)):
    raise SystemExit('[FAIL] non-PASS QM')
if {r['state_id'] for r in qrows} != {r['state_id'] for r in srows}:
    raise SystemExit('[FAIL] identity mismatch')
parm = pmd.load_file(str(PRMTOP))
zsym = {1: 'H', 6: 'C', 7: 'N', 8: 'O'}
formal = [zsym[a.atomic_number] for a in parm.atoms]
if len(formal) != 25:
    raise SystemExit('[FAIL] atom count')
prepared = []
for q in sorted(qrows, key=lambda r: int(r['selection_rank'])):
    sid = q['state_id']
    src = Path(q['final_xyz'])
    if not src.exists() or sha(src) != q['final_xyz_sha256']:
        raise SystemExit(f'[FAIL] QM XYZ changed: {sid}')
    sy, x = read_xyz(src)
    if sy != formal:
        raise SystemExit(f'[FAIL] atom order: {sid}')
    rd = RUNS / sid
    rd.mkdir()
    crd = rd / 'exact_qm.rst7'
    write_rst7(crd, x, f'NMe-Ala Batch08 {sid}')
    back = read_rst7(crd, 25)
    delta = float(np.max(np.linalg.norm(back - x, axis=1)))
    print(f'{sid}\tserialization_delta={delta:.10g} A')
    if delta > SER_TOL:
        raise SystemExit(f'[FAIL] serialization: {sid}')
    prepared.append({'rank': int(q['selection_rank']), 'cum': int(q['cumulative_GP_acquisition_rank']), 'sid': sid, 'phi': q['phi_target_deg'], 'psi': q['psi_target_deg'], 'omega': q['omega_target_deg'], 'qm_Eh': float(q['final_energy_Eh']), 'qm_xyz': src, 'qm_sha': q['final_xyz_sha256'], 'crd': crd, 'crd_sha': sha(crd), 'delta': delta})
print('[PASS] 24/24 exact QM geometries serialized')
print('\n===== 5. RUN 24 ZERO-STEP M0 EVALUATIONS =====')
env = os.environ.copy()

def run(item):
    rd = RUNS / item['sid']
    out = rd / 'm0.out'
    with (rd / 'pmemd_stdout.txt').open('w') as f:
        p = subprocess.run([str(PMEMD), '-O', '-i', str(MDIN), '-o', str(out), '-p', str(PRMTOP), '-c', str(item['crd']), '-r', str(rd / 'restrt'), '-inf', str(rd / 'mdinfo')], cwd=rd, stdout=f, stderr=subprocess.STDOUT, env=env)
    (rd / 'exitcode.txt').write_text(str(p.returncode) + '\n')
    return (item['sid'], p.returncode)
done = 0
with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
    fs = {ex.submit(run, x): x['sid'] for x in prepared}
    for fut in as_completed(fs):
        sid = fs[fut]
        try:
            _, rc = fut.result()
            tag = 'EXIT0' if rc == 0 else f'EXIT{rc}'
        except Exception as e:
            tag = f'EXCEPTION:{e!r}'
        done += 1
        print(f'[PROGRESS] {done:2d}/24 {sid} {tag}')
print('\n===== 6. PARSE / QC / GENERATE BATCH08 LABELS =====')
m0rows = []
labels = []
for x in sorted(prepared, key=lambda z: z['rank']):
    rd = RUNS / x['sid']
    out = rd / 'm0.out'
    ef = rd / 'exitcode.txt'
    reasons = []
    ec = ef.read_text().strip() if ef.exists() else 'MISSING'
    if ec != '0':
        reasons.append('NONZERO_EXIT')
    text = out.read_text(errors='ignore') if out.exists() else ''
    if not text:
        reasons.append('NO_M0_OUTPUT')
    comp = {}
    total = None
    benign_n = 0
    unexpected_n = 0
    if text:
        nh, bn, bad, inf, stars = nonfinite_audit(text)
        benign_n = len(bn)
        unexpected_n = len(bad) + len(inf) + len(stars)
        if len(nh) != 1 or benign_n != 1:
            reasons.append('BENIGN_NAN_NOT_UNIQUE')
        if bad:
            reasons.append('UNEXPECTED_NAN')
        if inf:
            reasons.append('INF_INFINITY')
        if stars:
            reasons.append('OVERFLOW_STARS')
        try:
            comp = {k: last_component(text, k) for k in COMPONENTS}
        except Exception as e:
            reasons.append('COMPONENT_PARSE:' + str(e))
        if len(comp) == 9:
            if not all((math.isfinite(v) for v in comp.values())):
                reasons.append('NONFINITE_COMPONENT')
            else:
                total = float(sum((comp[k] for k in COMPONENTS)))
                if not math.isfinite(total):
                    reasons.append('NONFINITE_TOTAL')
                if abs(comp['RESTRAINT']) > 1e-08:
                    reasons.append('NONZERO_RESTRAINT')
    status = 'PASS' if not reasons else 'HOLD'
    R = x['qm_Eh'] * H2K - total if status == 'PASS' else None
    row = {'selection_rank': x['rank'], 'cumulative_GP_acquisition_rank': x['cum'], 'state_id': x['sid'], 'phi_target_deg': x['phi'], 'psi_target_deg': x['psi'], 'omega_target_deg': x['omega'], 'qm_energy_Eh': f"{x['qm_Eh']:.12f}", 'qm_xyz': str(x['qm_xyz']), 'qm_xyz_sha256': x['qm_sha'], 'amber_coordinate': str(x['crd']), 'amber_coordinate_sha256': x['crd_sha'], 'serialization_max_atom_delta_A': f"{x['delta']:.12e}", 'm0_total_component_sum_kcal_mol': '' if total is None else f'{total:.4f}', 'absolute_QM_minus_M0_residual_kcal_mol': '' if R is None else f'{R:.12f}', 'allowed_zero_step_diagnostic_NaN_count': benign_n, 'unexpected_nonfinite_output_count': unexpected_n, 'pmemd_output': str(out) if out.exists() else '', 'pmemd_output_sha256': sha(out) if out.exists() else '', 'status': status, 'failure_reason': ';'.join(reasons)}
    for k in COMPONENTS:
        row['m0_' + k.replace(' ', '_') + '_kcal_mol'] = '' if k not in comp else f'{comp[k]:.4f}'
    m0rows.append(row)
    if status == 'PASS':
        labels.append({'selection_rank': x['rank'], 'cumulative_GP_acquisition_rank': x['cum'], 'state_id': x['sid'], 'phi_deg': x['phi'], 'psi_deg': x['psi'], 'omega_deg': x['omega'], 'QM_energy_Eh': f"{x['qm_Eh']:.12f}", 'M0_energy_component_sum_kcal_mol': f'{total:.4f}', 'absolute_QM_minus_M0_residual_kcal_mol': f'{R:.12f}', 'QM_xyz_sha256': x['qm_sha'], 'M0_coordinate_sha256': x['crd_sha'], 'M0_output_sha256': sha(out), 'label_precision_convention': 'PMEMD_PRINTED_NINE_COMPONENT_SUM', 'label_status': 'ACCEPTED_BATCH08_GP_LABEL'})

def write_tsv(p, rows):
    with Path(p).open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]), delimiter='\t', lineterminator='\n')
        w.writeheader()
        w.writerows(rows)
write_tsv(M0_RESULTS, m0rows)
if labels:
    write_tsv(LABELS, labels)
print('rank\tcumRank\tstate\tstatus\tM0\tR\tNaN_allowed\tunexpected')
for r in m0rows:
    print(f"{r['selection_rank']}\t{r['cumulative_GP_acquisition_rank']}\t{r['state_id']}\t{r['status']}\t{r['m0_total_component_sum_kcal_mol'] or 'NA'}\t{r['absolute_QM_minus_M0_residual_kcal_mol'] or 'NA'}\t{r['allowed_zero_step_diagnostic_NaN_count']}\t{r['unexpected_nonfinite_output_count']}")
    if r['failure_reason']:
        print('  FAILURE:', r['failure_reason'])
counts = Counter((r['status'] for r in m0rows))
npass = counts.get('PASS', 0)
print('status counts =', dict(counts))
print(f"[{('PASS' if npass == 24 else 'HOLD')}] Batch08 M0 accepted = {npass}/24")
print('\n===== 7. LABEL NUMERICAL QC =====')
if npass != 24 or len(labels) != 24:
    raise SystemExit('[HOLD] Batch08 label generation incomplete')
rs = np.asarray([float(r['absolute_QM_minus_M0_residual_kcal_mol']) for r in labels])
ms = np.asarray([float(r['M0_energy_component_sum_kcal_mol']) for r in labels])
maxser = max((float(r['serialization_max_atom_delta_A']) for r in m0rows))
print('Batch08 labels =', len(labels))
print('M0 total range =', f'{ms.min():.4f} to {ms.max():.4f} kcal/mol')
print('residual range =', f'{rs.min():.8f} to {rs.max():.8f} kcal/mol')
print('residual mean =', f'{rs.mean():.8f} kcal/mol')
print('residual SD =', f'{rs.std():.8f} kcal/mol')
print('maximum serialization delta =', f'{maxser:.12e} A')
print('allowed diagnostic NaN count-set =', {int(r['allowed_zero_step_diagnostic_NaN_count']) for r in m0rows})
print('unexpected nonfinite count-set =', {int(r['unexpected_nonfinite_output_count']) for r in m0rows})
print('[PASS] 24/24 Batch08 QM-minus-M0 labels accepted')
print('\n===== 8. WRITE SUMMARY / FREEZE =====')
SUMMARY.write_text(f'# NMe-Ala GP Batch08 label-generation summary v1\n\nSTATUS: BATCH08 DATA GENERATION COMPLETE.\n\nBatch08 identities: 24, cumulative ranks 169-192.\nFresh QM accepted: 24.\nSame-geometry M0 accepted: 24.\nAccepted Batch08 GP labels: 24.\n\nAuthoritative M0:\nPMEMD printed nine-component sum.\n\nM0 range:\n{ms.min():.4f} to {ms.max():.4f} kcal/mol.\n\nResidual range:\n{rs.min():.8f} to {rs.max():.8f} kcal/mol.\n\nResidual mean:\n{rs.mean():.8f} kcal/mol.\n\nResidual SD:\n{rs.std():.8f} kcal/mol.\n\nMaximum QM-to-AMBER serialization delta:\n{maxser:.12e} A.\n\nExpected benign diagnostic NaN per output: 1.\nUnexpected nonfinite output: 0.\n\nCumulative data available for final B192 evaluation:\n54 harmonized seeds + 24 Batch01 + 24 Batch02 + 24 Batch03 + 24 Batch04 + 24 Batch05 + 24 Batch06 + 24 Batch07 + 24 Batch08\n= 246 labels.\n\nNo Batch08 GP fit/scoring was performed.\nNo validation label was opened.\nPPII remained sealed.\nNo production model was fitted.\n')
freeze_paths = [SELECTION, SEL_FREEZE, QM_RESULTS, QM_PROTOCOL, POST_QM_QC, TRAIN198, TRAIN_FREEZE, PARSER, PRMTOP, PMEMD, MDIN, PROTOCOL, M0_RESULTS, LABELS, SUMMARY, Path(__file__)]
for x in prepared:
    freeze_paths.extend([x['qm_xyz'], x['crd']])
for r in m0rows:
    freeze_paths.append(Path(r['pmemd_output']))
seen = set()
uniq = []
for p in freeze_paths:
    p = Path(p)
    if str(p) not in seen:
        seen.add(str(p))
        uniq.append(p)
FREEZE.write_text(''.join((f'{sha(p)}  {p}\n' for p in uniq)))
for p in (MDIN, PROTOCOL, M0_RESULTS, LABELS, SUMMARY):
    print(sha(p), p)
print('freeze entries =', len(uniq))
print('Batch08 label-generation freeze SHA256 =', sha(FREEZE))
print('\n===== FINAL RESULT =====')
print('[PASS] Batch08 same-geometry M0 = 24/24')
print('[PASS] Batch08 new GP labels = 24/24')
print('[PASS] one benign zero-step NaN per output only')
print('[PASS] no MM geometry optimization')
print('[PASS] no Batch08 GP fitting/scoring')
print('[PASS] no validation label opened')
print('[PASS] PPII holdout remained sealed')
print('[PASS] no production fitting')
print('\n===== NME-ALA GP BATCH08 M0 / LABEL STAGE COMPLETE =====')
