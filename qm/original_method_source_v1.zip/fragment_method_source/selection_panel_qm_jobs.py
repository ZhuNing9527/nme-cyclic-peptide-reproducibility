from pathlib import Path
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import csv
import hashlib
import math
import os
import re
import shutil
import subprocess
import numpy as np
import parmed as pmd

from pathlib import Path
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
import csv
import hashlib
import math
import os
import re
import shutil
import subprocess
import numpy as np
import parmed as pmd

ROOT = Path(
    "/mnt/lab/zn/mem-perm/P0_starter_v1"
)

DEV = (
    ROOT
    / "07_nmeala_separability_pilot"
    / "13_joint_correction_development"
)

EXE = (
    DEV
    / "07_acquisition_benchmark_execution"
)

PRE = (
    EXE
    / "45_internal_validation144_qm_precommit"
)

MANIFEST = (
    PRE
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_EXECUTION_MANIFEST_v1.tsv"
)

PRE_PROTOCOL = (
    PRE
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_LABEL_OPENING_PRECOMMIT_v1.md"
)

PRE_SUMMARY = (
    PRE
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_PRECOMMIT_SUMMARY_v1.md"
)

PRE_FREEZE = (
    PRE
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_PRECOMMIT_FREEZE_v1.sha256"
)

PREPARER = (
    EXE
    / "run_prepare_internal_validation144_qm_precommit_v1.py"
)

PRED = (
    EXE
    / "44_budget192_prelabel_evaluator_predictions"
)

PRED_CLOSE_REPORT = (
    PRED
    / "NMEALA_JOINT_BUDGET192_PRELABEL_PREDICTION_CLOSURE_QC_v1.md"
)

PRED_CLOSE_FREEZE = (
    PRED
    / "NMEALA_JOINT_BUDGET192_PRELABEL_PREDICTION_CLOSURE_FREEZE_v1.sha256"
)

SOURCE_QM_RUNNER = (
    EXE
    / "run_budget192_physical_batch06_qm_v1.py"
)

SOURCE_QM_CLOSE = (
    EXE
    / "40_budget192_physical_batch06_qm"
    / "NMEALA_JOINT_BUDGET192_PHYSICAL_BATCH06_QM_CLOSURE_FREEZE_v1.sha256"
)

VAL = (
    DEV
    / "03_internal_validation_split"
    / "NMEALA_JOINT_144_INTERNAL_VALIDATION_MANIFEST_v1.tsv"
)

PRMTOP = (
    ROOT
    / "06_m0_formal_resp"
    / "03_tleap_topology"
    / "nmeala_resp_v1.prmtop"
)

ORCADIR = Path(
    "/mnt/lab/zn/software/"
    "orca_6_1_1_linux_x86-64_shared_openmpi418_nodmrg"
)

ORCA = (
    ORCADIR
    / "orca"
)

MPIDIR = Path(
    "/mnt/lab/zn/software/openmpi-4.1.8-local"
)

MPIRUN = (
    MPIDIR
    / "bin"
    / "mpirun"
)

OUT = (
    EXE
    / "46_internal_validation144_qm"
)

JOBS = (
    OUT
    / "jobs"
)

PROTOCOL = (
    OUT
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_QM_PROTOCOL_v1.md"
)

RESULTS = (
    OUT
    / "NMEALA_JOINT_INTERNAL_VALIDATION144_R2SCAN_RESULTS_v1.tsv"
)

MAX_WORKERS = 2
TORSION_TOL = 0.10

EXPECTED = {
    MANIFEST:
        "5ca8cdd72c521e0b4e856d2bb39613058bf3fb9ed137e954ab346c2ed43a7821",

    PRE_PROTOCOL:
        "28c390daa924884ce42bf2226b8d2169264c9a8a96639cb416c641f119618c63",

    PRE_SUMMARY:
        "756ecb34e3a2b015d4b727b9a1ada95a0bb32c0b89cc54780de36f8b89d6b280",

    PRE_FREEZE:
        "2baf84ebd4be54fadb13f25daf50cecbeb537489a84cc4c496f97be7bcf8a3d6",

    PREPARER:
        "dd3f53940e11d7f2727f1a5e420b590a764f318f8ed81a437c3a74f0c4f18f92",

    PRED_CLOSE_REPORT:
        "95ab92d7436573e8fe112d7b9e4236ff3d526b955786c978cd5e5670fb409010",

    PRED_CLOSE_FREEZE:
        "24dcd9e6f4b18e3c6518c2526ae3af913e42db92d86ee56f701a165165081ba6",

    SOURCE_QM_RUNNER:
        "86af3b80892a4b5643a416f607cdbe3b294b48b09288314a04eb541e9a7ee73e",

    SOURCE_QM_CLOSE:
        "0d9350ae3ab7bd0ca4ac5f2bd7ab4468bc61d3a61477a675b6457c7dc588cd9c",

    VAL:
        "f93fc7c2b2348f1629ad41a9327d66618f90d46b31520062eed20bdf876f7f66",

    PRMTOP:
        "9b2c68fad482b03562a4b9c956dc57586bfc73384bb3a68b019e866c1275f5e6",

    ORCA:
        "38b5f057452fef275c0a1b98d270ad03d0411dab70453820d1c678bd732f6c83",

    MPIRUN:
        "98208ee7654b64d4073525ccca2719c0ea6fc3beef371fede3f5847d26ed4959",
}

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as fh:
        for block in iter(lambda: fh.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def load(path):
    with Path(path).open('r', encoding='utf-8', newline='') as fh:
        return list(csv.DictReader(fh, delimiter='\t'))

def resolve_input_path(value):
    path = Path(str(value))
    if path.is_absolute():
        return path
    return ROOT / path

def read_xyz(path):
    lines = Path(path).read_text(encoding='utf-8').splitlines()
    n = int(lines[0])
    symbols = []
    xyz = []
    for line in lines[2:2 + n]:
        fields = line.split()
        symbols.append(fields[0])
        xyz.append([float(fields[1]), float(fields[2]), float(fields[3])])
    if len(symbols) != n:
        raise RuntimeError(f'truncated XYZ: {path}')
    return (symbols, np.asarray(xyz, dtype=float))

def dih(xyz, i, j, k, l):
    p0 = xyz[i]
    p1 = xyz[j]
    p2 = xyz[k]
    p3 = xyz[l]
    b0 = p0 - p1
    b1 = p2 - p1
    b2 = p3 - p2
    b1_norm = np.linalg.norm(b1)
    if b1_norm < 1e-12:
        raise RuntimeError('zero central dihedral bond')
    b1 = b1 / b1_norm
    v = b0 - np.dot(b0, b1) * b1
    w = b2 - np.dot(b2, b1) * b1
    nv = np.linalg.norm(v)
    nw = np.linalg.norm(w)
    if nv < 1e-12 or nw < 1e-12:
        raise RuntimeError('degenerate dihedral geometry')
    v = v / nv
    w = w / nw
    xx = np.clip(np.dot(v, w), -1.0, 1.0)
    yy = np.dot(np.cross(b1, v), w)
    return math.degrees(math.atan2(yy, xx))

def periodic_error(value, target):
    return abs((value - target + 180.0) % 360.0 - 180.0)

def chirality(xyz):
    ca = xyz[5]
    return float(np.dot(np.cross(xyz[3] - ca, xyz[7] - ca), xyz[6] - ca))

def run_one(row):
    sid = row['state_id']
    job_dir = JOBS / sid
    with (job_dir / 'job.out').open('w', encoding='utf-8') as output:
        process = subprocess.run([str(ORCA), 'job.inp'], cwd=job_dir, stdout=output, stderr=subprocess.STDOUT, env=environment, check=False)
    (job_dir / 'exitcode.txt').write_text(str(process.returncode) + '\n', encoding='utf-8')
    return (sid, process.returncode)

print(
    "===== FORMAL INTERNAL-VALIDATION144 FRESH QM RUNNER ====="
)

print(
    "CONDA_DEFAULT_ENV =",
    os.environ.get(
        "CONDA_DEFAULT_ENV"
    ),
)

print(
    "PYTHONPATH =",
    os.environ.get(
        "PYTHONPATH"
    ),
)

if os.environ.get(
    "CONDA_DEFAULT_ENV"
) != "nme-torsion-p0":
    raise SystemExit(
        "[FAIL] wrong environment"
    )

if os.environ.get(
    "PYTHONPATH"
) is not None:
    raise SystemExit(
        "[FAIL] PYTHONPATH must be unset"
    )


print(
    "===== 1. VERIFY EXACT FROZEN VALIDATION-QM AUTHORITIES ====="
)

for path, expected in EXPECTED.items():

    if not path.is_file():
        raise SystemExit(
            "[FAIL] required validation-QM authority missing: "
            + str(path)
        )

    actual = sha(path)

    print(path.name)
    print(" expected =", expected)
    print(" actual   =", actual)

    if actual != expected:
        raise SystemExit(
            "[FAIL] validation-QM authority SHA mismatch: "
            + path.name
        )


if not os.access(
    ORCA,
    os.X_OK,
):
    raise SystemExit(
        "[FAIL] ORCA is not executable"
    )

if not os.access(
    MPIRUN,
    os.X_OK,
):
    raise SystemExit(
        "[FAIL] mpirun is not executable"
    )


print(
    "[PASS] exact precommit / prediction closure / topology / executable authorities verified"
)


print(
    "===== 2. REHASH ALL26 VALIDATION-QM PRECOMMIT MEMBERS ====="
)

freeze_rows = []

for line in PRE_FREEZE.read_text(
    encoding="utf-8"
).splitlines():

    if not line.strip():
        continue

    parts = line.split(
        maxsplit=1
    )

    if len(parts) != 2:
        raise SystemExit(
            "[FAIL] malformed validation-QM precommit freeze line"
        )

    recorded, raw_path = parts

    member = resolve_input_path(
        raw_path
    ).resolve()

    if not member.is_file():
        raise SystemExit(
            "[FAIL] validation-QM precommit member missing: "
            + str(member)
        )

    if sha(
        member
    ) != recorded:
        raise SystemExit(
            "[FAIL] validation-QM precommit member changed: "
            + str(member)
        )

    freeze_rows.append(
        (
            recorded,
            member,
        )
    )


if len(
    freeze_rows
) != 26:
    raise SystemExit(
        "[FAIL] validation-QM precommit freeze entries !=26"
    )


if len({
    member
    for _, member in freeze_rows
}) != 26:
    raise SystemExit(
        "[FAIL] duplicate validation-QM precommit member"
    )


print(
    "[PASS] all26 validation-QM precommit authorities rehashed"
)


print(
    "===== 3. OUTPUT SAFETY ====="
)

if OUT.exists():
    raise SystemExit(
        "[FAIL] internal-validation144 QM directory already exists: "
        + str(OUT)
    )


OUT.mkdir(
    parents=True,
    exist_ok=False,
)

JOBS.mkdir(
    parents=False,
    exist_ok=False,
)


print(
    "[PASS] clean internal-validation144 formal QM directory created"
)


print(
    "===== 4. LOAD EXACT144 FROZEN VALIDATION IDENTITIES ====="
)

rows = load(
    MANIFEST
)

if len(
    rows
) != 144:
    raise SystemExit(
        "[FAIL] validation execution manifest rows !=144"
    )


if len({
    row[
        "state_id"
    ]
    for row in rows
}) != 144:
    raise SystemExit(
        "[FAIL] validation state IDs not unique144"
    )


rows = sorted(
    rows,
    key=lambda row:
        int(
            row[
                "validation_rank"
            ]
        ),
)


if [
    int(
        row[
            "validation_rank"
        ]
    )
    for row in rows
] != list(
    range(
        1,
        145,
    )
):
    raise SystemExit(
        "[FAIL] validation ranks !=1..144"
    )


val_rows = load(
    VAL
)

if len(
    val_rows
) != 144:
    raise SystemExit(
        "[FAIL] original validation manifest rows !=144"
    )


if [
    row[
        "state_id"
    ]
    for row in rows
] != [
    row[
        "state_id"
    ]
    for row in val_rows
]:
    raise SystemExit(
        "[FAIL] execution-manifest identities/order differ from locked validation manifest"
    )


for execution_row, validation_row in zip(
    rows,
    val_rows,
):

    for execution_field, validation_field in (
        (
            "phi_target_deg",
            "phi_target_deg",
        ),
        (
            "psi_target_deg",
            "psi_target_deg",
        ),
        (
            "omega_target_deg",
            "omega_target_deg",
        ),
        (
            "start_xyz_sha256",
            "final_start_xyz_sha256",
        ),
    ):

        if (
            execution_row[
                execution_field
            ]
            !=
            validation_row[
                validation_field
            ]
        ):
            raise SystemExit(
                "[FAIL] validation execution/locked-manifest mismatch: "
                + execution_row[
                    "state_id"
                ]
                + " "
                + execution_field
            )


for row in rows:

    sid = row[
        "state_id"
    ]

    path = Path(
        row[
            "start_xyz"
        ]
    )

    if not path.is_absolute():
        path = (
            ROOT
            /
            path
        )

    path = path.resolve()

    if not path.is_file():
        raise SystemExit(
            "[FAIL] validation start geometry missing: "
            + sid
        )

    if sha(
        path
    ) != row[
        "start_xyz_sha256"
    ]:
        raise SystemExit(
            "[FAIL] validation start geometry SHA changed: "
            + sid
        )


print(
    "[PASS] exact144 locked validation identities / ranks / geometries loaded"
)


print(
    "===== 5. LOAD FORMAL 25-ATOM /24-BOND CONNECTIVITY ====="
)

parm = pmd.load_file(
    str(
        PRMTOP
    )
)


if (
    len(
        parm.atoms
    ) != 25
    or
    len(
        parm.bonds
    ) != 24
):
    raise SystemExit(
        "[FAIL] formal topology size !=25 atoms /24 bonds"
    )


bonded = {
    tuple(
        sorted(
            (
                bond.atom1.idx,
                bond.atom2.idx,
            )
        )
    )
    for bond in parm.bonds
}


graph = {
    index:
        set()
    for index in range(
        25
    )
}


for i, j in bonded:

    graph[
        i
    ].add(
        j
    )

    graph[
        j
    ].add(
        i
    )


one3 = set()


for center in range(
    25
):

    neighbors = sorted(
        graph[
            center
        ]
    )

    for a in range(
        len(
            neighbors
        )
    ):

        for b in range(
            a + 1,
            len(
                neighbors
            ),
        ):

            one3.add(
                tuple(
                    sorted(
                        (
                            neighbors[
                                a
                            ],
                            neighbors[
                                b
                            ],
                        )
                    )
                )
            )


zsym = {
    1:
        "H",

    6:
        "C",

    7:
        "N",

    8:
        "O",
}


formal = [
    zsym[
        atom.atomic_number
    ]
    for atom in parm.atoms
]


print(
    "formal atoms =",
    len(
        formal
    ),
)

print(
    "formal bonds =",
    len(
        bonded
    ),
)

print(
    "[PASS] formal 25-atom /24-bond topology loaded"
)


print(
    "===== 6. FREEZE FORMAL VALIDATION144 QM PROTOCOL ====="
)

PROTOCOL.write_text(
"""# NMe-Ala internal-validation144 formal fresh-QM protocol v1

STATUS:
FROZEN AT FORMAL TRUTH GENERATION.

Pre-label model state:
all24 evaluator fits and all3456 validation-coordinate predictions were scientifically closed before this truth-generation run.

States:
exact frozen internal-validation144 identities;
validation ranks1-144;
no state substitution;
no state replacement.

System:
NMe-Ala;
neutral singlet;
25 atoms.

QM:
ORCA 6.1.1;
r2SCAN-3c;
TightSCF;
TightOpt;
CPCM(Water).

Constraints, zero-based:
omega 0 1 3 5
phi   1 3 5 7
psi   3 5 7 9

All other coordinates relax.

Resources:
8 ORCA MPI processes/state;
maxcore 2500 MB/process;
MaxIter 300;
MAX_WORKERS=2.

Acceptance:
exit code 0;
normal ORCA termination;
optimization converged;
final XYZ and final energy present;
maximum torsion-target error <=0.10 degree;
C-alpha chirality sign preserved;
maximum formal bond <1.90 A;
minimum nonlocal distance excluding 1-2 and 1-3 pairs >=0.75 A.

Boundary:
validation144 fresh QM only;
no M0;
no residual;
no RMSE/MAE/AULC;
no low-energy classification;
no evaluator refit;
no evaluator retuning;
no prediction regeneration;
PPII remains sealed.
""",
    encoding="utf-8",
)


print(
    "validation QM protocol SHA256 =",
    sha(
        PROTOCOL
    ),
)

print(
    "[PASS] formal validation144 QM protocol frozen before truth results"
)


print(
    "===== 7. GENERATE EXACT144 ORCA INPUTS ====="
)

for row in rows:

    sid = row[
        "state_id"
    ]

    job_dir = (
        JOBS
        /
        sid
    )

    job_dir.mkdir(
        parents=False,
        exist_ok=False,
    )


    source = Path(
        row[
            "start_xyz"
        ]
    )

    if not source.is_absolute():
        source = (
            ROOT
            /
            source
        )

    source = source.resolve()


    destination = (
        job_dir
        /
        "start.xyz"
    )


    shutil.copy2(
        source,
        destination,
    )


    if sha(
        destination
    ) != row[
        "start_xyz_sha256"
    ]:
        raise SystemExit(
            "[FAIL] copied validation start geometry changed: "
            + sid
        )


    symbols, _ = read_xyz(
        destination
    )


    if symbols != formal:
        raise SystemExit(
            "[FAIL] formal atom order mismatch: "
            + sid
        )


    phi = float(
        row[
            "phi_target_deg"
        ]
    )

    psi = float(
        row[
            "psi_target_deg"
        ]
    )

    om = float(
        row[
            "omega_target_deg"
        ]
    )


    (
        job_dir
        /
        "job.inp"
    ).write_text(
f"""! r2SCAN-3c TightSCF TightOpt CPCM(Water)
%pal nprocs 8 end
%maxcore 2500
%geom
 MaxIter 300
 Constraints
  {{ D 0 1 3 5 {om:9.3f} C }}
  {{ D 1 3 5 7 {phi:9.3f} C }}
  {{ D 3 5 7 9 {psi:9.3f} C }}
 end
end
* xyzfile 0 1 start.xyz
""",
        encoding="utf-8",
    )


print(
    "[PASS] exact144 validation ORCA inputs generated"
)


print(
    "===== 8. RUN EXACT144 FRESH VALIDATION R2SCAN-3C OPTIMIZATIONS ====="
)

environment = os.environ.copy()


environment[
    "PATH"
] = (
    f"{ORCADIR}:{MPIDIR / 'bin'}:"
    +
    environment.get(
        "PATH",
        "",
    )
)


environment[
    "LD_LIBRARY_PATH"
] = (
    f"{ORCADIR}:{MPIDIR / 'lib'}:"
    +
    environment.get(
        "LD_LIBRARY_PATH",
        "",
    )
)


for variable in (
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "BLIS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
):

    environment[
        variable
    ] = "1"


environment.pop(
    "DISPLAY",
    None,
)

environment.pop(
    "XAUTHORITY",
    None,
)

environment.pop(
    "WAYLAND_DISPLAY",
    None,
)


completed = 0


with ThreadPoolExecutor(
    max_workers=MAX_WORKERS
) as executor:

    futures = {
        executor.submit(
            run_one,
            row,
        ):
            row[
                "state_id"
            ]
        for row in rows
    }


    for future in as_completed(
        futures
    ):

        sid = futures[
            future
        ]

        try:

            _,
            return_code = future.result()

            tag = (
                "EXIT0"
                if return_code == 0
                else
                f"EXIT{return_code}"
            )

        except Exception as exc:

            tag = (
                "EXCEPTION:"
                +
                repr(
                    exc
                )
            )


        completed += 1

        print(
            f"[PROGRESS] "
            f"{completed:3d}/144 "
            f"{sid} "
            f"{tag}"
        )


print(
    "===== 9. FINAL INTERNAL-VALIDATION144 QM ACCEPTANCE QC ====="
)

result = []


for row in rows:

    sid = row[
        "state_id"
    ]

    job_dir = (
        JOBS
        /
        sid
    )

    start_path = (
        job_dir
        /
        "start.xyz"
    )

    final_xyz_path = (
        job_dir
        /
        "job.xyz"
    )

    output_path = (
        job_dir
        /
        "job.out"
    )

    exitcode_path = (
        job_dir
        /
        "exitcode.txt"
    )


    text = (
        output_path.read_text(
            encoding="utf-8",
            errors="ignore",
        )
        if output_path.exists()
        else ""
    )


    exitcode = (
        exitcode_path.read_text(
            encoding="utf-8"
        ).strip()
        if exitcode_path.exists()
        else "MISSING"
    )


    normal = (
        "ORCA TERMINATED NORMALLY"
        in text
    )

    converged = (
        "THE OPTIMIZATION HAS CONVERGED"
        in text
    )


    hits = re.findall(
        r"FINAL SINGLE POINT ENERGY\s+(-?\d+\.\d+)",
        text,
    )

    energy = (
        hits[
            -1
        ]
        if hits
        else ""
    )


    reasons = []

    phi = None
    psi = None
    omega = None
    maxerr = None

    start_chi = None
    final_chi = None
    max_bond = None
    min_nonlocal = None

    chirality_ok = False


    if (
        final_xyz_path.exists()
        and
        start_path.exists()
    ):

        final_symbols, final_coordinates = read_xyz(
            final_xyz_path
        )

        start_symbols, start_coordinates = read_xyz(
            start_path
        )


        if (
            final_symbols != start_symbols
            or
            final_symbols != formal
        ):
            reasons.append(
                "ATOM_ORDER_MISMATCH"
            )


        if (
            len(
                final_coordinates
            ) == 25
            and
            len(
                start_coordinates
            ) == 25
        ):

            omega = dih(
                final_coordinates,
                0,
                1,
                3,
                5,
            )

            phi = dih(
                final_coordinates,
                1,
                3,
                5,
                7,
            )

            psi = dih(
                final_coordinates,
                3,
                5,
                7,
                9,
            )


            maxerr = max(
                periodic_error(
                    omega,
                    float(
                        row[
                            "omega_target_deg"
                        ]
                    ),
                ),

                periodic_error(
                    phi,
                    float(
                        row[
                            "phi_target_deg"
                        ]
                    ),
                ),

                periodic_error(
                    psi,
                    float(
                        row[
                            "psi_target_deg"
                        ]
                    ),
                ),
            )


            start_chi = chirality(
                start_coordinates
            )

            final_chi = chirality(
                final_coordinates
            )


            chirality_ok = (
                abs(
                    start_chi
                ) > 1.0e-6
                and
                abs(
                    final_chi
                ) > 1.0e-6
                and
                start_chi
                *
                final_chi
                > 0.0
            )


            max_bond = max(
                float(
                    np.linalg.norm(
                        final_coordinates[
                            i
                        ]
                        -
                        final_coordinates[
                            j
                        ]
                    )
                )
                for i, j
                in bonded
            )


            nonlocal_distances = []


            for i in range(
                25
            ):

                for j in range(
                    i + 1,
                    25,
                ):

                    if (
                        i,
                        j,
                    ) in bonded:
                        continue

                    if (
                        i,
                        j,
                    ) in one3:
                        continue


                    nonlocal_distances.append(
                        float(
                            np.linalg.norm(
                                final_coordinates[
                                    i
                                ]
                                -
                                final_coordinates[
                                    j
                                ]
                            )
                        )
                    )


            min_nonlocal = min(
                nonlocal_distances
            )


    if exitcode != "0":
        reasons.append(
            "NONZERO_EXIT"
        )

    if not normal:
        reasons.append(
            "NO_NORMAL_TERMINATION"
        )

    if not converged:
        reasons.append(
            "OPT_NOT_CONVERGED"
        )

    if not final_xyz_path.exists():
        reasons.append(
            "NO_FINAL_XYZ"
        )

    if not energy:
        reasons.append(
            "NO_FINAL_ENERGY"
        )

    if (
        maxerr is None
        or
        maxerr > TORSION_TOL
    ):
        reasons.append(
            "TORSION_GATE"
        )

    if not chirality_ok:
        reasons.append(
            "CHIRALITY_NOT_PRESERVED"
        )

    if (
        max_bond is None
        or
        max_bond >= 1.90
    ):
        reasons.append(
            "FORMAL_BOND_GATE"
        )

    if (
        min_nonlocal is None
        or
        min_nonlocal < 0.75
    ):
        reasons.append(
            "NONLOCAL_GATE"
        )


    status = (
        "PASS"
        if not reasons
        else
        "HOLD"
    )


    result.append(
        {
            "validation_rank":
                row[
                    "validation_rank"
                ],

            "state_id":
                sid,

            "phi_target_deg":
                row[
                    "phi_target_deg"
                ],

            "psi_target_deg":
                row[
                    "psi_target_deg"
                ],

            "omega_target_deg":
                row[
                    "omega_target_deg"
                ],

            "start_xyz":
                str(
                    start_path
                ),

            "start_xyz_sha256":
                sha(
                    start_path
                ),

            "exitcode":
                exitcode,

            "normal_termination":
                str(
                    normal
                ),

            "optimization_converged":
                str(
                    converged
                ),

            "final_energy_Eh":
                energy,

            "final_phi_deg":
                (
                    ""
                    if phi is None
                    else
                    f"{phi:+.8f}"
                ),

            "final_psi_deg":
                (
                    ""
                    if psi is None
                    else
                    f"{psi:+.8f}"
                ),

            "final_omega_deg":
                (
                    ""
                    if omega is None
                    else
                    f"{omega:+.8f}"
                ),

            "max_constraint_error_deg":
                (
                    ""
                    if maxerr is None
                    else
                    f"{maxerr:.8f}"
                ),

            "start_chirality_scalar":
                (
                    ""
                    if start_chi is None
                    else
                    f"{start_chi:+.10f}"
                ),

            "final_chirality_scalar":
                (
                    ""
                    if final_chi is None
                    else
                    f"{final_chi:+.10f}"
                ),

            "chirality_sign_preserved":
                str(
                    chirality_ok
                ),

            "max_formal_bond_A":
                (
                    ""
                    if max_bond is None
                    else
                    f"{max_bond:.8f}"
                ),

            "min_final_nonlocal_A":
                (
                    ""
                    if min_nonlocal is None
                    else
                    f"{min_nonlocal:.8f}"
                ),

            "final_xyz":
                (
                    str(
                        final_xyz_path
                    )
                    if final_xyz_path.exists()
                    else ""
                ),

            "final_xyz_sha256":
                (
                    sha(
                        final_xyz_path
                    )
                    if final_xyz_path.exists()
                    else ""
                ),

            "status":
                status,

            "failure_reason":
                ",".join(
                    reasons
                ),
        }
    )


with RESULTS.open(
    "w",
    encoding="utf-8",
    newline="",
) as fh:

    writer = csv.DictWriter(
        fh,
        fieldnames=list(
            result[
                0
            ].keys()
        ),
        delimiter="\t",
        lineterminator="\n",
    )

    writer.writeheader()

    writer.writerows(
        result
    )


print(
    "rank\tstate\tstatus\tenergy_Eh\t"
    "phi\tpsi\tomega\tmaxerr\t"
    "chirality\tmaxbond\tmin_nonlocal"
)


for row in result:

    print(
        f"{row['validation_rank']}\t"
        f"{row['state_id']}\t"
        f"{row['status']}\t"
        f"{row['final_energy_Eh'] or 'NA'}\t"
        f"{row['final_phi_deg'] or 'NA'}\t"
        f"{row['final_psi_deg'] or 'NA'}\t"
        f"{row['final_omega_deg'] or 'NA'}\t"
        f"{row['max_constraint_error_deg'] or 'NA'}\t"
        f"{row['chirality_sign_preserved']}\t"
        f"{row['max_formal_bond_A'] or 'NA'}\t"
        f"{row['min_final_nonlocal_A'] or 'NA'}"
    )

    if row[
        "failure_reason"
    ]:
        print(
            "  FAILURE:",
            row[
                "failure_reason"
            ],
        )


counts = Counter(
    row[
        "status"
    ]
    for row in result
)


npass = counts.get(
    "PASS",
    0,
)


passed = [
    row
    for row in result
    if row[
        "status"
    ] == "PASS"
]


print()
print(
    "===== 10. FINAL FORMAL VALIDATION144 QM RESULT ====="
)

print(
    "status counts =",
    dict(
        counts
    ),
)


print(
    f"[{'PASS' if npass == 144 else 'HOLD'}] "
    f"accepted internal-validation QM states = "
    f"{npass}/144"
)


if passed:

    print(
        "maximum accepted torsion error =",
        max(
            float(
                row[
                    "max_constraint_error_deg"
                ]
            )
            for row in passed
        ),
        "deg",
    )

    print(
        "maximum accepted formal bond =",
        max(
            float(
                row[
                    "max_formal_bond_A"
                ]
            )
            for row in passed
        ),
        "A",
    )

    print(
        "minimum accepted final nonlocal distance =",
        min(
            float(
                row[
                    "min_final_nonlocal_A"
                ]
            )
            for row in passed
        ),
        "A",
    )


print(
    "[PASS] frozen validation identities were not changed"
)

print(
    "[PASS] no validation state was substituted"
)

print(
    "[PASS] no validation M0 calculation was performed"
)

print(
    "[PASS] no validation residual or benchmark metric calculated"
)

print(
    "[PASS] frozen evaluator fits/predictions were not modified"
)

print(
    "[PASS] PPII remains SEALED"
)


print(
    "formal results SHA256 =",
    sha(
        RESULTS
    ),
)


if npass != 144:
    raise SystemExit(
        1
    )


print(
    "===== FORMAL INTERNAL-VALIDATION144 FRESH QM RUNNER END ====="
)
