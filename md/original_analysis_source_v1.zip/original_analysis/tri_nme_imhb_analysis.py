#!/usr/bin/env python3
"""Read the six closed JACS4 runs; report geometric intramolecular H-bonds.

Only committed 1-ps solute captures at lambda=1 are decoded. No OpenMM,
NetCDF, MD, GPU, or writes to production folders. All thresholds are fixed
here, before examining the contact data. This is an exploratory analysis.
"""

import argparse
import csv
import hashlib
import io
import json
import os
import re
import sys
import tarfile
import tempfile
import xml.etree.ElementTree as ET
from collections import Counter, deque
from pathlib import Path, PurePosixPath

for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[key] = "1"
os.environ["CUDA_VISIBLE_DEVICES"] = ""

import numpy as np

VERSION = "NME_JACS4_IMHB_V1"
ROOT = Path("/mnt/lab/zn/mem-perm/P0_starter_v1")
DEV = Path("07_nmeala_separability_pilot/13_joint_correction_development")
PROD = "232e_formal_exact20_production_v5"
AONLY = Path("241_jacs4_A_ONLY_controls_v1/runs")
BUILD = Path("20r_post_m4_dmso_solvation_and_short_md_v1/systems/TIERA_JACS4/build")
BENCH = "TIERA_JACS4"
REF_NAME = "NMEALA_POSTM4_CYCLIC_TRANSFER_EXPERIMENTAL_DIHEDRAL_REFERENCE_v1.tsv"
REF_REL = DEV / "16b_post_m4_cyclic_transfer_benchmark_extraction" / REF_NAME
REF_SHA = "c965fda7d77c9784c119110fcf2863584da8eea539b75fdcd8d55fb893f7e49d"
TOOLS = Path("/mnt/lab/zn/JCTC/402EC_JACS4_frozen_analysis_v1.tar.gz")
TOOLS_SHA = "ece795c327e9d675474a5bfaa570f15814a93a144e0cf89341f9032fc48ab685"
TEST_XML_SHA = "03de1af8aaee6582de98b4c7a33ed21134ae6b474d58faab377c8eeee172ee00"
START = {
    "R1": ("406ab884f4351aac29d26ea5f452689ab36ff206a924d6bbf2603209b49fb828",
           (268626264, 670331566, 245284894)),
    "R2": ("9130f33e317123855c6206df5ee1828f8236a0a16ed51233e5f12786da4962bf",
           (1394027625, 2077650579, 1323207529)),
}
ROWS = (
    ("M0", "CONTROL", "R1", 13, 3915),
    ("M0", "CONTROL", "R2", 15, 3728),
    ("A_ONLY", "A_ONLY", "R1", 14, 43475),
    ("A_ONLY", "A_ONLY", "R2", 16, 43382),
    ("FULL", "TEST", "R1", 14, 45830),
    ("FULL", "TEST", "R2", 16, 45766),
)
ARMS = ("M0", "A_ONLY", "FULL")
REPS = ("R1", "R2")
DIFFS = (("M0", "A_ONLY"), ("M0", "FULL"), ("A_ONLY", "FULL"))
NATOMS = 59
FRAMES_PER_NS = 1000
MIN_CONDITIONAL_FRAMES = 500
MIN_CONDITIONAL_BLOCK_FRAMES = 50
MIN_SUPPORTING_BLOCKS = 4
MIN_SHIFT = 0.10
MIN_STRICT_SHIFT = 0.05
HN_MAX_NM = 0.25  # H to acceptor
NO_MAX_NM = 0.35
ANGLE = 135.0
STRICT_ANGLE = 150.0
MASKS = ("all", "in_M2", "outside_M2")


def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def pinned(path, expected):
    need(path.is_file(), f"missing: {path}")
    need(sha(path) == expected, f"SHA256 mismatch: {path}")
    return path


def load_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def table(path, rows):
    need(len(rows) > 0, f"empty result table: {path}")
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, rows[0].keys(), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def path_in(raw, root, parent):
    p = Path(raw)
    p = (p if p.is_absolute() else root / p).resolve()
    need(p.is_relative_to(parent.resolve()), f"unexpected path outside {parent}: {raw}")
    return p


def from_freeze(path, root):
    pins = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        digest, raw = line.split(maxsplit=1)
        need(re.fullmatch(r"[0-9a-f]{64}", digest), f"invalid SHA list: {path}")
        member = path_in(raw.strip().lstrip("*"), root, root)
        need(member not in pins, f"duplicate SHA member: {member}")
        pins[member] = digest
    return pins


def reference(root, explicit, archive):
    if explicit is not None:
        raw = pinned(explicit, REF_SHA).read_bytes()
        origin = str(explicit)
    elif (root / REF_REL).is_file():
        raw = pinned(root / REF_REL, REF_SHA).read_bytes()
        origin = str(root / REF_REL)
    else:
        # The previous frozen tools may carry the byte-exact reference table.
        # Inspect small regular members only; do not unpack or execute tools.
        raw = None
        origin = None
        if archive.is_file() and sha(archive) == TOOLS_SHA:
            with tarfile.open(archive, "r:gz") as tar:
                for member in tar:
                    if member.isfile() and 0 < member.size <= 500_000:
                        if PurePosixPath(member.name).suffix not in (".tsv", ".csv", ".txt"):
                            continue
                        data = tar.extractfile(member).read()
                        if hashlib.sha256(data).hexdigest() == REF_SHA:
                            raw = data
                            origin = str(archive) + ":" + member.name
                            break
        need(raw is not None,
             f"exact reference table absent. Copy {root / REF_REL} from the old server "
             "to this work directory and supply --reference-file with its name.")
    rows = list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig")), delimiter="\t"))
    rows = sorted((r for r in rows if r["benchmark_id"] == BENCH),
                  key=lambda r: int(r["residue_index"]))
    need([int(r["residue_index"]) for r in rows] == list(range(1, 6)),
         "reference must have the five JACS4 residues in source order")
    need(all(r["omega_state"].strip().lower() == "t" for r in rows),
         "reference omega pattern is not all trans")
    angles = np.array([[float(r["phi_deg"]), float(r["psi_deg"])] for r in rows])
    need(np.isfinite(angles).all(), "nonfinite reference angles")
    return angles, origin


def xml_graph(path):
    """Use only serialized masses, bonds and constrained bonds."""
    tree = ET.parse(path).getroot()
    need(tree.tag == "System", f"invalid System XML: {path}")
    particles = tree.findall("./Particles/Particle")
    need(len(particles) > NATOMS, f"expected solvated JACS4 System: {path}")
    types = []
    for item in particles[:NATOMS]:
        mass = float(item.attrib["mass"])
        kind = {1: "H", 12: "C", 14: "N", 16: "O"}.get(round(mass))
        need(kind is not None, f"unexpected solute atom mass {mass}: {path}")
        types.append(kind)
    need(Counter(types) == {"H": 31, "C": 18, "N": 5, "O": 5},
         f"first 59 atoms do not have JACS4 stoichiometry: {path}")
    graph = [set() for _ in types]
    bonds = list(tree.findall("./Constraints/Constraint"))
    for force in tree.findall("./Forces/Force"):
        if force.get("type") == "HarmonicBondForce":
            bonds += force.findall("./Bonds/Bond")
    for bond in bonds:
        a, b = int(bond.attrib["p1"]), int(bond.attrib["p2"])
        if min(a, b) >= NATOMS:
            continue
        need(0 <= a < NATOMS and 0 <= b < NATOMS and a != b,
             f"non-solute or invalid bond to peptide: {path}")
        graph[a].add(b)
        graph[b].add(a)
    need(sum(map(len, graph)) == 2 * NATOMS, f"JACS4 graph is not monocyclic: {path}")
    for kind, adj in zip(types, graph):
        need(len(adj) == {"C": 4, "N": 3, "H": 1, "O": 1}.get(kind, 0)
             or (kind == "C" and len(adj) == 3 and any(types[i] == "O" for i in adj)),
             f"unexpected atom valence in {path}")
    return types, graph


def only(values, description):
    vals = list(values)
    need(len(vals) == 1, f"expected one {description}; found {len(vals)}")
    return vals[0]


def topology(types, graph):
    """Bind exact atom indices by peptide chemistry, not arbitrary atom names."""
    residues = {}
    for n in (i for i, e in enumerate(types) if e == "N"):
        ca = only((i for i in graph[n] if types[i] == "C"
                   and sum(types[j] == "C" for j in graph[i]) == 2), "N-bound C-alpha")
        c = only((i for i in graph[ca] if types[i] == "C"
                  and any(types[j] == "O" for j in graph[i])), "C-alpha-bound carbonyl")
        o = only((i for i in graph[c] if types[i] == "O"), "carbonyl oxygen")
        nn = only((i for i in graph[c] if types[i] == "N"), "next peptide N")
        cb = only((i for i in graph[ca] - {c} if types[i] == "C"), "C-beta")
        ha = only((i for i in graph[ca] if types[i] == "H"), "C-alpha hydrogen")
        h = [i for i in graph[n] if types[i] == "H"]
        cn = [i for i in graph[n] - {ca} if types[i] == "C"
              and all(types[j] == "H" for j in graph[i] - {n})]
        need(len(h) + len(cn) == 1, "expected one amide H or N-methyl")
        residues[n] = dict(N=n, CA=ca, C=c, O=o, CB=cb, HA=ha,
                           next=nn, H=h[0] if h else None, CN=cn[0] if cn else None)
    previous = {r["next"]: n for n, r in residues.items()}
    need(len(previous) == 5, "five-residue peptide cycle is broken")
    methylated = {n for n, r in residues.items() if r["CN"] is not None}
    # Source sequence has NMe on 5 -> 1 -> 2. Residue 1 is the unique
    # methylated amide flanked by two methylated amides along the cycle.
    n = only((n for n in methylated
              if previous[n] in methylated and residues[n]["next"] in methylated),
             "middle residue of NMe5 -> NMe1 -> NMe2")
    ordered = []
    for _ in range(5):
        ordered.append(residues[n])
        n = residues[n]["next"]
    need(n == ordered[0]["N"] and len({r["N"] for r in ordered}) == 5, "invalid ring")
    need([i for i, r in enumerate(ordered, 1) if r["CN"] is not None] == [1, 2, 5],
         "JACS4 N-methyl sites differ from source")

    labels = {}
    torsion = []
    contacts = []
    for i, r in enumerate(ordered):
        for atom, idx in r.items():
            if atom != "next" and idx is not None:
                need(idx not in labels, "reused atom binding")
                labels[idx] = (i + 1, atom)
        for k, prefix in (("CB", "HB"), ("CN", "HM")):
            if r[k] is not None:
                h = sorted(j for j in graph[r[k]] if types[j] == "H")
                need(len(h) == 3, "methyl must have three hydrogens")
                for idx, atom in enumerate(h, 1):
                    need(atom not in labels, "reused methyl H")
                    labels[atom] = (i + 1, f"{prefix}{idx}")
        p, q = ordered[i - 1], ordered[(i + 1) % 5]
        torsion.append(((p["CA"], p["C"], r["N"], r["CA"]),
                        (p["C"], r["N"], r["CA"], r["C"]),
                        (r["N"], r["CA"], r["C"], q["N"])))
        if r["H"] is None:
            continue
        local = {r["N"]}
        for _ in range(3):
            local |= {j for a in local for j in graph[a]}
        for j, a in enumerate(ordered):
            if a["O"] not in local:
                contacts.append((f"NH{i+1}--O{j+1}", r["N"], r["H"], a["O"]))
    need(len(labels) == NATOMS and len(contacts) == 6, "incomplete peptide atom/contact binding")
    return ordered, labels, np.array(torsion), contacts


def read_run(root, spec, test_graph, verified_xml):
    arm, source_arm, rep, idx, target_m2 = spec
    name = f"ROW{idx:02d}_{BENCH}_{source_arm}_{rep}"
    run = (root / DEV / (AONLY if arm == "A_ONLY" else Path(PROD)) / name).resolve()
    need(run.is_dir() and run.is_relative_to((root / DEV).resolve()), f"missing run: {run}")
    manifest_path = run / "FORMAL_RUN_STORAGE_MANIFEST_v1.json"
    result_path = run / "FORMAL_RUN_RESULT_v1.json"
    contract_path = run / "FORMAL_RUN_CONTRACT_v1.json"
    freeze_path = run / "FORMAL_RUN_FINAL_FREEZE_v1.sha256"
    pins = from_freeze(freeze_path, root)
    for p in (manifest_path, result_path, contract_path):
        need(p in pins, f"no final freeze entry for {p}")
        pinned(p, pins[p])
    result, contract, manifest = map(load_json, (result_path, contract_path, manifest_path))
    need(result["status"].endswith("_COMPLETE"), f"{name}: formal result is not final")
    need((result["benchmark"], result["arm"], result["replicate"], result["row_index"])
         == (BENCH, source_arm, rep, idx), f"{name}: result identity differs")
    need((result["final_iteration"], result["equilibration_ns_per_replica"],
          result["recorded_production_ns_per_replica"], result["replicas"])
         == (600000, 10.0, 50.0, 12), f"{name}: incomplete protocol")
    need(result.get("normal_execution_restarts", 0) == 0
         and result.get("recovery_count", 0) == 0, f"{name}: recovery requires a separate mapping")
    start_hash, seeds = START[rep]
    need(result["formal_start_sha256"] == start_hash
         and tuple(result[k] for k in ("initial_velocity_seed", "integrator_seed", "exchange_seed"))
         == seeds, f"{name}: starts or seeds do not match paired authority")
    xml = path_in(contract["physical_xml"], root, root / DEV)
    xml_digest = result["physical_xml_sha256"]
    if xml not in verified_xml:
        pinned(xml, xml_digest)
        need(xml_graph(xml) == test_graph, f"{name}: atom order or solute bond graph differs")
        verified_xml[xml] = xml_digest
    need(verified_xml[xml] == xml_digest, f"{name}: inconsistent Hamiltonian SHA")
    records = manifest["records"]
    need(sorted(r["chunk_index"] for r in records) == list(range(1, 61)),
         f"{name}: expected exactly 60 committed chunks")
    captures = []
    for record in sorted(records, key=lambda r: r["chunk_index"]):
        chunk = record["chunk_index"]
        phase = "production" if chunk > 10 else "equilibration"
        need(record["phase"] == phase, f"{name}: phase mismatch at chunk {chunk}")
        receipt = path_in(record["checkpoint_receipt_path"], root, run / "checkpoints")
        pinned(receipt, record["checkpoint_receipt_sha256"])
        need(load_json(receipt)["global_iteration"] == chunk * 10000,
             f"{name}: incorrect checkpoint iteration for chunk {chunk}")
        if chunk > 10:
            p = path_in(record["capture_path"], root, run / "chunks")
            need(p.is_file(), f"missing capture: {p}")
            captures.append((chunk, p, record["capture_sha256"]))
    need(len({p for _, p, _ in captures}) == 50, f"{name}: reused capture")
    return name, captures, {
        "arm": arm, "repeat": rep, "run": str(run.relative_to(root)),
        "expected_M2_frames": target_m2, "formal_start_sha256": start_hash,
        "seeds": list(seeds), "physical_xml": str(xml.relative_to(root)),
        "physical_xml_sha256": xml_digest, "final_freeze_sha256": sha(freeze_path),
        "result_sha256": pins[result_path], "manifest_sha256": pins[manifest_path],
    }


def capture(chunk, path, digest):
    pinned(path, digest)
    with np.load(path, allow_pickle=False) as z:
        need(int(z["chunk_index"].item()) == chunk
             and str(z["phase"].item()) == "production"
             and int(z["global_iteration_start_exclusive"].item()) == (chunk - 1) * 10000
             and int(z["global_iteration_end_inclusive"].item()) == chunk * 10000,
             f"wrong chunk header: {path}")
        it = z["capture_1ps_iteration"]
        r = z["capture_1ps_lambda1_replica"]
        m = z["capture_1ps_mapping"]
        xyz = z["capture_1ps_positions"]
        box = z["capture_1ps_box"]
    need(np.array_equal(it, np.arange((chunk - 1) * 10000 + 10, chunk * 10000 + 1, 10)),
         f"wrong or duplicated 1 ps iterations: {path}")
    need(r.shape == (FRAMES_PER_NS,) and m.shape == (FRAMES_PER_NS, 12)
         and r.dtype.kind in "iu" and m.dtype.kind in "iu" and ((r >= 0) & (r < 12)).all(),
         f"invalid lambda=1 assignment shape: {path}")
    need(np.all(np.sort(m, axis=1) == np.arange(12)) and np.all(m[np.arange(len(r)), r] == 0),
         f"non-physical or non-unique saved replica: {path}")
    need(xyz.shape == (FRAMES_PER_NS, NATOMS, 3) and box.shape == (FRAMES_PER_NS, 3, 3),
         f"invalid capture shape: {path}")
    need(np.isfinite(xyz).all() and np.isfinite(box).all() and np.all(np.linalg.det(box) > 1),
         f"nonfinite positions or bad box: {path}")
    return it, xyz.astype(float, copy=False), box.astype(float, copy=False)


def unwrap(xyz, box, graph):
    inv = np.linalg.inv(box)
    unwrapped = np.empty_like(xyz)
    unwrapped[:, 0] = xyz[:, 0]
    reached = {0}
    queue = deque([0])
    while queue:
        a = queue.popleft()
        for b in sorted(graph[a] - reached):
            delta = xyz[:, b] - xyz[:, a]
            f = np.einsum("fi,fij->fj", delta, inv)
            f -= np.rint(f)
            unwrapped[:, b] = unwrapped[:, a] + np.einsum("fi,fij->fj", f, box)
            reached.add(b)
            queue.append(b)
    need(len(reached) == NATOMS, "peptide graph disconnected")
    u, v = zip(*[(a, b) for a, adjacent in enumerate(graph) for b in adjacent if a < b])
    bond_length = np.linalg.norm(unwrapped[:, u] - unwrapped[:, v], axis=-1)
    # Includes the ring-closing bond, which is not used by the unwrap tree.
    need(np.all((0.075 < bond_length) & (bond_length < 0.18)),
         "non-physical covalent distances after periodic unwrapping; check atom order/units")
    return unwrapped


def dihedrals(xyz, quads):
    p = xyz[:, quads]
    b0 = p[..., 0, :] - p[..., 1, :]
    b1 = p[..., 2, :] - p[..., 1, :]
    b2 = p[..., 3, :] - p[..., 2, :]
    b1 /= np.linalg.norm(b1, axis=-1, keepdims=True)
    v = b0 - np.sum(b0 * b1, axis=-1, keepdims=True) * b1
    w = b2 - np.sum(b2 * b1, axis=-1, keepdims=True) * b1
    need(np.all(np.linalg.norm(v, axis=-1) > 1e-6)
         and np.all(np.linalg.norm(w, axis=-1) > 1e-6), "degenerate backbone torsion")
    return np.degrees(np.arctan2(np.sum(np.cross(b1, v) * w, axis=-1), np.sum(v * w, axis=-1)))


def circular(x):
    return (x + 180.0) % 360.0 - 180.0


def geometry(xyz, reference_angles, torsion, contacts, residues):
    for i, r in enumerate(residues):
        ca = xyz[:, r["CA"]]
        triple = np.sum(np.cross(xyz[:, r["N"]] - ca, xyz[:, r["C"]] - ca)
                        * (xyz[:, r["CB"]] - ca), axis=1)
        if i == 0:
            d = triple
            need(np.all(np.abs(d) > 0.0005), "unexpected planar D-Ala1")
        else:
            need(np.all(d * triple < 0) and np.all(np.abs(triple) > 0.0005),
                 f"D/L peptide chirality check failed at residue {i+1}")
    angles = dihedrals(xyz, torsion)
    omega = np.max(np.abs(circular(angles[..., 0] - 180.0)), axis=1)
    crms = np.sqrt(np.mean(circular(angles[..., 1:] - reference_angles) ** 2, axis=(1, 2)))
    basin = (omega <= 30.0) & (crms <= 45.0)
    _, n, h, o = zip(*contacts)
    hn, ho = xyz[:, n] - xyz[:, h], xyz[:, o] - xyz[:, h]
    dh, dn = np.linalg.norm(ho, axis=-1), np.linalg.norm(xyz[:, o] - xyz[:, n], axis=-1)
    need(np.all(dh > 1e-6), "coincident H and O")
    cos = np.sum(hn * ho, axis=-1) / (np.linalg.norm(hn, axis=-1) * dh)
    ang = np.degrees(np.arccos(np.clip(cos, -1, 1)))
    near = (dh <= HN_MAX_NM) & (dn <= NO_MAX_NM)
    return omega, crms, basin, near & (ang >= ANGLE), near & (ang >= STRICT_ANGLE), dh, dn, ang


def summarize(arm, rep, iteration, basin, contact, strict, names):
    rows = []
    for block in (0, 1, 2, 3, 4, 5):
        include = (np.ones(len(iteration), dtype=bool) if block == 0 else
                   ((iteration > 100000 + (block - 1) * 100000)
                    & (iteration <= 100000 + block * 100000)))
        for label, subset in zip(MASKS, (include, include & basin, include & ~basin)):
            count = int(subset.sum())
            for i, name in enumerate(names):
                n, ns = int(contact[subset, i].sum()), int(strict[subset, i].sum())
                rows.append(dict(arm=arm, repeat=rep, block_10ns=block, subset=label,
                                 contact=name, frames=count, Hbond_frames=n, strict_frames=ns,
                                 occupancy_pct=100 * n / count if count else None,
                                 strict_pct=100 * ns / count if count else None))
    return rows


def rank_contacts(rows, names):
    """Predeclared descriptive screen; neither blocks nor frames are replicates."""
    index = {(r["arm"], r["repeat"], r["block_10ns"], r["subset"], r["contact"]): r for r in rows}

    def stat(a, r, b, s, c, strict=False):
        rec = index[a, r, b, s, c]
        key = "strict_pct" if strict else "occupancy_pct"
        return None if rec[key] is None else rec[key] / 100

    def within(a, r, b, c, strict=False):
        minimum = MIN_CONDITIONAL_FRAMES if b == 0 else MIN_CONDITIONAL_BLOCK_FRAMES
        if any(index[a, r, b, s, c]["frames"] < minimum for s in MASKS[1:]):
            return None
        return stat(a, r, b, "in_M2", c, strict) - stat(a, r, b, "outside_M2", c, strict)

    def pct(x):
        return None if x is None else 100 * x

    comparisons, associations, candidates = [], [], []
    for c in names:
        d = {}
        a_effects = {}
        for arm in ARMS:
            for rep in REPS:
                main, strict = within(arm, rep, 0, c), within(arm, rep, 0, c, True)
                blocks = [within(arm, rep, b, c) for b in range(1, 6)]
                n_support = sum(x is not None and main is not None and x * main > 0 for x in blocks)
                a_effects[arm, rep] = (main, strict, n_support)
                associations.append(dict(contact=c, arm=arm, repeat=rep, in_minus_out_pp=pct(main),
                                         strict_in_minus_out_pp=pct(strict),
                                         blocks_with_both_states=sum(x is not None for x in blocks),
                                         supporting_10ns_blocks=n_support))
        for x, y in DIFFS:
            for rep in REPS:
                main = stat(y, rep, 0, "all", c) - stat(x, rep, 0, "all", c)
                strict = stat(y, rep, 0, "all", c, True) - stat(x, rep, 0, "all", c, True)
                blocks = [stat(y, rep, b, "all", c) - stat(x, rep, b, "all", c) for b in range(1, 6)]
                n_support = sum(z * main > 0 for z in blocks)
                d[x, y, rep] = main, strict, n_support
                x_in, y_in = [stat(a, rep, 0, "in_M2", c) for a in (x, y)]
                x_out, y_out = [stat(a, rep, 0, "outside_M2", c) for a in (x, y)]
                weight = residual = None
                if None not in (x_in, y_in, x_out, y_out):
                    px, py = [index[a, rep, 0, "in_M2", c]["frames"]
                              / index[a, rep, 0, "all", c]["frames"] for a in (x, y)]
                    weight = (py - px) * ((x_in - x_out) + (y_in - y_out)) / 2
                    residual = main - weight
                comparisons.append(dict(contact=c, comparison=f"{y}_minus_{x}", repeat=rep,
                                        occupancy_change_pp=pct(main), strict_change_pp=pct(strict),
                                        supporting_10ns_blocks=n_support, basin_reweighting_pp=pct(weight),
                                        within_state_component_pp=pct(residual)))
        for sign in (1, -1):
            m0 = [d["M0", a, r] for a in ("A_ONLY", "FULL") for r in REPS]
            if not all(sign * v >= MIN_SHIFT and sign * s >= MIN_STRICT_SHIFT
                       and n >= MIN_SUPPORTING_BLOCKS for v, s, n in m0):
                continue
            supporting_arms = [a for a in ARMS if all(
                v is not None and sign * v >= MIN_SHIFT and sign * s >= MIN_STRICT_SHIFT
                and n >= MIN_SUPPORTING_BLOCKS for v, s, n in (a_effects[a, r] for r in REPS))]
            opposite = any(v is not None and sign * v <= -MIN_SHIFT
                           and n >= MIN_SUPPORTING_BLOCKS for v, _, n in a_effects.values())
            if supporting_arms and not opposite:
                candidates.append(dict(contact=c, direction="enriched" if sign > 0 else "depleted",
                                       supporting_arms=supporting_arms,
                                       min_absolute_M0_shift_pp=100 * min(abs(v) for v, _, _ in m0)))
    candidates.sort(key=lambda d: (-d["min_absolute_M0_shift_pp"], d["contact"]))
    return comparisons, associations, candidates


def align(xyz, ref, backbone):
    cur = xyz[:, backbone]
    center = cur.mean(axis=1, keepdims=True)
    ref_back = ref[backbone]
    ref_center = ref_back.mean(axis=0)
    u, _, vt = np.linalg.svd(np.swapaxes(cur - center, 1, 2) @ (ref_back - ref_center))
    u[:, :, -1] *= np.where(np.linalg.det(u @ vt) < 0, -1, 1)[:, None]
    return (xyz - center) @ (u @ vt) + ref_center


def representative(xyz, basin, target, omega, crms, backbone):
    valid = np.flatnonzero(basin == target)
    need(len(valid) > 0, "no frames in requested representative stratum")
    # Dense bin in the exact plotted coordinates, using a fixed 6 degree grid.
    bins, counts = np.unique(np.floor(np.column_stack((omega[valid], crms[valid])) / 6).astype(int),
                             axis=0, return_counts=True)
    peak = bins[np.argmax(counts)]
    keep = valid[(np.floor(omega[valid] / 6) == peak[0]) & (np.floor(crms[valid] / 6) == peak[1])]
    x = align(xyz[keep], xyz[keep[0]], backbone)
    mean = x[:, backbone].mean(axis=0)
    nearest = np.argmin(np.mean(np.sum((x[:, backbone] - mean) ** 2, axis=-1), axis=1))
    return int(keep[nearest]), int(len(keep)), (int(6 * peak[0]), int(6 * peak[1]))


def pdb(path, xyz_a, types, labels, graph):
    with path.open("w", encoding="ascii") as stream:
        stream.write("REMARK  JACS4 PHYSICAL-STATE FRAME, UNWRAPPED AND RIGIDLY ALIGNED\n")
        stream.write("REMARK  RESIDUES 1,2,5 ARE N-METHYLATED; RESIDUE 1 IS D-ALA\n")
        for i, (x, y, z) in enumerate(xyz_a):
            resid, label = labels[i]
            name = {1: "DMA", 2: "NAL", 5: "NAL"}.get(resid, "ALA")
            stream.write(f"HETATM{i+1:5d} {label:^4s} {name:>3s} A{resid:4d}    "
                         f"{x:8.3f}{y:8.3f}{z:8.3f}  1.00  0.00          {types[i]:>2s}\n")
        for i, neighbors in enumerate(graph):
            stream.write(f"CONECT{i+1:5d}" + "".join(f"{j+1:5d}" for j in sorted(neighbors)) + "\n")
        stream.write("END\n")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--project-root", type=Path, default=ROOT)
    ap.add_argument("--tools-archive", type=Path, default=TOOLS)
    ap.add_argument("--reference-file", type=Path, help="optional exact original reference TSV")
    ap.add_argument("--preflight", action="store_true", help="verify metadata + first production chunk per row")
    args = ap.parse_args()
    root = args.project_root.resolve()
    dev = root / DEV
    print(f"===== {VERSION} BEGIN =====", flush=True)
    print("CPU only; no MD, Context, or production writes", flush=True)
    angles, ref_origin = reference(root, args.reference_file, args.tools_archive)
    xml = pinned(dev / BUILD / "TEST.xml", TEST_XML_SHA)
    types, graph = xml_graph(xml)
    residues, labels, torsion, contacts = topology(types, graph)
    names = [q[0] for q in contacts]
    print("[PASS] exact source angles and 59-atom JACS4 graph; NH donors 3/4", flush=True)
    checked = {xml.resolve(): TEST_XML_SHA}
    runs = [read_run(root, s, (types, graph), checked) for s in ROWS]
    print("[PASS] all six closed rows, matched starts/seeds and atom order", flush=True)
    all_rows, closure, representatives = [], [], []
    backbone = [r[k] for r in residues for k in ("N", "CA", "C")]
    for spec, (name, captures, proof) in zip(ROWS, runs):
        arm, _, rep, _, target_m2 = spec
        batch = []
        for c in (captures[:1] if args.preflight else captures):
            chunk, *_ = c
            it, xyz, box = capture(*c)
            xyz = unwrap(xyz, box, graph)
            omega, crms, basin, hb, strict, dh, dn, ang = geometry(xyz, angles, torsion, contacts, residues)
            if not args.preflight:
                batch.append((it, xyz, omega, crms, basin, hb, strict, dh, dn, ang))
            if chunk % 10 == 0:
                print(f"[PROGRESS] {name}: {chunk-10}/50 production chunks", flush=True)
        if args.preflight:
            print(f"[PASS] {name}: first production chunk validated", flush=True)
            continue
        it, xyz, omega, crms, basin, hb, strict, dh, dn, ang = map(np.concatenate, zip(*batch))
        need(len(it) == 50000 and basin.sum() == target_m2,
             f"{name}: frozen M2 does not reproduce ({basin.sum()} vs {target_m2} of 50000); "
             "do not use contact results")
        print(f"[PASS] {name}: 50000 physical frames, M2={100*basin.mean():.3f}%", flush=True)
        proof["observed_M2_frames"] = int(basin.sum())
        closure.append(proof)
        all_rows += summarize(arm, rep, it, basin, hb, strict, names)
        # One populated-bin representative per state per row. Selection does
        # not see contact occupancy, distance, angle or candidate rankings.
        for state in (False, True):
            i, count, (lo_w, lo_c) = representative(xyz, basin, state, omega, crms, backbone)
            info = dict(arm=arm, repeat=rep, in_M2=state, global_iteration=int(it[i]),
                        production_ns=(int(it[i]) - 100000) / 10000, modal_bin_frames=count,
                        omega_bin_lower_deg=lo_w, crms_bin_lower_deg=lo_c,
                        omega_max_deviation_deg=float(omega[i]), backbone_crms_deg=float(crms[i]),
                        preferred_for_mechanism=(state == (arm != "M0")))
            measures = [
                dict(contact=contact, H_to_O_A=10 * dh[i, k], N_to_O_A=10 * dn[i, k],
                     N_H_O_deg=ang[i, k], passes=bool(hb[i, k]), strict_passes=bool(strict[i, k]))
                for k, contact in enumerate(names)
            ]
            representatives.append((info, xyz[i].copy(), measures))
        del batch, xyz
    if args.preflight:
        print("[PASS] preflight only; no report written", flush=True)
        return

    comparisons, associations, candidates = rank_contacts(all_rows, names)
    out = Path(tempfile.mkdtemp(prefix="244_jacs4_imhb_v1.", dir=dev))
    table(out / "imhb_occupancy.tsv", all_rows)
    table(out / "paired_arm_changes.tsv", comparisons)
    table(out / "within_state_association.tsv", associations)
    table(out / "atom_binding.tsv", [
        dict(capture_index_0based=i, pdb_serial=i+1, residue=labels[i][0],
             atom=labels[i][1], element=types[i], bonds_0based=",".join(map(str, sorted(graph[i]))))
        for i in range(NATOMS)
    ])
    table(out / "candidate_contacts.tsv", [
        dict(contact=name, donor_N_0based=n, hydrogen_0based=h, acceptor_O_0based=o,
             passes_screen=any(c["contact"] == name for c in candidates))
        for name, n, h, o in contacts
    ])
    save_json(out / "analysis.json", {
        "version": VERSION,
        "status": "CANDIDATES_FOR_MECHANISM_PANEL" if candidates else "NO_CONTACT_PASSED_SCREEN",
        "scope": "Exploratory geometric contact association in DMSO; no causal or permeability inference.",
        "reference_origin": ref_origin, "reference_sha256": REF_SHA,
        "reference_phi_psi_deg": angles.tolist(),
        "cutoffs": {"H_to_O_A_max": 10 * HN_MAX_NM, "N_to_O_A_max": 10 * NO_MAX_NM,
                    "N_H_O_deg_min": ANGLE, "strict_angle_deg_min": STRICT_ANGLE,
                    "excluded_N_to_O_graph_distance_max_bonds": 3},
        "screen": {"min_shift_pp": MIN_SHIFT * 100, "min_strict_shift_pp": MIN_STRICT_SHIFT * 100,
                   "min_direction_consistent_10ns_blocks": MIN_SUPPORTING_BLOCKS,
                   "min_conditional_frames_per_state": MIN_CONDITIONAL_FRAMES,
                   "min_conditional_block_frames_per_state": MIN_CONDITIONAL_BLOCK_FRAMES,
                   "rule": "Both corrected arms vs M0, both repeats; robust same-direction within-state "
                           "association in both repeats of at least one arm; no supported opposite arm. "
                           "Matched time blocks are descriptive, not independent replicates."},
        "candidates": candidates, "rows": closure,
    })
    if candidates:
        rep_dir = out / "representatives"
        rep_dir.mkdir()
        infos, distances = [], []
        ref = representatives[0][1]  # M0 R1, outside M2; common alignment only.
        for info, xyz, measures in representatives:
            suffix = "inM2" if info["in_M2"] else "outsideM2"
            name = f'{info["arm"]}_{info["repeat"]}_{suffix}.pdb'
            infos.append({**info, "file": name})
            distances += [{"file": name, **r} for r in measures]
            pdb(rep_dir / name, align(xyz[None], ref, backbone)[0] * 10, types, labels, graph)
        table(out / "representative_frames.tsv", infos)
        table(out / "representative_contacts.tsv", distances)
        for c in candidates:
            print(f'[CANDIDATE] {c["contact"]}: {c["direction"]}; '
                  f'minimum M0 contrast {c["min_absolute_M0_shift_pp"]:.1f} pp', flush=True)
    else:
        print("[RESULT] No contact met the predeclared repeated/conditional screen.", flush=True)

    archive = out / "JACS4_IMHB_RESULTS_v1.tar.gz"
    with tarfile.open(archive, "x:gz") as tar:
        for p in sorted(out.iterdir()):
            if p != archive:
                tar.add(p, arcname=p.name)
    print(f"RESULT_ARCHIVE_SHA256={sha(archive)}", flush=True)
    print(f"UPLOAD_THIS_EXACT_FILE={archive}", flush=True)
    print(f"===== {VERSION} END =====", flush=True)


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, TypeError, KeyError, ET.ParseError) as exc:
        sys.exit(f"[HOLD] {exc}")
