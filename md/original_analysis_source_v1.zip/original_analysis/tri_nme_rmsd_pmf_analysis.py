#!/usr/bin/env python3
"""Read closed JACS4 captures for backbone RMSD and population PMFs.

Uses one common frozen starting geometry, not an experimental XYZ structure.
The physical-state frame grid and M2 counts must reproduce the original results.
No MD, OpenMM, GPU, NetCDF, exchange-audit arrays or checkpoints are opened.
"""
from __future__ import annotations

import argparse
from contextlib import redirect_stderr, redirect_stdout
import hashlib
import importlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tarfile
import tempfile
import traceback

ROOT = Path("/mnt/lab/zn/mem-perm/P0_starter_v1")
DEV = Path("07_nmeala_separability_pilot/13_joint_correction_development")
TOOLS = Path("/mnt/lab/zn/JCTC/402EC_JACS4_frozen_analysis_v1.tar.gz")
UPSTREAM = "run_nme_jacs4_aonly_paired_analysis_v1.py"
UPSTREAM_SHA = "edc8921257c8a68bf7377b79a5dadcd2759d74f639ab9e0768c1a83081efdba8"
ARMS = ("M0", "A_ONLY", "FULL")
REPS = ("R1", "R2")
EXPECTED = {"M0": (3915, 3728), "A_ONLY": (43475, 43382), "FULL": (45830, 45766)}
NFRAME = 50000
TEMP_K = 297.0
R_KCAL = 0.00198720425864083
CAP_KEYS = ("capture_1ps_iteration", "capture_1ps_mapping", "capture_1ps_lambda1_replica",
            "capture_1ps_positions", "capture_1ps_box", "chunk_index", "phase",
            "global_iteration_start_exclusive", "global_iteration_end_inclusive")


def need(condition, message):
    if not bool(condition):
        raise RuntimeError(message)


def hash_bytes(data):
    return hashlib.sha256(data).hexdigest()


def load_upstream(path):
    source = path.read_bytes()
    need(hash_bytes(source) == UPSTREAM_SHA, "Prior paired-analysis script SHA256 mismatch")
    spec = importlib.util.spec_from_file_location("jacs4_pinned_ablation", path)
    module = importlib.util.module_from_spec(spec)
    exec(compile(source, str(path), "exec"), vars(module))
    return module


def unwrap(np, pos, box, binding):
    pos = np.asarray(pos, dtype=np.float64)
    box = np.asarray(box, dtype=np.float64)
    nsolute = binding["solute_particles"]
    need(pos.shape == (len(pos), nsolute, 3) and box.shape == (len(pos),3,3), "Unwrap shape")
    need(np.isfinite(pos).all() and np.isfinite(box).all(), "Nonfinite coordinates/box")
    lengths = np.diagonal(box,axis1=1,axis2=2)
    diag = np.zeros_like(box)
    diag[:,np.arange(3),np.arange(3)] = lengths
    need(np.all(lengths>0) and np.max(np.abs(box-diag))<=1e-12, "Orthorhombic box required")
    whole=np.empty_like(pos)
    whole[:,0]=pos[:,0]
    for parent,child in binding["unwrap_tree_parent_child"]:
        v=pos[:,child]-pos[:,parent]
        whole[:,child]=whole[:,parent]+v-np.rint(v/lengths)*lengths
    b=np.asarray(binding["bonds"],dtype=int)
    v=pos[:,b[:,1]]-pos[:,b[:,0]]
    v-=np.rint(v/lengths[:,None,:])*lengths[:,None,:]
    residual=float(np.max(np.abs(whole[:,b[:,1]]-whole[:,b[:,0]]-v)))
    need(residual<=1e-8,"Unwrap failed bonded ring closure")
    return whole,residual


def rmsd_A(np, positions, ref):
    x=positions-positions.mean(axis=1,keepdims=True)
    y=ref-ref.mean(axis=0,keepdims=True)
    u,_,vt=np.linalg.svd(x.swapaxes(-1,-2)@y)
    # Reject reflections: only proper rotations may superimpose a peptide.
    u[:,:,-1]*=np.where(np.linalg.det(u@vt)<0,-1.,1.)[:,None]
    return 10*np.sqrt(np.mean(np.sum((x@(u@vt)-y)**2,axis=2),axis=1))


def reference(j, reader, contract, definition, backbone):
    np=j.np
    raw=Path(contract["formal_start_path"])
    path=reader.metadata.path(raw)
    need(path.is_file() and path.suffix==".npz" and path.stat().st_size<64*1024**2, "Frozen start file")
    data=path.read_bytes()
    need(hash_bytes(data)==contract["formal_start_sha256"], "Frozen start SHA256")
    with np.load(io.BytesIO(data),allow_pickle=False) as z:
        p=z["positions_nm"]
        need(p.shape==(12,definition["binding"]["total_particles"],3),"Frozen start position shape")
        candidates=[]
        for key in z.files:
            if "box" not in key.lower():
                continue
            b=z[key]
            if b.shape in ((3,3),(1,3,3),(12,3,3)):
                candidates.append((key,np.asarray(b).reshape(-1,3,3)[0]))
        need(candidates and all(np.array_equal(candidates[0][1], b) for _,b in candidates),
             "Frozen start periodic box identity")
        k,b=candidates[0]
        w,err=unwrap(np,p[:1,:definition["nsolute"]],b[None],definition["binding"])
    return w[0,backbone],{
        "source":str(raw),"sha256":contract["formal_start_sha256"],
        "coordinate_record":0,"box_key":k,"backbone_atom_indices_0based":backbone,
        "reference_type":"common frozen R1 starting geometry",
        "experimental_reference_coordinates":False,"reference_unwrap_residual_nm":err}


def read_row(j, reader, name, manifest, definition, backbone, ref):
    np=j.np
    records=[]
    worst=0.
    for rec in manifest["records"]:
        i=rec["chunk_index"]
        if i<=10:
            continue
        start,end=(i-1)*10000,i*10000
        path=j.PROD/name/"chunks"/f"CAPTURE_{i:02d}_production_v1.npz"
        need(Path(rec["capture_path"])==path and rec["phase"]=="production","Committed capture identity")
        reader.digest(path,rec["capture_sha256"])
        c=reader.arrays(path,CAP_KEYS)
        need((c["chunk_index"].item(),c["phase"].item(),c["global_iteration_start_exclusive"].item(),
              c["global_iteration_end_inclusive"].item())==(i,"production",start,end),"Capture counters")
        t=c["capture_1ps_iteration"]
        m=c["capture_1ps_mapping"]
        q=c["capture_1ps_lambda1_replica"]
        need(np.array_equal(t,np.arange(start+10,end+1,10)), "Physical-frame grid")
        j.f.validate_mapping(m,1000)
        need(q.shape==(1000,) and np.issubdtype(q.dtype,np.integer) and np.all((q>=0)&(q<12)),
             "Physical-state walker index")
        need(np.all(m[np.arange(1000),q]==0),"Not the physical REST2 state")
        pos,box=c["capture_1ps_positions"],c["capture_1ps_box"]
        w,err=unwrap(np,pos,box,definition["binding"])
        worst=max(worst,err)
        a={k:np.column_stack([j.f.omega_degrees(pos,box,g[k+"_atoms"])
                              for g in definition["geometry"]]) for k in ("phi","psi","omega")}
        obs=j.f.calculate_observables(a["phi"],a["psi"],a["omega"],
                                       definition["reference_angles_deg"],definition["target_classes"])
        x=np.abs(np.mod(a["omega"],360)-180).max(axis=1)
        y=obs["crms_deg"]
        need(np.array_equal((x<=30)&(y<=45),obs["M2"]),"Frozen M2 coordinates")
        records.append(dict(iteration=t,rmsd_A=rmsd_A(np,w[:,backbone],ref),
            omega_max_deviation_deg=x,backbone_crms_deg=y,phi2_deg=a["phi"][:,1],
            psi2_deg=a["psi"][:,1],M2=obs["M2"]))
        if i%10==0:
            print(f"[PROGRESS] {name}: {i-10}/50 physical production chunks",flush=True)
    need(len(records)==50,"Missing production chunks")
    series={k:np.concatenate([r[k] for r in records]) for k in records[0]}
    need(np.array_equal(series["iteration"],np.arange(100010,600001,10)),"Complete 50 ns grid")
    return series,worst


def density(np, runs, columns, edges):
    counts=np.stack([np.histogram2d(s[columns[0]],s[columns[1]],bins=edges)[0].astype(np.int32)
                     for s in runs])
    need(np.all(counts.sum(axis=(1,2))==NFRAME),"Histogram must include every physical frame")
    # Equal-repeat pooled counts: both repeats contain exactly 50,000 frames.
    total=counts.sum(axis=0)
    mask=(counts>=5).all(axis=0)
    pmf=np.full(total.shape,np.nan,dtype=np.float64)
    if mask.any():
        pmf[mask]=-R_KCAL*TEMP_K*np.log(total[mask]/total[mask].max())
    return counts,pmf


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root",type=Path,default=ROOT)
    parser.add_argument("--tools-archive",type=Path,default=TOOLS)
    parser.add_argument("--paired-analyzer",type=Path)
    args=parser.parse_args()
    root=args.project_root.resolve(strict=True)
    dev=root/DEV
    need(dev.is_dir() and dev.resolve()==dev,"Project development directory")
    a=load_upstream(args.paired_analyzer or root/UPSTREAM)
    run=Path(tempfile.mkdtemp(prefix="243_jacs4_rmsd_pmf_v1.",dir=dev))
    log=run/"analysis.log"
    print("RUN_DIRECTORY="+str(run),flush=True)
    print("LOG="+str(log),flush=True)
    with log.open("x",encoding="utf-8",buffering=1) as fh:
        with redirect_stdout(a.Tee(sys.stdout,fh)),redirect_stderr(a.Tee(sys.stderr,fh)):
            try:
                analyze(a,root,run,args.tools_archive)
            except Exception:
                traceback.print_exc()
                print("[HOLD] analysis incomplete; see "+str(log),flush=True)
                return 1
    return 0


def analyze(a,root,run,tools):
    sys.dont_write_bytecode=True
    os.environ.update({"CUDA_VISIBLE_DEVICES":"","OMP_NUM_THREADS":"1","OPENBLAS_NUM_THREADS":"1",
        "MKL_NUM_THREADS":"1","NUMEXPR_NUM_THREADS":"1","TMPDIR":str(run),"TMP":str(run),"TEMP":str(run)})
    sys.path.insert(0,str(a.frozen_tools(tools,run)))
    j=importlib.import_module("analyze_jacs4_v1")
    j.verify_package()
    np=j.np
    primary,abl=j.Reader(root),j.Reader(root)
    _,old_contracts,old_manifests,definition=j.preflight(primary)
    contracts,manifests=a.check_ablation_metadata(j,abl.metadata)
    a.check_pair_and_topology(j,primary,abl,old_contracts,contracts,definition)
    backbone=[x for g in definition["geometry"] for x in g["psi_atoms"][:3]]
    need(len(backbone)==len(set(backbone))==15,"Common N/C-alpha/C backbone mapping")
    ref,provenance=reference(j,primary,old_contracts[a.FNAMES["R1"]],definition,backbone)
    need(rmsd_A(np,ref[None],ref)[0]<1e-9,"Reference self-alignment")
    results=run/"results";results.mkdir()
    summary={"temperature_K":TEMP_K,"reference":provenance,"replicates":list(REPS),
             "physical_state_index":0,"frames_per_row":NFRAME,"runs":[],
             "coordinate_map":{"x":"maximum circular omega deviation from trans, degrees",
               "y":"backbone circular RMS deviation from source torsions, degrees",
               "edges_deg":list(range(0,181,3)),"min_count_per_repeat_display":5,
               "energy":"-RT log(p / p_max) among supported bins; zero set separately per arm"},
             "rama_map":{"axes":"L-Ala2 phi and psi, degrees",
                         "edges_deg":list(range(-180,181,10)),"min_count_per_repeat_display":5},
             "basin_contrast":"-RT log(P(M2)/[1-P(M2)]), population contrast in kcal/mol; not a barrier",
             "production_modified":False,"new_MD":False}
    dist_edges=np.arange(0,181,3);rama_edges=np.arange(-180,181,10)
    for arm in ARMS:
        if arm=="A_ONLY":
            reader,rows,scope,lookup=abl,a.ANAMES,a.AB_RUNS,manifests
        else:
            reader,scope=primary,j.closed.PROD
            rows=a.FNAMES if arm=="FULL" else dict(zip(REPS,(j.closed.ROW_NAMES[13],j.closed.ROW_NAMES[15])))
            lookup={r:old_manifests[n] for r,n in rows.items()}
        all_runs=[]
        # The primary reader retains snapshots of both M0 and FULL chunks.
        allowed=tuple(rows.values()) if arm=="A_ONLY" else tuple(j.closed.ROW_NAMES[i] for i in range(13,17))
        with a.original_reader_scope(j,scope,allowed):
            for rep,n in rows.items():
                series,err=read_row(j,reader,n,lookup[rep],definition,backbone,ref)
                hits=int(series["M2"].sum())
                need(hits==EXPECTED[arm][REPS.index(rep)],"Frozen M2 count differs: "+arm+" "+rep)
                p=hits/NFRAME
                q=np.quantile(series["rmsd_A"],[.10,.50,.90])
                row={"arm":arm,"replicate":rep,"row":n,"M2_frames":hits,"M2_fraction":p,
                     "basin_minus_rest_kcal_mol":float(-R_KCAL*TEMP_K*np.log(p/(1-p))),
                     "rmsd_A_p10_median_p90":q.tolist(),"max_ring_unwrap_residual_nm":err}
                summary["runs"].append(row)
                all_runs.append(series)
                np.savez_compressed(results/f"{arm}_{rep}_DERIVED_v1.npz",**series)
                print(f"ROW {arm} {rep} M2={100*p:.3f}% median_RMSD_A={q[1]:.4f} "
                      f"basin_minus_rest_kcal_mol={row['basin_minus_rest_kcal_mol']:.4f}",flush=True)
            reader.check_unchanged()
        c,g=density(np,all_runs,("omega_max_deviation_deg","backbone_crms_deg"),(dist_edges,dist_edges))
        r,s=density(np,all_runs,("phi2_deg","psi2_deg"),(rama_edges,rama_edges))
        np.savez_compressed(results/f"{arm}_PROJECTED_PMF_v1.npz",criterion_edges_deg=dist_edges,
            criterion_counts_R1_R2=c,criterion_relative_kcal_mol=g,rama_edges_deg=rama_edges,
            rama_counts_R1_R2=r,rama_relative_kcal_mol=s)
    j.f.write_json(results/"JACS4_RMSD_PMF_SUMMARY_v1.json",summary)
    j.f.write_json(results/"INPUT_HASHES_v1.json",{
        **{str(p):hash_bytes(v) for d in (primary,abl) for p,v in d.metadata.payload.items()},
        **primary.digests,**abl.digests,provenance["source"]:provenance["sha256"]})
    path=results/"JACS4_RMSD_PMF_RESULTS_v1.tar.gz"
    with tarfile.open(path,"x:gz",compresslevel=4) as archive:
        for p in sorted(results.iterdir()):
            if p!=path:
                archive.add(p,arcname=p.name,recursive=False)
    print("[PASS] six original trajectories analyzed; no production files modified",flush=True)
    print("RESULT_ARCHIVE_SHA256="+j.f.sha(path),flush=True)
    print("UPLOAD_THIS_EXACT_FILE="+str(path),flush=True)


if __name__=="__main__":
    raise SystemExit(main())
