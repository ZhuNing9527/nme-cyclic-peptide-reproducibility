#!/usr/bin/env python3
"""N-methyl cyclic peptide analysis of closed runs. No dynamics or GPU calls.

server: inspect the canonical old/new project, recompute REST2 diagnostics
        from read-only NetCDF, and collect small original QM / source files.
frames: score physical-state series exported by the frozen analysis loader.
        A ROW*.npz contains global_iteration (100010..600000 every 10),
        omega_deg (50000,5), and backbone_crms_deg (50000,). Column i is
        CA(i-1)-C(i-1)-N(i)-CA(i), including the ring-closing bond for i=1.
        Optional M5 inputs: roe_moment (50000,n), roe_power (scalar),
        roe_lower_A and roe_upper_A (n,). Moments are r**(-roe_power), with
        the original ROE mapping and averaging convention. Only use those
        fields after verifying them against the frozen endpoint calculation.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys
import tarfile
import tempfile
import zipfile


PROJECT = Path("/mnt/lab/zn/mem-perm/P0_starter_v1")
WORK = Path("07_nmeala_separability_pilot/13_joint_correction_development")
PROD = "232e_formal_exact20_production_v5"
ABLATION = Path("241_jacs4_A_ONLY_controls_v1/runs")
EQ, END, PER_NS, NSTATE = 100000, 600000, 10000, 12
SAMPLE_EVERY = 10
ARCHIVES = {
    "NME_ENDPOINT_SOLVENT_SENSITIVITY_RESULTS_v1.tar.gz":
        "6b09d666390e486e5099d143e51c6a026b992eb51200086c235eec6178680d09",
    "NMe_QM_model_comparison_v1.zip":
        "62af362863315eb37332a8002e8489139a552d8c998d8dbd39de9d082fd3fa9f",
    "OLD_SERVER_CLOSED_COHORT_ANALYSIS_INPUTS_v1.tar.gz":
        "9ab8ee391f238ab8c8ae4be262792798148b7b70c75ef7de1e3f1411f9395245",
    "NEW_SERVER_CLOSED_COHORT_ANALYSIS_INPUTS_v1.tar.gz":
        "69edfb85913bf355aba37858452c6ffb16a668aff12bad34741c36fe27fbe9e9",
}
WORKER = "run_402EC_formal_exact20_worker_v5.py"
WORKER_SHA = "a2be00c88322dca860e44d09c21147f3b1547c133da6ffd04c18a793611cb605"
NME = {"JACS1": {1}, "JACS3": {1,5}, "JACS4": {1,2,5}}
META = (
    "FORMAL_RUN_CONTRACT_v1.json", "FORMAL_RUN_PROGRESS_v1.json",
    "FORMAL_RUN_RESULT_v1.json", "FORMAL_RUN_STORAGE_MANIFEST_v1.json",
    "FORMAL_RUN_FINAL_FREEZE_v1.sha256",
)
REC_META = ("FORMAL_RECOVERY_BOUNDARY_v1.json", "FORMAL_RECOVERY_CONTRACT_v1.json")
FINAL_RECEIPT = Path("checkpoints/ITER_600000/CHECKPOINT_RECEIPT_v1.json")
# arm, repeat, frozen M1 %, M2 %, mean cRMS (if reported), M5 Å.
REGISTRY = [
    (1,"JACS1","CONTROL","R1",68.298,1.384,52.748576,.397969),
    (2,"JACS1","TEST","R1",59.574,11.186,64.615001,.258347),
    (3,"JACS1","CONTROL","R2",68.374,1.312,52.843002,.396884),
    (4,"JACS1","TEST","R2",61.098,13.216,63.482827,.247829),
    (9,"JACS3","CONTROL","R1",34.912,18.866,72.405678,.286944),
    (10,"JACS3","TEST","R1",74.638,30.646,47.568654,.235423),
    (11,"JACS3","CONTROL","R2",36.016,19.202,72.267167,.283120),
    (12,"JACS3","TEST","R2",74.164,30.130,47.769135,.235024),
    (13,"JACS4","CONTROL","R1",19.762,7.830,75.793068,.231181),
    (14,"JACS4","TEST","R1",91.722,91.660,25.908207,.156540),
    (15,"JACS4","CONTROL","R2",19.802,7.456,75.716108,.230867),
    (16,"JACS4","TEST","R2",91.608,91.532,25.939751,.156286),
    (14,"JACS4","A_ONLY","R1",87.176,86.950,None,.142693),
    (16,"JACS4","A_ONLY","R2",86.942,86.764,None,.142962),
]


def name(row):
    i, peptide, arm, repeat = row[:4]
    return f"ROW{i:02d}_TIERA_{peptide}_{arm}_{repeat}"


def require(flag, msg):
    if not flag:
        raise ValueError(msg)


def digest(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()


def tsv(path, cols, rows):
    with path.open("x",encoding="utf-8",newline="") as f:
        w=csv.writer(f,delimiter="\t",lineterminator="\n")
        w.writerow(cols)
        w.writerows(rows)


def closed(path):
    for f in (*META, FINAL_RECEIPT):
        x=path/f
        require(x.is_file() and x.stat().st_size>0, f"Missing closed-run authority: {x}")
    j=json.loads((path/"FORMAL_RUN_PROGRESS_v1.json").read_text())
    require(j.get("completed_global_iteration")==END, f"Final global iteration absent: {path.name}")
    require(j.get("completed_production_ns_per_replica")==50.0, f"Final 50 ns absent: {path.name}")
    present={p.name for p in (path/"checkpoints").iterdir() if p.is_dir() and p.name.startswith("ITER_")}
    expect={f"ITER_{i:06d}" for i in range(PER_NS,END+1,PER_NS)}
    require(present==expect, f"Checkpoint directory set is not the exact 60 commits: {path.name}")
    require(all((path/"checkpoints"/k/"CHECKPOINT_RECEIPT_v1.json").is_file() for k in expect),
            f"Incomplete checkpoint receipts: {path.name}")


def unmask(value, label):
    import numpy as np
    require(not np.ma.is_masked(value), f"Masked or missing values in {label}")
    return np.asarray(value)


def nc_last(ds):
    return int(unmask(ds.variables["last_iteration"][0],"last_iteration"))


def segment(ds, begin, end, step=5000):
    """Accumulate mirrored neighbor counts once, checking alignment with the walker map."""
    import numpy as np
    v=ds.variables
    require(begin>=1 and end>=begin and end<=nc_last(ds),"Range is outside committed reporter data")
    require(v["states"].shape[1:]==(NSTATE,), "Unexpected states shape")
    require(v["states"].dimensions[0]=="iteration","Unexpected state time dimension")
    for key in ("accepted","proposed"):
        require(v[key].shape[1:]==(NSTATE,NSTATE) and v[key].dimensions[0]=="iteration",
                f"Unexpected {key} shape")
    i=np.arange(NSTATE-1)
    neighbors=np.abs(np.arange(NSTATE)[:,None]-np.arange(NSTATE)[None,:])==1
    accepted=np.zeros(NSTATE-1,np.int64); proposed=accepted.copy()
    walkers=[]
    for lo in range(begin,end+1,step):
        hi=min(end+1,lo+step)
        a=unmask(v["accepted"][lo:hi],"accepted")
        p=unmask(v["proposed"][lo:hi],"proposed")
        states=unmask(v["states"][lo-1:hi],"states")
        require(all(x.dtype.kind in "iu" for x in (a,p,states)),"Expected integer mixing arrays")
        require(states.shape==(hi-lo+1,NSTATE) and np.all(np.sort(states,axis=1)==np.arange(NSTATE)),
                "Each saved state map must be a permutation of 0..11")
        require(a.shape==p.shape==(hi-lo,NSTATE,NSTATE),"Truncated exchange arrays")
        require(np.all((a>=0)&(p>=a)&(p<=1)), "Invalid accepted/proposed counts per swap-neighbors iteration")
        require(np.array_equal(a,a.transpose(0,2,1)) and np.array_equal(p,p.transpose(0,2,1)),
                "Directional counts are not the expected mirrored exchange record")
        require(not np.any(p[:,~neighbors]),"Unexpected non-neighbor proposals")
        na=a[:,i,i+1]; np_=p[:,i,i+1]
        require(np.array_equal(2*na.sum(axis=1),np.count_nonzero(states[1:]!=states[:-1],axis=1)),
                "Exchange counts do not match saved state changes")
        accepted+=na.sum(axis=0,dtype=np.int64)
        proposed+=np_.sum(axis=0,dtype=np.int64)
        walkers.append(states[1:].astype(np.int8,copy=True))
    return accepted,proposed,np.concatenate(walkers,axis=0)


def roundtrips(states):
    """Count complete 0 -> 11 -> 0 trips in saved production mappings."""
    import numpy as np
    for w in range(states.shape[1]):
        s=states[:,w]
        idx=np.flatnonzero((s==0)|(s==NSTATE-1))
        if idx.size:
            # If the walker dwells at state 0, use the last frame of that
            # visit as the departure time and first frame on return.
            ep=s[idx]
            cut=np.r_[0, np.flatnonzero(ep[1:]!=ep[:-1])+1,idx.size]
            ep=ep[cut[:-1]]
            jj=np.flatnonzero((ep[:-2]==0)&(ep[1:-1]==NSTATE-1)&(ep[2:]==0))
            elapsed=(idx[cut[jj+2]]-idx[cut[jj+1]-1])/PER_NS
        else:
            elapsed=np.empty(0)
        yield elapsed


def analyze_nc(path,row,Dataset):
    import numpy as np
    boundary={3:400000,11:290000}.get(row[0]) if row[2]=="CONTROL" else None
    f=path/"technical.nc"
    with Dataset(str(f),"r") as ds:
        if boundary is None:
            require(nc_last(ds)==END, f"Unexpected last reporter iteration for {path.name}")
        a,p,w=segment(ds,EQ+1,boundary or END)
        prior=unmask(ds.variables["states"][boundary],"boundary state") if boundary else None
    mappings=[w]
    bridge="uninterrupted"
    if boundary:
        f=path/"technical_recovery_01.nc"
        with Dataset(str(f),"r") as ds:
            last=nc_last(ds)
            if last==END-boundary:
                offset=boundary
            elif last==END:
                offset=0
            else:
                raise ValueError(f"Unrecognized recovery iteration origin: {last}")
            handoff=unmask(ds.variables["states"][boundary-offset],"recovery boundary state")
            aa,pp,ww=segment(ds,boundary-offset+1,END-offset)
        a+=aa
        p+=pp
        if np.array_equal(handoff,prior):
            mappings=[np.concatenate((w,ww),axis=0)]
            bridge="verified matching recovery map"
        else:
            mappings.append(ww)
            bridge="censored trips at recovery boundary"
    require(sum(len(x) for x in mappings)==END-EQ,"Incomplete production mapping")
    require(np.all(p>0),"At least one adjacent edge has no proposals")
    visits=sum(np.count_nonzero(m==0,axis=0) for m in mappings)
    assert int(visits.sum())==END-EQ
    fractions=visits/(END-EQ)
    trips=[np.concatenate(ls) for ls in zip(*(roundtrips(m) for m in mappings))]
    return a,p,visits,trips,float(1/np.sum(fractions**2)),bridge


def npz_headers(path):
    import numpy as np
    output={}
    with zipfile.ZipFile(path) as z:
        for k in z.namelist():
            if not k.endswith(".npy"):
                continue
            with z.open(k) as f:
                version=np.lib.format.read_magic(f)
                if version==(1,0):
                    shape,_,dtype=np.lib.format.read_array_header_1_0(f)
                elif version==(2,0):
                    shape,_,dtype=np.lib.format.read_array_header_2_0(f)
                else:
                    output[k]={"header_version":version}
                    continue
            output[k]={"shape":shape,"dtype":str(dtype)}
    return output


def source_paths(root, tool_roots):
    """Find only the known inputs; do not recurse into production/checkpoints."""
    names=set(ARCHIVES)
    names.add("402EC_JACS4_frozen_analysis_v1.tar.gz")
    names.add("run_nme_jacs4_rmsd_pmf_v1.py")
    names.add("run_nme_jacs4_aonly_controls_v1.py")
    for scan in [root,*tool_roots]:
        if not scan.is_dir():
            continue
        for directory,subs,files in os.walk(scan,followlinks=False):
            p=Path(directory)
            depth=len(p.relative_to(scan).parts)
            subs[:]=[s for s in subs if depth<5 and not s.startswith(".") and s not in
                     (PROD,"checkpoints","chunks","segment_commits","runs","_runtime_tmp")]
            tool_package=re.compile(r"402EC_JACS[134]_(?:frozen_analysis|.*tools)_v[0-9]+\.tar\.gz")
            for n in sorted(n for n in files if n in names or tool_package.fullmatch(n)):
                yield p/n
            text_dir=any(re.search(r"jacs[134].*(analysis|tools|sampling|m123|roe)",c,re.I)
                         for c in p.relative_to(scan).parts)
            if text_dir:
                for n in sorted(files):
                    if re.search(r"\.py$",n) and (p/n).stat().st_size<=2*1024*1024:
                        yield p/n


def on_server(args):
    root=args.project_root.resolve()
    work=root/WORK
    require(work.is_dir(),f"Project work directory absent: {work}")
    workfile=work/WORKER
    require(workfile.is_file() and digest(workfile)==WORKER_SHA,"Frozen formal worker hash mismatch")
    out=Path(tempfile.mkdtemp(prefix=f"NME_CPU_AUDIT_{args.site}_",dir=work))
    selected=[r for r in REGISTRY if (r[1]=="JACS1")== (args.site=="old")]
    all_edges,all_trips,all_summary=[],[],[]
    manifest={"site":args.site,"runs_md":False,"gpu_compute":False,
              "reads_coordinates":False,"source_files":[],"rows":{}}
    try:
        from netCDF4 import Dataset
    except ImportError:
        Dataset=None
        print("[HOLD] netCDF4 unavailable; source collection will still run.",flush=True)
    included=[(workfile,"source/"+WORKER)]
    for row in selected:
        rn=name(row)
        run=work/(ABLATION if row[2]=="A_ONLY" else PROD)/rn
        info=manifest["rows"][rn]={"path":str(run)}
        try:
            closed(run)
            info["closure"]="verified final progress and 60 checkpoint receipts"
            for f in (*META,*REC_META,FINAL_RECEIPT):
                q=run/f
                if q.is_file() and q.stat().st_size<=5*1024*1024:
                    included.append((q,f"row_metadata/{rn}/{str(f)}"))
            chunks=sorted((run/"chunks").rglob("*.npz"))
            if chunks:
                try:
                    info["sample_chunk"]={"name":chunks[0].name,"headers":npz_headers(chunks[0])}
                except (ValueError,OSError,zipfile.BadZipFile) as e:
                    info["chunk_header_error"]=str(e)
            if Dataset is not None:
                for q in (run/"technical.nc",run/"technical_recovery_01.nc"):
                    if q.is_file():
                        with Dataset(str(q),"r") as ds:
                            info[q.name]={"last_iteration":nc_last(ds),"variables":{
                                k:{"dimensions":v.dimensions,"shape":v.shape,"dtype":str(v.dtype)}
                                for k,v in ds.variables.items()
                                if k in {"positions","box_vectors","states","accepted","proposed","analysis_particle_indices"}
                            }}
            if args.sources_only or Dataset is None:
                info["REST2"]="not computed"
                continue
            a,p,visits,trips,neff,bridge=analyze_nc(run,row,Dataset)
            import numpy as np
            rates=a/p
            all_edges.extend([rn,i,i+1,int(a[i]),int(p[i]),f"{rates[i]:.8f}"] for i in range(NSTATE-1))
            all_trips.extend([rn,w,int(visits[w]),len(t),f"{float(np.median(t)):.7f}" if len(t) else ""] for w,t in enumerate(trips))
            all_summary.append([rn,f"{float(rates.min()):.8f}",f"{float(a.sum()/p.sum()):.8f}",
                                sum(len(t) for t in trips),f"{neff:.7f}",bridge])
            info["REST2"]="computed"
            print(f"[PASS] {rn}: 11 edges; minimum acceptance={rates.min():.5f}; "
                  f"state 0->11->0 trips={sum(len(t) for t in trips)}",flush=True)
        except (ValueError,OSError,KeyError,RuntimeError,ImportError) as e:
            info["hold"]=str(e)
            print(f"[HOLD] {rn}: {e}",flush=True)
    seen=set()
    byte_budget=35*1024*1024
    for q in source_paths(root,args.tool_root):
        if not q.is_file() or q.is_symlink():
            continue
        sz=q.stat().st_size
        limit=(80 if q.name in ARCHIVES else 12)*1024*1024
        if not 0<sz<=limit:
            if q.name in ARCHIVES:
                manifest["source_files"].append({"path":str(q),"bytes":sz,"status":"outside automatic transfer size gate"})
            continue
        h=digest(q)
        if (q.name,h) in seen:
            continue
        seen.add((q.name,h))
        if q.name in ARCHIVES and h!=ARCHIVES[q.name]:
            manifest["source_files"].append({"path":str(q),"sha256":h,"status":"unexpected SHA256; excluded"})
            continue
        if q.name not in ARCHIVES:
            if sz>byte_budget:
                continue
            byte_budget-=sz
        arc=f"original_inputs/{q.name}" if q.name in ARCHIVES else f"analysis_source/{h[:12]}_{q.name}"
        manifest["source_files"].append({"path":str(q),"sha256":h,"archive_member":arc})
        included.append((q,arc))
    for key in ARCHIVES:
        if key.startswith(("NME_","NMe_")):
            hit=any(x.get("archive_member")==f"original_inputs/{key}" for x in manifest["source_files"])
            print(f"{'[PASS]' if hit else '[MISSING]'} {key}",flush=True)
    tsv(out/"REST2_EDGES.tsv",["row","state_i","state_j","accepted","proposed","fraction"],all_edges)
    tsv(out/"REST2_WALKERS.tsv",["row","walker","state0_frames","complete_0_11_0_trips","median_trip_ns"],all_trips)
    tsv(out/"REST2_RUNS.tsv",["row","min_adjacent_acceptance","count_weighted_acceptance","complete_0_11_0_trips",
                            "state0_walker_inverse_simpson","restart_handling"],all_summary)
    (out/"INPUT_AND_CLOSURE_AUDIT.json").write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8")
    arch=out/f"NME_CPU_AUDIT_{args.site.upper()}_v1.tar.gz"
    with tarfile.open(arch,"x:gz",compresslevel=3) as t:
        for q,arc in included:
            t.add(q,arcname=arc,recursive=False)
        for q in sorted(out.iterdir()):
            if q!=arch and q.is_file():
                t.add(q,arcname=q.name,recursive=False)
    print(f"REST2_COMPLETE_ROWS={len(all_summary)}/{len(selected)}")
    print(f"UPLOAD_THIS_EXACT_FILE={arch}\nARCHIVE_SHA256={digest(arch)}",flush=True)


def inefficiency(x):
    """Initial positive paired ACF sums, in saved frames; constant series undefined."""
    import numpy as np
    y=np.asarray(x,dtype=float)-np.mean(x)
    n=len(y)
    denom=np.dot(y,y)
    if denom<=0:
        return None
    f=np.fft.rfft(y,n=2*n)
    ac=np.fft.irfft(f*f.conj(),n=2*n)[:n]/denom
    g=1.0
    for i in range(1,n-1,2):
        pair=ac[i]+ac[i+1]
        if pair<=0:
            break
        g+=2*pair
    return min(float(n),max(1.0,float(g)))


def read_angles(path,row):
    import numpy as np
    with np.load(path,allow_pickle=False) as z:
        idx=z["global_iteration"]; w=z["omega_deg"]; c=z["backbone_crms_deg"]
        n=(END-EQ)//SAMPLE_EVERY
        require(np.array_equal(idx,np.arange(EQ+SAMPLE_EVERY,END+1,SAMPLE_EVERY)),
                f"{path.name}: incomplete or noncanonical frame chronology")
        require(w.shape==(n,5) and c.shape==(n,) and np.isfinite(w).all() and np.isfinite(c).all()
                and np.all((c>=0)&(c<=180)), f"{path.name}: malformed angles")
        wrap=lambda x:(x+180.0)%360.0-180.0
        cis=np.abs(wrap(w))<=30.0
        trans=np.abs(wrap(w-180.0))<=30.0
        m1=trans.all(axis=1)
        m2=m1&(c<=45.0)
        require(abs(m1.mean()*100-row[4])<.00051 and abs(m2.mean()*100-row[5])<.00051,
                f"{path.name}: frame series does not reproduce frozen M1/M2")
        require(row[6] is None or abs(c.mean()-row[6])<.003, f"{path.name}: M3 differs from frozen output")
        v=np.column_stack((m1,m2,c)).astype(float)
        params=None
        if any(x in z for x in ("roe_moment","roe_power","roe_lower_A","roe_upper_A")):
            r=z["roe_moment"]; power=float(z["roe_power"])
            lb=z["roe_lower_A"]; ub=z["roe_upper_A"]
            nroe={"JACS1":25,"JACS3":26,"JACS4":20}[row[1]]
            require(r.shape==(n,nroe) and lb.shape==ub.shape==(nroe,) and np.isfinite(r).all()
                    and np.isfinite(lb).all() and np.isfinite(ub).all() and math.isfinite(power)
                    and np.all(r>0) and np.all((lb>=0)&(ub>=lb)) and power>0,"Invalid ROE moment inputs")
            params=(power,lb,ub)
            require(abs(float(m5(r.mean(axis=0),params))-row[7])<.00001,
                    f"{path.name}: ROE moments do not reproduce frozen M5")
            v=np.column_stack((v,r))
    return v,cis,trans,params


def m5(moments,params):
    import numpy as np
    power,lo,hi=params
    d=moments**(-1.0/power)
    return np.maximum(np.maximum(d-hi,lo-d),0).mean(axis=-1)


def block_draw(v,length,draws,rng):
    import numpy as np
    n,k=v.shape
    require(n%length==0 and 0<length<n,"Block length must divide the run length")
    # Circular moving blocks give every frame equal probability of selection.
    doubled=np.concatenate((v,v[:length-1]),axis=0)
    prefix=np.vstack((np.zeros((1,k)),np.cumsum(doubled,axis=0)))
    means=(prefix[length:length+n]-prefix[:n])/length
    ans=np.empty((draws,k),dtype=float)
    for start in range(0,draws,128):
        end=min(start+128,draws)
        x=rng.integers(0,n,size=(end-start,n//length))
        ans[start:end]=means[x].mean(axis=1)
    return ans


def frames(args):
    import numpy as np
    expected={name(row):row for row in REGISTRY}
    block_ns=(1,2,5,10)
    rng=np.random.default_rng(BOOTSTRAP_SEED)
    nboot=5000
    result,omega,acf,boots,contrasts,seen=[],[],[],[],[],{}
    labels=("M1_pp","M2_pp","M3_deg","M5_A")
    for path in sorted(args.input,key=lambda p:p.stem):
        require(path.stem in expected and path.stem not in seen,f"Unknown or repeated row: {path.stem}")
        row=expected[path.stem]
        x,ci,tr,param=read_angles(path,row)
        seen[path.stem]=digest(path)
        n=len(x)
        for i in range(5):
            cc=int(ci[:,i].sum()); tt=int(tr[:,i].sum())
            omega.append([path.stem,i+1,int(i+1 in NME[row[1]]),n,cc,tt,n-cc-tt,
                          f"{100*cc/n:.6f}",f"{100*tt/n:.6f}",f"{100*(n-cc-tt)/n:.6f}"])
        for i in range(3):
            g=inefficiency(x[:,i])
            acf.append([path.stem,labels[i],n,"" if g is None else g,"" if g is None else n/g])
        point=x[:,:3].mean(axis=0); point[:2]*=100
        if param is not None:
            point=np.r_[point,m5(x[:,3:].mean(axis=0),param)]
        for b in block_ns:
            draw=block_draw(x,b*PER_NS//SAMPLE_EVERY,nboot,rng)
            boot=draw[:,:3].copy()
            boot[:,:2]*=100
            if param is not None:
                boot=np.column_stack((boot,m5(draw[:,3:],param)))
            boots.append((row,b,point,boot))
            for i in range(boot.shape[1]):
                lo,hi=np.quantile(boot[:,i],[.025,.975])
                result.append([path.stem,b,labels[i],point[i],lo,hi,nboot])
    by={(r[1],r[2],r[3],b):(p,v) for r,b,p,v in boots}
    for peptide in NME:
        for base in (("CONTROL","A_ONLY") if peptide=="JACS4" else ("CONTROL",)):
            for b in block_ns:
                p_deltas,v_deltas=[],[]
                for rep in ("R1","R2"):
                    a=(peptide,"TEST",rep,b); c=(peptide,base,rep,b)
                    if a not in by or c not in by:
                        continue
                    ap,av=by[a]; cp,cv=by[c]
                    m=min(len(ap),len(cp))
                    p=ap[:m]-cp[:m]; v=av[:,:m]-cv[:,:m]
                    p_deltas.append(p); v_deltas.append(v)
                    for i in range(m):
                        lo,hi=np.quantile(v[:,i],[.025,.975])
                        contrasts.append([peptide,base,rep,b,labels[i],p[i],lo,hi])
                if len(p_deltas)==2:
                    m=min(len(p) for p in p_deltas)
                    p=np.mean([d[:m] for d in p_deltas],axis=0)
                    v=np.mean([d[:,:m] for d in v_deltas],axis=0)
                    for i in range(m):
                        lo,hi=np.quantile(v[:,i],[.025,.975])
                        contrasts.append([peptide,base,"equal-R1-R2",b,labels[i],p[i],lo,hi])
    out=args.out
    out.mkdir(exist_ok=False)
    tsv(out/"OMEGA_BY_RUN.tsv",["row","bond_before_residue","N_methylated","frames","cis_frames",
                              "trans_frames","other_frames","cis_pct","trans_pct","other_pct"],omega)
    tsv(out/"STATISTICAL_INEFFICIENCY.tsv",["row","observable","frames","g_frames","within_run_ESS"],acf)
    tsv(out/"BLOCK_INTERVALS.tsv",["row","block_ns","observable","point","lower_95","upper_95","draws"],result)
    tsv(out/"MATCHED_CONTRASTS.tsv",["peptide","baseline_arm","repeat","block_ns","observable",
                                   "test_minus_baseline","lower_95","upper_95"],contrasts)
    (out/"ANALYSIS_RECEIPT.json").write_text(json.dumps({
        "inputs_sha256":seen,"block_ns":block_ns,"seed":BOOTSTRAP_SEED,"draws":nboot,
        "interval":"circular moving-block, conditional on existing runs; independent draws per trajectory, equal replicate weights",
        "n_rows_with_M5_moments":sum(b==1 and len(p)==4 for _,b,p,_ in boots),
        "unobserved_rows":sorted(set(expected)-set(seen)),
    },indent=2)+"\n",encoding="utf-8")
    print(f"[PASS] {len(seen)} frozen frame series analyzed; {out}",flush=True)


BOOTSTRAP_SEED = 40226


def main():
    parser=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    sub=parser.add_subparsers(dest="mode",required=True)
    p=sub.add_parser("server",help="Collect original inputs and compute REST2 exchange diagnostics")
    p.add_argument("--site",choices=("old","new"),required=True)
    p.add_argument("--project-root",type=Path,default=PROJECT)
    p.add_argument("--tool-root",type=Path,action="append",default=[Path("/mnt/lab/zn/JCTC")])
    p.add_argument("--sources-only",action="store_true",help="Only collect source files and headers")
    q=sub.add_parser("frames",help="Compute five-bond populations and conditional block intervals")
    q.add_argument("--out",type=Path,required=True)
    q.add_argument("input",nargs="+",type=Path)
    args=parser.parse_args()
    try:
        if args.mode=="server":
            on_server(args)
        else:
            frames(args)
    except (ValueError,OSError,KeyError,RuntimeError,ImportError) as exc:
        parser.exit(1,f"[HOLD] {exc}\n")


if __name__=="__main__":
    main()
