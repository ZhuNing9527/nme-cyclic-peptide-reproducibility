# NMe-Ala post-M4 cyclic-transfer Tier-A analysis/observable precommit v1

STATUS:
FROZEN BEFORE CYCLIC-PEPTIDE TOPOLOGY GENERATION AND BEFORE ANY CONTROL/TEST MD.

## 1. Tier-A universe

Exact seven JACS2006 article-defined conformationally homogeneous systems:

TIERA_JACS1
TIERA_JACS2
TIERA_JACS3
TIERA_JACS4
TIERA_JACS5
TIERA_JACS6
TIERA_JACS7

No Tier-A peptide may be removed because of later topology difficulty, MD behavior, M4 performance, or analysis outcome.

All seven have:
- trusted source major conformer;
- exact five-residue phi/psi reference;
- source major cis/trans assignment;
- ROE restraint table availability.

## 2. Source population reporting

The JACS source reports Tier-A major populations as either:

100

or

98:2.

These strings are retained literally.

They define an experimentally dominant single-conformer regime.

They are NOT treated as high-precision continuous regression targets.

In particular, source-reported 100 must not be interpreted as an exact equilibrium probability of 1.000 with zero uncertainty.

No artificial uncertainty is invented.

## 3. Signed periodic torsions

All phi, psi and omega values are signed periodic torsions.

For any angular difference:

d_periodic(a,b)
=
minimum absolute angular displacement modulo 360 degrees.

## 4. Frozen cis/trans classifier

For every peptide bond:

CIS:
d_periodic(omega,0 degrees) <=30 degrees.

TRANS:
d_periodic(omega,180 degrees) <=30 degrees.

INTERMEDIATE:
all other omega values.

A frame matches the experimental major cis/trans pattern only if all five peptide bonds have exactly the source-defined cis/trans class.

Any intermediate bond makes that frame nonmatching.

These windows may not be changed after MD is inspected.

## 5. Frozen backbone basin distance

For every frame, compare the five residue phi/psi pairs with the exact trusted source reference.

Define:

phi_psi_cRMS
=
sqrt(
 mean over the ten phi/psi angles
 [
  d_periodic(simulated,reference)^2
 ]
).

The frozen dominant-backbone threshold is:

phi_psi_cRMS <=45 degrees.

## 6. Primary Tier-A endpoint

PRIMARY:
M2_JOINT_MAJOR_BASIN_OCCUPANCY.

A frame belongs to the source major basin only if BOTH conditions hold:

1. exact source cis/trans pattern;
2. phi_psi_cRMS <=45 degrees.

Per peptide:

P_major
=
number of analyzed frames in the joint major basin
/
total analyzed frames.

The primary paired effect is:

Delta_major
=
P_major(TEST M0+M4)
-
P_major(CONTROL M0).

Positive values favor the frozen M4 correction.

## 7. Secondary conformational endpoints

M1:
exact cis/trans-pattern occupancy.

M3:
phi/psi circular RMS deviation;
report mean and median.

These are secondary.

Neither may replace M2 as the primary endpoint after results are known.

## 8. ROE validation

ROE comparison is an orthogonal secondary NMR layer.

The source protocol remains:

297 K;
500 MHz;
DMSO-d6;
ROESY mixing time 150 ms;
alanine Halpha-Hbeta reference distance 2.19 A;
source-derived restraint uncertainty +/-10%;
reported averaging convention r^-3.

For each frozen ROE restraint:

r_eff
=
<r^-3>^(-1/3).

The exact ROE target values and atom/pseudoatom mappings must be transcribed from the source SI and SHA-frozen before MD analysis.

No restraint may be added, removed, reassigned, or reweighted according to CONTROL/TEST performance.

If the source uses an ambiguous or pseudoatom restraint, its source-defined equivalence convention must be preserved rather than invented after simulation.

Primary ROE summaries:

M4:
fraction of restraints satisfied.

M5:
mean absolute bound violation in Angstrom.

ROE metrics remain secondary and cannot override an unfavorable M2 result.

## 9. Transition behavior

Transition counts are descriptive only.

They may reveal trapping or sampling limitations but are not used as a primary thermodynamic success criterion.

No kinetic rate claim is permitted unless a later sampling protocol explicitly supports such inference.

## 10. Statistical unit and paired comparison

The scientific comparison unit is the peptide.

Frames are not treated as independent biological/chemical replicates.

For every metric:

calculate CONTROL and TEST separately for each peptide first.

Then calculate paired TEST-versus-CONTROL effects.

All seven Tier-A peptides receive equal weight.

No peptide may receive greater weight because it has more saved frames or lower apparent variance.

For the primary M2 endpoint report:

- all seven peptide-level paired effects;
- equal-peptide mean paired effect;
- median paired effect;
- number of peptides with positive paired effect.

An exact two-sided 2^7 sign-flip permutation test on the mean paired effect may be reported as a secondary inferential summary.

It is not used to change the endpoint definition.

No pooled-frame p value is permitted.

## 11. Sampling boundary

Only frames admitted by the later frozen MD sampling/equilibration protocol may enter analysis.

Equilibration discard, replica count, trajectory length, frame stride and replica weighting must be frozen before CONTROL/TEST trajectories are inspected.

Analysis thresholds in this document may not be retuned from convergence behavior.

## 12. Tier-A scientific conclusion hierarchy

The direction of Tier-A conformational transfer is determined primarily by the equal-peptide paired effect in M2 joint-major-basin occupancy.

M1, M3, M4 and M5 provide mechanistic and orthogonal support.

No post-hoc composite score is permitted.

No post-hoc reweighting of the observables is permitted.

If M2 is unfavorable, favorable secondary observables cannot be substituted as the primary result.

## 13. Tier-B boundary

Tier-B remains a secondary mixed-ensemble stress test.

The definitions of cis/trans classification, periodic phi/psi distance and ROE calculation established here are inherited into Tier-B unless a source-specific observable is genuinely unavailable.

Tier-B results may not redefine the Tier-A primary metric.

## 14. Required source-target extraction still pending

The exact JACS2006 Tier-A ROE restraint values and atom/pseudoatom identities have not yet been materialized into a machine-readable target table.

They must be extracted verbatim from the already-frozen SI tables:

JACS1: SI Table4
JACS2: SI Table7
JACS3: SI Table10
JACS4: SI Table13
JACS5: SI Table16
JACS6: SI Table19
JACS7: SI Table22

This source-target extraction must occur before MD analysis and must not inspect any CONTROL/TEST result.

## 15. Scientific boundary

This precommit performs no:

- cyclic-peptide topology generation;
- solvent-box construction;
- MD;
- M4 refit;
- coefficient modification;
- K/lambda change;
- peptide exclusion;
- performance-driven observable selection.

Production FOURIER_K4_L100 remains immutable.

NMe-D-Ala continues to use the scientifically closed mirrored rule:

V_D(phi,psi,omega)
=
V_L(-phi,-psi,-omega).

AUTHORIZED NEXT:

extract and freeze the exact Tier-A JACS ROE restraint target table and source atom/pseudoatom mapping.

After that source-target closure, prepare the exact paired CONTROL/TEST topology and MD sampling protocol.
