from pathlib import Path
import csv
import hashlib
import os


ROOT=Path("/mnt/lab/zn/mem-perm/P0_starter_v1")
DEV=ROOT/"07_nmeala_separability_pilot"/"13_joint_correction_development"

SRC=DEV/"16b_post_m4_cyclic_transfer_benchmark_extraction"
SRC_CLOSE=DEV/"16c_post_m4_cyclic_transfer_benchmark_extraction_closure"
CHIR_CLOSE=DEV/"16e_post_m4_cyclic_transfer_chirality_application_closure"

MANIFEST=SRC/"NMEALA_POSTM4_CYCLIC_TRANSFER_EXACT16_BENCHMARK_MANIFEST_v1.tsv"
DIHEDRALS=SRC/"NMEALA_POSTM4_CYCLIC_TRANSFER_EXPERIMENTAL_DIHEDRAL_REFERENCE_v1.tsv"
NMR=SRC/"NMEALA_POSTM4_CYCLIC_TRANSFER_NMR_PROTOCOL_v1.tsv"
EVIDENCE=SRC/"NMEALA_POSTM4_CYCLIC_TRANSFER_EXACT16_NMR_EVIDENCE_INVENTORY_v1.tsv"
ADJ=SRC_CLOSE/"NMEALA_POSTM4_CYCLIC_TRANSFER_SOURCE_ADJUDICATION_v1.tsv"

CHIR_FREEZE=CHIR_CLOSE/"NMEALA_POSTM4_CYCLIC_TRANSFER_CHIRALITY_APPLICATION_FINAL_CLOSURE_FREEZE_v1.sha256"

OUT=DEV/"16f_post_m4_cyclic_transfer_tiera_analysis_precommit"

TARGETS=OUT/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_EXACT7_ANALYSIS_TARGETS_v1.tsv"
METRICS=OUT/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_OBSERVABLE_DEFINITIONS_v1.tsv"
PROTOCOL=OUT/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ANALYSIS_PROTOCOL_v1.md"
FREEZE=OUT/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ANALYSIS_PRECOMMIT_FREEZE_v1.sha256"

EXPECTED={
    MANIFEST:"405de2188acba1f0217174deb8ef4b327d9335608e1186da0da429b39551593b",
    DIHEDRALS:"c965fda7d77c9784c119110fcf2863584da8eea539b75fdcd8d55fb893f7e49d",
    NMR:"d39d10d3a2b3878e1636596bcab21f710054f4ffe7cab4e4f0d08782492c5d51",
    EVIDENCE:"bfb11d13cef050123913887573ea3c1a344b35285477c1a68f970c3a56c0818f",
    ADJ:"7490102c0660331b67bf57aedafdd70fdce9b487df50ff4c86f986332e58de75",
    CHIR_FREEZE:"f95e0dcfd3a0817bc8af83a92c5afc9575f9271399092c99e5f2f470e056b3e9",
}

TIERA={
    "TIERA_JACS1",
    "TIERA_JACS2",
    "TIERA_JACS3",
    "TIERA_JACS4",
    "TIERA_JACS5",
    "TIERA_JACS6",
    "TIERA_JACS7",
}


def sha(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):
            h.update(b)
    return h.hexdigest()


def rel(p):
    p=Path(p).resolve()
    try:
        return str(p.relative_to(ROOT))
    except ValueError:
        return str(p)


def read_tsv(p):
    with Path(p).open("r",encoding="utf-8",newline="") as f:
        r=csv.DictReader(f,delimiter="\t")
        return list(r.fieldnames or []),list(r)


def write_tsv(p,fields,rows):
    with Path(p).open("w",encoding="utf-8",newline="") as f:
        w=csv.DictWriter(
            f,
            fieldnames=fields,
            delimiter="\t",
            lineterminator="\n",
        )
        w.writeheader()
        w.writerows(rows)


print("===== 401MH TIER-A ANALYSIS / OBSERVABLE PRECOMMIT =====")
print("CONDA_DEFAULT_ENV =",os.environ.get("CONDA_DEFAULT_ENV"))
print("PYTHONPATH =",os.environ.get("PYTHONPATH"))

if os.environ.get("CONDA_DEFAULT_ENV")!="nme-torsion-p0":
    raise SystemExit("[FAIL] wrong environment")

if os.environ.get("PYTHONPATH") is not None:
    raise SystemExit("[FAIL] PYTHONPATH must be unset")

if OUT.exists():
    raise SystemExit("[FAIL] 16f output already exists")


print("===== 1. VERIFY CLOSED AUTHORITIES =====")

for p,e in EXPECTED.items():
    if not p.is_file():
        raise SystemExit("[FAIL] missing authority: "+str(p))

    a=sha(p)

    print(p.name)
    print(" expected =",e)
    print(" actual   =",a)

    if a!=e:
        raise SystemExit("[FAIL] SHA mismatch: "+p.name)

print("[PASS] exact6 closed authorities verified")


print("===== 2. RECOVER EXACT7 TIER-A TARGETS =====")

_,manifest=read_tsv(MANIFEST)
_,dihedrals=read_tsv(DIHEDRALS)
_,evidence=read_tsv(EVIDENCE)

tier_a=[r for r in manifest if r["benchmark_id"] in TIERA]

if len(tier_a)!=7 or {r["benchmark_id"] for r in tier_a}!=TIERA:
    raise SystemExit("[FAIL] exact7 Tier-A identity set differs")

tier_a_dih=[r for r in dihedrals if r["benchmark_id"] in TIERA]

if len(tier_a_dih)!=35:
    raise SystemExit("[FAIL] Tier-A trusted phi/psi rows !=35")

evidence_map={r["benchmark_id"]:r for r in evidence}

targets=[]

for r in sorted(tier_a,key=lambda x:int(x["source_label"].split("_")[1])):

    bid=r["benchmark_id"]

    if bid not in evidence_map:
        raise SystemExit("[FAIL] Tier-A evidence row missing: "+bid)

    ev=evidence_map[bid]

    if (
        ev["trusted_reference_structure"]!="True"
        or ev["phi_psi_reference_available"]!="True"
        or ev["ROE_restraint_table_available"]!="True"
    ):
        raise SystemExit("[FAIL] Tier-A trusted evidence surface differs: "+bid)

    targets.append({
        "benchmark_id":bid,
        "source_label":r["source_label"],
        "global_library_compound_id":r["global_library_compound_id"],
        "source_population_ratio":r["source_population_ratio"],
        "major_population_percent":r["major_population_percent"],
        "major_cis_bonds":r["major_cis_bonds"],
        "major_cis_count":r["major_cis_count"],
        "conformational_class":r["conformational_class"],
        "trusted_phi_psi_rows":"5",
        "roe_source_table":ev["roe_locator"],
        "primary_target_role":"ARTICLE_DEFINED_DOMINANT_SINGLE_CONFORMER",
        "population_use_rule":"SOURCE_ANNOTATION_NOT_HIGH_PRECISION_REGRESSION_TARGET",
    })

print("Tier-A target rows =",len(targets))
print("Tier-A trusted phi/psi rows =",len(tier_a_dih))

OUT.mkdir(parents=True,exist_ok=False)

write_tsv(
    TARGETS,
    list(targets[0].keys()),
    targets,
)

print("Tier-A targets SHA256 =",sha(TARGETS))


print("===== 3. WRITE FROZEN OBSERVABLE DEFINITIONS =====")

metrics=[
    {
        "metric_id":"M1_EXACT_CISTRANS_PATTERN_OCCUPANCY",
        "priority":"SECONDARY_KEY",
        "direction":"HIGHER_BETTER",
        "definition":"fraction of analyzed frames in which all five peptide bonds match the source major cis/trans pattern; cis if periodic distance to 0 deg <=30; trans if periodic distance to 180 deg <=30; intermediate otherwise and therefore nonmatching",
    },
    {
        "metric_id":"M2_JOINT_MAJOR_BASIN_OCCUPANCY",
        "priority":"PRIMARY",
        "direction":"HIGHER_BETTER",
        "definition":"fraction of analyzed frames satisfying M1 exact cis/trans pattern AND backbone phi/psi circular RMS deviation from the exact five-residue source reference <=45 deg over the ten phi/psi angles",
    },
    {
        "metric_id":"M3_BACKBONE_PHI_PSI_CRMS_DEG",
        "priority":"SECONDARY",
        "direction":"LOWER_BETTER",
        "definition":"per-frame circular RMS deviation in degrees across the ten source-referenced phi/psi angles; report trajectory median and mean",
    },
    {
        "metric_id":"M4_ROE_RESTRAINT_SATISFACTION",
        "priority":"SECONDARY_ORTHOGONAL_NMR",
        "direction":"HIGHER_BETTER",
        "definition":"fraction of frozen source ROE restraints whose ensemble r^-3 effective distance lies within the frozen source-derived restraint bounds",
    },
    {
        "metric_id":"M5_ROE_MEAN_BOUND_VIOLATION_A",
        "priority":"SECONDARY_ORTHOGONAL_NMR",
        "direction":"LOWER_BETTER",
        "definition":"mean absolute distance outside the applicable frozen ROE lower/upper bound; zero for a satisfied restraint",
    },
    {
        "metric_id":"M6_MAJOR_PATTERN_TRANSITION_COUNT",
        "priority":"DESCRIPTIVE_ONLY",
        "direction":"NONE",
        "definition":"number of entries into or exits from the exact source major cis/trans pattern after the frozen MD sampling/equilibration protocol is applied; not a primary thermodynamic endpoint",
    },
]

write_tsv(
    METRICS,
    list(metrics[0].keys()),
    metrics,
)

print("observable definitions rows =",len(metrics))
print("observable definitions SHA256 =",sha(METRICS))


print("===== 4. WRITE TIER-A ANALYSIS PRECOMMIT =====")

PROTOCOL.write_text(
"""# NMe-Ala post-M4 cyclic-transfer Tier-A analysis/observable precommit v1

STATUS:
FROZEN BEFORE CYCLIC-PEPTIDE TOPOLOGY GENERATION AND BEFORE ANY CONTROL/TEST MD.

## 1. Tier-A universe

Exact seven JACS2006 article-defined conformationally homogeneous systems:

TIERA_JACS1
TIERA_JACS2
TIERA_JACS3
TIERA_JACS4
TIERA_JACS5
TIERA_JACS6
TIERA_JACS7

No Tier-A peptide may be removed because of later topology difficulty, MD behavior, M4 performance, or analysis outcome.

All seven have:
- trusted source major conformer;
- exact five-residue phi/psi reference;
- source major cis/trans assignment;
- ROE restraint table availability.

## 2. Source population reporting

The JACS source reports Tier-A major populations as either:

100

or

98:2.

These strings are retained literally.

They define an experimentally dominant single-conformer regime.

They are NOT treated as high-precision continuous regression targets.

In particular, source-reported 100 must not be interpreted as an exact equilibrium probability of 1.000 with zero uncertainty.

No artificial uncertainty is invented.

## 3. Signed periodic torsions

All phi, psi and omega values are signed periodic torsions.

For any angular difference:

d_periodic(a,b)
=
minimum absolute angular displacement modulo 360 degrees.

## 4. Frozen cis/trans classifier

For every peptide bond:

CIS:
d_periodic(omega,0 degrees) <=30 degrees.

TRANS:
d_periodic(omega,180 degrees) <=30 degrees.

INTERMEDIATE:
all other omega values.

A frame matches the experimental major cis/trans pattern only if all five peptide bonds have exactly the source-defined cis/trans class.

Any intermediate bond makes that frame nonmatching.

These windows may not be changed after MD is inspected.

## 5. Frozen backbone basin distance

For every frame, compare the five residue phi/psi pairs with the exact trusted source reference.

Define:

phi_psi_cRMS
=
sqrt(
 mean over the ten phi/psi angles
 [
  d_periodic(simulated,reference)^2
 ]
).

The frozen dominant-backbone threshold is:

phi_psi_cRMS <=45 degrees.

## 6. Primary Tier-A endpoint

PRIMARY:
M2_JOINT_MAJOR_BASIN_OCCUPANCY.

A frame belongs to the source major basin only if BOTH conditions hold:

1. exact source cis/trans pattern;
2. phi_psi_cRMS <=45 degrees.

Per peptide:

P_major
=
number of analyzed frames in the joint major basin
/
total analyzed frames.

The primary paired effect is:

Delta_major
=
P_major(TEST M0+M4)
-
P_major(CONTROL M0).

Positive values favor the frozen M4 correction.

## 7. Secondary conformational endpoints

M1:
exact cis/trans-pattern occupancy.

M3:
phi/psi circular RMS deviation;
report mean and median.

These are secondary.

Neither may replace M2 as the primary endpoint after results are known.

## 8. ROE validation

ROE comparison is an orthogonal secondary NMR layer.

The source protocol remains:

297 K;
500 MHz;
DMSO-d6;
ROESY mixing time 150 ms;
alanine Halpha-Hbeta reference distance 2.19 A;
source-derived restraint uncertainty +/-10%;
reported averaging convention r^-3.

For each frozen ROE restraint:

r_eff
=
<r^-3>^(-1/3).

The exact ROE target values and atom/pseudoatom mappings must be transcribed from the source SI and SHA-frozen before MD analysis.

No restraint may be added, removed, reassigned, or reweighted according to CONTROL/TEST performance.

If the source uses an ambiguous or pseudoatom restraint, its source-defined equivalence convention must be preserved rather than invented after simulation.

Primary ROE summaries:

M4:
fraction of restraints satisfied.

M5:
mean absolute bound violation in Angstrom.

ROE metrics remain secondary and cannot override an unfavorable M2 result.

## 9. Transition behavior

Transition counts are descriptive only.

They may reveal trapping or sampling limitations but are not used as a primary thermodynamic success criterion.

No kinetic rate claim is permitted unless a later sampling protocol explicitly supports such inference.

## 10. Statistical unit and paired comparison

The scientific comparison unit is the peptide.

Frames are not treated as independent biological/chemical replicates.

For every metric:

calculate CONTROL and TEST separately for each peptide first.

Then calculate paired TEST-versus-CONTROL effects.

All seven Tier-A peptides receive equal weight.

No peptide may receive greater weight because it has more saved frames or lower apparent variance.

For the primary M2 endpoint report:

- all seven peptide-level paired effects;
- equal-peptide mean paired effect;
- median paired effect;
- number of peptides with positive paired effect.

An exact two-sided 2^7 sign-flip permutation test on the mean paired effect may be reported as a secondary inferential summary.

It is not used to change the endpoint definition.

No pooled-frame p value is permitted.

## 11. Sampling boundary

Only frames admitted by the later frozen MD sampling/equilibration protocol may enter analysis.

Equilibration discard, replica count, trajectory length, frame stride and replica weighting must be frozen before CONTROL/TEST trajectories are inspected.

Analysis thresholds in this document may not be retuned from convergence behavior.

## 12. Tier-A scientific conclusion hierarchy

The direction of Tier-A conformational transfer is determined primarily by the equal-peptide paired effect in M2 joint-major-basin occupancy.

M1, M3, M4 and M5 provide mechanistic and orthogonal support.

No post-hoc composite score is permitted.

No post-hoc reweighting of the observables is permitted.

If M2 is unfavorable, favorable secondary observables cannot be substituted as the primary result.

## 13. Tier-B boundary

Tier-B remains a secondary mixed-ensemble stress test.

The definitions of cis/trans classification, periodic phi/psi distance and ROE calculation established here are inherited into Tier-B unless a source-specific observable is genuinely unavailable.

Tier-B results may not redefine the Tier-A primary metric.

## 14. Required source-target extraction still pending

The exact JACS2006 Tier-A ROE restraint values and atom/pseudoatom identities have not yet been materialized into a machine-readable target table.

They must be extracted verbatim from the already-frozen SI tables:

JACS1: SI Table4
JACS2: SI Table7
JACS3: SI Table10
JACS4: SI Table13
JACS5: SI Table16
JACS6: SI Table19
JACS7: SI Table22

This source-target extraction must occur before MD analysis and must not inspect any CONTROL/TEST result.

## 15. Scientific boundary

This precommit performs no:

- cyclic-peptide topology generation;
- solvent-box construction;
- MD;
- M4 refit;
- coefficient modification;
- K/lambda change;
- peptide exclusion;
- performance-driven observable selection.

Production FOURIER_K4_L100 remains immutable.

NMe-D-Ala continues to use the scientifically closed mirrored rule:

V_D(phi,psi,omega)
=
V_L(-phi,-psi,-omega).

AUTHORIZED NEXT:

extract and freeze the exact Tier-A JACS ROE restraint target table and source atom/pseudoatom mapping.

After that source-target closure, prepare the exact paired CONTROL/TEST topology and MD sampling protocol.
""",
encoding="utf-8",
)

print("Tier-A protocol SHA256 =",sha(PROTOCOL))


print("===== 5. WRITE EXACT10-MEMBER PRECOMMIT FREEZE =====")

members={
    Path(__file__).resolve(),
    CHIR_FREEZE.resolve(),
    MANIFEST.resolve(),
    DIHEDRALS.resolve(),
    NMR.resolve(),
    EVIDENCE.resolve(),
    ADJ.resolve(),
    TARGETS.resolve(),
    METRICS.resolve(),
    PROTOCOL.resolve(),
}

if len(members)!=10:
    raise SystemExit("[FAIL] precommit member count !=10")

FREEZE.write_text(
    "\n".join(
        sha(p)+"  "+rel(p)
        for p in sorted(members,key=lambda x:str(x))
    )+"\n",
    encoding="utf-8",
)

print("precommit freeze entries =",len(members))
print("precommit freeze SHA256 =",sha(FREEZE))


print("===== 6. FINAL PRECOMMIT STATE =====")

if len([p for p in OUT.iterdir() if p.is_file()])!=4:
    raise SystemExit("[FAIL] 16f output !=exact4 files")

print("[PASS] TIER-A ANALYSIS/OBSERVABLE PROTOCOL FROZEN")
print("[PASS] exact7 Tier-A identities retained")
print("[PASS] exact35 trusted source phi/psi rows retained")
print("[PASS] primary endpoint = joint major-basin occupancy")
print("[PASS] cis/trans windows =30 deg")
print("[PASS] phi/psi cRMS basin threshold =45 deg")
print("[PASS] source 100 / 98:2 retained without false precision")
print("[PASS] ROE uses source r^-3 averaging and frozen source bounds")
print("[PASS] peptide is the paired statistical unit; no pooled-frame inference")
print("[PASS] no topology / MD / M4 change occurred")
print("[AUTHORIZED-NEXT] extract exact Tier-A ROE target tables before topology/MD analysis")

print("401MH script SHA256 =",sha(Path(__file__)))
print("===== 401MH2-TIERA-ANALYSIS-OBSERVABLE-PRECOMMIT-v2 END =====")
