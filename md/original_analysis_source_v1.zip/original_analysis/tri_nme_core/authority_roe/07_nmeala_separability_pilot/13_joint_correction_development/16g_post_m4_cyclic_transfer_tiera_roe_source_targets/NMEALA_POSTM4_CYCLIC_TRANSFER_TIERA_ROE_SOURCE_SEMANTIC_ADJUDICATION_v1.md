# Tier-A JACS2006 ROE source semantic adjudication v1

STATUS:
SOURCE SEMANTICS ADJUDICATED BEFORE CONTROL/TEST TOPOLOGY OR MD.

The seven SI tables are complete distance-restraint inventories, not violation-only subsets.

Per-peptide restraint counts:
JACS1=25
JACS2=20
JACS3=26
JACS4=20
JACS5=21
JACS6=19
JACS7=21
TOTAL=152

Evidence for completeness:
Every table contains both zero-violation and nonzero-violation rows.

Frozen interpretation:
- Proton/end-point labels are preserved exactly as printed.
- Low and Upp are the experimental restraint interval used for future M4/M5 evaluation.
- Source Calc. and Viol columns are retained only for provenance/source reconstruction.
- Source Calc. and Viol are NOT CONTROL/TEST targets.
- Source-reported calculated distances use <r^-3> averaging.
- No restraint row is deduplicated.
- The duplicated JACS1 ALA3:HN--ALA3:Halpha source pair is retained twice with its two source bounds.
- Cbeta/CN/Halpha/HN labels are not yet translated into production topology atom/pseudoatom selections.
- Production atom/pseudoatom mapping must be frozen separately before trajectory analysis.

No topology, MD, M4 refit, threshold change, or peptide exclusion occurred.
