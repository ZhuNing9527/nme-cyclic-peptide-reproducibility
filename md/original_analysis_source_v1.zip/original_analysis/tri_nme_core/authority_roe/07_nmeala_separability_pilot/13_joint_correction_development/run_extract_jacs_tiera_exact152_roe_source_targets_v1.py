from pathlib import Path
from collections import Counter
import csv, hashlib, os, re, shutil, subprocess

ROOT=Path("/mnt/lab/zn/mem-perm/P0_starter_v1")
DEV=ROOT/"07_nmeala_separability_pilot"/"13_joint_correction_development"

SI=DEV/"16_post_m4_cyclic_transfer_source_acquisition"/"raw_sources"/"ja063123d_si_001.pdf"
PRE=DEV/"16f_post_m4_cyclic_transfer_tiera_analysis_precommit"/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ANALYSIS_PRECOMMIT_FREEZE_v1.sha256"
INSPECT=DEV/"run_inspect_jacs_tiera_roe_source_tables_v1.py"

OUT=DEV/"16g_post_m4_cyclic_transfer_tiera_roe_source_targets"
TARGET=OUT/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_EXACT152_ROE_DISTANCE_RESTRAINTS_v1.tsv"
ADJ=OUT/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_SOURCE_SEMANTIC_ADJUDICATION_v1.md"
FREEZE=OUT/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_SOURCE_TARGET_FREEZE_v1.sha256"

EXP={
 SI:"a26b8b3d90c74775fa06fbf0efaecf4cffaa796fff3a04c773daf98810f23728",
 PRE:"a23bc0eb9ccbf024ad86af04c9115bfcd48b687d2e19f560bbb2b2712a0f17e4",
 INSPECT:"9b0745f03f4ac55b868e08d9e744f62ae74fb2f555e40699d633260122df3a5a",
}

# compound : table, PDF page, expected restraint rows
SPEC={
 1:(4,9,25), 2:(7,12,20), 3:(10,15,26), 4:(13,18,20),
 5:(16,21,21), 6:(19,24,19), 7:(22,27,21),
}

def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""): h.update(b)
    return h.hexdigest()

def rel(p):
    return str(Path(p).resolve().relative_to(ROOT))

def rehash(p,n):
    rows=[]
    for line in p.read_text().splitlines():
        if not line.strip(): continue
        h,s=line.split(maxsplit=1)
        q=Path(s)
        if not q.is_absolute(): q=ROOT/q
        if not q.is_file() or sha(q)!=h:
            raise SystemExit("[FAIL] frozen member changed: "+str(q))
        rows.append(q.resolve())
    if len(rows)!=n: raise SystemExit("[FAIL] freeze cardinality differs")
    return rows

print("===== 401MJ EXACT152 ROE SOURCE-TARGET EXTRACTION =====")
print("CONDA_DEFAULT_ENV =",os.environ.get("CONDA_DEFAULT_ENV"))
print("PYTHONPATH =",os.environ.get("PYTHONPATH"))

if os.environ.get("CONDA_DEFAULT_ENV")!="nme-torsion-p0":
    raise SystemExit("[FAIL] wrong environment")
if os.environ.get("PYTHONPATH") is not None:
    raise SystemExit("[FAIL] PYTHONPATH must be unset")
if OUT.exists():
    raise SystemExit("[FAIL] 16g already exists")

print("===== 1. VERIFY AUTHORITIES =====")
for p,e in EXP.items():
    if not p.is_file(): raise SystemExit("[FAIL] missing "+str(p))
    a=sha(p)
    print(p.name,"expected =",e)
    print(p.name,"actual   =",a)
    if a!=e: raise SystemExit("[FAIL] SHA mismatch "+p.name)

print("Tier-A precommit entries =",len(rehash(PRE,10)))
print("[PASS] frozen SI / precommit / 401MI authorities verified")

print("===== 2. EXTRACT EXACT SOURCE PAGES =====")
exe=shutil.which("pdftotext")
if exe is None: raise SystemExit("[FAIL] pdftotext unavailable")

r=subprocess.run(
    [exe,"-layout","-enc","UTF-8",str(SI),"-"],
    stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,check=False
)
print("pdftotext exit status =",r.returncode)
if r.returncode: raise SystemExit("[FAIL] pdftotext failed")

pages=r.stdout.split("\f")
while pages and not pages[-1].strip(): pages.pop()
print("PDF pages =",len(pages))
if len(pages)!=28: raise SystemExit("[FAIL] page count !=28")

pat=re.compile(
 r"^\s*(1:\S+)\s+(1:\S+)\s+"
 r"([0-9]+(?:\.[0-9]+)?)\s+([0-9]+(?:\.[0-9]+)?)\s+"
 r"([0-9]+(?:\.[0-9]+)?)\s+(-?[0-9]+(?:\.[0-9]+)?)\s*$"
)

out=[]
counts={}
endpoint_types=Counter()

for compound,(table,page,nexp) in SPEC.items():
    page_text=pages[page-1]
    heading=f"Table {table}. Distance restraints and their violations during the 150 ps rMD simulation of {compound}."

    if page_text.count(heading)!=1:
        raise SystemExit(f"[FAIL] Table{table} heading not unique on page{page}")

    rows=[]
    for line in page_text.splitlines():
        m=pat.match(line)
        if m: rows.append(m.groups())

    counts[compound]=len(rows)
    print(f"JACS{compound} Table{table} page{page} rows =",len(rows))

    if len(rows)!=nexp:
        raise SystemExit(f"[FAIL] Table{table} rows !={nexp}")

    zero=sum(float(x[5])==0.0 for x in rows)
    nonzero=len(rows)-zero

    print(" zero-violation rows =",zero)
    print(" nonzero-violation rows =",nonzero)

    if zero==0 or nonzero==0:
        raise SystemExit("[FAIL] complete-restraint semantic gate failed")

    for rank,(p1,p2,low,upp,calc,viol) in enumerate(rows,1):
        if float(low)>=float(upp):
            raise SystemExit("[FAIL] invalid source bound")

        endpoint_types[p1.rsplit(":",1)[1]]+=1
        endpoint_types[p2.rsplit(":",1)[1]]+=1

        out.append({
          "restraint_id":f"TIERA_JACS{compound}_T{table}_R{rank:02d}",
          "benchmark_id":f"TIERA_JACS{compound}",
          "source_compound":str(compound),
          "source_table":str(table),
          "source_pdf_page":str(page),
          "source_row_rank":str(rank),
          "source_endpoint_1":p1,
          "source_endpoint_2":p2,
          "lower_bound_A":low,
          "upper_bound_A":upp,
          "source_rMD_calc_rminus3_A":calc,
          "source_rMD_violation_A":viol,
          "analysis_target":"LOWER_UPPER_BOUNDS_ONLY",
          "md_atom_mapping_status":"SOURCE_LABEL_PRESERVED_MAPPING_PENDING",
        })

print("total restraint rows =",len(out))
print("endpoint-label occurrences =",dict(sorted(endpoint_types.items())))

if len(out)!=152:
    raise SystemExit("[FAIL] exact152 cardinality differs")

dups=Counter(
 (r["benchmark_id"],r["source_endpoint_1"],r["source_endpoint_2"])
 for r in out
)
dup_groups=[(k,v) for k,v in dups.items() if v>1]

print("duplicate endpoint-pair groups =",dup_groups)

if dup_groups != [(("TIERA_JACS1","1:ALA3:HN","1:ALA3:Hα"),2)]:
    raise SystemExit("[FAIL] source duplicate-pair structure differs")

print("[PASS] exact source duplicate preserved; no deduplication")

print("===== 3. MATERIALIZE SOURCE TARGETS =====")
OUT.mkdir(parents=True,exist_ok=False)

fields=list(out[0])
with TARGET.open("w",encoding="utf-8",newline="") as f:
    w=csv.DictWriter(f,fieldnames=fields,delimiter="\t",lineterminator="\n")
    w.writeheader()
    w.writerows(out)

print("target rows =",len(out))
print("target SHA256 =",sha(TARGET))

ADJ.write_text(
f"""# Tier-A JACS2006 ROE source semantic adjudication v1

STATUS:
SOURCE SEMANTICS ADJUDICATED BEFORE CONTROL/TEST TOPOLOGY OR MD.

The seven SI tables are complete distance-restraint inventories, not violation-only subsets.

Per-peptide restraint counts:
JACS1=25
JACS2=20
JACS3=26
JACS4=20
JACS5=21
JACS6=19
JACS7=21
TOTAL=152

Evidence for completeness:
Every table contains both zero-violation and nonzero-violation rows.

Frozen interpretation:
- Proton/end-point labels are preserved exactly as printed.
- Low and Upp are the experimental restraint interval used for future M4/M5 evaluation.
- Source Calc. and Viol columns are retained only for provenance/source reconstruction.
- Source Calc. and Viol are NOT CONTROL/TEST targets.
- Source-reported calculated distances use <r^-3> averaging.
- No restraint row is deduplicated.
- The duplicated JACS1 ALA3:HN--ALA3:Halpha source pair is retained twice with its two source bounds.
- Cbeta/CN/Halpha/HN labels are not yet translated into production topology atom/pseudoatom selections.
- Production atom/pseudoatom mapping must be frozen separately before trajectory analysis.

No topology, MD, M4 refit, threshold change, or peptide exclusion occurred.
""",
encoding="utf-8"
)

print("adjudication SHA256 =",sha(ADJ))

members={Path(__file__).resolve(),SI.resolve(),PRE.resolve(),INSPECT.resolve(),TARGET.resolve(),ADJ.resolve()}
if len(members)!=6: raise SystemExit("[FAIL] freeze members !=6")

FREEZE.write_text(
 "\n".join(sha(p)+"  "+rel(p) for p in sorted(members,key=str))+"\n",
 encoding="utf-8"
)

print("freeze entries =",len(members))
print("freeze SHA256 =",sha(FREEZE))

print("===== 4. FINAL STATE =====")
print("[PASS] exact152 Tier-A distance-restraint rows frozen")
print("[PASS] complete-restraint semantics frozen")
print("[PASS] Low/Upp are M4/M5 source targets")
print("[PASS] source Calc/Viol retained as provenance only")
print("[PASS] duplicate source restraint preserved")
print("[PASS] atom/pseudoatom production mapping remains intentionally pending")
print("[PASS] no topology / MD / M4 modification")
print("[AUTHORIZED-NEXT] one independent ROE source-target closure, then freeze production atom/pseudoatom mapping")
print("401MJ script SHA256 =",sha(Path(__file__)))
print("===== 401MJ-TIERA-EXACT152-ROE-SOURCE-TARGET-EXTRACTION END =====")
