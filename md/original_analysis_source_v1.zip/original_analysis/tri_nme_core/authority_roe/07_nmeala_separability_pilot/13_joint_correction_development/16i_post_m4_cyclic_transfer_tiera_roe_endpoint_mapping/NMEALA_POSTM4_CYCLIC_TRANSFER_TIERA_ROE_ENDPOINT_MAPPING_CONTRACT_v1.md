# Tier-A ROE endpoint semantic mapping contract v1

STATUS:
FROZEN BEFORE TIER-A PRODUCTION TOPOLOGY GENERATION.

Published experimental origin:
ROESY cross-peak volumes were converted to proton-proton distances;
Ala Halpha-Hbeta 2.19 A was the reference;
Low/Upp were formed from the experimental distance with +/-10%.

Published computational comparison:
The SI restraint tables operationally label the methyl endpoints Cbeta and CN.
The published trajectory Calc. values are reported with <r^-3> averaging.

Frozen reproduction semantics:
Halpha -> alpha hydrogen coordinate.
HN -> amide hydrogen coordinate.
Cbeta -> alanine side-chain methyl carbon coordinate proxy.
CN -> N-methyl carbon coordinate proxy.

For every restraint, the trajectory observable is:
r_eff = <r(t)^-3>^(-1/3).

No explicit three-methyl-proton group averaging is substituted for Cbeta or CN.
No additional pseudoatom-distance correction is added.
Low/Upp remain the frozen source bounds.
Source Calc./Viol. are not CONTROL/TEST targets.

Interpretive boundary:
Cbeta/CN are computational coordinate proxies for methyl ROE endpoints.
This does not mean carbon atoms generate the experimental ROE.

Topology boundary:
No concrete Amber atom name/index is frozen here because Tier-A production
topologies do not yet exist. Each generated topology must later bind these
four chemical coordinate semantics to exactly one corresponding atom and
pass an independent topology-binding audit before trajectory analysis.

No topology, MD, M4 refit, threshold change, or source-target modification occurred.
