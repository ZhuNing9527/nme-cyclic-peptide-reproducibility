from pathlib import Path
import hashlib
import re
import shutil
import subprocess
import os


ROOT=Path("/mnt/lab/zn/mem-perm/P0_starter_v1")
DEV=ROOT/"07_nmeala_separability_pilot"/"13_joint_correction_development"

SI=(
    DEV
    /"16_post_m4_cyclic_transfer_source_acquisition"
    /"raw_sources"
    /"ja063123d_si_001.pdf"
)

PRECOMMIT=(
    DEV
    /"16f_post_m4_cyclic_transfer_tiera_analysis_precommit"
    /"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ANALYSIS_PRECOMMIT_FREEZE_v1.sha256"
)

EXPECTED_SI="a26b8b3d90c74775fa06fbf0efaecf4cffaa796fff3a04c773daf98810f23728"
EXPECTED_PRE="a23bc0eb9ccbf024ad86af04c9115bfcd48b687d2e19f560bbb2b2712a0f17e4"

TARGET_TABLES=[4,7,10,13,16,19,22]


def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):
            h.update(b)
    return h.hexdigest()


def resolve(s):
    p=Path(s)
    return p if p.is_absolute() else ROOT/p


def rehash_freeze(p):
    rows=[]

    for line in p.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue

        a,b=line.split(maxsplit=1)
        q=resolve(b).resolve()

        if not q.is_file():
            raise SystemExit("[FAIL] frozen member missing: "+str(q))

        if sha(q)!=a:
            raise SystemExit("[FAIL] frozen member SHA changed: "+str(q))

        rows.append((a,q))

    return rows


print("===== 401MI JACS TIER-A ROE SOURCE-TABLE SEMANTIC INSPECTION =====")
print("CONDA_DEFAULT_ENV =",os.environ.get("CONDA_DEFAULT_ENV"))
print("PYTHONPATH =",os.environ.get("PYTHONPATH"))

if os.environ.get("CONDA_DEFAULT_ENV")!="nme-torsion-p0":
    raise SystemExit("[FAIL] wrong environment")

if os.environ.get("PYTHONPATH") is not None:
    raise SystemExit("[FAIL] PYTHONPATH must be unset")


print("===== 1. VERIFY FROZEN SOURCE / TIER-A PRECOMMIT =====")

for p,e in [(SI,EXPECTED_SI),(PRECOMMIT,EXPECTED_PRE)]:
    if not p.is_file():
        raise SystemExit("[FAIL] missing authority: "+str(p))

    a=sha(p)

    print(p.name)
    print(" expected =",e)
    print(" actual   =",a)

    if a!=e:
        raise SystemExit("[FAIL] SHA mismatch: "+p.name)


pre_rows=rehash_freeze(PRECOMMIT)

print("Tier-A precommit freeze entries =",len(pre_rows))

if len(pre_rows)!=10:
    raise SystemExit("[FAIL] Tier-A precommit freeze !=10")

print("[PASS] exact10 Tier-A precommit members independently rehashed")


print("===== 2. EXTRACT JACS SI TEXT READ-ONLY =====")

pdftotext=shutil.which("pdftotext")

print("pdftotext =",pdftotext)

if pdftotext is None:
    raise SystemExit("[FAIL] pdftotext unavailable")

run=subprocess.run(
    [
        pdftotext,
        "-layout",
        "-enc","UTF-8",
        str(SI),
        "-",
    ],
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
    check=False,
)

print("pdftotext exit status =",run.returncode)

if run.stderr.strip():
    print("pdftotext stderr:")
    print(run.stderr.strip())

if run.returncode!=0:
    raise SystemExit("[FAIL] pdftotext failed")

text=run.stdout

pages=text.split("\f")

while pages and not pages[-1].strip():
    pages.pop()

print("extracted PDF pages =",len(pages))

if len(pages)!=28:
    raise SystemExit("[FAIL] extracted JACS SI page count !=28")


print("===== 3. LOCATE ALL TABLE HEADINGS =====")

pattern=re.compile(
    r"(?im)^[ \t]*Table[ \t]+([0-9]+)\b[^\n]*"
)

matches=list(pattern.finditer(text))

headers=[]

for m in matches:
    number=int(m.group(1))
    page=text[:m.start()].count("\f")+1
    heading=m.group(0).strip()

    headers.append(
        (number,page,m.start(),heading)
    )

print("table heading count =",len(headers))

for number,page,_,heading in headers:
    print(
        f"TABLE_HEADER table={number} pdf_page={page} :: {heading}"
    )


print("===== 4. VERIFY EXACT TARGET TABLE LOCATORS =====")

target_hits={}

for target in TARGET_TABLES:
    hits=[
        row
        for row in headers
        if row[0]==target
    ]

    print(
        "target table",
        target,
        "hits =",
        len(hits),
        "pages =",
        [x[1] for x in hits],
    )

    if len(hits)!=1:
        raise SystemExit(
            "[HOLD] target Table "
            +str(target)
            +" not uniquely localized"
        )

    target_hits[target]=hits[0]


print("[PASS] exact7 target table headings uniquely localized")


print("===== 5. PRINT EXACT7 TARGET TABLE BLOCKS =====")

for target in TARGET_TABLES:

    _,page,start,heading=target_hits[target]

    later=[
        x
        for x in headers
        if x[2]>start
    ]

    end=(
        min(x[2] for x in later)
        if later
        else len(text)
    )

    block=text[start:end].strip()

    low=block.lower()

    print()
    print(
        "===== TARGET TABLE",
        target,
        "PDF_PAGE",
        page,
        "BEGIN ====="
    )

    print("HEADING =",heading)

    print(
        "keyword_counts:",
        "roe=",
        low.count("roe"),
        "violation=",
        low.count("violation"),
        "restraint=",
        low.count("restraint"),
        "distance=",
        low.count("distance"),
    )

    print("--- SOURCE BLOCK ---")
    print(block)
    print("--- END SOURCE BLOCK ---")

    print(
        "===== TARGET TABLE",
        target,
        "END ====="
    )


print()
print("===== 6. READ-ONLY SCIENTIFIC BOUNDARY =====")

print("[PASS] original JACS SI remained byte-identical")
print("[PASS] Tier-A analysis precommit remained byte-identical")
print("[PASS] no ROE target TSV generated")
print("[PASS] no restraint/restriction semantics inferred")
print("[PASS] no topology / MD / M4 modification")
print("[AUTHORIZED-NEXT] adjudicate whether Tables4/7/10/13/16/19/22 are complete restraint tables or violation-only tables")

print("401MI script SHA256 =",sha(Path(__file__)))

print("===== 401MI-JACS-TIERA-ROE-SOURCE-TABLE-SEMANTIC-INSPECTION END =====")
