# Tier-A exact152 ROE source-target final closure v1

STATUS:
SCIENTIFICALLY CLOSED BY INDEPENDENT SOURCE RECONSTRUCTION.

Source:
JACS2006 Supporting Information, exact Tables 4, 7, 10, 13, 16, 19 and 22.

Independent restraint counts:
- JACS1 =25
- JACS2 =20
- JACS3 =26
- JACS4 =20
- JACS5 =21
- JACS6 =19
- JACS7 =21
- total =152

Semantic closure:
- the seven tables are treated as complete distance-restraint inventories;
- every table contains both zero-violation and nonzero-violation rows;
- Low/Upp are frozen experimental analysis bounds;
- source Calc./Viol. are retained only for source provenance;
- source calculated distances use r^-3 averaging;
- no restraint has been deduplicated;
- the duplicated JACS1 ALA3:HN--ALA3:Halpha endpoint pair remains as two distinct source rows.

Independent reconstruction:
- original SI SHA verified;
- Tier-A precommit exact10 lineage rehashed;
- source-target exact6 lineage rehashed;
- exact152 rows reconstructed independently from source pages;
- all frozen fields reproduce the independent source reconstruction exactly.

Boundary:
- endpoint labels remain source labels;
- production atom/pseudoatom mapping is still pending;
- Cbeta/CN must not be interpreted as literal production atoms without a separately frozen mapping contract;
- no topology generated;
- no cyclic-peptide MD run;
- no M4 modification;
- no observable threshold changed.

AUTHORIZED NEXT:
determine and freeze the source-label to production atom/pseudoatom mapping before topology/trajectory analysis.
