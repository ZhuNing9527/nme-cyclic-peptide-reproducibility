from pathlib import Path
from collections import Counter
import csv
import hashlib
import os
import shutil
import subprocess


ROOT=Path("/mnt/lab/zn/mem-perm/P0_starter_v1")
DEV=ROOT/"07_nmeala_separability_pilot"/"13_joint_correction_development"

SI=DEV/"16_post_m4_cyclic_transfer_source_acquisition"/"raw_sources"/"ja063123d_si_001.pdf"

PRE=DEV/"16f_post_m4_cyclic_transfer_tiera_analysis_precommit"/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ANALYSIS_PRECOMMIT_FREEZE_v1.sha256"

INSPECT=DEV/"run_inspect_jacs_tiera_roe_source_tables_v1.py"
EXTRACT=DEV/"run_extract_jacs_tiera_exact152_roe_source_targets_v1.py"

SRC=DEV/"16g_post_m4_cyclic_transfer_tiera_roe_source_targets"

TARGET=SRC/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_EXACT152_ROE_DISTANCE_RESTRAINTS_v1.tsv"
ADJ=SRC/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_SOURCE_SEMANTIC_ADJUDICATION_v1.md"
SRC_FREEZE=SRC/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_SOURCE_TARGET_FREEZE_v1.sha256"

OUT=DEV/"16h_post_m4_cyclic_transfer_tiera_roe_source_target_closure"

INVENTORY=OUT/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_SOURCE_TARGET_AUTHORITY_INVENTORY_v1.tsv"
REPORT=OUT/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_SOURCE_TARGET_FINAL_CLOSURE_QC_v1.md"
FREEZE=OUT/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_SOURCE_TARGET_FINAL_CLOSURE_FREEZE_v1.sha256"

EXPECTED={
    SI:"a26b8b3d90c74775fa06fbf0efaecf4cffaa796fff3a04c773daf98810f23728",
    PRE:"a23bc0eb9ccbf024ad86af04c9115bfcd48b687d2e19f560bbb2b2712a0f17e4",
    INSPECT:"9b0745f03f4ac55b868e08d9e744f62ae74fb2f555e40699d633260122df3a5a",
    EXTRACT:"bb2bb1b86b310f2f1bced8cd8c3620956b0f78b5ec4f754236829558ff1ded1c",
    TARGET:"d2c74165aa896fcc5a6547d75c83d3a869b2b59b13e586569e5d042b7c3f21dd",
    ADJ:"925b767b6adc17a2836999c8927bf19628a4a53f47a4892790de81f537111a76",
    SRC_FREEZE:"c28745f2731169ef80583a94dda03350800f421574839048b1c52dfe2454e78b",
}

SPEC={
    1:(4,9,25,13,12),
    2:(7,12,20,10,10),
    3:(10,15,26,13,13),
    4:(13,18,20,13,7),
    5:(16,21,21,11,10),
    6:(19,24,19,7,12),
    7:(22,27,21,12,9),
}


def sha(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):
            h.update(b)
    return h.hexdigest()


def rel(p):
    return str(Path(p).resolve().relative_to(ROOT))


def resolve(s):
    p=Path(s)
    return p if p.is_absolute() else ROOT/p


def rehash_freeze(p,n):
    rows=[]

    for line in Path(p).read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue

        h,s=line.split(maxsplit=1)
        q=resolve(s).resolve()

        if not q.is_file():
            raise SystemExit("[FAIL] frozen member absent: "+str(q))

        if sha(q)!=h:
            raise SystemExit("[FAIL] frozen member changed: "+str(q))

        rows.append(q)

    if len(rows)!=n or len(set(rows))!=n:
        raise SystemExit("[FAIL] freeze cardinality/path uniqueness differs")

    return rows


def read_tsv(p):
    with Path(p).open("r",encoding="utf-8",newline="") as f:
        r=csv.DictReader(f,delimiter="\t")
        return list(r.fieldnames or []),list(r)


print("===== 401MK INDEPENDENT EXACT152 ROE SOURCE-TARGET CLOSURE =====")
print("CONDA_DEFAULT_ENV =",os.environ.get("CONDA_DEFAULT_ENV"))
print("PYTHONPATH =",os.environ.get("PYTHONPATH"))

if os.environ.get("CONDA_DEFAULT_ENV")!="nme-torsion-p0":
    raise SystemExit("[FAIL] wrong environment")

if os.environ.get("PYTHONPATH") is not None:
    raise SystemExit("[FAIL] PYTHONPATH must be unset")

if OUT.exists():
    raise SystemExit("[FAIL] 16h already exists")


print("===== 1. VERIFY DIRECT AUTHORITIES =====")

for p,e in EXPECTED.items():
    if not p.is_file():
        raise SystemExit("[FAIL] missing authority: "+str(p))

    a=sha(p)

    print(p.name)
    print(" expected =",e)
    print(" actual   =",a)

    if a!=e:
        raise SystemExit("[FAIL] SHA mismatch: "+p.name)

print("[PASS] exact7 direct authority SHAs verified")


print("===== 2. REHASH PRECOMMIT10 / SOURCE-TARGET6 =====")

pre_rows=rehash_freeze(PRE,10)
src_rows=rehash_freeze(SRC_FREEZE,6)

print("Tier-A precommit entries =",len(pre_rows))
print("source-target freeze entries =",len(src_rows))

expected_src={
    SI.resolve(),
    PRE.resolve(),
    INSPECT.resolve(),
    EXTRACT.resolve(),
    TARGET.resolve(),
    ADJ.resolve(),
}

if set(src_rows)!=expected_src:
    raise SystemExit("[FAIL] source-target exact6 member set differs")

print("[PASS] precommit10 and exact6 source-target lineage independently rehashed")


print("===== 3. INDEPENDENT SOURCE RECONSTRUCTION =====")

exe=shutil.which("pdftotext")

if exe is None:
    raise SystemExit("[FAIL] pdftotext unavailable")

r=subprocess.run(
    [exe,"-layout","-enc","UTF-8",str(SI),"-"],
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
    check=False,
)

print("pdftotext exit status =",r.returncode)

if r.returncode!=0:
    raise SystemExit("[FAIL] pdftotext failed")

pages=r.stdout.split("\f")

while pages and not pages[-1].strip():
    pages.pop()

print("independent PDF pages =",len(pages))

if len(pages)!=28:
    raise SystemExit("[FAIL] SI page count !=28")

rebuilt=[]
endpoint_counts=Counter()

for compound,(table,page,nexp,zexp,nzexp) in SPEC.items():

    text=pages[page-1]

    heading=(
        f"Table {table}. Distance restraints and their violations "
        f"during the 150 ps rMD simulation of {compound}."
    )

    if text.count(heading)!=1:
        raise SystemExit(f"[FAIL] Table{table} heading localization differs")

    rows=[]

    for line in text.splitlines():

        t=line.split()

        if len(t)!=6:
            continue

        if not (t[0].startswith("1:") and t[1].startswith("1:")):
            continue

        try:
            [float(x) for x in t[2:]]
        except ValueError:
            continue

        rows.append(t)

    zero=sum(float(x[5])==0 for x in rows)
    nonzero=len(rows)-zero

    print(
        f"JACS{compound}: rows={len(rows)} "
        f"zero={zero} nonzero={nonzero}"
    )

    if (len(rows),zero,nonzero)!=(nexp,zexp,nzexp):
        raise SystemExit(f"[FAIL] independently reconstructed Table{table} counts differ")

    for rank,t in enumerate(rows,1):

        p1,p2,low,upp,calc,viol=t

        if float(low)>=float(upp):
            raise SystemExit("[FAIL] invalid Low/Upp interval")

        endpoint_counts[p1.rsplit(":",1)[1]]+=1
        endpoint_counts[p2.rsplit(":",1)[1]]+=1

        rebuilt.append({
            "restraint_id":f"TIERA_JACS{compound}_T{table}_R{rank:02d}",
            "benchmark_id":f"TIERA_JACS{compound}",
            "source_compound":str(compound),
            "source_table":str(table),
            "source_pdf_page":str(page),
            "source_row_rank":str(rank),
            "source_endpoint_1":p1,
            "source_endpoint_2":p2,
            "lower_bound_A":low,
            "upper_bound_A":upp,
            "source_rMD_calc_rminus3_A":calc,
            "source_rMD_violation_A":viol,
            "analysis_target":"LOWER_UPPER_BOUNDS_ONLY",
            "md_atom_mapping_status":"SOURCE_LABEL_PRESERVED_MAPPING_PENDING",
        })


print("independent total rows =",len(rebuilt))
print("independent endpoint counts =",dict(sorted(endpoint_counts.items())))

if len(rebuilt)!=152:
    raise SystemExit("[FAIL] independent total !=152")

if endpoint_counts!=Counter({
    "CN":44,
    "Cβ":61,
    "HN":95,
    "Hα":104,
}):
    raise SystemExit("[FAIL] endpoint-label totals differ")


print("===== 4. ROW-BY-ROW COMPARE WITH FROZEN TARGET =====")

fields,frozen=read_tsv(TARGET)

if len(frozen)!=152:
    raise SystemExit("[FAIL] frozen target rows !=152")

if fields!=list(rebuilt[0].keys()):
    raise SystemExit("[FAIL] frozen target schema differs")

mismatches=[]

for i,(a,b) in enumerate(zip(rebuilt,frozen),1):
    if a!=b:
        mismatches.append(i)

print("row mismatches =",mismatches)

if mismatches:
    raise SystemExit("[FAIL] frozen target differs from independent source reconstruction")

print("[PASS] exact152 frozen rows reproduce source byte-for-field")


print("===== 5. DUPLICATE / SEMANTIC RECONSTRUCTION =====")

pairs=Counter(
    (
        r["benchmark_id"],
        r["source_endpoint_1"],
        r["source_endpoint_2"],
    )
    for r in rebuilt
)

dups=[(k,v) for k,v in pairs.items() if v>1]

print("duplicate endpoint-pair groups =",dups)

expected_dup=[
    (("TIERA_JACS1","1:ALA3:HN","1:ALA3:Hα"),2)
]

if dups!=expected_dup:
    raise SystemExit("[FAIL] duplicate source structure differs")

for compound,(table,page,nexp,zexp,nzexp) in SPEC.items():
    if zexp==0 or nzexp==0:
        raise SystemExit("[FAIL] completeness semantic invariant failed")

print("[PASS] duplicate source restraint preserved")
print("[PASS] every source table contains zero and nonzero violation rows")
print("[PASS] tables support complete distance-restraint inventory interpretation")
print("[PASS] Low/Upp remain analysis targets; Calc/Viol remain provenance only")


print("===== 6. WRITE INDEPENDENT CLOSURE =====")

OUT.mkdir(parents=True,exist_ok=False)

authority=set(expected_src)
authority.add(SRC_FREEZE.resolve())

inventory=[]

for p in sorted(authority,key=str):
    inventory.append({
        "path":rel(p),
        "sha256":sha(p),
        "bytes":str(p.stat().st_size),
    })

with INVENTORY.open("w",encoding="utf-8",newline="") as f:
    w=csv.DictWriter(
        f,
        fieldnames=["path","sha256","bytes"],
        delimiter="\t",
        lineterminator="\n",
    )
    w.writeheader()
    w.writerows(inventory)

print("authority inventory rows =",len(inventory))
print("authority inventory SHA256 =",sha(INVENTORY))

if len(inventory)!=7:
    raise SystemExit("[FAIL] authority inventory !=7")


REPORT.write_text(
"""# Tier-A exact152 ROE source-target final closure v1

STATUS:
SCIENTIFICALLY CLOSED BY INDEPENDENT SOURCE RECONSTRUCTION.

Source:
JACS2006 Supporting Information, exact Tables 4, 7, 10, 13, 16, 19 and 22.

Independent restraint counts:
- JACS1 =25
- JACS2 =20
- JACS3 =26
- JACS4 =20
- JACS5 =21
- JACS6 =19
- JACS7 =21
- total =152

Semantic closure:
- the seven tables are treated as complete distance-restraint inventories;
- every table contains both zero-violation and nonzero-violation rows;
- Low/Upp are frozen experimental analysis bounds;
- source Calc./Viol. are retained only for source provenance;
- source calculated distances use r^-3 averaging;
- no restraint has been deduplicated;
- the duplicated JACS1 ALA3:HN--ALA3:Halpha endpoint pair remains as two distinct source rows.

Independent reconstruction:
- original SI SHA verified;
- Tier-A precommit exact10 lineage rehashed;
- source-target exact6 lineage rehashed;
- exact152 rows reconstructed independently from source pages;
- all frozen fields reproduce the independent source reconstruction exactly.

Boundary:
- endpoint labels remain source labels;
- production atom/pseudoatom mapping is still pending;
- Cbeta/CN must not be interpreted as literal production atoms without a separately frozen mapping contract;
- no topology generated;
- no cyclic-peptide MD run;
- no M4 modification;
- no observable threshold changed.

AUTHORIZED NEXT:
determine and freeze the source-label to production atom/pseudoatom mapping before topology/trajectory analysis.
""",
encoding="utf-8",
)

print("closure report SHA256 =",sha(REPORT))

members=set(authority)
members.update({
    Path(__file__).resolve(),
    INVENTORY.resolve(),
    REPORT.resolve(),
})

print("final closure entries =",len(members))

if len(members)!=10:
    raise SystemExit("[FAIL] final closure entries !=10")

FREEZE.write_text(
    "\n".join(
        sha(p)+"  "+rel(p)
        for p in sorted(members,key=str)
    )+"\n",
    encoding="utf-8",
)

rehash_freeze(FREEZE,10)

print("final closure freeze SHA256 =",sha(FREEZE))


print("===== 7. FINAL SCIENTIFIC STATE =====")

if {p.name for p in OUT.iterdir() if p.is_file()}!={
    INVENTORY.name,
    REPORT.name,
    FREEZE.name,
}:
    raise SystemExit("[FAIL] 16h !=exact3 files")

print("[PASS] TIER-A EXACT152 ROE SOURCE TARGETS SCIENTIFICALLY CLOSED")
print("[PASS] exact152 independently reconstructed from original SI")
print("[PASS] per-peptide counts =25/20/26/20/21/19/21")
print("[PASS] Low/Upp target semantics closed")
print("[PASS] duplicate source restraint preserved")
print("[PASS] atom/pseudoatom mapping remains intentionally pending")
print("[PASS] no topology / MD / M4 modification")
print("[AUTHORIZED-NEXT] freeze source-label -> production atom/pseudoatom mapping")

print("401MK script SHA256 =",sha(Path(__file__)))
print("===== 401MK-TIERA-EXACT152-ROE-SOURCE-TARGET-INDEPENDENT-CLOSURE END =====")
