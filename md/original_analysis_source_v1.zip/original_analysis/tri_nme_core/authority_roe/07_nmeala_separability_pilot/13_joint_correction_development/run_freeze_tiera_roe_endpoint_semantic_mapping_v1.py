from pathlib import Path
from collections import Counter
import csv, hashlib, os

ROOT=Path("/mnt/lab/zn/mem-perm/P0_starter_v1")
DEV=ROOT/"07_nmeala_separability_pilot"/"13_joint_correction_development"

MAIN=DEV/"16_post_m4_cyclic_transfer_source_acquisition"/"raw_sources"/"chatterjee2006.pdf"
SI=DEV/"16_post_m4_cyclic_transfer_source_acquisition"/"raw_sources"/"ja063123d_si_001.pdf"

CLOSE=DEV/"16h_post_m4_cyclic_transfer_tiera_roe_source_target_closure"/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_SOURCE_TARGET_FINAL_CLOSURE_FREEZE_v1.sha256"

TARGET=DEV/"16g_post_m4_cyclic_transfer_tiera_roe_source_targets"/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_EXACT152_ROE_DISTANCE_RESTRAINTS_v1.tsv"

OUT=DEV/"16i_post_m4_cyclic_transfer_tiera_roe_endpoint_mapping"
MAP=OUT/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_ENDPOINT_SEMANTIC_MAPPING_v1.tsv"
CONTRACT=OUT/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_ENDPOINT_MAPPING_CONTRACT_v1.md"
FREEZE=OUT/"NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_ENDPOINT_MAPPING_FREEZE_v1.sha256"

EXP={
 MAIN:"b350b1b6451be610667260d32068be65dee07d9c6ea30f6f190e64fda59a8a82",
 SI:"a26b8b3d90c74775fa06fbf0efaecf4cffaa796fff3a04c773daf98810f23728",
 CLOSE:"88ee6f66efcfc3993573629715491df7ee40d668ddee97c789499d007c0b70e1",
 TARGET:"d2c74165aa896fcc5a6547d75c83d3a869b2b59b13e586569e5d042b7c3f21dd",
}

def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""):
            h.update(b)
    return h.hexdigest()

def rel(p):
    return str(p.resolve().relative_to(ROOT))

print("===== 401ML TIER-A ROE ENDPOINT SEMANTIC MAPPING =====")
print("CONDA_DEFAULT_ENV =",os.environ.get("CONDA_DEFAULT_ENV"))
print("PYTHONPATH =",os.environ.get("PYTHONPATH"))

if os.environ.get("CONDA_DEFAULT_ENV")!="nme-torsion-p0":
    raise SystemExit("[FAIL] wrong environment")
if os.environ.get("PYTHONPATH") is not None:
    raise SystemExit("[FAIL] PYTHONPATH must be unset")
if OUT.exists():
    raise SystemExit("[FAIL] 16i already exists")

print("===== 1. VERIFY CLOSED AUTHORITIES =====")
for p,e in EXP.items():
    if not p.is_file():
        raise SystemExit("[FAIL] missing authority: "+str(p))
    a=sha(p)
    print(p.name,"expected =",e)
    print(p.name,"actual   =",a)
    if a!=e:
        raise SystemExit("[FAIL] SHA mismatch: "+p.name)

with TARGET.open("r",encoding="utf-8",newline="") as f:
    rows=list(csv.DictReader(f,delimiter="\t"))

if len(rows)!=152:
    raise SystemExit("[FAIL] target rows !=152")

labels=Counter()

for r in rows:
    for key in ("source_endpoint_1","source_endpoint_2"):
        labels[r[key].rsplit(":",1)[1]]+=1

print("endpoint labels =",dict(sorted(labels.items())))

if labels!=Counter({"Cβ":61,"CN":44,"HN":95,"Hα":104}):
    raise SystemExit("[FAIL] endpoint-label surface differs")

same_cb_ha=[]

for r in rows:
    a=r["source_endpoint_1"]
    b=r["source_endpoint_2"]

    if a.endswith(":Cβ") and b.endswith(":Hα"):
        if a.rsplit(":",1)[0]==b.rsplit(":",1)[0]:
            same_cb_ha.append(float(r["source_rMD_calc_rminus3_A"]))

print("same-residue Cbeta-Halpha source Calc rows =",len(same_cb_ha))
print("same-residue Cbeta-Halpha Calc range =",min(same_cb_ha),max(same_cb_ha))

if len(same_cb_ha)<20:
    raise SystemExit("[FAIL] insufficient Cbeta-Halpha proxy fingerprint")

print("[PASS] exact152 endpoint semantics recovered")

print("===== 2. WRITE CHEMICAL COORDINATE MAPPING =====")

mapping=[
 {
  "source_label":"Hα",
  "experimental_resonance":"ALPHA_PROTON",
  "analysis_coordinate":"ALPHA_HYDROGEN",
  "group_rule":"SINGLE_ATOM",
  "topology_binding_status":"BIND_AFTER_TOPOLOGY_GENERATION",
 },
 {
  "source_label":"HN",
  "experimental_resonance":"AMIDE_PROTON",
  "analysis_coordinate":"AMIDE_HYDROGEN",
  "group_rule":"SINGLE_ATOM",
  "topology_binding_status":"BIND_AFTER_TOPOLOGY_GENERATION",
 },
 {
  "source_label":"Cβ",
  "experimental_resonance":"ALA_HBETA_METHYL_RESONANCE",
  "analysis_coordinate":"ALA_SIDECHAIN_METHYL_CARBON_PROXY",
  "group_rule":"SINGLE_CARBON_PROXY_NOT_EXPLICIT_METHYL_H_GROUP",
  "topology_binding_status":"BIND_AFTER_TOPOLOGY_GENERATION",
 },
 {
  "source_label":"CN",
  "experimental_resonance":"N_METHYL_PROTON_RESONANCE",
  "analysis_coordinate":"N_METHYL_CARBON_PROXY",
  "group_rule":"SINGLE_CARBON_PROXY_NOT_EXPLICIT_METHYL_H_GROUP",
  "topology_binding_status":"BIND_AFTER_TOPOLOGY_GENERATION",
 },
]

OUT.mkdir(parents=True,exist_ok=False)

with MAP.open("w",encoding="utf-8",newline="") as f:
    w=csv.DictWriter(f,fieldnames=list(mapping[0]),delimiter="\t",lineterminator="\n")
    w.writeheader()
    w.writerows(mapping)

print("mapping rows =",len(mapping))
print("mapping SHA256 =",sha(MAP))

CONTRACT.write_text(
"""# Tier-A ROE endpoint semantic mapping contract v1

STATUS:
FROZEN BEFORE TIER-A PRODUCTION TOPOLOGY GENERATION.

Published experimental origin:
ROESY cross-peak volumes were converted to proton-proton distances;
Ala Halpha-Hbeta 2.19 A was the reference;
Low/Upp were formed from the experimental distance with +/-10%.

Published computational comparison:
The SI restraint tables operationally label the methyl endpoints Cbeta and CN.
The published trajectory Calc. values are reported with <r^-3> averaging.

Frozen reproduction semantics:
Halpha -> alpha hydrogen coordinate.
HN -> amide hydrogen coordinate.
Cbeta -> alanine side-chain methyl carbon coordinate proxy.
CN -> N-methyl carbon coordinate proxy.

For every restraint, the trajectory observable is:
r_eff = <r(t)^-3>^(-1/3).

No explicit three-methyl-proton group averaging is substituted for Cbeta or CN.
No additional pseudoatom-distance correction is added.
Low/Upp remain the frozen source bounds.
Source Calc./Viol. are not CONTROL/TEST targets.

Interpretive boundary:
Cbeta/CN are computational coordinate proxies for methyl ROE endpoints.
This does not mean carbon atoms generate the experimental ROE.

Topology boundary:
No concrete Amber atom name/index is frozen here because Tier-A production
topologies do not yet exist. Each generated topology must later bind these
four chemical coordinate semantics to exactly one corresponding atom and
pass an independent topology-binding audit before trajectory analysis.

No topology, MD, M4 refit, threshold change, or source-target modification occurred.
""",
encoding="utf-8",
)

print("contract SHA256 =",sha(CONTRACT))

members={
    Path(__file__).resolve(),
    MAIN.resolve(),
    SI.resolve(),
    CLOSE.resolve(),
    TARGET.resolve(),
    MAP.resolve(),
    CONTRACT.resolve(),
}

if len(members)!=7:
    raise SystemExit("[FAIL] freeze members !=7")

FREEZE.write_text(
    "\n".join(sha(p)+"  "+rel(p) for p in sorted(members,key=str))+"\n",
    encoding="utf-8",
)

print("freeze entries =",len(members))
print("freeze SHA256 =",sha(FREEZE))

print("===== 3. FINAL STATE =====")
print("[PASS] Tier-A ROE chemical endpoint semantics FROZEN")
print("[PASS] Halpha/HN = direct proton coordinates")
print("[PASS] Cbeta/CN = published carbon-coordinate proxies")
print("[PASS] all endpoints use trajectory <r^-3> averaging")
print("[PASS] no methyl-H reinterpretation or extra pseudoatom correction")
print("[PASS] concrete topology atom binding remains pending")
print("[PASS] no topology / MD / M4 modification")
print("[AUTHORIZED-NEXT] freeze Tier-A molecular/topology construction protocol")
print("401ML script SHA256 =",sha(Path(__file__)))
print("===== 401ML-TIERA-ROE-ENDPOINT-SEMANTIC-MAPPING END =====")
