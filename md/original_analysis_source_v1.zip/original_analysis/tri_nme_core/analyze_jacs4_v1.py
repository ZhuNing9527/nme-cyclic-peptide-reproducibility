#!/usr/bin/env python3
"""CPU-only analysis of the four closed JACS4 runs using frozen observables."""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile
import time
import traceback

import numpy as np
import closed_inputs_v1 as closed
import frozen_math_v1 as f
import graph_binding_v1 as graph


VERSION = "402EC_JACS4_FROZEN_SAMPLING_M123_ROE_V1"
PACKAGE = Path(__file__).resolve().parent
BENCHMARK = "TIERA_JACS4"
DEV, PROD, CX = closed.DEV, closed.PROD, closed.CX
ROWS = tuple(closed.ROW_NAMES[i] for i in range(13, 17))
BUILD = DEV / "20r_post_m4_dmso_solvation_and_short_md_v1/systems/TIERA_JACS4/build"
ENDPOINT = DEV / "16f_post_m4_cyclic_transfer_tiera_analysis_precommit"
REFERENCE = DEV / "16b_post_m4_cyclic_transfer_benchmark_extraction/NMEALA_POSTM4_CYCLIC_TRANSFER_EXPERIMENTAL_DIHEDRAL_REFERENCE_v1.tsv"
TARGETS = ENDPOINT / "NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_EXACT7_ANALYSIS_TARGETS_v1.tsv"
ENDPOINT_FREEZE = ENDPOINT / "NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ANALYSIS_PRECOMMIT_FREEZE_v1.sha256"
OBSERVABLES = ENDPOINT / "NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_OBSERVABLE_DEFINITIONS_v1.tsv"
ROE_TARGET_DIR = DEV / "16g_post_m4_cyclic_transfer_tiera_roe_source_targets"
ROE_TARGET = ROE_TARGET_DIR / "NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_EXACT152_ROE_DISTANCE_RESTRAINTS_v1.tsv"
ROE_FREEZE = ROE_TARGET_DIR / "NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_SOURCE_TARGET_FREEZE_v1.sha256"
ROE_CLOSURE = DEV / "16h_post_m4_cyclic_transfer_tiera_roe_source_target_closure/NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_SOURCE_TARGET_FINAL_CLOSURE_FREEZE_v1.sha256"
ROE_MAPPING_DIR = DEV / "16i_post_m4_cyclic_transfer_tiera_roe_endpoint_mapping"
ROE_MAPPING = ROE_MAPPING_DIR / "NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_ENDPOINT_SEMANTIC_MAPPING_v1.tsv"
ROE_MAPPING_FREEZE = ROE_MAPPING_DIR / "NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_ENDPOINT_MAPPING_FREEZE_v1.sha256"
CAPTURE_KEYS = ("capture_1ps_iteration", "capture_1ps_lambda1_replica", "capture_1ps_positions",
    "capture_1ps_box", "capture_1ps_mapping", "capture_1ps_energy", "capture_10ps_iteration",
    "capture_10ps_positions", "capture_10ps_box", "capture_10ps_mapping")
AUDIT_KEYS = ("iteration", "before", "after", "energy", "proposed", "accepted")
M123_METRICS = ("M1_exact_pattern_occupancy", "M2_joint_major_basin_occupancy", "M3_crms_mean_deg")
require = f.require


def asset(raw):
    raw = Path(raw)
    require(not raw.is_absolute() and ".." not in raw.parts, "UNSAFE_PACKAGE_PATH")
    path = PACKAGE / raw
    require(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(PACKAGE), "PACKAGE_ASSET_MISSING")
    return path


def read_table(path):
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def verify_package():
    expected = json.loads(asset("PACKAGE_PINS_v1.json").read_text())
    for raw, digest in expected.items():
        require(f.sha(asset(raw)) == digest, "PACKAGE_SHA_MISMATCH: " + raw)
    return expected


class Reader:
    def __init__(self, root):
        self.metadata = closed.Collector(root)
        self.root = self.metadata.root
        self.snapshots = {}
        self.digests = {}

    def chunk_path(self, raw):
        raw = Path(raw)
        require(not raw.is_absolute() and ".." not in raw.parts and raw.suffix == ".npz", "UNSAFE_ARRAY_PATH")
        require(any(raw.is_relative_to(PROD / row / "chunks") for row in ROWS), "ARRAY_OUTSIDE_SELECTED_CLOSED_ROWS")
        path = self.metadata.path(raw)
        require(path.is_file() and not path.is_symlink(), "MISSING_COMMITTED_ARRAY: " + str(raw))
        st = path.stat()
        require(st.st_size > 0, "EMPTY_COMMITTED_ARRAY")
        signature = (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns)
        if str(raw) in self.snapshots:
            require(self.snapshots[str(raw)] == signature, "ARRAY_CHANGED: " + str(raw))
        else:
            self.snapshots[str(raw)] = signature
        return path

    def digest(self, raw, expected):
        path = self.chunk_path(raw)
        raw = str(raw)
        if raw not in self.digests:
            self.digests[raw] = f.sha(path)
        require(self.digests[raw] == expected, "COMMITTED_ARRAY_SHA_MISMATCH: " + raw)
        self.chunk_path(raw)

    def arrays(self, raw, keys):
        with np.load(self.chunk_path(raw), allow_pickle=False) as archive:
            require(all(k in archive.files for k in keys), "MISSING_CAPTURE_OR_AUDIT_FIELDS")
            out = {key: archive[key] for key in keys}
        self.chunk_path(raw)
        return out

    def check_unchanged(self):
        self.metadata.assert_unchanged()
        for raw in list(self.snapshots):
            self.chunk_path(raw)


def load_definitions(protocol, parent_freeze, benchmark=BENCHMARK):
    authority = PACKAGE / "authority"
    ef = asset(Path("authority") / ENDPOINT_FREEZE)
    require(parent_freeze[ENDPOINT_FREEZE] == f.sha(ef) == "a23bc0eb9ccbf024ad86af04c9115bfcd48b687d2e19f560bbb2b2712a0f17e4", "M123_PARENT_PIN")
    for raw, expected in closed.freeze_entries(ef.read_text()).items():
        require(f.sha(asset(Path("authority") / raw)) == expected, "M123_DIRECT_MEMBER_SHA")
    refs = [r for r in read_table(authority / REFERENCE) if r["benchmark_id"] == benchmark]
    refs.sort(key=lambda r: int(r["residue_index"]))
    require(len(refs) == 5 and [int(r["residue_index"]) for r in refs] == [1,2,3,4,5], "FIVE_SOURCE_RESIDUES")
    require(all(r["reference_trust_status"] == "SOURCE_TRUSTED_REFERENCE" for r in refs), "SOURCE_REFERENCE_TRUST")
    target = [r for r in read_table(authority / TARGETS) if r["benchmark_id"] == benchmark]
    require(len(target) == 1 and target[0]["major_cis_bonds"] == "NONE" and target[0]["major_cis_count"] == "0", "FROZEN_ALL_TRANS_TARGET")
    require(all(r["omega_state"] == "t" for r in refs), "SOURCE_OMEGA_PATTERN")
    metrics = {r["metric_id"]: r for r in read_table(authority / OBSERVABLES)}
    require(metrics["M2_JOINT_MAJOR_BASIN_OCCUPANCY"]["priority"] == "PRIMARY", "PRIMARY_ENDPOINT_CHANGED")
    reference = np.array([[float(r["phi_deg"]), float(r["psi_deg"])] for r in refs])
    classes = np.full(5, 2, dtype=np.uint8)
    # Verify the complete original source/mapping freeze chains before filtering.
    roe_spec = protocol["ROE_secondary_analysis"]
    require(parent_freeze[ROE_CLOSURE] == roe_spec["source_target_freeze_sha256"]
            == "88ee6f66efcfc3993573629715491df7ee40d668ddee97c789499d007c0b70e1", "ROE_TARGET_PARENT_PIN")
    require(parent_freeze[ROE_MAPPING_FREEZE] == roe_spec["endpoint_mapping_freeze_sha256"]
            == "1f9035a75bbac1a691a971a02615967da1b067be7d64a1dd6af5af4779f36053", "ROE_MAPPING_PARENT_PIN")
    for raw in (ROE_CLOSURE, ROE_MAPPING_FREEZE, ROE_FREEZE):
        frozen = asset(Path("authority_roe") / raw)
        require(raw not in parent_freeze or f.sha(frozen) == parent_freeze[raw], "ROE_FREEZE_ANCHOR")
        for child, expected in closed.freeze_entries(frozen.read_text()).items():
            require(f.sha(asset(Path("authority_roe") / child)) == expected, "ROE_DIRECT_MEMBER_SHA")
    mapping = {r["source_label"]: r for r in read_table(asset(Path("authority_roe") / ROE_MAPPING))}
    rules = {"Hα":("ALPHA_HYDROGEN","SINGLE_ATOM"), "HN":("AMIDE_HYDROGEN","SINGLE_ATOM"),
        "Cβ":("ALA_SIDECHAIN_METHYL_CARBON_PROXY","SINGLE_CARBON_PROXY_NOT_EXPLICIT_METHYL_H_GROUP"),
        "CN":("N_METHYL_CARBON_PROXY","SINGLE_CARBON_PROXY_NOT_EXPLICIT_METHYL_H_GROUP")}
    require(set(mapping) == set(rules), "FOUR_FROZEN_ROE_SEMANTICS")
    for label, rule in rules.items():
        require((mapping[label]["analysis_coordinate"], mapping[label]["group_rule"]) == rule, "ROE_COORDINATE_RULE_CHANGED")
    all_roe = read_table(asset(Path("authority_roe") / ROE_TARGET))
    require(len(all_roe) == 152, "EXACT152_SOURCE_ROWS")
    roe_rows = [r for r in all_roe if r["benchmark_id"] == benchmark]
    expected_count, compound, table, page = {"TIERA_JACS3":(26,"3","10","15"), "TIERA_JACS4":(20,"4","13","18")}[benchmark]
    require(len(roe_rows) == expected_count and [int(r["source_row_rank"]) for r in roe_rows] == list(range(1, expected_count+1)), "ALL_ROE_ROWS_IN_SOURCE_ORDER")
    require(len({r["restraint_id"] for r in roe_rows}) == expected_count, "UNIQUE_ROE_IDENTIFIERS")
    require(all(r["source_compound"] == compound and r["source_table"] == table and r["source_pdf_page"] == page
                and r["analysis_target"] == "LOWER_UPPER_BOUNDS_ONLY" for r in roe_rows), "ROE_SOURCE_IDENTITY")
    lower = np.array([float(r["lower_bound_A"]) for r in roe_rows])
    upper = np.array([float(r["upper_bound_A"]) for r in roe_rows])
    require(np.isfinite(lower).all() and np.isfinite(upper).all() and np.all((lower > 0)&(upper >= lower)), "SOURCE_BOUNDS")
    return {"references":refs, "target":target[0], "reference_angles_deg":reference, "target_classes":classes,
            "roe_rows":roe_rows, "lower_A":lower, "upper_A":upper, "semantic_mapping":mapping}


def bind_static(geometry, report, control, test, definition):
    f.validate_geometry(geometry, report["solute_atoms"])
    methylated = {int(r["residue_index"]) for r in definition["references"] if r["n_methylated_at_residue"] == "True"}
    binding = graph.bind_both_systems(control, test, geometry, methylated, report["solute_atoms"], report["total_atoms"])
    pairs = np.array([[f.resolve_endpoint(r["source_endpoint_1"], binding), f.resolve_endpoint(r["source_endpoint_2"], binding)] for r in definition["roe_rows"]], dtype=np.int64)
    require(pairs.shape == (len(definition["roe_rows"]),2) and np.all(pairs[:,0] != pairs[:,1]), "ROE_PAIR_BINDING")
    binding.update(restraint_count=len(pairs), restraint_atom_pairs_0based=pairs.tolist(),
                   bound_restraint_ids=[r["restraint_id"] for r in definition["roe_rows"]])
    return binding, pairs


def preflight(reader):
    pins = json.loads(asset("RUNTIME_INPUT_PINS_v1.json").read_text())
    for raw, expected in pins.items():
        reader.metadata.add(raw, expected)
    meta = reader.metadata
    protocol = meta.json(CX / "402CX_v2_FINAL_PRODUCTION_PROTOCOL_v1.json")
    require(protocol["run_schedule"]["per_run_equilibration_ns"] == 10 and protocol["run_schedule"]["per_run_recorded_production_ns"] == 50
            and protocol["rest2"]["replicas"] == 12 and protocol["rest2"]["primary_analysis_tracks_thermodynamic_state_not_fixed_walker"] is True,
            "PRODUCTION_SAMPLING_PROTOCOL_CHANGED")
    require(protocol["primary_endpoint"]["metric"] == "M2_JOINT_MAJOR_BASIN_OCCUPANCY", "PRIMARY_ENDPOINT")
    parent_freeze = closed.freeze_entries(meta.add(CX / "402CX_v2_FINAL_PRODUCTION_PROTOCOL_FREEZE_v1.sha256").decode())
    starts = list(csv.DictReader(io.StringIO(meta.add(CX / "402CX_v2_PRODUCTION_STARTS_AND_SEEDS_v1.tsv").decode()), delimiter="\t"))
    require(len(starts) == 20, "ORIGINAL_STARTS_COUNT")
    contracts, manifests = {}, {}
    for name in ROWS:
        row = PROD / name
        contract, result = [meta.json(row / f"FORMAL_RUN_{kind}_v1.json") for kind in ("CONTRACT","RESULT")]
        index = int(name[3:5]);arm,rep = name.rsplit("_",2)[-2:]
        for record in (contract,result):
            require((record["row_index"],record["benchmark"],record["arm"],record["replicate"]) == (index,BENCHMARK,arm,rep), "ROW_IDENTITY")
        require(result["status"] == "FORMAL_EXACT20_RUN_COMPLETE" and result["final_iteration"] == 600000
                and result["total_ns_per_replica"] == 60 and result["recorded_production_ns_per_replica"] == 50
                and result["final_context_steps"] == 720000000, "JACS4_RUN_NOT_CLOSED")
        for key in ("initial_velocity_seed","integrator_seed","exchange_seed"):
            require(contract[key] == result[key] == int(starts[index-1][key]), "FROZEN_SEED_MISMATCH")
        log = meta.add(PROD / "_launch_logs" / (name+".log")).decode()
        import re
        commits=[(int(a),int(b)) for a,b in re.findall(r"\[402EC FORMAL COMMIT\] chunk=(\d+)/60 iteration=(\d+)",log)]
        require(commits == [(i,i*10000) for i in range(1,61)] and log.count("===== 402EC FORMAL EXACT20 WORKER END =====") == 1, "CLOSED_LOG_SEQUENCE")
        for raw, expected in closed.freeze_entries(meta.add(row / "FORMAL_RUN_FINAL_FREEZE_v1.sha256").decode()).items():
            require(str(raw) in pins and pins[str(raw)] == expected, "REVIEWED_FINAL_FREEZE_MEMBER")
            meta.add(raw, expected)
        manifest=meta.json(row / "FORMAL_RUN_STORAGE_MANIFEST_v1.json")
        require(manifest["status"] == "FORMAL_STORAGE_COMPLETE" and manifest["record_count"] == 60
                and [r["chunk_index"] for r in manifest["records"]] == list(range(1,61)), "MANIFEST_CHUNKS")
        for i, record in enumerate(manifest["records"],1):
            phase="equilibration" if i <= 10 else "production"
            require(record["phase"] == phase, "MANIFEST_PHASE")
            receipt_path=row / "checkpoints" / f"ITER_{i*10000:06d}" / "CHECKPOINT_RECEIPT_v1.json"
            require(Path(record["checkpoint_receipt_path"]) == receipt_path, "RECEIPT_PATH")
            receipt=meta.json(receipt_path,record["checkpoint_receipt_sha256"])
            require(receipt["global_iteration"] == i*10000 and receipt["context_steps"] == i*12000000
                    and receipt["phase"] == phase, "RECEIPT_COUNTERS")
        contracts[name],manifests[name]=contract,manifest
    for rep in ("R1","R2"):
        pair=[contracts[name] for name in ROWS if name.endswith(rep)]
        for key in ("formal_start_sha256","initial_velocity_seed","integrator_seed","exchange_seed"):
            require(pair[0][key] == pair[1][key], "PAIRED_DESIGN")
    require(contracts[ROWS[0]]["exchange_seed"] != contracts[ROWS[2]]["exchange_seed"], "DISTINCT_REPEAT_SEEDS")
    definition=load_definitions(protocol,parent_freeze)
    geometry=meta.json(BUILD / "SOLUTE_GEOMETRY_v1.json")
    report=meta.json(BUILD / "BUILD_REPORT_v1.json")
    require(report["benchmark_id"] == BENCHMARK and report["solute_atoms"] == 59 and report["total_atoms"] == 4939
            and report["m4_physical_sites"] == 3, "REVIEWED_JACS4_BUILD_IDENTITY")
    binding,pairs=bind_static(geometry,report,meta.add(BUILD / "CONTROL.xml"),meta.add(BUILD / "TEST.xml"),definition)
    require(binding == json.loads(asset("REVIEWED_TOPOLOGY_BINDING_v1.json").read_text()), "RUNTIME_BINDING_DIFFERS_FROM_REVIEWED_STATIC_MAPPING")
    definition.update(geometry=geometry,nsolute=report["solute_atoms"],binding=binding,pairs=pairs)
    print("[PASS] four JACS4 closed lifecycles, source hashes, paired seeds and committed storage metadata",flush=True)
    print("[PASS] frozen 30-degree pattern / 45-degree backbone rule; all 20 source ROE restraints bound",flush=True)
    return protocol,contracts,manifests,definition


def chunk_arrays(reader,name,record):
    i=record["chunk_index"];phase="equilibration" if i <= 10 else "production"
    row=PROD / name
    expected={"capture":row / "chunks" / f"CAPTURE_{i:02d}_{phase}_v1.npz",
              "exchange_audit":row / "chunks" / f"EXCHANGE_AUDIT_{i:02d}_{phase}_v1.npz"}
    for kind,raw in expected.items():
        require(Path(record[kind+"_path"]) == raw,"COMMITTED_CHUNK_PATH")
        reader.digest(raw,record[kind+"_sha256"])
    if i <= 10:return None,None
    cap=reader.arrays(expected["capture"],CAPTURE_KEYS+("chunk_index","phase","global_iteration_start_exclusive","global_iteration_end_inclusive"))
    audit=reader.arrays(expected["exchange_audit"],AUDIT_KEYS)
    scalar=lambda k:np.asarray(cap[k]).item()
    require(scalar("chunk_index") == i and scalar("phase") == "production"
            and scalar("global_iteration_start_exclusive") == (i-1)*10000
            and scalar("global_iteration_end_inclusive") == i*10000,"CAPTURE_GLOBAL_COUNTERS")
    return cap,audit


def summarize_roe_blocks(name,chunk_moments,definition):
    lower,upper=definition["lower_A"],definition["upper_A"]
    moment=f.combine_moments(chunk_moments,np.full(50,1000))
    summary=f.evaluate_moments(moment,lower,upper)[0]
    summary.update(row=name,arm=name.rsplit("_",2)[1],replicate=name.rsplit("_",1)[1],frames=50000,recovery_boundary_global_iteration=None)
    blocks=[];moments=[]
    for i in range(5):
        bm=f.combine_moments(chunk_moments[i*10:(i+1)*10],np.full(10,1000))
        b=f.evaluate_moments(bm,lower,upper)[0]
        b.update(row=name,block_index=i+1,production_start_ns_exclusive=i*10,production_end_ns_inclusive=(i+1)*10,
                 frames=10000,independent_statistical_replicate=False)
        blocks.append(b);moments.append(bm)
    return summary,moment,blocks,moments


def analyze_row(reader,name,manifest,definition):
    geometry=definition["geometry"];nsolute=definition["nsolute"]
    sites={r["residue_name"]:geometry[int(r["residue_index"])-1]["omega_atoms"] for r in definition["references"] if r["n_methylated_at_residue"] == "True"}
    trackers={site:f.Crossings() for site in sites}
    counts={k:np.zeros(11,dtype=np.int64 if k in ("proposed","accepted") else float) for k in ("proposed","accepted","expected_proposed_sum","expected_all_sum")}
    contributions=np.zeros(12,dtype=np.int64);visits=np.zeros((12,12),dtype=np.int64)
    mappings=[];previous=None
    parts={k:[] for k in ("M1","M2","crms_deg","omega_class","iteration","phi_deg","psi_deg","omega_deg")}
    means=[];minimum=[];maximum=[];closure=[];direct=[]
    for record in manifest["records"]:
        cap,audit=chunk_arrays(reader,name,record)
        i=record["chunk_index"]
        if cap is None:continue
        start,end=(i-1)*10000,i*10000
        stats=f.validate_audit(audit,start,end)
        f.validate_capture(cap,audit,start,end,nsolute)
        if previous is not None:require(np.array_equal(previous,audit["before"][0]),"INTERCHUNK_MAPPING_HANDOFF")
        previous=audit["after"][-1].copy()
        mappings.append(audit["after"].astype(np.uint8))
        for k in counts:counts[k]+=stats[k]
        contributions+=np.bincount(cap["capture_1ps_lambda1_replica"],minlength=12)
        for w in range(12):visits[w]+=np.bincount(audit["after"][:,w],minlength=12)
        pos,box=cap["capture_1ps_positions"],cap["capture_1ps_box"]
        angles={kind:np.column_stack([f.omega_degrees(pos,box,g[kind+"_atoms"]) for g in geometry]) for kind in ("phi","psi","omega")}
        obs=f.calculate_observables(angles["phi"],angles["psi"],angles["omega"],definition["reference_angles_deg"],definition["target_classes"])
        for key in ("M1","M2","crms_deg","omega_class"):parts[key].append(obs[key])
        parts["iteration"].append(cap["capture_1ps_iteration"])
        for kind in angles:parts[kind+"_deg"].append(angles[kind])
        for site,atoms in sites.items():
            labels=f.basin_labels(f.omega_degrees(cap["capture_10ps_positions"],cap["capture_10ps_box"],atoms))
            trackers[site].update(labels,cap["capture_10ps_mapping"])
        distances,checks=graph.intramolecular_distances_A(pos,box,definition["pairs"],definition["binding"])
        moments=distances**-3
        require(np.isfinite(moments).all() and np.all(moments > 0),"INVALID_ROE_MOMENTS")
        means.append(np.mean(moments,axis=0));minimum.append(distances.min(axis=0));maximum.append(distances.max(axis=0))
        closure.append(checks["unwrap_closure_max_residual_nm"]);direct.append(checks["direct_minimum_image_distance_max_residual_nm"])
        if i%10 == 0:print(f"[PROGRESS] {name}: {i-10}/50 production chunks; sampling + M123 + ROE",flush=True)
    series={k:np.concatenate(v) for k,v in parts.items()}
    require(np.array_equal(series["iteration"],np.arange(100010,600001,10)),"EXACT_PHYSICAL_FRAME_GRID")
    summary=f.summarize_series(series)
    require(summary["frames"] == 50000 and contributions.sum() == 50000 and np.all(visits.sum(axis=1) == 500000),"PRODUCTION_FRAME_COUNTS")
    summary.update(row=name,benchmark=BENCHMARK,arm=name.rsplit("_",2)[1],replicate=name.rsplit("_",1)[1],
                   recovery_boundary_global_iteration=None,original_reporter_tail_read=False,physical_state_index=0,independent_frame_p_value=None)
    summary["all_five_omega_site_occupancies"]=[]
    for i in range(5):
        oc=np.bincount(series["omega_class"][:,i],minlength=3)
        summary["all_five_omega_site_occupancies"].append({"residue_index":i+1,"order":["intermediate","cis","trans"],
            "counts":oc.tolist(),"fractions":(oc/50000).tolist(),"window_deg":30.0,"target_class":"trans"})
    if summary["M2_major_frames"] in (0,50000):
        summary["constant_indicator_warning"]="Finite constant M2 indicator; not exact equilibrium probability or zero uncertainty."
    means=np.asarray(means)
    require(means.shape == (50,20),"ALL_50_CHUNKS_AND_20_ROE_RESTRAINTS")
    roe,moment,roe_blocks,block_moments=summarize_roe_blocks(name,means,definition)
    require(np.all(counts["proposed"] > 0),"NO_EDGE_PROPOSALS")
    fractions=contributions/50000
    limitations=[]
    if np.any(np.count_nonzero(visits,axis=1) < 12):limitations.append("Not every walker visited every state; retain all runs and sites.")
    if np.count_nonzero(contributions) < 12:limitations.append("Not every walker contributed lambda=1 frames; retain all runs and sites.")
    for site,tracker in trackers.items():
        if tracker.walker_counts.sum() < 2:limitations.append(site+": fewer than two committed crossings; report sampling limitation without excluding the site.")
    trips=f.count_roundtrips([np.concatenate(mappings)])
    sampling={"row":name,"exchange_events":500000,"lambda1_frames":50000,"all_replica_frames":5000,
        "edge_observed":(counts["accepted"]/counts["proposed"]).tolist(),
        "edge_expected_on_proposed_events":(counts["expected_proposed_sum"]/counts["proposed"]).tolist(),
        "edge_expected_on_all_events":(counts["expected_all_sum"]/500000).tolist(),
        "edge_proposals":counts["proposed"].tolist(),"edge_acceptances":counts["accepted"].tolist(),
        "visitation_counts_by_walker":visits.tolist(),"unique_states_by_walker":np.count_nonzero(visits,axis=1).tolist(),
        "walkers_both_endpoints":int(((visits[:,0]>0)&(visits[:,-1]>0)).sum()),"state_entropy_by_walker":f.norm_entropy(visits).tolist(),
        "roundtrips_by_walker":trips.tolist(),"roundtrips_total":int(trips.sum()),
        "lambda1_counts_by_walker":contributions.tolist(),"lambda1_fraction_by_walker":fractions.tolist(),
        "lambda1_entropy":float(f.norm_entropy(contributions)),"lambda1_walker_inverse_simpson_effective_number":float(1/np.sum(fractions**2)),
        "walker_effective_number_is_NOT_independent_configuration_ESS":True,
        "omega_committed_crossings":{site:t.result() for site,t in trackers.items()},
        "sampling_limitations_descriptive_not_endpoint_filters":limitations,"technical_NC_read":False,
        "cross_stream_max_residual_nm":0.0,"all_60_chunk_hashes_verified":True,"kinetic_rate_interpretation":False}
    roe_observations={"global_start_exclusive":np.arange(100000,600000,10000),"global_end_inclusive":np.arange(110000,600001,10000),
        "frame_count":np.full(50,1000,dtype=np.int64),"mean_rminus3_Aminus3":means,"minimum_distance_A":np.asarray(minimum),
        "maximum_distance_A":np.asarray(maximum),"unwrap_closure_max_residual_nm":np.asarray(closure),
        "direct_minimum_image_distance_max_residual_nm":np.asarray(direct)}
    return {"m123":summary,"series":series,"m123_blocks":f.block_summaries(series,name),"roe":roe,"roe_moment":moment,
            "roe_blocks":roe_blocks,"roe_block_moments":block_moments,"roe_observations":roe_observations,"sampling":sampling}


def aggregate(results,rows=ROWS,benchmark=BENCHMARK):
    arms=[];effects=[]
    for arm in ("CONTROL","TEST"):
        names=[n for n in rows if n.endswith(("_"+arm+"_R1","_"+arm+"_R2"))]
        require(len(names)==2 and names[0].endswith("R1") and names[1].endswith("R2"),"ARM_REPEAT_ORDER")
        summaries=[results[n]["m123"] for n in names]
        require(all(s["frames"] == 50000 for s in summaries),"EQUAL_50000_FRAME_REPEATS")
        record={"benchmark":benchmark,"arm":arm,"frames_per_replicate":50000}
        for metric in M123_METRICS:
            record[metric]=sum(s[metric] for s in summaries)/2
            record[metric+"_R1"]=summaries[0][metric];record[metric+"_R2"]=summaries[1][metric]
            record[metric+"_absolute_R1_R2_difference"]=abs(summaries[0][metric]-summaries[1][metric])
        record["M3_crms_median_deg"]=float(np.median(np.concatenate([results[n]["series"]["crms_deg"] for n in names])))
        record["M3_crms_median_deg_R1"]=summaries[0]["M3_crms_median_deg"]
        record["M3_crms_median_deg_R2"]=summaries[1]["M3_crms_median_deg"]
        record["M3_crms_median_deg_absolute_R1_R2_difference"]=abs(record["M3_crms_median_deg_R1"]-record["M3_crms_median_deg_R2"])
        arms.append(record)
    for level in ("R1","R2","ARM_EQUAL_REPLICATE_ESTIMATOR"):
        if level.startswith("ARM"):
            c,t=arms
        else:
            c=results[next(n for n in rows if n.endswith("CONTROL_"+level))]["m123"]
            t=results[next(n for n in rows if n.endswith("TEST_"+level))]["m123"]
        effects.append({"benchmark":benchmark,"level":level,**{k+"_TEST_minus_CONTROL":t[k]-c[k] for k in M123_METRICS+("M3_crms_median_deg",)}})
    return arms,effects


def aggregate_roe(results,definition,rows=ROWS):
    lower,upper=definition["lower_A"],definition["upper_A"]
    arms=[];effects=[];arm_moments={};blocks=[];arm_records=[]
    for arm in ("CONTROL","TEST"):
        names=[n for n in rows if f"_{arm}_" in n]
        moment=np.mean([results[n]["roe_moment"] for n in names],axis=0)
        record=f.evaluate_moments(moment,lower,upper)[0]
        record.update(arm=arm,level="ARM_EQUAL_REPLICATE_MOMENT",frames_per_replicate=50000)
        for metric in (f.M4,f.M5):
            record[metric+"_R1"]=results[names[0]]["roe"][metric]
            record[metric+"_R2"]=results[names[1]]["roe"][metric]
            record[metric+"_absolute_R1_R2_difference"]=abs(record[metric+"_R1"]-record[metric+"_R2"])
        arms.append(record);arm_moments[arm]=moment
        arm_records.extend(f.restraint_records(definition["roe_rows"],moment,lower,upper,{"arm":arm}))
        for i in range(5):
            bm=np.mean([results[n]["roe_block_moments"][i] for n in names],axis=0)
            b=f.evaluate_moments(bm,lower,upper)[0]
            b.update(arm=arm,block_index=i+1,production_start_ns_exclusive=i*10,production_end_ns_inclusive=(i+1)*10,independent_statistical_replicate=False)
            blocks.append(b)
    for level in ("R1","R2","ARM_EQUAL_REPLICATE_MOMENT"):
        if level.startswith("ARM"):c,t=arms
        else:
            c=results[next(n for n in rows if n.endswith("CONTROL_"+level))]["roe"]
            t=results[next(n for n in rows if n.endswith("TEST_"+level))]["roe"]
        effects.append({"level":level,**{k+"_TEST_minus_CONTROL":t[k]-c[k] for k in (f.M4,f.M5)}})
    cr=f.restraint_records(definition["roe_rows"],arm_moments["CONTROL"],lower,upper,{})
    tr=f.restraint_records(definition["roe_rows"],arm_moments["TEST"],lower,upper,{})
    comparison=[]
    for c,t in zip(cr,tr):
        comparison.append({"restraint_id":c["restraint_id"],"source_endpoint_1":c["source_endpoint_1"],"source_endpoint_2":c["source_endpoint_2"],
            "lower_bound_A":c["lower_bound_A"],"upper_bound_A":c["upper_bound_A"],"CONTROL_r_eff_A":c["r_eff_A"],"TEST_r_eff_A":t["r_eff_A"],
            "CONTROL_satisfied":c["within_source_bounds"],"TEST_satisfied":t["within_source_bounds"],"CONTROL_violation_A":c["absolute_bound_violation_A"],
            "TEST_violation_A":t["absolute_bound_violation_A"],"violation_A_TEST_minus_CONTROL":t["absolute_bound_violation_A"]-c["absolute_bound_violation_A"]})
    return arms,effects,blocks,arm_records,comparison


def export_results(output):
    archive=output / "JACS4_FROZEN_SAMPLING_M123_ROE_RESULTS_v1.tar.gz"
    with tarfile.open(archive,"x:gz",compresslevel=3) as a:
        for p in sorted(output.rglob("*")):
            if p.is_file() and p != archive:a.add(p,arcname=str(p.relative_to(output)),recursive=False)
    print("RESULT_ARCHIVE_SHA256="+f.sha(archive),flush=True)
    print("UPLOAD_THIS_EXACT_FILE="+str(archive),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root",default=str(closed.DEFAULT_ROOT))
    parser.add_argument("--output")
    parser.add_argument("--preflight-only",action="store_true")
    args=parser.parse_args()
    reader=Reader(args.root);output=Path(args.output).absolute() if args.output else None
    own_output=False;start=time.monotonic()
    print("===== JACS4 FROZEN CPU ANALYSIS BEGIN =====",flush=True)
    print("VERSION="+VERSION,flush=True)
    print("MD=False CONTEXT=False GPU=False SAMPLING=True M1=True M2=True M3=True ROE=True MBAR=False",flush=True)
    try:
        package_pins=verify_package()
        require(not closed.active_target_workers((13,14,15,16)),"TARGET_FORMAL_WORKER_STILL_ACTIVE")
        protocol,contracts,manifests,definition=preflight(reader)
        if args.preflight_only:
            reader.check_unchanged();print("[PASS] read-only preflight; no arrays opened and no analysis output created",flush=True);return 0
        require(output is not None and output.parent.parent == reader.root / DEV and output.parent.name.startswith("238_jacs4_frozen_analysis_v1.")
                and output.name == "results" and output.parent.is_dir() and output.resolve() == output
                and not output.exists() and not output.is_relative_to(reader.root / PROD),"UNSAFE_OR_EXISTING_OUTPUT")
        output.mkdir(exist_ok=False);own_output=True
        f.write_json(output / "ROE_TOPOLOGY_BINDING_AUDIT_v1.json",definition["binding"])
        f.write_json(output / "ANALYSIS_IMPLEMENTATION_SCOPE_v1.json",{
            "version":VERSION,"rows":ROWS,"benchmark":BENCHMARK,"scientific_peptide_units":1,
            "current_reduced_cohort":["TIERA_JACS1","TIERA_JACS3","TIERA_JACS4"],"original_protocol_cohort":protocol["cohort"],
            "this_result_is_not_the_original_exact5_confirmatory_cohort":True,"existing_frozen_endpoints_not_new_preregistration":True,
            "primary":"M2_JOINT_MAJOR_BASIN_OCCUPANCY","omega_window_deg":30.0,"backbone_crms_max_deg":45.0,
            "denominator_per_run":50000,"admitted_global_iteration_grid":[100010,600000,10],"physical_state_index":0,
            "equilibration_excluded":True,"M3_uses_all_frames":True,"D_reference_angles_not_mirrored":True,
            "source_target":definition["target"],"reference_residues":definition["references"],"geometry":definition["geometry"],
            "ROE_restraints":definition["roe_rows"],"ROE_semantic_mapping":definition["semantic_mapping"],
            "ROE_averaging":"average equal-repeat inverse-cube moments before effective distance and bound evaluation",
            "carbon_proxy_semantics_preserved":True,"methyl_H_group_averaging":False,"extra_pseudoatom_correction":False,
            "fixed_10ns_blocks_are_independent_replicates":False,"pooled_frame_p_value":None,
            "outcome_driven_extension_refit_or_exclusion":False,"kinetic_rate_claim":False,
            "technical_NC_and_binary_restart_payloads_read":False,"production_files_modified":False,
            "coordinate_reads_before_mapping_freeze":0,"package_pins":package_pins})
        results={};all_m_blocks=[];all_roe_blocks=[];all_restraints=[]
        for name in ROWS:
            r=analyze_row(reader,name,manifests[name],definition);results[name]=r
            all_m_blocks.extend(r["m123_blocks"]);all_roe_blocks.extend(r["roe_blocks"])
            records=f.restraint_records(definition["roe_rows"],r["roe_moment"],definition["lower_A"],definition["upper_A"],{"row":name})
            all_restraints.extend(records)
            f.write_json(output / (name+".M123_v1.json"),r["m123"])
            f.write_json(output / (name+".ROE_v1.json"),{"summary":r["roe"],"restraints":records})
            f.write_json(output / (name+".sampling_v1.json"),r["sampling"])
            np.savez_compressed(output / (name+".OBSERVABLES_v1.npz"),**r["series"])
            np.savez_compressed(output / (name+".ROE_CHUNK_MOMENTS_v1.npz"),**r["roe_observations"])
            print(f"[ROW COMPLETE] {name} M1={r['m123']['M1_exact_pattern_occupancy']:.6f} M2={r['m123']['M2_joint_major_basin_occupancy']:.6f} "
                  f"M3_mean_deg={r['m123']['M3_crms_mean_deg']:.6f} ROE={r['roe']['restraints_satisfied']}/20 mean_violation_A={r['roe'][f.M5]:.6f}",flush=True)
        arms,effects=aggregate(results)
        roe_arms,roe_effects,arm_blocks,arm_restraints,comparisons=aggregate_roe(results,definition)
        reader.check_unchanged()
        mresult={"trajectories":[results[n]["m123"] for n in ROWS],"arms":arms,"paired_effects":effects,"blocks":all_m_blocks}
        rresult={"trajectories":[results[n]["roe"] for n in ROWS],"arms":roe_arms,"paired_effects":roe_effects,
                 "trajectory_blocks":all_roe_blocks,"arm_blocks":arm_blocks,"arm_restraints":arm_restraints,"all20_control_test_comparison":comparisons}
        f.write_json(output / "RESULTS_M123_v1.json",mresult);f.write_json(output / "RESULTS_ROE_v1.json",rresult)
        tables={"TRAJECTORY_M123_v1.tsv":mresult["trajectories"],"ARM_EQUAL_REPLICATE_M123_v1.tsv":arms,
            "PAIRED_TEST_MINUS_CONTROL_M123_v1.tsv":effects,"FIXED_10NS_BLOCKS_M123_v1.tsv":all_m_blocks,
            "TRAJECTORY_ROE_v1.tsv":rresult["trajectories"],"ARM_EQUAL_REPLICATE_MOMENT_ROE_v1.tsv":roe_arms,
            "PAIRED_TEST_MINUS_CONTROL_ROE_v1.tsv":roe_effects,"ALL20_TRAJECTORY_RESTRAINTS_v1.tsv":all_restraints,
            "ALL20_ARM_RESTRAINTS_v1.tsv":arm_restraints,"ALL20_CONTROL_TEST_COMPARISON_v1.tsv":comparisons,
            "FIXED_10NS_TRAJECTORY_BLOCKS_ROE_v1.tsv":all_roe_blocks,"FIXED_10NS_ARM_BLOCKS_ROE_v1.tsv":arm_blocks}
        for filename,records in tables.items():f.write_table(output / filename,records)
        f.write_json(output / "SAMPLING_RESULTS_v1.json",{name:results[name]["sampling"] for name in ROWS})
        f.write_json(output / "INPUT_HASHES_v1.json",{**{str(p):closed.sha_bytes(v) for p,v in reader.metadata.payload.items()},**reader.digests})
        f.write_json(output / "RUN_STATUS_v1.json",{"status":"JACS4_FROZEN_SAMPLING_M123_ROE_COMPLETE","rows_completed":ROWS,
            "scientific_peptide_units":1,"frames_per_row":50000,"restraints_per_row":20,
            "Delta_major":effects[-1]["M2_joint_major_basin_occupancy_TEST_minus_CONTROL"],"Delta_ROE_M4":roe_effects[-1][f.M4+"_TEST_minus_CONTROL"],
            "Delta_ROE_M5_A":roe_effects[-1][f.M5+"_TEST_minus_CONTROL"],"wall_seconds":time.monotonic()-start,"numpy_version":np.__version__,
            "input_files_unchanged":True,"production_files_modified":False})
        print("DELTA_MAJOR_PERCENTAGE_POINTS="+str(100*effects[-1]["M2_joint_major_basin_occupancy_TEST_minus_CONTROL"]),flush=True)
        print("DELTA_ROE_M5_A_TEST_MINUS_CONTROL="+str(roe_effects[-1][f.M5+"_TEST_minus_CONTROL"]),flush=True)
        export_results(output)
        print("[PASS] JACS4 frozen sampling, M123 and all-20 ROE analysis complete; inputs unchanged",flush=True)
        return 0
    except Exception as exc:
        if own_output and not (output / "FAILURE_v1.json").exists():f.write_json(output / "FAILURE_v1.json",{"status":"FAILED_NOT_COMPLETE","error":str(exc)})
        print("[HOLD] "+str(exc),flush=True);traceback.print_exc();return 1
    finally:print("===== JACS4 FROZEN CPU ANALYSIS END =====",flush=True)


if __name__ == "__main__":sys.exit(main())
