#!/usr/bin/env python3
"""Collect closed-run metadata and static topology for frozen cohort analysis.

Uses only the Python standard library. Does not import OpenMM, create a
Context, read trajectory/checkpoint arrays, signal processes, or change
production files. Outputs are written to a new directory on the project disk.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import tempfile


VERSION = "402EC_CLOSED_THREE_SYSTEM_ANALYSIS_INPUTS_V1"
DEFAULT_ROOT = Path("/mnt/lab/zn/mem-perm/P0_starter_v1")
DEV = Path("07_nmeala_separability_pilot/13_joint_correction_development")
PROD = DEV / "232e_formal_exact20_production_v5"
CX = DEV / "21l_post_m4_final_production_protocol_freeze_v2"
INPUT_PINS = DEV / "21i_post_m4_final_ladder_redesign_precommit_v1/source/INPUT_PINS_v1.json"
WORKER = DEV / "run_402EC_formal_exact20_worker_v5.py"
PINNED = {
    WORKER: "a2be00c88322dca860e44d09c21147f3b1547c133da6ffd04c18a793611cb605",
    CX / "402CX_v2_FINAL_PRODUCTION_PROTOCOL_v1.json": "960dc16d81fbd58df2cda17a9d9d91a5dc70c556a08f883a94b704ea38a451ac",
    CX / "402CX_v2_PRODUCTION_STARTS_AND_SEEDS_v1.tsv": "7d62289519fde4a23a2fe8954c13566aca4ba97bef0af7eb839cd7c69e5593fc",
    CX / "402CX_v2_FINAL_PRODUCTION_PROTOCOL_FREEZE_v1.sha256": "937c290d1f2b44c1d7e6aa998f4bd8885e5b75d4245c471c340aff7a6a6e917f",
}
SERVERS = {
    "OLD_SERVER": {
        "uuids": {"GPU-c1867bec-4a62-1044-2aa7-edbce92e2f53", "GPU-d09a14ac-e7f8-98fe-d737-4994bce89e35"},
        "rows": (1, 2, 3, 4),
    },
    "NEW_SERVER": {
        "uuids": {"GPU-09206009-045c-41af-263d-4e60c5f695ed", "GPU-be4a4fac-949b-1fc0-e656-29340a1863b0"},
        "rows": tuple(range(9, 17)),
    },
}
ROW_NAMES = {
    i: f"ROW{i:02d}_TIERA_JACS{pep}_{arm}_{rep}"
    for pep, start in ((1, 1), (3, 9), (4, 13))
    for i, (arm, rep) in enumerate((("CONTROL", "R1"), ("TEST", "R1"), ("CONTROL", "R2"), ("TEST", "R2")), start)
}
MAX_FILE = 32 * 1024**2
MAX_TOTAL = 128 * 1024**2
ALLOWED_SUFFIXES = {".py", ".json", ".sha256", ".log", ".txt", ".tsv", ".csv", ".md", ".xml"}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def freeze_entries(text):
    entries = []
    for line in text.splitlines():
        if not line.strip():
            continue
        match = re.fullmatch(r"([0-9a-f]{64})\s+(.+)", line)
        require(match is not None, "INVALID_SHA256_LIST")
        raw = Path(match.group(2).strip())
        require(not raw.is_absolute() and ".." not in raw.parts, "UNSAFE_FREEZE_PATH")
        entries.append((raw, match.group(1)))
    require(entries and len({p for p, _ in entries}) == len(entries), "EMPTY_OR_DUPLICATE_SHA256_LIST")
    return dict(entries)


class Collector:
    def __init__(self, root):
        self.root = Path(root).resolve(strict=True)
        self.payload = {}
        self.snapshots = {}
        self.total = 0

    def path(self, relative):
        p = Path(relative)
        require(not p.is_absolute() and ".." not in p.parts, "UNSAFE_RELATIVE_PATH")
        path = self.root / p
        require(not path.is_symlink() and path.resolve().is_relative_to(self.root), f"UNSAFE_INPUT: {p}")
        return path

    def exists(self, relative):
        return self.path(relative).is_file()

    def add(self, relative, expected=None):
        relative = Path(relative)
        require(relative.suffix.lower() in ALLOWED_SUFFIXES, f"NON_METADATA_INPUT_FORBIDDEN: {relative}")
        path = self.path(relative)
        require(path.is_file(), f"MISSING_INPUT: {relative}")
        info = path.stat()
        require(0 < info.st_size <= MAX_FILE, f"INPUT_SIZE: {relative}")
        signature = (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns)
        if relative in self.payload:
            require(self.snapshots[relative] == signature, f"INPUT_CHANGED: {relative}")
            data = self.payload[relative]
        else:
            require(self.total + info.st_size <= MAX_TOTAL, "METADATA_COLLECTION_SIZE_LIMIT")
            data = path.read_bytes()
            after = path.stat()
            require(signature == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), f"INPUT_CHANGED: {relative}")
            self.total += len(data)
            self.snapshots[relative] = signature
            self.payload[relative] = data
        require(expected is None or sha_bytes(data) == expected, f"SHA_MISMATCH: {relative}")
        return data

    def json(self, relative, expected=None):
        return json.loads(self.add(relative, expected))

    def assert_unchanged(self):
        for relative, signature in self.snapshots.items():
            s = self.path(relative).stat()
            require((s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns) == signature, f"INPUT_CHANGED: {relative}")


def server_identity():
    result = subprocess.run(["nvidia-smi", "--query-gpu=index,uuid,driver_version", "--format=csv,noheader"],
                            capture_output=True, text=True, check=True, timeout=20)
    rows = list(csv.reader(result.stdout.splitlines(), skipinitialspace=True))
    require(rows and all(len(row) == 3 for row in rows), "GPU_IDENTITY_OUTPUT")
    uuids = {row[1].strip() for row in rows}
    matches = [name for name, spec in SERVERS.items() if spec["uuids"].issubset(uuids)]
    require(len(matches) == 1, "UNKNOWN_OR_AMBIGUOUS_SERVER")
    return matches[0], [{"index": r[0], "uuid": r[1], "driver": r[2]} for r in rows]


def active_target_workers(indices):
    found = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit() or int(entry.name) == os.getpid():
            continue
        try:
            args = (entry / "cmdline").read_bytes().decode(errors="replace").split("\x00")
        except (OSError, PermissionError):
            continue
        runner_names = [Path(a).name for a in args if a.endswith(".py")]
        if "run_402EC_formal_exact20_worker_v5.py" in runner_names and "--row-index" in args:
            at = args.index("--row-index")
            if at + 1 < len(args) and args[at + 1].isdigit() and int(args[at + 1]) in indices:
                found.append({"pid": int(entry.name), "row_index": int(args[at + 1])})
        for runner in runner_names:
            match = re.fullmatch(r"run_402EC_ROW(\d+)_formal_recovery_from_\d+_v\d+\.py", runner)
            if match and int(match.group(1)) in indices:
                found.append({"pid": int(entry.name), "row_index": int(match.group(1))})
    return found


def collect_row(c, index, starts):
    name = ROW_NAMES[index]
    row = PROD / name
    pep = name.split("_")[2]
    benchmark = "TIERA_" + pep
    arm, replicate = name.rsplit("_", 2)[-2:]
    contract = c.json(row / "FORMAL_RUN_CONTRACT_v1.json")
    result = c.json(row / "FORMAL_RUN_RESULT_v1.json")
    for obj in (contract, result):
        require((obj["row_index"], obj["benchmark"], obj["arm"], obj["replicate"]) ==
                (index, benchmark, arm, replicate), f"ROW_IDENTITY: {name}")
    require(result["final_iteration"] == 600000 and result["total_ns_per_replica"] == 60
            and result["recorded_production_ns_per_replica"] == 50 and result["replicas"] == 12,
            f"NOT_COMPLETE: {name}")
    require(result["final_context_steps"] == 720000000, f"FINAL_STEP_COUNT: {name}")
    recovered = result["status"] == "FORMAL_EXACT20_RUN_COMPLETE_WITH_AUTHORIZED_RECOVERY"
    require(recovered or result["status"] == "FORMAL_EXACT20_RUN_COMPLETE", f"FINAL_STATUS: {name}")
    require(recovered == (index in (3, 11)), f"RECOVERY_HISTORY_REQUIRES_REVIEW: {name}")
    require(contract["formal_protocol_sha256"] == PINNED[CX / "402CX_v2_FINAL_PRODUCTION_PROTOCOL_v1.json"],
            f"PROTOCOL_PIN: {name}")
    for key in ("initial_velocity_seed", "integrator_seed", "exchange_seed"):
        require(contract[key] == result[key] == int(starts[index - 1][key]), f"SEED: {name}")

    log_path = PROD / "_launch_logs" / (name + ".log")
    log = c.add(log_path).decode("utf-8")
    commits = [(int(a), int(b)) for a, b in re.findall(r"\[402EC FORMAL COMMIT\] chunk=(\d+)/60 iteration=(\d+)", log)]
    require(commits == [(i, 10000 * i) for i in range(1, 61)], f"COMMIT_SEQUENCE: {name}")
    require(log.count("===== 402EC FORMAL EXACT20 WORKER END =====") == 1, f"WORKER_END: {name}")
    for label, filename in (("result", "FORMAL_RUN_RESULT_v1.json"),
                            ("storage manifest", "FORMAL_RUN_STORAGE_MANIFEST_v1.json"),
                            ("final freeze", "FORMAL_RUN_FINAL_FREEZE_v1.sha256")):
        values = re.findall(re.escape(label) + r" SHA256 = ([0-9a-f]{64})", log)
        require(len(values) == 1, f"FINAL_LOG_HASH: {name} {label}")
        c.add(row / filename, values[0])

    final_pins = freeze_entries(c.add(row / "FORMAL_RUN_FINAL_FREEZE_v1.sha256").decode())
    allowed_sources = {WORKER, DEV / "run_402EC_ROW03_formal_recovery_from_400000_v2.py",
                       DEV / "run_402EC_ROW11_formal_recovery_from_290000_v1.py"}
    for relative, expected in final_pins.items():
        require(relative.is_relative_to(row) or relative in allowed_sources, f"UNEXPECTED_FINAL_FREEZE_MEMBER: {name}")
        c.add(relative, expected)

    manifest = c.json(row / "FORMAL_RUN_STORAGE_MANIFEST_v1.json")
    records = manifest["records"]
    require(manifest["status"] == "FORMAL_STORAGE_COMPLETE" and manifest["record_count"] == 60
            and len(records) == 60 and [r["chunk_index"] for r in records] == list(range(1, 61)),
            f"MANIFEST_SEQUENCE: {name}")
    require(sum(r["phase"] == "production" for r in records) == 50, f"PRODUCTION_CHUNKS: {name}")
    expected_dirs = {f"ITER_{i * 10000:06d}" for i in range(1, 61)}
    observed_dirs = {p.name for p in c.path(row / "checkpoints").glob("ITER_*") if p.is_dir()}
    require(observed_dirs == expected_dirs, f"CHECKPOINT_DIRECTORIES: {name}")
    for i, record in enumerate(records, 1):
        cp = row / "checkpoints" / f"ITER_{i * 10000:06d}"
        receipt_path = cp / "CHECKPOINT_RECEIPT_v1.json"
        require(Path(record["checkpoint_receipt_path"]) == receipt_path, f"RECEIPT_PATH: {name}")
        receipt = c.json(receipt_path, record["checkpoint_receipt_sha256"])
        require(receipt["global_iteration"] == i * 10000
                and receipt["total_ns_per_replica"] == i
                and receipt["production_ns_per_replica"] == max(0, i - 10), f"RECEIPT_COUNTER: {name}")
        c.add(cp / "CHECKPOINT_METADATA_v1.json", receipt["checkpoint_metadata_sha256"])
        # Only record inventory/stat; do not open scientific array files yet.
        for key in ("capture_path", "exchange_audit_path"):
            relative = Path(record[key])
            require(relative.is_relative_to(row / "chunks") and relative.suffix == ".npz", f"CHUNK_PATH: {name}")
            path = c.path(relative)
            require(path.is_file() and path.stat().st_size > 0, f"MISSING_COMMITTED_CHUNK: {name} {relative.name}")

    pre_pins = freeze_entries(c.add(row / "FORMAL_RUN_PRECOMMIT_v1.sha256").decode())
    build = DEV / f"20r_post_m4_dmso_solvation_and_short_md_v1/systems/{benchmark}/build"
    require(INPUT_PINS in pre_pins and build / "BUILD_REPORT_v1.json" in pre_pins,
            f"STATIC_PRECOMMIT_PINS: {name}")
    input_pins = c.json(INPUT_PINS, pre_pins[INPUT_PINS])["short_md_input_files"]
    build_report = c.json(build / "BUILD_REPORT_v1.json", pre_pins[build / "BUILD_REPORT_v1.json"])
    require(build_report["benchmark_id"] == benchmark, f"BUILD_IDENTITY: {name}")
    for basename in ("SOLUTE_GEOMETRY_v1.json", "CONTROL.xml", "TEST.xml"):
        key = f"systems/{benchmark}/build/{basename}"
        require(key in input_pins, f"BUILD_INPUT_PIN: {key}")
        c.add(build / basename, input_pins[key])
    physical_xml = Path(contract["physical_xml"])
    require(physical_xml == build / (arm + ".xml"), f"PHYSICAL_XML_PATH: {name}")
    c.add(physical_xml, contract["physical_xml_sha256"])

    boundary = None
    if recovered:
        boundary = c.json(row / "FORMAL_RECOVERY_BOUNDARY_v1.json")
        recovery = c.json(row / "FORMAL_RECOVERY_CONTRACT_v1.json")
        require(boundary["boundary_global_iteration"] == {3: 400000, 11: 290000}[index], f"RECOVERY_BOUNDARY: {name}")
        require(recovery["recovery_semantics"] == "ENSEMBLE_VALID_STOCHASTIC_CHECKPOINT_RECOVERY"
                and recovery["kinetic_continuity_claim_across_recovery_boundary"] is False,
                f"RECOVERY_SEMANTICS: {name}")
        c.add(row / "FORMAL_RECOVERY_PRECOMMIT_v1.sha256")
    receipt_dir = c.path(PROD / "_launch_receipts")
    if receipt_dir.is_dir():
        for path in sorted(receipt_dir.glob(name + "*.txt")):
            if path.is_file():
                c.add(path.relative_to(c.root))
    return {"row": name, "final_status": result["status"], "formal_commits": len(commits),
            "total_ns_per_replica": 60, "production_ns_per_replica": 50,
            "committed_chunk_arrays_present_but_not_opened": True,
            "solute_atoms": build_report["solute_atoms"],
            "recovery_boundary": boundary, "contract": contract}


def collect(c, indices):
    for relative, expected in PINNED.items():
        c.add(relative, expected)
    starts = list(csv.DictReader(io.StringIO(c.add(CX / "402CX_v2_PRODUCTION_STARTS_AND_SEEDS_v1.tsv").decode()), delimiter="\t"))
    require(len(starts) == 20, "FROZEN_STARTS_COUNT")
    rows = []
    for index in indices:
        row = collect_row(c, index, starts)
        rows.append(row)
        print(f"[PASS] {row['row']}: 60 commits; 60 checkpoints; final hashes exact", flush=True)
    for benchmark in sorted({row["contract"]["benchmark"] for row in rows}):
        family = [r for r in rows if r["contract"]["benchmark"] == benchmark]
        for rep in ("R1", "R2"):
            pair = [r["contract"] for r in family if r["contract"]["replicate"] == rep]
            require(len(pair) == 2 and {p["arm"] for p in pair} == {"CONTROL", "TEST"}, "INCOMPLETE_PAIR")
            for key in ("formal_start_sha256", "initial_velocity_seed", "integrator_seed", "exchange_seed"):
                require(pair[0][key] == pair[1][key], f"PAIRED_DESIGN: {benchmark} {rep}")
        require(len({r["contract"]["exchange_seed"] for r in family}) == 2, "REPLICATE_SEEDS")
    # Include the exact normal/recovery engines if present. Their identities are
    # explicit in the source inventory; the downstream analyzer verifies its pins.
    for basename in ("run_402CY_exact_restart_production_engine_validation_v4.py",
                     "run_402DX_jacs4_test_alldouble_1ns_production_canary_v2.py"):
        if c.exists(DEV / basename):
            c.add(DEV / basename)
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    args = parser.parse_args()
    print("===== CLOSED THREE SYSTEM ANALYSIS INPUTS BEGIN =====", flush=True)
    print("VERSION=" + VERSION, flush=True)
    print("MD=False CONTEXT=False GPU_COMPUTE=False READS_NC=False READS_NPZ=False", flush=True)
    output = None
    try:
        server, gpu_identity = server_identity()
        indices = SERVERS[server]["rows"]
        print("SERVER=" + server, flush=True)
        require(not active_target_workers(indices), "TARGET_FORMAL_WORKER_STILL_ACTIVE")
        c = Collector(args.root)
        rows = collect(c, indices)
        c.assert_unchanged()
        report = {"version": VERSION, "server": server, "gpu_identity_read_only": gpu_identity,
                  "collected_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
                  "project_root": str(c.root), "rows": rows,
                  "payload_sha256": {str(p): sha_bytes(data) for p, data in sorted(c.payload.items())},
                  "M1_M2_M3_ROE_evaluated": False,
                  "raw_array_content_verification_pending_analysis": True,
                  "production_files_modified": False}
        output = Path(tempfile.mkdtemp(prefix="402EC_closed_cohort_analysis_inputs_v1.", dir=c.root))
        archive = output / f"{server}_CLOSED_COHORT_ANALYSIS_INPUTS_v1.tar.gz"
        report_bytes = (json.dumps(report, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode()
        with tarfile.open(archive, "x:gz", compresslevel=3) as a:
            for relative, data in sorted(c.payload.items()):
                info = tarfile.TarInfo(str(relative)); info.size = len(data); info.mode = 0o644
                a.addfile(info, io.BytesIO(data))
            info = tarfile.TarInfo("CLOSED_COHORT_ANALYSIS_INPUTS_v1.json")
            info.size = len(report_bytes); info.mode = 0o644
            a.addfile(info, io.BytesIO(report_bytes))
        c.assert_unchanged()
        (output / "CLOSED_COHORT_ANALYSIS_INPUTS_v1.json").write_bytes(report_bytes)
        digest = sha_bytes(archive.read_bytes())
        (output / (archive.name + ".sha256")).write_text(digest + "  " + archive.name + "\n")
        print("PAYLOAD_FILE_COUNT=" + str(len(c.payload)), flush=True)
        print("ARCHIVE_BYTES=" + str(archive.stat().st_size), flush=True)
        print("ARCHIVE_SHA256=" + digest, flush=True)
        print("UPLOAD_THIS_EXACT_FILE=" + str(archive), flush=True)
        print("[PASS] closed metadata and topology collected; production unchanged", flush=True)
        print("[NEXT] use this bundle to prepare the pinned CPU analysis for these rows", flush=True)
        return 0
    except Exception as exc:
        print("[HOLD] " + str(exc), flush=True)
        if output is not None:
            print("RETAIN_OUTPUT_DIRECTORY=" + str(output), flush=True)
        return 1
    finally:
        print("===== CLOSED THREE SYSTEM ANALYSIS INPUTS END =====", flush=True)


if __name__ == "__main__":
    sys.exit(main())
