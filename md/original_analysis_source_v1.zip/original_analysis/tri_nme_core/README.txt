402EC JACS4 frozen CPU analysis v1

Scope
  Analyze only the closed ROW13, ROW14, ROW15 and ROW16 trajectories on the
  new server. No OpenMM import, Context, MD, GPU computation, package install,
  technical NetCDF read, binary restart read or production write is performed.
  Other users' compute processes are not inspected or signaled by this program.

Run
  After verifying the distributed archive SHA256 and extracting to a fresh
  directory, run: bash /absolute/path/jacs4_analysis_v1/run_new_server.sh
  Keep the terminal open. Uses the existing nme_rest2_openmm84_v1 Python and
  NumPy, one CPU thread, nice 19 and idle I/O priority. Temporary files and new
  analysis outputs use /mnt/lab, not the root filesystem's /tmp.

Frozen scientific definitions
  10 ns equilibration excluded; 50 ns production per replica, 12 REST2 replicas.
  Track thermodynamic state index 0 (lambda=1), not a fixed walker. The admitted
  global iteration grid is 100010..600000, stride 10: 50000 frames per trajectory.
  M1: all five omega bonds match the source pattern within +/-30 degrees.
  M2 (primary): M1 AND circular RMS of all ten phi/psi angles <=45 degrees.
  M3: mean and median circular RMS over all admitted frames, including frames
  outside M1/M2. The signed source D-residue reference is not mirrored again.
  Intermediate omega states remain in the occupancy denominator.
  All five omega site populations are retained. Committed crossing diagnostics
  use the previous 60/120 degree basin definitions, not the 30 degree endpoint.
  JACS4: 59 solute atoms, N-methyl residues 1,2,5; all 20 frozen ROE restraints
  from source Table 13, SI page 18. Halpha/HN are proton coordinates; Cbeta/CN
  retain the original single-carbon proxy semantics. No methyl-H group average,
  new pseudoatom correction, source-bound reconstruction or endpoint tuning.
  ROE effective distance = <r_A^-3>^(-1/3). Equal-repeat inverse-cube moments are
  averaged BEFORE conversion to distance and evaluation against closed bounds.
  M4 = fraction satisfying source bounds. M5 = mean bound violation over ALL
  restraints, including zero violations. CONTROL/TEST share the exact atom order.

Integrity and outputs
  The static mapping was bound from chemical graphs in both System XML files
  before reading trajectories. Runtime metadata and all 60 committed capture
  and exchange-audit chunks per row are checked against supplied source hashes.
  Equilibration chunk hashes are checked but their arrays are not analyzed.
  Original technical reporters, application checkpoint NPZs and binary Context
  checkpoints are never opened. JACS4 has no recovery segment.
  Outputs are created only in a fresh 238_jacs4_frozen_analysis_v1.* directory.
  They include full run, repeat, arm and fixed-10ns-block tables, all 20 per-run
  and arm restraints, all five site omega populations, all phi/psi/omega series,
  sampling diagnostics, provenance and a small derived-results archive.
  Upload the archive printed as UPLOAD_THIS_EXACT_FILE after successful exit.

Interpretation
  This is one peptide of the reduced JACS1/JACS3/JACS4 cohort, not the original
  exact-five confirmatory cohort. No study-wide significance or generalization
  claim is made by this program. Frames, walkers, blocks and restraints are not
  independent peptide replicates. The walker inverse-Simpson effective number
  describes walker contribution balance, not independent configuration ESS.
  Sampling limitations and constant indicators are reported, never used to
  drop runs/sites or change the frozen compute plan. REST2 crossings are not
  physical kinetic rates. Five fixed 10 ns blocks are descriptive diagnostics.

Local validation
  See LOCAL_VALIDATION_v1.json for the review fixtures, numerical tolerances
  and completed tests. Synthetic fixtures are software tests, not MD results.
  Actual JACS4 M123/ROE values can only be obtained by running on the server;
  the supplied metadata bundle does not contain production coordinate arrays.
