#!/usr/bin/env bash

jacs4_frozen_cpu_analysis() (
    local here root dev py run log rc
    local -a pipeline_status
    here="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)" || return 1
    root="/mnt/lab/zn/mem-perm/P0_starter_v1"
    dev="$root/07_nmeala_separability_pilot/13_joint_correction_development"
    py="/home/dlab/miniconda3/envs/nme_rest2_openmm84_v1/bin/python"
    echo "===== JACS4 FROZEN CPU ANALYSIS SHELL BEGIN ====="
    if [ ! -x "$py" ] || [ ! -d "$dev" ]; then
        echo "[HOLD] new-server Python or project directory missing"
        return 1
    fi
    if ! command -v ionice >/dev/null || ! command -v nice >/dev/null; then
        echo "[HOLD] ionice or nice missing"
        return 1
    fi
    if ! (cd -- "$here" && sha256sum --quiet -c PACKAGE_SHA256SUMS); then
        echo "[HOLD] analysis package checksum failure"
        return 1
    fi
    run="$(mktemp -d "$dev/238_jacs4_frozen_analysis_v1.XXXXXX")" || return 1
    mkdir -- "$run/runtime_tmp" || return 1
    log="$run/JACS4_FROZEN_SAMPLING_M123_ROE_v1.log"
    echo "RUN_DIRECTORY=$run"
    echo "LOG=$log"
    echo "[INFO] CPU only, one thread, low I/O priority; keep this terminal open"
    ionice -c 3 nice -n 19 env \
        CUDA_VISIBLE_DEVICES="" PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 \
        OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 \
        NUMEXPR_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 \
        TMPDIR="$run/runtime_tmp" TMP="$run/runtime_tmp" TEMP="$run/runtime_tmp" \
        "$py" -B "$here/analyze_jacs4_v1.py" --root "$root" --output "$run/results" \
        2>&1 | tee -- "$log"
    pipeline_status=("${PIPESTATUS[@]}")
    echo "PYTHON_EXIT_STATUS=${pipeline_status[0]}"
    echo "TEE_EXIT_STATUS=${pipeline_status[1]}"
    if [ "${pipeline_status[0]}" -ne 0 ] || [ "${pipeline_status[1]}" -ne 0 ]; then
        echo "[HOLD] analysis did not complete; preserve the log above"
        return 1
    fi
    echo "[PASS] JACS4 four-row analysis saved; production files unchanged"
    echo "UPLOAD_THIS_EXACT_FILE=$run/results/JACS4_FROZEN_SAMPLING_M123_ROE_RESULTS_v1.tar.gz"
    echo "===== JACS4 FROZEN CPU ANALYSIS SHELL END ====="
)

jacs4_frozen_cpu_analysis
rc=$?
exit "$rc"
