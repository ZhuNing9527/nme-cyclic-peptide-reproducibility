# Original structural-analysis implementations

These unchanged sources implement REST2 exchange diagnostics, tri-NMe RMSD/projected
free energy, intramolecular hydrogen bonds and the original M1–M3/ROE analysis core.
They retain lab-path and raw-coordinate dependencies. Portable replay of the supplied
derived arrays and native inputs remains in md/code/. MANIFEST.json records exact
source identities. Production coordinates and raw job directories are separate data.
