#!/usr/bin/env bash
jacs3_frozen_roe_cpu_run() (
  local j3_root=/mnt/lab/zn/mem-perm/P0_starter_v1
  local j3_dev="$j3_root/07_nmeala_separability_pilot/13_joint_correction_development"
  local j3_python=/home/dlab/miniconda3/envs/nme_rest2_openmm84_v1/bin/python
  local j3_here j3_run j3_log j3_tool
  local -a j3_pipe
  printf '%s\n' '===== JACS3 FROZEN ROE CPU SHELL BEGIN ====='
  trap 'printf "%s\n" "===== JACS3 FROZEN ROE CPU SHELL END ====="' EXIT
  j3_here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P) || return 1
  for j3_tool in sha256sum findmnt mktemp ionice nice tee; do
    command -v "$j3_tool" >/dev/null 2>&1 || return 1
  done
  [ -x "$j3_python" ] && [ -d "$j3_dev/232e_formal_exact20_production_v5" ] || return 1
  [ "$(findmnt -n -T "$j3_root" -o TARGET)" = /mnt/lab ] || {
    printf '%s\n' '[HOLD] expected /mnt/lab filesystem unavailable'
    return 1
  }
  (cd "$j3_here" && sha256sum --quiet -c PACKAGE_SHA256SUMS_v1.txt) || {
    printf '%s\n' '[HOLD] package checksum failed'
    return 1
  }
  j3_run=$(mktemp -d "$j3_dev/236_jacs3_frozen_ROE_v1.XXXXXX") || return 1
  mkdir -- "$j3_run/runtime_tmp" || return 1
  j3_log="$j3_run/JACS3_FROZEN_ROE_v1.log"
  printf 'RUN_DIRECTORY=%s\nLOG=%s\n' "$j3_run" "$j3_log"
  printf '%s\n' '[INFO] CPU only, single thread, low I/O priority; all 26 frozen ROE restraints; keep terminal open'
  ionice -c3 nice -n 19 env \
    CUDA_VISIBLE_DEVICES= PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 \
    OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1 \
    TMPDIR="$j3_run/runtime_tmp" TMP="$j3_run/runtime_tmp" TEMP="$j3_run/runtime_tmp" \
    "$j3_python" -B "$j3_here/run_jacs3_roe_v1.py" \
    --root "$j3_root" --output "$j3_run/results" 2>&1 | tee "$j3_log"
  j3_pipe=("${PIPESTATUS[@]}")
  printf 'PYTHON_EXIT_STATUS=%s\nTEE_EXIT_STATUS=%s\n' "${j3_pipe[0]}" "${j3_pipe[1]}"
  if [ "${j3_pipe[0]}" -ne 0 ] || [ "${j3_pipe[1]}" -ne 0 ]; then
    printf '%s\n' '[HOLD] analysis incomplete; retain output and report error; leave all MD workers untouched'
    return 1
  fi
  printf '%s\n' '[PASS] frozen JACS3 secondary ROE analysis complete; no production file modified'
  printf 'UPLOAD_THIS_EXACT_FILE=%s/results/JACS3_FROZEN_ROE_RESULTS_v1.tar.gz\n' "$j3_run"
)

jacs3_frozen_roe_cpu_run
