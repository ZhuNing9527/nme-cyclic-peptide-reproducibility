#!/usr/bin/env python3
"""Frozen JACS3 M1/M2/M3 analysis of four closed physical-state streams."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import tarfile
import time
import traceback

import numpy as np
import sampling_core_v1 as core

VERSION = "402EC_JACS3_FROZEN_M123_ANALYSIS_V1"
BENCHMARK = "TIERA_JACS3"
WINDOW_DEG = 30.0
CRMS_MAX_DEG = 45.0
DEV = core.DEV_REL
ENDPOINT_DIR = DEV / "16f_post_m4_cyclic_transfer_tiera_analysis_precommit"
ENDPOINT_FREEZE = ENDPOINT_DIR / "NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ANALYSIS_PRECOMMIT_FREEZE_v1.sha256"
TARGETS = ENDPOINT_DIR / "NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_EXACT7_ANALYSIS_TARGETS_v1.tsv"
METRICS = ENDPOINT_DIR / "NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_OBSERVABLE_DEFINITIONS_v1.tsv"
REFERENCE = DEV / "16b_post_m4_cyclic_transfer_benchmark_extraction" / "NMEALA_POSTM4_CYCLIC_TRANSFER_EXPERIMENTAL_DIHEDRAL_REFERENCE_v1.tsv"
BUILD_DIR = DEV / "20r_post_m4_dmso_solvation_and_short_md_v1/systems/TIERA_JACS3/build"
GEOMETRY = BUILD_DIR / "SOLUTE_GEOMETRY_v1.json"
BUILD_REPORT = BUILD_DIR / "BUILD_REPORT_v1.json"
INPUT_PINS = DEV / "21i_post_m4_final_ladder_redesign_precommit_v1/source/INPUT_PINS_v1.json"
PACKAGE = Path(__file__).resolve().parent

require = core.require
write_json = core.write_json


def read_tsv(path):
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def asset_path(raw):
    raw = Path(raw)
    require(not raw.is_absolute() and ".." not in raw.parts, "UNSAFE_ASSET_PATH")
    path = PACKAGE / raw
    require(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(PACKAGE), "ASSET_MISSING_OR_UNSAFE")
    return path


def verify_assets():
    pins = json.loads((PACKAGE / "ASSET_PINS_v1.json").read_text())
    for raw, expected in pins.items():
        require(core.sha(asset_path(raw)) == expected, "BUNDLED_ASSET_SHA_MISMATCH: " + raw)
    return pins


def periodic_delta_deg(a, b):
    return (np.asarray(a, dtype=np.float64) - np.asarray(b, dtype=np.float64) + 180.0) % 360.0 - 180.0


def frozen_omega_classes(omega):
    """0 intermediate, 1 cis, 2 trans. Scientific windows are +/-30, not 60."""
    omega = np.asarray(omega, dtype=np.float64)
    require(np.isfinite(omega).all(), "NONFINITE_OMEGA")
    cis = np.abs(periodic_delta_deg(omega, 0.0)) <= WINDOW_DEG
    trans = np.abs(periodic_delta_deg(omega, 180.0)) <= WINDOW_DEG
    require(not np.any(cis & trans), "OVERLAPPING_OMEGA_WINDOWS")
    return np.where(cis, 1, np.where(trans, 2, 0)).astype(np.uint8)


def calculate_observables(phi, psi, omega, reference, target_classes):
    phi, psi, omega = [np.asarray(x, dtype=np.float64) for x in (phi, psi, omega)]
    require(phi.ndim == 2 and phi.shape[1] == 5 and phi.shape == psi.shape == omega.shape, "ANGLE_ARRAY_SHAPE")
    require(all(np.isfinite(x).all() for x in (phi, psi, omega)), "NONFINITE_TORSION")
    reference = np.asarray(reference, dtype=np.float64)
    target_classes = np.asarray(target_classes, dtype=np.uint8)
    require(reference.shape == (5, 2) and np.isfinite(reference).all(), "REFERENCE_ANGLE_SHAPE")
    require(target_classes.shape == (5,) and np.isin(target_classes, [1, 2]).all(), "TARGET_PATTERN")
    angles = np.stack([phi, psi], axis=-1)
    differences = periodic_delta_deg(angles, reference)
    # The source D-Ala reference is already signed for the actual D residue.
    # Do not apply the force-field mirror rule again to any analysis angle.
    crms = np.sqrt(np.mean(differences**2, axis=(1, 2)))
    classes = frozen_omega_classes(omega)
    m1 = np.all(classes == target_classes, axis=1)
    m2 = m1 & (crms <= CRMS_MAX_DEG)
    require(np.all(~m2 | m1), "M2_NOT_SUBSET_OF_M1")
    return {"M1": m1, "M2": m2, "crms_deg": crms, "omega_class": classes}


def summarize_series(series):
    n = len(series["M1"])
    require(n > 0 and len(series["M2"]) == len(series["crms_deg"]) == n, "SERIES_LENGTH")
    return {
        "frames": n,
        "M1_matching_frames": int(np.count_nonzero(series["M1"])),
        "M2_major_frames": int(np.count_nonzero(series["M2"])),
        "M1_exact_pattern_occupancy": float(np.mean(series["M1"])),
        "M2_joint_major_basin_occupancy": float(np.mean(series["M2"])),
        "M3_crms_mean_deg": float(np.mean(series["crms_deg"])),
        "M3_crms_median_deg": float(np.median(series["crms_deg"])),
    }


def block_summaries(series, row, frames_per_block=10000):
    require(len(series["M1"]) == 5 * frames_per_block, "FIVE_FIXED_BLOCKS_REQUIRE_EQUAL_LENGTH")
    records = []
    for index in range(5):
        section = slice(index * frames_per_block, (index + 1) * frames_per_block)
        record = summarize_series({key: series[key][section] for key in ("M1", "M2", "crms_deg")})
        record.update(row=row, block_index=index + 1,
                      production_start_ns_exclusive=index * 10, production_end_ns_inclusive=(index + 1) * 10,
                      global_start_ns_exclusive=10 + index * 10, global_end_ns_inclusive=20 + index * 10,
                      independent_statistical_replicate=False)
        records.append(record)
    return records


def make_arm_and_effect_tables(series_by_row):
    summaries = {name: summarize_series(series_by_row[name]) for name in core.ROWS}
    arms = []
    metrics = ("M1_exact_pattern_occupancy", "M2_joint_major_basin_occupancy", "M3_crms_mean_deg")
    for arm in ("CONTROL", "TEST"):
        names = [name for name in core.ROWS if f"_{arm}_" in name]
        require(len(names) == 2 and names[0].endswith("R1") and names[1].endswith("R2"), "ARM_REPLICATE_ORDER")
        r1, r2 = [summaries[name] for name in names]
        require(r1["frames"] == r2["frames"], "UNEQUAL_LENGTH_REPLICATES")
        record = {"benchmark": BENCHMARK, "arm": arm, "frames_per_replicate": r1["frames"]}
        for metric in metrics:
            record[metric] = (r1[metric] + r2[metric]) / 2.0
            record[metric + "_R1"] = r1[metric]
            record[metric + "_R2"] = r2[metric]
            record[metric + "_absolute_R1_R2_difference"] = abs(r1[metric] - r2[metric])
        record["M3_crms_median_deg"] = float(np.median(np.concatenate([series_by_row[name]["crms_deg"] for name in names])))
        record["M3_crms_median_deg_R1"] = r1["M3_crms_median_deg"]
        record["M3_crms_median_deg_R2"] = r2["M3_crms_median_deg"]
        record["M3_crms_median_deg_absolute_R1_R2_difference"] = abs(r1["M3_crms_median_deg"] - r2["M3_crms_median_deg"])
        arms.append(record)
    effects = []
    effect_metrics = metrics + ("M3_crms_median_deg",)
    for rep in ("R1", "R2"):
        control = next(summaries[n] for n in core.ROWS if n.endswith("_CONTROL_" + rep))
        test = next(summaries[n] for n in core.ROWS if n.endswith("_TEST_" + rep))
        require(control["frames"] == test["frames"], "UNEQUAL_PAIRED_LENGTHS")
        effect = {"benchmark": BENCHMARK, "level": rep}
        for metric in effect_metrics:
            effect[metric + "_TEST_minus_CONTROL"] = test[metric] - control[metric]
        effects.append(effect)
    total = {"benchmark": BENCHMARK, "level": "ARM_EQUAL_REPLICATE_ESTIMATOR"}
    for metric in effect_metrics:
        total[metric + "_TEST_minus_CONTROL"] = arms[1][metric] - arms[0][metric]
    require(np.isclose(total["M2_joint_major_basin_occupancy_TEST_minus_CONTROL"],
                       np.mean([e["M2_joint_major_basin_occupancy_TEST_minus_CONTROL"] for e in effects]),
                       atol=1e-14, rtol=0), "PAIRED_ARM_EFFECT_MISMATCH")
    effects.append(total)
    return arms, effects


def validate_geometry(geometry, nsolute):
    require(len(geometry) == 5 and [g["residue_index"] for g in geometry] == [1, 2, 3, 4, 5], "GEOMETRY_RESIDUE_ORDER")
    for g in geometry:
        for kind in ("phi_atoms", "psi_atoms", "omega_atoms"):
            atoms = g[kind]
            require(len(atoms) == 4 and len(set(atoms)) == 4
                    and all(type(i) is int and 0 <= i < nsolute for i in atoms), "GEOMETRY_ATOM_INDICES")
    ns = [g["phi_atoms"][1] for g in geometry]
    cas = [g["phi_atoms"][2] for g in geometry]
    cs = [g["phi_atoms"][3] for g in geometry]
    for i, g in enumerate(geometry):
        prev, nxt = (i - 1) % 5, (i + 1) % 5
        require(g["phi_atoms"] == [cs[prev], ns[i], cas[i], cs[i]], "PHI_CONVENTION")
        require(g["psi_atoms"] == [ns[i], cas[i], cs[i], ns[nxt]], "PSI_CONVENTION")
        require(g["omega_atoms"] == [cas[prev], cs[prev], ns[i], cas[i]], "OMEGA_CONVENTION")


def load_definition_tables(authority_root):
    references = [r for r in read_tsv(authority_root / REFERENCE) if r["benchmark_id"] == BENCHMARK]
    references.sort(key=lambda r: int(r["residue_index"]))
    require(len(references) == 5 and [int(r["residue_index"]) for r in references] == [1, 2, 3, 4, 5], "EXACT_FIVE_SOURCE_RESIDUES")
    require(all(r["reference_trust_status"] == "SOURCE_TRUSTED_REFERENCE" for r in references), "UNTRUSTED_SOURCE_REFERENCE")
    targets = [r for r in read_tsv(authority_root / TARGETS) if r["benchmark_id"] == BENCHMARK]
    require(len(targets) == 1, "EXACT_ONE_PEPTIDE_TARGET")
    target = targets[0]
    require(target["major_cis_bonds"] == "NONE" and target["major_cis_count"] == "0", "JACS3_SOURCE_TARGET_NOT_ALL_TRANS")
    require(target["source_population_ratio"] == "98:2", "JACS3_SOURCE_POPULATION_ANNOTATION")
    require(all(r["omega_state"] == "t" for r in references), "REFERENCE_PATTERN_DISAGREES_WITH_TARGET")
    metrics = {r["metric_id"]: r for r in read_tsv(authority_root / METRICS)}
    require(metrics["M2_JOINT_MAJOR_BASIN_OCCUPANCY"]["priority"] == "PRIMARY", "PRIMARY_ENDPOINT_CHANGED")
    reference = np.array([[float(r["phi_deg"]), float(r["psi_deg"])] for r in references])
    target_classes = np.array([2 if r["omega_state"] == "t" else 1 for r in references], dtype=np.uint8)
    return references, target, reference, target_classes


def load_runtime_authorities(reader, precommits, source_pins):
    # The original frozen production protocol pins the earlier analysis freeze.
    production_freeze = dict((raw, expected) for expected, raw in core.parse_freeze(reader.text(core.CX_REL / "402CX_v2_FINAL_PRODUCTION_PROTOCOL_FREEZE_v1.sha256")))
    require(production_freeze[str(ENDPOINT_FREEZE)] == core.ENDPOINT_FREEZE_SHA, "ENDPOINT_PARENT_PIN")
    authority_root = PACKAGE / "authority"
    endpoint_freeze = authority_root / ENDPOINT_FREEZE
    require(core.sha(endpoint_freeze) == core.ENDPOINT_FREEZE_SHA, "ENDPOINT_FREEZE_SHA")
    for expected, raw in core.parse_freeze(endpoint_freeze.read_text(encoding="utf-8")):
        require(core.sha(asset_path(Path("authority") / raw)) == expected, "ENDPOINT_DIRECT_MEMBER_SHA")
    references, target, reference, target_classes = load_definition_tables(authority_root)
    input_pin_values = set()
    build_pin_values = set()
    for raw in precommits:
        entries = {p: expected for expected, p in core.parse_freeze(reader.text(raw))}
        input_pin_values.add(entries[str(INPUT_PINS)])
        build_pin_values.add(entries[str(BUILD_REPORT)])
    require(len(input_pin_values) == len(build_pin_values) == 1, "ROW_INPUT_AUTHORITY_DISAGREEMENT")
    reader.digest(INPUT_PINS, input_pin_values.pop())
    reader.digest(BUILD_REPORT, build_pin_values.pop())
    input_pins = reader.json(INPUT_PINS)["short_md_input_files"]
    geometry_pin = input_pins["systems/TIERA_JACS3/build/SOLUTE_GEOMETRY_v1.json"]
    reader.digest(GEOMETRY, geometry_pin)
    geometry = reader.json(GEOMETRY)
    nsolute = reader.json(BUILD_REPORT)["solute_atoms"]
    require(nsolute == 56, "JACS3_SOLUTE_COUNT")
    validate_geometry(geometry, nsolute)
    baseline = json.loads(asset_path("sampling_review/INPUT_HASHES_v1.json").read_text())
    status = json.loads(asset_path("sampling_review/RUN_STATUS_v1.json").read_text())
    require(status["status"] == "SAMPLING_COMPLETE__M2_NOT_YET_EVALUATED"
            and status["input_files_unchanged"] is True and status["rows_completed"] == list(core.ROWS), "PRIOR_SAMPLING_STATUS")
    print("[PASS] original M2 definition: exact five-bond +/-30deg pattern AND ten-angle cRMS <=45deg", flush=True)
    print("[PASS] source reference and SHA-pinned five-residue solute geometry; no D-residue angle mirroring", flush=True)
    return references, target, reference, target_classes, geometry, nsolute, baseline


def extract_chunk(reader, record, name, nsolute, baseline):
    chunk = record["chunk_index"]
    start, end = (chunk - 1) * 10000, chunk * 10000
    require(11 <= chunk <= 60 and record["phase"] == "production", "NONPRODUCTION_CHUNK")
    row = core.PROD_REL / name
    raw = row / "chunks" / f"CAPTURE_{chunk:02d}_production_v1.npz"
    require(record["capture_path"] == str(raw), "CAPTURE_PATH")
    require(baseline[str(raw)] == record["capture_sha256"], "PRIOR_SAMPLING_CAPTURE_IDENTITY")
    reader.digest(raw, record["capture_sha256"])
    receipt_raw = row / "checkpoints" / f"ITER_{end:06d}" / "CHECKPOINT_RECEIPT_v1.json"
    require(record["checkpoint_receipt_path"] == str(receipt_raw), "CHECKPOINT_RECEIPT_PATH")
    reader.digest(receipt_raw, record["checkpoint_receipt_sha256"])
    receipt = reader.json(receipt_raw)
    require(receipt["global_iteration"] == end and receipt["phase"] == "production", "CHECKPOINT_BOUNDARY")
    keys = ["chunk_index", "phase", "global_iteration_start_exclusive", "global_iteration_end_inclusive",
            "capture_1ps_iteration", "capture_1ps_positions", "capture_1ps_box", "capture_1ps_mapping", "capture_1ps_lambda1_replica"]
    recovery = name == core.ROWS[2] and chunk >= 30
    if recovery:
        keys += ["recovery_segment", "recovery_local_iteration_start_exclusive", "recovery_local_iteration_end_inclusive"]
    cap = core.load_npz(reader, raw, keys)
    scalar = lambda key: np.asarray(cap[key]).item()
    require(scalar("chunk_index") == chunk and scalar("phase") == "production"
            and scalar("global_iteration_start_exclusive") == start
            and scalar("global_iteration_end_inclusive") == end, "CAPTURE_METADATA")
    if recovery:
        require(scalar("recovery_segment") == 1
                and scalar("recovery_local_iteration_start_exclusive") == start - 290000
                and scalar("recovery_local_iteration_end_inclusive") == end - 290000, "RECOVERY_OFFSET")
    require(np.array_equal(cap["capture_1ps_iteration"], np.arange(start + 10, end + 1, 10)), "PHYSICAL_FRAME_ITERATIONS")
    core.validate_mapping(cap["capture_1ps_mapping"], 1000)
    walker = cap["capture_1ps_lambda1_replica"]
    require(walker.shape == (1000,) and np.issubdtype(walker.dtype, np.integer)
            and np.all((walker >= 0) & (walker < 12)), "PHYSICAL_WALKER_INDEX")
    require(np.all(cap["capture_1ps_mapping"][np.arange(1000), walker] == 0), "NOT_PHYSICAL_THERMODYNAMIC_STATE")
    positions, boxes = cap["capture_1ps_positions"], cap["capture_1ps_box"]
    require(positions.shape == (1000, nsolute, 3) and boxes.shape == (1000, 3, 3), "PHYSICAL_COORDINATE_SHAPE")
    require(np.isfinite(positions).all() and np.isfinite(boxes).all(), "NONFINITE_COORDINATES")
    return cap


def analyze_row(reader, name, manifest, definition, baseline):
    reference, target_classes, geometry, nsolute = definition
    parts = {k: [] for k in ("M1", "M2", "crms_deg", "omega_class", "iteration")}
    require([r["chunk_index"] for r in manifest["records"]] == list(range(1, 61)), "MANIFEST_CHUNKS")
    for record in manifest["records"][10:]:
        cap = extract_chunk(reader, record, name, nsolute, baseline)
        positions, boxes = cap["capture_1ps_positions"], cap["capture_1ps_box"]
        angles = {}
        for kind in ("phi", "psi", "omega"):
            angles[kind] = np.column_stack([core.omega_degrees(positions, boxes, g[kind + "_atoms"]) for g in geometry])
        observations = calculate_observables(angles["phi"], angles["psi"], angles["omega"], reference, target_classes)
        for key in ("M1", "M2", "crms_deg", "omega_class"):
            parts[key].append(observations[key])
        parts["iteration"].append(cap["capture_1ps_iteration"])
        if record["chunk_index"] % 10 == 0:
            print(f"[PROGRESS] {name} M1/M2/M3 production chunks {record['chunk_index'] - 10}/50", flush=True)
    series = {key: np.concatenate(values) for key, values in parts.items()}
    require(np.array_equal(series["iteration"], np.arange(100010, 600001, 10)), "FINAL_ADMISSION_GRID")
    summary = summarize_series(series)
    require(summary["frames"] == 50000, "EXACT_50000_PHYSICAL_FRAMES")
    summary.update(row=name, benchmark=BENCHMARK, arm=name.rsplit("_", 2)[1], replicate=name.rsplit("_", 1)[1],
                   recovery_boundary_global_iteration=290000 if name == core.ROWS[2] else None,
                   original_reporter_tail_read=False, physical_state_index=0, independent_frame_p_value=None)
    sites = []
    for i, g in enumerate(geometry):
        counts = np.bincount(series["omega_class"][:, i], minlength=3)
        sites.append({"residue_index": g["residue_index"], "order": ["intermediate", "cis", "trans"],
                      "counts": counts.tolist(), "fractions": (counts / 50000).tolist(),
                      "window_deg": WINDOW_DEG, "target_class": "trans" if target_classes[i] == 2 else "cis"})
    summary["all_five_omega_site_occupancies"] = sites
    if summary["M2_major_frames"] in (0, 50000):
        summary["constant_indicator_warning"] = "Observed M2 indicator is constant in this finite trajectory; do not interpret this as exact equilibrium probability or zero uncertainty."
    return summary, series, block_summaries(series, name)


def write_table(path, records, fields=None):
    require(records, "EMPTY_RESULT_TABLE")
    if fields is None:
        fields = list(records[0])
    with path.open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, delimiter="\t", extrasaction="ignore", lineterminator="\n")
        writer.writeheader()
        writer.writerows(records)


def export_result(output):
    archive = output / "JACS3_FROZEN_M123_RESULTS_v1.tar.gz"
    with tarfile.open(archive, "w:gz") as tar:
        for path in sorted(output.rglob("*")):
            if path.is_file() and path != archive:
                tar.add(path, arcname=str(path.relative_to(output)), recursive=False)
    print("RESULT_ARCHIVE_SHA256=" + core.sha(archive), flush=True)
    print("UPLOAD_THIS_EXACT_FILE=" + str(archive), flush=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", default="/mnt/lab/zn/mem-perm/P0_starter_v1")
    ap.add_argument("--output", required=True)
    a = ap.parse_args()
    reader = core.Reader(a.root)
    output = Path(a.output).absolute()
    own_output = False
    t0 = time.monotonic()
    print("===== JACS3 FROZEN M1 M2 M3 ANALYSIS BEGIN =====", flush=True)
    print("VERSION=" + VERSION, flush=True)
    print("MD=False CONTEXT=False GPU=False PRIMARY_M2=True ROE=False MBAR=False", flush=True)
    try:
        require(output.resolve().is_relative_to(reader.root / DEV)
                and not output.resolve().is_relative_to(reader.root / core.PROD_REL), "UNSAFE_OUTPUT_LOCATION")
        require(not output.exists(), "OUTPUT_EXISTS_NO_OVERWRITE")
        assets = verify_assets()
        source_pins = json.loads((PACKAGE / "SOURCE_PINS_v1.json").read_text())
        protocol, contracts, manifests, precommits = core.preflight(reader, source_pins)
        refs, target, reference, target_classes, geometry, nsolute, baseline = load_runtime_authorities(reader, precommits, source_pins)
        output.mkdir(exist_ok=False)
        own_output = True
        write_json(output / "ANALYSIS_IMPLEMENTATION_SCOPE_v1.json", {
            "version": VERSION, "endpoint_definition_is_existing_frozen_definition": True,
            "new_preregistration_claim": False, "prior_omega_sampling_diagnostics_were_observed": True,
            "primary": "M2_JOINT_MAJOR_BASIN_OCCUPANCY", "omega_scientific_window_deg": WINDOW_DEG,
            "sampling_diagnostic_60deg_classifier_not_used_for_M1_M2": True,
            "backbone_cRMS_max_deg": CRMS_MAX_DEG,
            "backbone_cRMS_angles": 10, "all_source_sites_included": 5,
            "physical_state_index": 0, "admitted_global_iterations": [100010, 600000], "stride_iterations": 10,
            "equilibration_excluded": True, "denominator_per_row": 50000,
            "M3_uses_all_admitted_frames_not_conditioned_on_M1_or_M2": True,
            "source_target": target, "literal_source_reference": refs, "geometry": geometry,
            "D_residue_analysis_angles_mirrored": False,
            "ROW11_production_segments_ns": [19, 31], "ROW11_recovery_boundary_global_iteration": 290000,
            "original_reporter_tail_never_opened": [290001, 295253], "kinetic_continuity_claim": False,
            "original_frozen_cohort": protocol["cohort"], "this_stage_peptides": [BENCHMARK],
            "current_resource_limited_three_peptide_plan_is_not_original_five_peptide_analysis": True,
            "no_pooled_frame_p_value": True, "no_overall_cohort_p_value": True,
            "two_repeats_do_not_establish_precise_population_uncertainty": True,
            "outcome_driven_exclusion_extension_retuning": False, "ROE_computed": False, "MBAR_computed": False,
            "analysis_script_sha256": core.sha(Path(__file__)), "sampling_core_sha256": core.sha(Path(core.__file__)),
            "source_asset_pins": assets,
        })
        all_summaries, all_blocks, series_by_row = [], [], {}
        for name in core.ROWS:
            summary, series, blocks = analyze_row(reader, name, manifests[name],
                (reference, target_classes, geometry, nsolute), baseline)
            all_summaries.append(summary)
            all_blocks.extend(blocks)
            series_by_row[name] = series
            write_json(output / (name + ".M123_v1.json"), summary)
            np.savez_compressed(output / (name + ".OBSERVABLES_v1.npz"),
                global_iteration=series["iteration"].astype(np.int32),
                M1_exact_pattern=series["M1"], M2_joint_major=series["M2"],
                M3_phi_psi_crms_deg=series["crms_deg"], omega_class=series["omega_class"])
            print(f"[ROW COMPLETE] {name} M1={summary['M1_exact_pattern_occupancy']:.6f} "
                  f"M2={summary['M2_joint_major_basin_occupancy']:.6f} "
                  f"M3_mean_deg={summary['M3_crms_mean_deg']:.6f} M3_median_deg={summary['M3_crms_median_deg']:.6f}", flush=True)
        arms, effects = make_arm_and_effect_tables(series_by_row)
        reader.check_unchanged()
        trajectory_fields = ["row", "benchmark", "arm", "replicate", "frames", "M1_matching_frames", "M2_major_frames",
                             "M1_exact_pattern_occupancy", "M2_joint_major_basin_occupancy", "M3_crms_mean_deg", "M3_crms_median_deg"]
        write_table(output / "TRAJECTORY_M123_v1.tsv", all_summaries, trajectory_fields)
        write_table(output / "ARM_EQUAL_REPLICATE_M123_v1.tsv", arms)
        write_table(output / "PAIRED_TEST_MINUS_CONTROL_v1.tsv", effects)
        write_table(output / "FIXED_10NS_BLOCKS_M123_v1.tsv", all_blocks)
        write_json(output / "RESULTS_M123_v1.json", {"trajectories": all_summaries, "arms": arms, "paired_effects": effects, "blocks": all_blocks})
        write_json(output / "INPUT_HASHES_v1.json", reader.digests)
        delta = effects[-1]["M2_joint_major_basin_occupancy_TEST_minus_CONTROL"]
        write_json(output / "RUN_STATUS_v1.json", {
            "status": "JACS3_FROZEN_M123_ANALYSIS_COMPLETE", "rows_completed": list(core.ROWS),
            "wall_seconds": time.monotonic() - t0, "numpy_version": np.__version__, "Delta_major": delta,
            "scientific_peptide_units": 1, "pooled_frame_p_value": None, "overall_cohort_p_value": None,
            "production_files_written": 0, "input_files_unchanged": True,
            "source_98_percent_not_used_as_exact_continuous_probability_target": True,
            "ROE_orthogonal_validation_pending": True,
        })
        print("DELTA_MAJOR_TEST_MINUS_CONTROL=" + str(delta), flush=True)
        print("DELTA_MAJOR_PERCENTAGE_POINTS=" + str(100.0 * delta), flush=True)
        export_result(output)
        print("[PASS] existing frozen M1/M2/M3 evaluated for JACS3 only; no MD or production modification", flush=True)
        print("[HOLD] no study-wide conclusion, pooled-frame inference or outcome-driven compute change", flush=True)
        return 0
    except Exception as exc:
        if own_output and not (output / "FAILURE_v1.json").exists():
            write_json(output / "FAILURE_v1.json", {"status": "ANALYSIS_FAILED_NOT_COMPLETE", "error": str(exc)})
        print("[HOLD] " + str(exc), flush=True)
        traceback.print_exc()
        return 1
    finally:
        print("===== JACS3 FROZEN M1 M2 M3 ANALYSIS END =====", flush=True)


if __name__ == "__main__":
    raise SystemExit(main())
