import contextlib
import copy
import io
import json
from pathlib import Path
import tarfile
import tempfile
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET

import numpy as np
import run_jacs3_roe_v1 as m


def static_inputs():
    geometry = json.loads(m.asset(Path("topology_source") / m.BUILD / "SOLUTE_GEOMETRY_v1.json").read_text())
    control = m.asset(Path("topology_source") / m.BUILD / "CONTROL.xml").read_bytes()
    test = m.asset(Path("topology_source") / m.BUILD / "TEST.xml").read_bytes()
    binding = m.topology.bind_both_systems(control, test, geometry, {1, 5})
    protocol = json.loads(m.roe_asset(m.core.CX_REL / "402CX_v2_FINAL_PRODUCTION_PROTOCOL_v1.json").read_text())

    class StaticReader:
        def text(self, raw):
            return m.roe_asset(raw).read_text()

    rows, lower, upper, mapping = m.load_roe_targets(protocol, StaticReader())
    pairs = np.array([[m.resolve_endpoint(r[k], binding) for k in ("source_endpoint_1", "source_endpoint_2")] for r in rows])
    return geometry, control, test, binding, rows, lower, upper, mapping, pairs


class ROETests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        (cls.geometry, cls.control, cls.test, cls.binding, cls.rows,
         cls.lower, cls.upper, cls.mapping, cls.pairs) = static_inputs()

    def test_all_static_asset_checksums(self):
        self.assertEqual(len(m.verify_assets()), 29)

    def test_real_independent_graph_matches_reviewed_binding(self):
        expected = json.loads(m.asset("LOCAL_TOPOLOGY_BINDING_AUDIT_v1.json").read_text())
        self.assertEqual(self.binding, expected)
        self.assertEqual(len(self.binding["bonds"]), 56)
        self.assertEqual(len(self.binding["unwrap_tree_parent_child"]), 55)
        self.assertFalse(self.binding["trajectories_read"])
        self.assertFalse(self.binding["Context_created"])

    def test_all_semantic_indices_and_carbon_proxies(self):
        expected = {"1:CN": 5, "1:Cβ": 4, "1:Hα": 27,
                    "2:Cβ": 10, "2:HN": 34, "2:Hα": 35,
                    "3:Cβ": 15, "3:HN": 39, "3:Hα": 40,
                    "4:Cβ": 20, "4:HN": 44, "4:Hα": 45,
                    "5:CN": 26, "5:Cβ": 25, "5:Hα": 49}
        self.assertEqual(self.binding["semantic_to_atom_index_0based"], expected)
        self.assertEqual(m.resolve_endpoint("1:D-ALA1:CN", self.binding), 5)
        self.assertEqual(m.resolve_endpoint("1:ALA5:CN", self.binding), 26)

    def test_all_26_restraints_retained_in_source_order(self):
        self.assertEqual(len(self.rows), 26)
        self.assertEqual([int(r["source_row_rank"]) for r in self.rows], list(range(1, 27)))
        self.assertEqual(len({r["restraint_id"] for r in self.rows}), 26)
        self.assertEqual(self.pairs.shape, (26, 2))

    def test_literal_wide_row21_bound_not_reconstructed(self):
        self.assertEqual(self.rows[20]["source_endpoint_1"], "1:ALA3:Cβ")
        self.assertEqual(self.rows[20]["source_endpoint_2"], "1:ALA3:Hα")
        self.assertEqual(self.lower[20], 1.92)
        self.assertEqual(self.upper[20], 3.35)

    def test_unavailable_HN_and_wrong_chirality_rejected(self):
        for endpoint in ("1:D-ALA1:HN", "1:ALA5:HN", "1:ALA2:CN", "1:ALA1:CN",
                         "1:D-ALA2:HN", "1:ALA6:HN", "1:ALA2:HB1"):
            with self.subTest(endpoint=endpoint), self.assertRaises(RuntimeError):
                m.resolve_endpoint(endpoint, self.binding)

    def test_wrong_methylation_identity_rejected(self):
        with self.assertRaisesRegex(RuntimeError, "N_METHYLATION_IDENTITY"):
            m.topology.bind_both_systems(self.control, self.test, self.geometry, {1, 2})

    def test_wrong_CA_anchor_element_rejected(self):
        geometry = copy.deepcopy(self.geometry)
        geometry[0]["chirality_atoms"][0] = 27
        with self.assertRaises(RuntimeError):
            m.topology.bind_both_systems(self.control, self.test, geometry, {1, 5})

    def test_hydrogen_mass_repartitioning_rejected(self):
        root = ET.fromstring(self.control)
        root.findall("./Particles/Particle")[27].set("mass", "3.0")
        data = ET.tostring(root)
        with self.assertRaisesRegex(RuntimeError, "MASS_OR_HMR"):
            m.topology.read_system_graph(data)

    def test_same_formula_but_different_atom_order_rejected(self):
        root = ET.fromstring(self.test)
        particles = root.findall("./Particles/Particle")
        particles[1].set("mass", "1.008")
        particles[27].set("mass", "12.01")
        with self.assertRaisesRegex(RuntimeError, "PARTICLE_ORDER_OR_SOLUTE_GRAPH"):
            m.topology.bind_both_systems(self.control, ET.tostring(root), self.geometry, {1, 5})

    def test_graph_missing_bond_rejected(self):
        root = ET.fromstring(self.control)
        bonds = root.find('./Forces/Force[@type="HarmonicBondForce"]/Bonds')
        node = next(b for b in bonds if max(int(b.get("p1")), int(b.get("p2"))) < 56)
        bonds.remove(node)
        with self.assertRaisesRegex(RuntimeError, "SOLUTE_BOND_COUNT"):
            m.topology.read_system_graph(ET.tostring(root))

    def test_inverse_cube_not_arithmetic_distance_average(self):
        distances = np.array([2.0, 4.0])
        moment = m.combine_moments((distances ** -3)[:, None], [1, 1])
        actual = m.evaluate_moments(moment, [1.0], [5.0])[1][0]
        expected = (0.5 * (2.0 ** -3 + 4.0 ** -3)) ** (-1.0 / 3.0)
        self.assertAlmostEqual(actual, expected)
        self.assertNotAlmostEqual(actual, np.mean(distances))

    def test_moment_weighting_by_frame_count(self):
        actual = m.combine_moments([[0.125], [0.015625]], [1, 3])[0]
        self.assertEqual(actual, (0.125 + 3 * 0.015625) / 4)

    def test_invalid_weights_and_moments_rejected(self):
        for moments, weights in (([[1], [2]], [1, 0]), ([[1], [2]], [1, np.inf]),
                                 ([[np.nan]], [1]), ([[0]], [1]), ([[1], [2]], [1])):
            with self.subTest(moments=moments, weights=weights), self.assertRaises(RuntimeError):
                m.combine_moments(moments, weights)

    def test_closed_bounds_and_both_violation_directions(self):
        distances = np.array([2., 4., 1., 8.])
        summary, restored, violation, satisfied = m.evaluate_moments(distances ** -3, np.full(4, 2.), np.full(4, 4.))
        np.testing.assert_allclose(restored, distances)
        np.testing.assert_array_equal(satisfied, [True, True, False, False])
        np.testing.assert_allclose(violation, [0, 0, 1, 4])
        self.assertEqual(summary[m.M4], 0.5)
        self.assertEqual(summary[m.M5], 1.25)

    def test_invalid_or_zero_distance_moments_rejected(self):
        for moment, lower, upper in (([0], [1], [2]), ([np.inf], [1], [2]), ([1], [2], [1]), ([], [], [])):
            with self.assertRaises(RuntimeError):
                m.evaluate_moments(moment, lower, upper)

    def synthetic_positions(self, n=4):
        return np.random.default_rng(1997).uniform(-0.15, 0.15, size=(n, 56, 3))

    def test_PBC_unwrap_and_Angstrom_conversion(self):
        p = self.synthetic_positions()
        boxes = np.broadcast_to(np.eye(3) * 4.0, (len(p), 3, 3))
        expected = 10 * np.linalg.norm(p[:, self.pairs[:, 1]] - p[:, self.pairs[:, 0]], axis=-1)
        distances, checks = m.intramolecular_distances_A(p, boxes, self.pairs, self.binding)
        np.testing.assert_allclose(distances, expected, atol=1e-12)
        self.assertLess(checks["unwrap_closure_max_residual_nm"], 1e-12)

    def test_individual_atom_and_frame_lattice_translations_do_not_change_distance(self):
        p = self.synthetic_positions()
        boxes = np.broadcast_to(np.diag([3., 4., 5.]), (len(p), 3, 3))
        expected = 10 * np.linalg.norm(p[:, self.pairs[:, 1]] - p[:, self.pairs[:, 0]], axis=-1)
        lattice = np.random.default_rng(9).integers(-3, 4, size=p.shape) * [3., 4., 5.]
        translated = p + lattice
        distances, checks = m.intramolecular_distances_A(translated, boxes, self.pairs, self.binding)
        np.testing.assert_allclose(distances, expected, atol=1e-11)
        self.assertLess(checks["unwrap_closure_max_residual_nm"], 1e-11)

    def test_nonfinite_skew_zero_box_and_zero_distance_rejected(self):
        p = self.synthetic_positions(1)
        box = np.eye(3)[None] * 4
        cases = [(p * np.nan, box), (p, box * 0), (p, box + np.array([[[0., .2, 0.], [0., 0., 0.], [0., 0., 0.]]])),
                 (np.zeros_like(p), box)]
        for pos, boxes in cases:
            with self.assertRaises(RuntimeError):
                m.intramolecular_distances_A(pos, boxes, self.pairs, self.binding)

    def test_invalid_atom_pairs_rejected(self):
        p = self.synthetic_positions(1)
        box = np.eye(3)[None] * 4
        for pairs in (self.pairs.astype(float), self.pairs[:25], np.full((26, 2), 56), np.zeros((26, 2), int)):
            with self.assertRaisesRegex(RuntimeError, "ATOM_PAIR_SHAPE"):
                m.intramolecular_distances_A(p, box, pairs, self.binding)

    def test_ring_winding_is_not_silently_accepted(self):
        p = self.synthetic_positions(1)
        p[0, 0, 0] += 1.8
        p[0, 1, 0] -= 1.0
        with self.assertRaisesRegex(RuntimeError, "RING_CLOSURE"):
            m.intramolecular_distances_A(p, np.eye(3)[None] * 4, self.pairs, self.binding)

    def synthetic_manifest(self):
        return {"records": [{"chunk_index": i, "phase": "equilibration" if i <= 10 else "production",
                              "capture_path": "capture_" + str(i), "capture_sha256": str(i)} for i in range(1, 61)]}

    def test_all_50_chunks_global_grid_and_recovery_not_double_offset(self):
        manifest = self.synthetic_manifest()
        hashes = {r["capture_path"]: r["capture_sha256"] for r in manifest["records"]}

        def fake_chunk(reader, record, name, nsolute, baseline):
            i = record["chunk_index"]
            return {"capture_1ps_positions": np.broadcast_to(self.synthetic_positions(1), (1000, 56, 3)),
                    "capture_1ps_box": np.broadcast_to(np.eye(3) * 4, (1000, 3, 3)),
                    "capture_1ps_iteration": np.arange((i - 1) * 10000 + 10, i * 10000 + 1, 10)}

        with patch.object(m.support, "extract_chunk", side_effect=fake_chunk) as extract, contextlib.redirect_stdout(io.StringIO()):
            summary, moment, blocks, bm, observations = m.analyze_row(None, m.core.ROWS[2], manifest, 56,
                hashes, hashes, self.binding, self.pairs, self.lower, self.upper)
        self.assertEqual(extract.call_count, 50)
        self.assertEqual(summary["frames"], 50000)
        self.assertEqual(summary["recovery_boundary_global_iteration"], 290000)
        self.assertEqual(observations["global_start_exclusive"][0], 100000)
        self.assertEqual(observations["global_end_inclusive"][-1], 600000)
        self.assertEqual(observations["mean_rminus3_Aminus3"].shape, (50, 26))
        self.assertEqual(len(blocks), 5)
        self.assertFalse(any(b["independent_statistical_replicate"] for b in blocks))
        self.assertEqual(sum(b["frames"] for b in blocks), 50000)
        np.testing.assert_allclose(bm, np.broadcast_to(moment, (5, 26)))

    def test_changed_primary_stage_input_hash_stops_before_coordinates(self):
        manifest = self.synthetic_manifest()
        hashes = {r["capture_path"]: r["capture_sha256"] for r in manifest["records"]}
        hashes["capture_11"] = "bad"
        with patch.object(m.support, "extract_chunk") as extract, self.assertRaisesRegex(RuntimeError, "M123_CAPTURE_INPUT_IDENTITY"):
            m.analyze_row(None, m.core.ROWS[0], manifest, 56, {}, hashes, self.binding, self.pairs, self.lower, self.upper)
        extract.assert_not_called()

    def test_missing_global_chunk_rejected(self):
        manifest = self.synthetic_manifest()
        manifest["records"].pop(30)
        with self.assertRaisesRegex(RuntimeError, "MANIFEST_GLOBAL_CHUNKS"):
            m.analyze_row(None, m.core.ROWS[0], manifest, 56, {}, {}, self.binding, self.pairs, self.lower, self.upper)

    def arm_fixture(self):
        # R1/R2 individually fail opposite sides, but their combined moment passes.
        distances = [2., 3., 4., 3.]
        lower, upper = np.full(26, 2.5), np.full(26, 3.5)
        moments = {n: np.full(26, d ** -3) for n, d in zip(m.core.ROWS, distances)}
        summaries = {n: {**m.evaluate_moments(moments[n], lower, upper)[0], "frames": 50000,
                        "replicate": n.rsplit("_", 1)[1]} for n in m.core.ROWS}
        bm = {n: [moments[n]] * 5 for n in m.core.ROWS}
        return summaries, moments, bm, lower, upper

    def test_arm_combines_moments_not_distances_or_satisfaction_fractions(self):
        summaries, moments, bm, lower, upper = self.arm_fixture()
        # Control reff=2.4228, outside 2.5..3.5; use 2.4 to include the combined moment.
        lower[:] = 2.4
        for n in m.core.ROWS:
            summaries[n].update(m.evaluate_moments(moments[n], lower, upper)[0])
        arms, effects, combined, blocks, comparisons = m.arm_summaries_and_effects(
            self.rows, summaries, moments, bm, lower, upper)
        self.assertEqual(arms[0][m.M4 + "_R1"], 0)
        self.assertEqual(arms[0][m.M4 + "_R2"], 0)
        self.assertEqual(arms[0][m.M4], 1)
        np.testing.assert_allclose(combined["CONTROL"], (moments[m.core.ROWS[0]] + moments[m.core.ROWS[2]]) / 2)
        self.assertNotAlmostEqual(comparisons[0]["CONTROL_r_eff_A"], 3.0)
        self.assertEqual(len(blocks), 10)
        self.assertEqual(len(comparisons), 26)
        self.assertEqual(len(effects), 3)

    def test_unequal_length_arm_rejected(self):
        summaries, moments, bm, lower, upper = self.arm_fixture()
        summaries[m.core.ROWS[2]]["frames"] = 49999
        with self.assertRaisesRegex(RuntimeError, "ARM_EQUAL_LENGTH_REPLICATES"):
            m.arm_summaries_and_effects(self.rows, summaries, moments, bm, lower, upper)

    def test_result_archive_exact_members(self):
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)
            (output / "test.json").write_text("{}\n")
            with contextlib.redirect_stdout(io.StringIO()):
                m.export_result(output)
            with tarfile.open(output / "JACS3_FROZEN_ROE_RESULTS_v1.tar.gz") as tar:
                self.assertEqual(tar.getnames(), ["test.json"])
            with self.assertRaises(FileExistsError):
                m.export_result(output)

    def test_forbidden_reporters_other_rows_and_traversal(self):
        with tempfile.TemporaryDirectory() as temp:
            reader = m.core.Reader(temp)
            for raw in (m.core.PROD_REL / m.core.ROWS[2] / "technical.nc",
                        m.core.PROD_REL / "ROW15_TIERA_JACS4_CONTROL_R2" / "FORMAL_RUN_PROGRESS_v1.json",
                        Path("../escape")):
                with self.assertRaises(RuntimeError):
                    reader.path(raw)


if __name__ == "__main__":
    unittest.main(verbosity=2)
