402EC JACS3 frozen secondary ROE analysis, version 1

Run on the NEW server with its existing nme_rest2_openmm84_v1 environment:
    bash /path/to/jacs3_roe_analysis_v1/run_new_server.sh
The deployment command supplied with this package uses a fresh /mnt/lab directory.
No system installation, sudo, OpenMM import, Context creation or GPU use is needed.
NumPy is the only non-standard Python dependency. All numerical processing uses
float64. The shell limits numerical-library threads, lowers CPU/I/O priority and
keeps all temporary files and results on /mnt/lab. Leave the terminal open.

Scope and provenance
- Read ONLY four CLOSED JACS3 trajectories, ROW09 through ROW12, plus explicitly
  SHA-pinned static code, definitions and build files. Never read running ROW04,
  ROW15 or ROW16. Never signal a process, reset a GPU, or change a production file.
- Production is global iterations 100010 through 600000, stride 10: 50,000
  physical-state lambda=1 frames per trajectory, in committed capture NPZ files.
  Replica/walker labels are not treated as independent experimental replicates.
- The exact input capture hashes must match both the completed sampling analysis
  and the completed M1/M2/M3 analysis. All live final freezes remain mandatory.
- ROW11 uses 19 ns original committed production plus 31 ns authorized recovery.
  Recovered capture iteration numbers are already global. Do not offset twice.
  No original reporter, technical.nc, checkpoint NC or binary Context file is
  opened. The uncommitted original tail 290001..295253 is never admitted. An
  ensemble comparison does not assert uninterrupted stochastic/kinetic history.

Existing secondary endpoint, NOT a new primary or a new preregistration
- All 26 JACS3 source Table 10 constraints are used in original order. No outcome-
  dependent row selection or bound change. Source Low/Upp are the only targets;
  printed rMD Calc/Viol columns are provenance, not alternative simulation targets.
- Source row 21 retains its printed 1.92..3.35 Angstrom interval. Bounds are not
  reconstructed by applying a generic percentage rule.
- Existing semantic mapping is retained: Halpha and HN are unique proton atoms;
  Cbeta and CN are single carbon-coordinate proxies. No methyl-proton r^-3 sum,
  no methyl hydrogen averaging, and no additional pseudoatom correction. These
  results reproduce the frozen proxy endpoint; do not describe them as a newly
  derived explicit-proton experimental forward model.
- Both exact System XMLs are inspected using standard-library XML parsing, not
  OpenMM. Independent bond/constraint graph checks bind each residue and unique
  coordinate atom, validate N-methylation at residues 1 and 5, cover all 56 solute
  atoms, and verify identical atom mass order and solute connectivity in both arms.
- Runtime must reproduce LOCAL_TOPOLOGY_BINDING_AUDIT_v1.json exactly. A fresh
  output copy with all 26 atom pairs is written BEFORE any coordinate read.
- Distances are computed from bond-graph-unwrapped solute coordinates with cyclic
  closure verification and independent pair-minimum-image agreement. Skew boxes
  or ambiguous images stop for review, not silent approximation. nm is converted
  to Angstrom exactly once.
- For each restraint, r_eff = mean(r_A**(-3))**(-1/3). R1/R2 have equal 50,000-frame
  weights. Average their inverse-cube MOMENTS first, THEN transform to r_eff and
  evaluate bounds. Do not average effective distances, per-replicate pass counts,
  or framewise violation scores to obtain the arm estimator.
- M4: fraction of the 26 effective distances within closed source intervals.
- M5: mean of max(Low-r_eff, r_eff-Upp, 0), across ALL 26 constraints, in Angstrom.
- Show R1 and R2, their paired TEST-CONTROL effects, and five fixed 10-ns production
  blocks per trajectory. Blocks are descriptive stability checks, NOT independent
  peptide observations or a source of cohort-level p-values.
- Original primary M2 is unchanged. Previous primary results were already known
  before this secondary implementation and are transparently linked. No composite
  endpoint, refit, extension, replicate deletion or study-wide conclusion is made.
- JACS3 is ONE peptide unit, not four peptides, 12 replicas or 200,000 independent
  observations. The reduced 3-peptide plan is not the original 5-peptide cohort.

Outputs
Fresh DEV/236_jacs3_frozen_ROE_v1.XXXXXX/results contains:
  ROE_TOPOLOGY_BINDING_AUDIT_v1.json, ANALYSIS_IMPLEMENTATION_SCOPE_v1.json
  four trajectory ROE JSONs and compact 50-chunk inverse-cube moment NPZs
  all 26 constraints per trajectory and per arm, with bounds/atoms/proxy semantics
  repeat, equal-replicate-moment arm, paired-effect and fixed-10ns-block tables
  RESULTS_ROE_v1.json, INPUT_HASHES_v1.json, RUN_STATUS_v1.json
  JACS3_FROZEN_ROE_RESULTS_v1.tar.gz (upload this returned result archive for review)
No raw coordinates or per-frame MD trajectory are exported.

Validation
LOCAL_VALIDATION_v1.json and LOCAL_TEST_LOG_v1.txt distinguish synthetic tests
from real scientific results. No formal coordinate arrays were supplied locally,
so this package does NOT contain or predict actual JACS3 ROE outcome values.
All source generators included under authority_roe are archived static provenance
only and are NEVER executed. SHA manifests preserve all upstream asset bytes.
