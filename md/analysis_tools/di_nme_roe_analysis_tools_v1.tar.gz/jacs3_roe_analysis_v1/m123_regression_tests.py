import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import run_jacs3_m123_v1 as m


REF = np.array([[138.02, -56.34], [-88.79, -87.56], [-119.18, -16.03], [-105.40, 88.41], [53.02, 63.54]])
TARGET = np.full(5, 2, dtype=np.uint8)


class EndpointTests(unittest.TestCase):
    def score(self, n=1, phi=None, psi=None, omega=None):
        return m.calculate_observables(
            np.tile(REF[:, 0], (n, 1)) if phi is None else phi,
            np.tile(REF[:, 1], (n, 1)) if psi is None else psi,
            np.full((n, 5), 180.0) if omega is None else omega, REF, TARGET)

    def test_strict_30_degree_windows_not_sampling_60(self):
        angles = [0, 30, -30, 30.001, -30.001, 60, 120, 149.999, 150, 180, -180, -150, 210, 330]
        np.testing.assert_array_equal(m.frozen_omega_classes(angles), [1, 1, 1, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 1])

    def test_periodic_signed_difference(self):
        np.testing.assert_allclose(m.periodic_delta_deg([-179, 179, 10, 370], [179, -179, 370, 10]), [2, -2, 0, 0])

    def test_exact_source_reference_is_joint_major(self):
        result = self.score()
        self.assertTrue(result["M1"][0])
        self.assertTrue(result["M2"][0])
        self.assertEqual(result["crms_deg"][0], 0)

    def test_periodic_equivalent_reference_is_joint_major(self):
        result = self.score(phi=REF[:, 0][None] + 360, psi=REF[:, 1][None] - 360)
        self.assertTrue(result["M2"][0])
        np.testing.assert_allclose(result["crms_deg"], 0, atol=1e-12)

    def test_all_ten_angles_and_inclusive_45_threshold(self):
        result = self.score(phi=REF[:, 0][None] + 45, psi=REF[:, 1][None] + 45)
        self.assertEqual(result["crms_deg"][0], 45)
        self.assertTrue(result["M2"][0])
        beyond = self.score(phi=REF[:, 0][None] + 45.001, psi=REF[:, 1][None] + 45.001)
        self.assertTrue(beyond["M1"][0])
        self.assertFalse(beyond["M2"][0])

    def test_one_bad_angle_is_divided_by_ten_not_five(self):
        phi = REF[:, 0][None].copy()
        phi[0, 0] += 30
        result = self.score(phi=phi)
        self.assertAlmostEqual(result["crms_deg"][0], 30 / np.sqrt(10))

    def test_every_bond_remains_in_pattern(self):
        for site in range(5):
            omega = np.full((1, 5), 180.0)
            omega[0, site] = 0
            result = self.score(omega=omega)
            self.assertFalse(result["M1"][0])
            self.assertFalse(result["M2"][0])

    def test_intermediate_frame_nonmatching_not_removed(self):
        omega = np.full((2, 5), 180.0)
        omega[1, 4] = 120
        result = self.score(n=2, omega=omega)
        summary = m.summarize_series(result)
        self.assertEqual(summary["frames"], 2)
        self.assertEqual(summary["M1_exact_pattern_occupancy"], 0.5)
        self.assertEqual(summary["M2_joint_major_basin_occupancy"], 0.5)

    def test_D_residue_reference_must_not_be_mirrored_again(self):
        self.assertEqual(REF[0, 0], 138.02)
        self.assertEqual(REF[4, 0], 53.02)
        mirrored_phi = REF[:, 0][None].copy()
        mirrored_phi[0, 0] *= -1
        self.assertGreater(self.score(phi=mirrored_phi)["crms_deg"][0], 0)
        self.assertEqual(self.score()["crms_deg"][0], 0)

    def test_M3_uses_nonmatching_frames_too(self):
        omega = np.full((2, 5), 180.0)
        omega[1, 0] = 0
        phi, psi = np.tile(REF[:, 0], (2, 1)), np.tile(REF[:, 1], (2, 1))
        phi[1] += 80
        psi[1] += 80
        result = self.score(n=2, phi=phi, psi=psi, omega=omega)
        summary = m.summarize_series(result)
        self.assertEqual(summary["M3_crms_mean_deg"], 40)

    def test_nonfinite_angles_rejected(self):
        phi = REF[:, 0][None].copy()
        phi[0, 0] = np.nan
        with self.assertRaisesRegex(RuntimeError, "NONFINITE"):
            self.score(phi=phi)

    def test_fixed_five_blocks_with_no_discard(self):
        series = {"M1": np.ones(50, bool), "M2": np.arange(50) < 10, "crms_deg": np.arange(50, dtype=float)}
        records = m.block_summaries(series, "synthetic", frames_per_block=10)
        self.assertEqual([r["M2_joint_major_basin_occupancy"] for r in records], [1, 0, 0, 0, 0])
        self.assertEqual(sum(r["frames"] for r in records), 50)
        self.assertEqual([r["production_end_ns_inclusive"] for r in records], [10, 20, 30, 40, 50])
        self.assertFalse(any(r["independent_statistical_replicate"] for r in records))

    def test_short_series_cannot_change_block_schedule(self):
        with self.assertRaisesRegex(RuntimeError, "FIVE_FIXED_BLOCKS"):
            m.block_summaries({"M1": np.ones(49, bool)}, "synthetic", frames_per_block=10)

    @staticmethod
    def fake_series(m2, crms):
        return {"M1": np.ones(len(m2), bool), "M2": np.asarray(m2, bool), "crms_deg": np.asarray(crms, float)}

    def test_equal_replicate_arm_means_paired_effect_and_pooled_median(self):
        data = dict(zip(m.core.ROWS, [
            self.fake_series([1, 0, 0], [0, 0, 100]), self.fake_series([1, 1, 0], [2, 2, 2]),
            self.fake_series([0, 0, 0], [1, 1, 1]), self.fake_series([1, 0, 0], [3, 3, 3])]))
        arms, effects = m.make_arm_and_effect_tables(data)
        self.assertAlmostEqual(arms[0]["M2_joint_major_basin_occupancy"], 1 / 6)
        self.assertAlmostEqual(arms[1]["M2_joint_major_basin_occupancy"], 0.5)
        self.assertAlmostEqual(effects[-1]["M2_joint_major_basin_occupancy_TEST_minus_CONTROL"], 1 / 3)
        self.assertEqual(arms[0]["M3_crms_median_deg"], 1)
        self.assertNotEqual(arms[0]["M3_crms_median_deg"], 0.5)
        self.assertEqual(len(effects), 3)

    def test_unequal_replicate_lengths_rejected(self):
        data = {name: self.fake_series([1, 0], [1, 2]) for name in m.core.ROWS}
        data[m.core.ROWS[2]] = self.fake_series([1], [1])
        with self.assertRaisesRegex(RuntimeError, "UNEQUAL_LENGTH"):
            m.make_arm_and_effect_tables(data)

    def test_independent_dihedral_orientation_and_PBC(self):
        rng = np.random.default_rng(118)
        p = rng.normal(size=(300, 4, 3))
        b = np.diff(p, axis=1)
        n0, n1 = np.cross(b[:, 0], b[:, 1]), np.cross(b[:, 1], b[:, 2])
        direction = b[:, 1] / np.linalg.norm(b[:, 1], axis=1)[:, None]
        expected = np.degrees(np.arctan2(np.sum(np.cross(n0, n1) * direction, axis=1), np.sum(n0 * n1, axis=1)))
        boxes = np.broadcast_to(np.eye(3) * 40, (len(p), 3, 3))
        result = m.core.omega_degrees(p, boxes, [0, 1, 2, 3])
        np.testing.assert_allclose(m.periodic_delta_deg(result, expected), 0, atol=1e-12)
        wrapped = np.mod(p + 39, 40)
        np.testing.assert_allclose(m.periodic_delta_deg(m.core.omega_degrees(wrapped, boxes, [0, 1, 2, 3]), expected), 0, atol=1e-10)

    def test_loaded_literal_source_and_five_residue_geometry(self):
        refs, target, reference, pattern = m.load_definition_tables(m.PACKAGE / "authority")
        np.testing.assert_allclose(reference, REF)
        np.testing.assert_array_equal(pattern, TARGET)
        self.assertEqual(target["source_population_ratio"], "98:2")
        self.assertEqual(refs[0]["source_locator"], "JACS2006 SI Table8")

    def test_cyclic_geometry_mapping_is_zero_based_and_consistent(self):
        ns, cas, cs = np.arange(0, 15, 3), np.arange(1, 15, 3), np.arange(2, 15, 3)
        geometry = []
        for i in range(5):
            prev, nxt = (i - 1) % 5, (i + 1) % 5
            geometry.append({"residue_index": i + 1,
                "phi_atoms": [int(x) for x in (cs[prev], ns[i], cas[i], cs[i])],
                "psi_atoms": [int(x) for x in (ns[i], cas[i], cs[i], ns[nxt])],
                "omega_atoms": [int(x) for x in (cas[prev], cs[prev], ns[i], cas[i])]})
        m.validate_geometry(geometry, 56)
        geometry[0]["omega_atoms"][0] = 16
        with self.assertRaisesRegex(RuntimeError, "OMEGA_CONVENTION"):
            m.validate_geometry(geometry, 56)

    def test_real_npz_read_and_recovery_double_offset_rejection(self):
        name, chunk, end = m.core.ROWS[2], 30, 300000
        raw = m.core.PROD_REL / name / "chunks/CAPTURE_30_production_v1.npz"
        receipt = m.core.PROD_REL / name / "checkpoints/ITER_300000/CHECKPOINT_RECEIPT_v1.json"
        record = {"chunk_index": chunk, "phase": "production", "capture_path": str(raw), "capture_sha256": "a" * 64,
                  "checkpoint_receipt_path": str(receipt), "checkpoint_receipt_sha256": "b" * 64}
        mapping = np.tile(np.arange(12), (1000, 1))
        cap = dict(chunk_index=np.array(30), phase=np.array("production"),
            global_iteration_start_exclusive=np.array(290000), global_iteration_end_inclusive=np.array(end),
            capture_1ps_iteration=np.arange(290010, 300001, 10),
            capture_1ps_positions=np.zeros((1000, 56, 3)),
            capture_1ps_box=np.broadcast_to(np.eye(3) * 4, (1000, 3, 3)),
            capture_1ps_mapping=mapping, capture_1ps_lambda1_replica=np.zeros(1000, dtype=np.int64),
            recovery_segment=np.array(1), recovery_local_iteration_start_exclusive=np.array(0),
            recovery_local_iteration_end_inclusive=np.array(10000))
        with tempfile.TemporaryDirectory() as directory:
            file = Path(directory) / "synthetic.npz"

            class FakeReader:
                def digest(self, raw, expected):
                    return expected
                def json(self, raw):
                    return {"global_iteration": 300000, "phase": "production"}
                def touch(self, raw):
                    return file

            np.savez_compressed(file, **cap)
            m.extract_chunk(FakeReader(), record, name, 56, {str(raw): "a" * 64})
            cap["capture_1ps_iteration"] += 290000
            np.savez_compressed(file, **cap)
            with self.assertRaisesRegex(RuntimeError, "PHYSICAL_FRAME_ITERATIONS"):
                m.extract_chunk(FakeReader(), record, name, 56, {str(raw): "a" * 64})

    def test_full_50chunk_scoring_with_synthetic_angles_and_recovery_metadata(self):
        def fake_chunk(reader, record, name, nsolute, baseline):
            i = record["chunk_index"]
            return {"capture_1ps_positions": np.zeros((1000, nsolute, 3)),
                    "capture_1ps_box": np.broadcast_to(np.eye(3), (1000, 3, 3)),
                    "capture_1ps_iteration": np.arange((i - 1) * 10000 + 10, i * 10000 + 1, 10)}

        geometry = []
        for i in range(5):
            geometry.append({"residue_index": i + 1, "phi_atoms": [0, i, 0, 0],
                             "psi_atoms": [1, i, 0, 0], "omega_atoms": [2, i, 0, 0]})

        def fake_angle(positions, boxes, atoms):
            kind, i = atoms[:2]
            value = REF[i, kind] if kind < 2 else 180.0
            return np.full(1000, value)

        manifest = {"records": [{"chunk_index": i} for i in range(1, 61)]}
        with patch.object(m, "extract_chunk", side_effect=fake_chunk), patch.object(m.core, "omega_degrees", side_effect=fake_angle), contextlib.redirect_stdout(io.StringIO()):
            summary, series, blocks = m.analyze_row(None, m.core.ROWS[2], manifest, (REF, TARGET, geometry, 56), {})
        self.assertEqual(summary["frames"], 50000)
        self.assertEqual(summary["M2_major_frames"], 50000)
        self.assertEqual(summary["recovery_boundary_global_iteration"], 290000)
        self.assertEqual(series["iteration"][0], 100010)
        self.assertEqual(series["iteration"][-1], 600000)
        self.assertEqual(len(blocks), 5)


if __name__ == "__main__":
    unittest.main(verbosity=2)
