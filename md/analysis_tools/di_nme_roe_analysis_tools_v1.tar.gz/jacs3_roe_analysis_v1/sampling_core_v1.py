#!/usr/bin/env python3
"""CPU-only closed-run sampling diagnostics; not an M1/M2/M3 analysis."""
from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile
import time
import traceback

import numpy as np

VERSION = "402EC_JACS3_FOURROW_SAMPLING_V1"
DEV_REL = Path("07_nmeala_separability_pilot/13_joint_correction_development")
PROD_REL = DEV_REL / "232e_formal_exact20_production_v5"
CX_REL = DEV_REL / "21l_post_m4_final_production_protocol_freeze_v2"
ROWS = (
    "ROW09_TIERA_JACS3_CONTROL_R1", "ROW10_TIERA_JACS3_TEST_R1",
    "ROW11_TIERA_JACS3_CONTROL_R2", "ROW12_TIERA_JACS3_TEST_R2",
)
ENDPOINT_FREEZE = DEV_REL / "16f_post_m4_cyclic_transfer_tiera_analysis_precommit" / (
    "NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ANALYSIS_PRECOMMIT_FREEZE_v1.sha256")
ENDPOINT_FREEZE_SHA = "a23bc0eb9ccbf024ad86af04c9115bfcd48b687d2e19f560bbb2b2712a0f17e4"
SITES = {"D-Ala1": [22, 23, 0, 1], "L-Ala5": [17, 18, 21, 22]}
NREP = 12
CP_ITER = 10000
EQUIL_ITER = 100000
FINAL_ITER = 600000


def require(ok, message):
    if not bool(ok):
        raise RuntimeError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path, obj):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(obj, stream, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


class Reader:
    """Allow only closed JACS3 rows and explicit static definitions; never NC."""
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.snapshots = {}
        self.digests = {}

    def path(self, raw):
        raw = Path(raw)
        require(not raw.is_absolute() and ".." not in raw.parts, "UNSAFE_INPUT_PATH")
        path = self.root / raw
        require(not path.is_symlink(), f"SYMLINK_INPUT: {raw}")
        resolved = path.resolve()
        require(resolved.is_relative_to(self.root), "INPUT_OUTSIDE_PROJECT")
        require(path.suffix.lower() not in (".nc", ".chk"), "FORBIDDEN_INPUT_TYPE")
        if raw.is_relative_to(PROD_REL):
            parts = raw.relative_to(PROD_REL).parts
            permitted = parts[0] in ROWS or (
                parts[0] == "_launch_logs" and len(parts) == 2
                and parts[1] in tuple(name + ".log" for name in ROWS))
            require(permitted, f"UNAUTHORIZED_PRODUCTION_ROW: {raw}")
        return path

    def touch(self, raw):
        path = self.path(raw)
        require(path.is_file(), f"MISSING_INPUT: {raw}")
        st = path.stat()
        signature = (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns)
        if str(raw) in self.snapshots:
            require(self.snapshots[str(raw)] == signature, f"INPUT_CHANGED: {raw}")
        else:
            self.snapshots[str(raw)] = signature
        return path

    def digest(self, raw, expected=None):
        path = self.touch(raw)
        key = str(raw)
        if key not in self.digests:
            self.digests[key] = sha(path)
        actual = self.digests[key]
        require(expected is None or actual == expected, f"SHA_MISMATCH: {raw}")
        return actual

    def json(self, raw):
        return json.loads(self.touch(raw).read_text(encoding="utf-8"))

    def text(self, raw):
        return self.touch(raw).read_text(encoding="utf-8")

    def check_unchanged(self):
        for raw in list(self.snapshots):
            self.touch(raw)


def parse_freeze(text):
    entries = []
    for line in text.splitlines():
        if not line.strip():
            continue
        expected, raw = line.split(None, 1)
        require(re.fullmatch(r"[0-9a-f]{64}", expected), "BAD_FREEZE_SHA")
        entries.append((expected, raw.strip()))
    require(entries, "EMPTY_FREEZE")
    require(len({p for _, p in entries}) == len(entries), "DUPLICATE_FREEZE_MEMBER")
    return entries


def verify_final_freeze(reader, row):
    for expected, raw in parse_freeze(reader.text(row / "FORMAL_RUN_FINAL_FREEZE_v1.sha256")):
        p = Path(raw)
        require(p.is_relative_to(row) or p in (
            DEV_REL / "run_402EC_formal_exact20_worker_v5.py",
            DEV_REL / "run_402EC_ROW11_formal_recovery_from_290000_v1.py"),
            "UNEXPECTED_FINAL_FREEZE_MEMBER")
        reader.digest(p, expected)


def validate_mapping(mapping, rows, nrep=NREP):
    require(mapping.shape == (rows, nrep), "MAPPING_SHAPE")
    require(np.issubdtype(mapping.dtype, np.integer), "NONINTEGER_MAPPING")
    require(np.array_equal(np.sort(mapping, axis=1),
                          np.broadcast_to(np.arange(nrep), mapping.shape)), "MAPPING_NOT_PERMUTATION")


def validate_audit(audit, start, end, nrep=NREP):
    n = end - start
    require(np.array_equal(audit["iteration"], np.arange(start + 1, end + 1)), "AUDIT_GLOBAL_ITERATIONS")
    before, after = audit["before"], audit["after"]
    validate_mapping(before, n, nrep)
    validate_mapping(after, n, nrep)
    require(np.array_equal(before[1:], after[:-1]), "AUDIT_WITHIN_CHUNK_MAPPING_HANDOFF")
    energy, proposed, accepted = (audit[k] for k in ("energy", "proposed", "accepted"))
    for label, array in (("energy", energy), ("proposed", proposed), ("accepted", accepted)):
        require(array.shape == (n, nrep, nrep), label + "_SHAPE")
        require(np.isfinite(array).all(), label + "_NONFINITE")
    adjacent = np.abs(np.arange(nrep)[:, None] - np.arange(nrep)[None, :]) == 1
    require(np.all(proposed[:, ~adjacent] == 0), "NONNEIGHBOR_PROPOSAL")
    require(np.all((proposed == 0) | (proposed == 1)), "NONBINARY_PROPOSAL")
    require(np.all((accepted == 0) | (accepted == 1)), "NONBINARY_ACCEPTANCE")
    require(np.all(accepted <= proposed), "ACCEPTED_WITHOUT_PROPOSAL")
    require(np.array_equal(proposed, proposed.swapaxes(1, 2)), "ASYMMETRIC_PROPOSAL")
    require(np.array_equal(accepted, accepted.swapaxes(1, 2)), "ASYMMETRIC_ACCEPTANCE")
    require(np.all(proposed.sum(axis=2) <= 1), "OVERLAPPING_NEIGHBOR_PROPOSALS")
    # Each event must propose precisely one of the two swap-neighbors matchings.
    even = np.zeros((nrep, nrep), dtype=np.int8)
    odd = even.copy()
    for parity, matrix in ((0, even), (1, odd)):
        for i in range(parity, nrep - 1, 2):
            matrix[i, i + 1] = matrix[i + 1, i] = 1
    valid_proposals = np.all(proposed == even, axis=(1, 2)) | np.all(proposed == odd, axis=(1, 2))
    require(valid_proposals.all(), "PROPOSAL_MATCHING_NOT_SWAP_NEIGHBORS")
    inverse = np.argsort(before, axis=1)
    expected_after = before.copy()
    probability = np.empty((n, nrep - 1), dtype=np.float64)
    ti = np.arange(n)
    for i in range(nrep - 1):
        j = i + 1
        ri, rj = inverse[:, i], inverse[:, j]
        logp = -energy[ti, ri, j] - energy[ti, rj, i] + energy[ti, ri, i] + energy[ti, rj, j]
        require(np.isfinite(logp).all(), "NONFINITE_EXCHANGE_LOG_RATIO")
        probability[:, i] = np.exp(np.minimum(0.0, logp))
        mask = accepted[:, i, j] == 1
        expected_after[ti[mask], ri[mask]] = j
        expected_after[ti[mask], rj[mask]] = i
    require(np.array_equal(after, expected_after), "MAPPING_ACCEPTANCE_INCONSISTENT")
    prop_edge = proposed[:, np.arange(nrep - 1), np.arange(1, nrep)]
    acc_edge = accepted[:, np.arange(nrep - 1), np.arange(1, nrep)]
    return {
        "proposed": prop_edge.sum(axis=0), "accepted": acc_edge.sum(axis=0),
        "expected_proposed_sum": (probability * prop_edge).sum(axis=0),
        "expected_all_sum": probability.sum(axis=0),
    }


CAPTURE_KEYS = (
    "capture_1ps_iteration", "capture_1ps_lambda1_replica", "capture_1ps_positions",
    "capture_1ps_box", "capture_1ps_mapping", "capture_1ps_energy",
    "capture_10ps_iteration", "capture_10ps_positions", "capture_10ps_box",
    "capture_10ps_mapping",
)
AUDIT_KEYS = ("iteration", "before", "after", "energy", "proposed", "accepted")


def load_npz(reader, raw, keys):
    with np.load(reader.touch(raw), allow_pickle=False) as z:
        require(all(key in z.files for key in keys), f"MISSING_NPZ_FIELDS: {raw}")
        return {k: z[k] for k in keys}


def validate_capture(cap, audit, start, end, nsolute, nrep=NREP):
    n1, n10 = (end - start) // 10, (end - start) // 100
    for cadence, count in ((1, n1), (10, n10)):
        stride = cadence * 10
        require(np.array_equal(cap[f"capture_{cadence}ps_iteration"],
                               np.arange(start + stride, end + 1, stride)), "CAPTURE_GLOBAL_ITERATIONS")
        validate_mapping(cap[f"capture_{cadence}ps_mapping"], count, nrep)
        extra = () if cadence == 1 else (nrep,)
        require(cap[f"capture_{cadence}ps_positions"].shape == (count,) + extra + (nsolute, 3),
                "POSITIONS_SHAPE")
        boxes = cap[f"capture_{cadence}ps_box"]
        require(boxes.shape == (count,) + extra + (3, 3), "BOX_SHAPE")
        for key in (f"capture_{cadence}ps_positions", f"capture_{cadence}ps_box"):
            require(np.isfinite(cap[key]).all(), "NONFINITE_COORDINATES_OR_BOX")
        require(np.all(np.linalg.det(boxes) > 0), "NONPOSITIVE_BOX_VOLUME")
        audited = audit["after"][stride - 1::stride]
        require(np.array_equal(cap[f"capture_{cadence}ps_mapping"], audited), "CAPTURE_AUDIT_MAPPING")
    replica = cap["capture_1ps_lambda1_replica"]
    require(replica.shape == (n1,) and np.issubdtype(replica.dtype, np.integer), "LAMBDA1_WALKER_SHAPE")
    require(np.all((replica >= 0) & (replica < nrep)), "LAMBDA1_WALKER_RANGE")
    require(np.all(cap["capture_1ps_mapping"][np.arange(n1), replica] == 0), "NOT_PHYSICAL_LAMBDA1")
    require(cap["capture_1ps_energy"].shape == (n1, nrep, nrep), "CAPTURE_ENERGY_SHAPE")
    require(np.isfinite(cap["capture_1ps_energy"]).all(), "NONFINITE_CAPTURE_ENERGY")
    # Audit i+1 uses energies from the post-propagation report at iteration i.
    require(np.array_equal(cap["capture_1ps_energy"][:-1], audit["energy"][10::10]),
            "CAPTURE_ENERGY_AUDIT_HANDOFF")
    at1 = np.arange(9, n1, 10)
    at10 = np.arange(n10)
    require(np.array_equal(cap["capture_10ps_positions"][at10, replica[at1]],
                           cap["capture_1ps_positions"][at1]), "CROSS_STREAM_POSITIONS_DIFFER")
    require(np.array_equal(cap["capture_10ps_box"][at10, replica[at1]],
                           cap["capture_1ps_box"][at1]), "CROSS_STREAM_BOX_DIFFER")


def omega_degrees(positions, boxes, atoms):
    """Minimum-image bonded dihedral, in degrees. Used for sampling only."""
    p = np.asarray(positions, dtype=np.float64)[..., atoms, :]
    bonds = np.diff(p, axis=-2)
    boxes = np.asarray(boxes, dtype=np.float64)
    # Frozen DMSO boxes are expected to be orthorhombic. Refuse a different cell
    # rather than silently applying a nearest-image approximation to skew boxes.
    diagonal = np.zeros_like(boxes)
    diagonal[..., np.arange(3), np.arange(3)] = boxes[..., np.arange(3), np.arange(3)]
    require(np.allclose(boxes, diagonal, atol=1e-12, rtol=0), "SKEW_BOX_NEEDS_EXPLICIT_IMAGE_REVIEW")
    lengths = np.diagonal(boxes, axis1=-2, axis2=-1)[..., None, :]
    require(np.all(lengths > 0), "INVALID_BOX_LENGTH")
    bonds -= np.rint(bonds / lengths) * lengths
    b0, b1, b2 = -bonds[..., 0, :], bonds[..., 1, :], bonds[..., 2, :]
    norm = np.linalg.norm(b1, axis=-1, keepdims=True)
    require(np.all(norm > 1e-12), "DEGENERATE_DIHEDRAL_BOND")
    b1 = b1 / norm
    v = b0 - (b0 * b1).sum(axis=-1, keepdims=True) * b1
    w = b2 - (b2 * b1).sum(axis=-1, keepdims=True) * b1
    require(np.all(np.linalg.norm(v, axis=-1) > 1e-12) and
            np.all(np.linalg.norm(w, axis=-1) > 1e-12), "DEGENERATE_DIHEDRAL_PLANE")
    x = (v * w).sum(axis=-1)
    y = (np.cross(b1, v) * w).sum(axis=-1)
    return np.degrees(np.arctan2(y, x))


def basin_labels(angles):
    absolute = np.abs(angles)
    return np.where(absolute <= 60.0, 1, np.where(absolute >= 120.0, 2, 0)).astype(np.int8)


def norm_entropy(counts):
    counts = np.asarray(counts, dtype=float)
    p = counts / counts.sum(axis=-1, keepdims=True)
    return -(p * np.log(np.where(p > 0, p, 1))).sum(axis=-1) / np.log(counts.shape[-1])


def count_roundtrips(mapping_segments, nrep=NREP):
    """Two alternating endpoint passages complete a trip; reset per segment."""
    result = np.zeros(nrep, dtype=np.int64)
    for segment in mapping_segments:
        for walker in range(nrep):
            sequence = segment[:, walker]
            sequence = sequence[(sequence == 0) | (sequence == nrep - 1)]
            result[walker] += int(np.count_nonzero(np.diff(sequence))) // 2
    return result


class Crossings:
    def __init__(self, nrep=NREP):
        self.nrep = nrep
        self.previous = np.zeros(nrep, dtype=np.int8)
        self.walker_counts = np.zeros(nrep, dtype=np.int64)
        self.state_counts = np.zeros(nrep, dtype=np.int64)
        self.state_population = np.zeros((nrep, 3), dtype=np.int64)

    def reset_boundary(self):
        self.previous[:] = 0

    def update(self, labels, mapping):
        require(labels.shape == mapping.shape, "CROSSING_SHAPE")
        for state in range(self.nrep):
            self.state_population[state] += np.bincount(labels[mapping == state], minlength=3)
        for w in range(self.nrep):
            indices = np.flatnonzero(labels[:, w] != 0)
            if not len(indices):
                continue
            seq = labels[indices, w]
            preceding = np.r_[self.previous[w], seq[:-1]]
            changed = (preceding != 0) & (seq != preceding)
            self.walker_counts[w] += int(changed.sum())
            self.state_counts += np.bincount(mapping[indices[changed], w], minlength=self.nrep)
            self.previous[w] = seq[-1]

    def result(self):
        total = int(self.walker_counts.sum())
        classes = ("NO_COMMITTED_INTERCONVERSION_OBSERVED", "SINGLE_COMMITTED_INTERCONVERSION_OBSERVED")
        return {
            "crossings": total,
            "class": classes[total] if total < 2 else "COMMITTED_RETURN_OBSERVED",
            "crossings_by_walker": self.walker_counts.tolist(),
            "crossings_by_state_at_destination": self.state_counts.tolist(),
            "state_counts_order": ["intermediate", "cis", "trans"],
            "state_population_counts": self.state_population.tolist(),
            "state_population_fractions": (self.state_population / self.state_population.sum(axis=1)[:, None]).tolist(),
            "physical_kinetic_rate_interpretation": False,
        }


def collect_endpoint_sources(reader, output, precommits):
    """Copy only explicit small frozen metadata; never a trajectory or ROE target."""
    records, selected = [], []
    missing_freeze = not reader.path(ENDPOINT_FREEZE).is_file()
    if not missing_freeze:
        reader.digest(ENDPOINT_FREEZE, ENDPOINT_FREEZE_SHA)
        selected.append((ENDPOINT_FREEZE_SHA, str(ENDPOINT_FREEZE)))
        selected.extend(parse_freeze(reader.text(ENDPOINT_FREEZE)))
    else:
        records.append({"path": str(ENDPOINT_FREEZE), "status": "MISSING_ON_SERVER"})
    # Include the pinned build report and input-pins files, plus their small
    # same-directory topology metadata. Physical XML and all coordinates excluded.
    build_reports = set()
    for precommit in precommits:
        for expected, raw in parse_freeze(reader.text(precommit)):
            if Path(raw).name in ("BUILD_REPORT_v1.json", "INPUT_PINS_v1.json"):
                selected.append((expected, raw))
                if Path(raw).name == "BUILD_REPORT_v1.json":
                    build_reports.add(Path(raw))
    for raw in build_reports:
        directory = reader.path(raw).parent
        for path in sorted(directory.iterdir()):
            if path.is_file() and not path.is_symlink() and path.suffix.lower() in (
                ".json", ".tsv", ".csv", ".txt", ".sha256"):
                selected.append((None, str(path.relative_to(reader.root))))
    seen = set()
    total_bytes = 0
    for expected, raw in selected:
        if raw in seen:
            continue
        seen.add(raw)
        suffix = Path(raw).suffix.lower()
        # Filename-based exclusion of ROE-labelled sources. Metadata copying is
        # not a claim of blinded access to every possible experimental label.
        if "roe" in raw.lower() or suffix not in (
            ".py", ".json", ".tsv", ".csv", ".txt", ".md", ".sha256"):
            records.append({"path": raw, "status": "NOT_COPIED_OUT_OF_STAGE_SCOPE", "expected_sha256": expected})
            continue
        path = reader.path(raw)
        if not path.is_file():
            records.append({"path": raw, "status": "MISSING_ON_SERVER", "expected_sha256": expected})
            continue
        size = path.stat().st_size
        if size > 2 * 1024**2 or total_bytes + size > 20 * 1024**2:
            records.append({"path": raw, "status": "SIZE_LIMIT_NOT_COPIED", "size": size})
            continue
        digest = reader.digest(raw, expected)
        destination = output / "endpoint_sources" / raw
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(reader.touch(raw), destination)
        require(sha(destination) == digest, "ENDPOINT_COPY_SHA")
        total_bytes += size
        records.append({"path": raw, "status": "COPIED_METADATA_ONLY", "sha256": digest,
                        "pin_origin": "frozen_sha256" if expected else "unverified_auxiliary_metadata"})
    write_json(output / "ENDPOINT_SOURCE_INVENTORY_v1.json", records)
    return {"analysis_precommit_freeze_available": not missing_freeze,
            "copied_bytes": total_bytes, "scientific_endpoint_evaluation": False}


def preflight(reader, pins):
    for raw, expected in pins.items():
        reader.digest(raw, expected)
    protocol = reader.json(CX_REL / "402CX_v2_FINAL_PRODUCTION_PROTOCOL_v1.json")
    require(protocol["primary_endpoint"]["metric"] == "M2_JOINT_MAJOR_BASIN_OCCUPANCY", "PRIMARY_ENDPOINT_CHANGED")
    require(protocol["run_schedule"]["per_run_equilibration_ns"] == 10, "EQUIL_CHANGED")
    require(protocol["run_schedule"]["per_run_recorded_production_ns"] == 50, "PRODUCTION_CHANGED")
    require(protocol["rest2"]["replicas"] == NREP, "REPLICA_COUNT_CHANGED")
    require(protocol["sampling_adequacy"]["committed_cis"] == "abs(omega)<=60 degrees", "CIS_BASIN_CHANGED")
    require(protocol["sampling_adequacy"]["committed_trans"] == "abs(omega)>=120 degrees", "TRANS_BASIN_CHANGED")
    require(protocol["cohort"]["formal_production_run_count"] == 20, "ORIGINAL_COHORT_CHANGED")
    screen = reader.text(DEV_REL / "233_jacs3_r1_sampling_only_screen_v1/JACS3_R1_SAMPLING_ONLY_DECISION_SCREEN_v1.log")
    for site, atoms in SITES.items():
        matches = re.findall(re.escape(site) + r" omega_atoms=(\[[^\n]+?\])", screen)
        require(len(matches) == 2 and all(ast.literal_eval(m) == atoms for m in matches), "DIAGNOSTIC_ATOM_MAPPING_CHANGED")
    with reader.touch(CX_REL / "402CX_v2_PRODUCTION_STARTS_AND_SEEDS_v1.tsv").open(newline="") as stream:
        starts = list(csv.DictReader(stream, delimiter="\t"))
    require(len(starts) == 20, "STARTS_ROW_COUNT")
    contracts, manifests = {}, {}
    precommits = []
    for name in ROWS:
        row = PROD_REL / name
        contract, result = (reader.json(row / f"FORMAL_RUN_{kind}_v1.json") for kind in ("CONTRACT", "RESULT"))
        row_index = int(name[3:5])
        arm, rep = name.rsplit("_", 2)[-2:]
        for obj in (contract, result):
            require(obj["row_index"] == row_index and obj["benchmark"] == "TIERA_JACS3"
                    and obj["arm"] == arm and obj["replicate"] == rep, "ROW_IDENTITY_CHANGED")
        require(result["final_iteration"] == FINAL_ITER and result["total_ns_per_replica"] == 60
                and result["recorded_production_ns_per_replica"] == 50, "ROW_NOT_COMPLETE")
        require(result["final_context_steps"] == FINAL_ITER * NREP * 100, "FINAL_STEP_COUNT")
        allowed = "FORMAL_EXACT20_RUN_COMPLETE" + ("_WITH_AUTHORIZED_RECOVERY" if row_index == 11 else "")
        require(result["status"] == allowed, "ROW_RESULT_STATUS")
        require(contract["formal_protocol_sha256"] == pins[str(CX_REL / "402CX_v2_FINAL_PRODUCTION_PROTOCOL_v1.json")], "ROW_PROTOCOL_SHA")
        for key in ("initial_velocity_seed", "integrator_seed", "exchange_seed"):
            require(contract[key] == result[key] == int(starts[row_index - 1][key]), "ROW_SEED_MISMATCH")
        log = reader.text(PROD_REL / "_launch_logs" / (name + ".log"))
        commits = [(int(a), int(b)) for a, b in re.findall(r"\[402EC FORMAL COMMIT\] chunk=(\d+)/60 iteration=(\d+)", log)]
        require(commits == [(i, i * CP_ITER) for i in range(1, 61)], "COMMIT_SEQUENCE")
        require(log.count("===== 402EC FORMAL EXACT20 WORKER END =====") == 1, "WORKER_END")
        verify_final_freeze(reader, row)
        manifest = reader.json(row / "FORMAL_RUN_STORAGE_MANIFEST_v1.json")
        require(manifest["status"] == "FORMAL_STORAGE_COMPLETE" and manifest["record_count"] == 60
                and [r["chunk_index"] for r in manifest["records"]] == list(range(1, 61)), "MANIFEST_SEQUENCE")
        contracts[name], manifests[name] = contract, manifest
        precommits.append(row / "FORMAL_RUN_PRECOMMIT_v1.sha256")
    for rep in ("R1", "R2"):
        ctrl, test = [contracts[n] for n in ROWS if n.endswith(rep)]
        require(ctrl["arm"] == "CONTROL" and test["arm"] == "TEST", "PAIR_ORDER")
        for key in ("formal_start_sha256", "initial_velocity_seed", "integrator_seed", "exchange_seed"):
            require(ctrl[key] == test[key], "PAIRED_DESIGN_CHANGED")
    require(contracts[ROWS[0]]["exchange_seed"] != contracts[ROWS[2]]["exchange_seed"], "REPLICATE_SEEDS_NOT_DISTINCT")
    recovery_row = PROD_REL / ROWS[2]
    boundary = reader.json(recovery_row / "FORMAL_RECOVERY_BOUNDARY_v1.json")
    recovery = reader.json(recovery_row / "FORMAL_RECOVERY_CONTRACT_v1.json")
    require(boundary["boundary_global_iteration"] == 290000
            and boundary["excluded_original_reporter_iterations"] == [290001, 295253]
            and boundary["first_recovery_iteration_global"] == 290001, "RECOVERY_BOUNDARY_CHANGED")
    require(recovery["kinetic_continuity_claim_across_recovery_boundary"] is False
            and recovery["recovery_semantics"] == "ENSEMBLE_VALID_STOCHASTIC_CHECKPOINT_RECOVERY",
            "RECOVERY_SEMANTICS_CHANGED")
    require(manifests[ROWS[2]]["recovery_boundaries"][0]["global_iteration"] == 290000, "MANIFEST_RECOVERY_BOUNDARY")
    print("[PASS] pinned source, frozen 10+50ns protocol, paired design and four closed lifecycles", flush=True)
    print("[PASS] ROW11 uses committed global chunks; original reporter tail is never opened", flush=True)
    return protocol, contracts, manifests, precommits


def process_row(reader, name, manifest):
    row = PROD_REL / name
    recovered = name == ROWS[2]
    proposal = np.zeros(NREP - 1, dtype=np.int64)
    accepted = proposal.copy()
    expected_sum = np.zeros(NREP - 1)
    expected_all = expected_sum.copy()
    contributions = np.zeros(NREP, dtype=np.int64)
    visitation = np.zeros((NREP, NREP), dtype=np.int64)
    crossings = {site: Crossings() for site in SITES}
    physical_labels = {site: [] for site in SITES}
    mapping_segments = [[]]
    chunk_rows = []
    previous_after = None
    nsolute = None
    for record in manifest["records"]:
        chunk = record["chunk_index"]
        phase = "equilibration" if chunk <= 10 else "production"
        require(record["phase"] == phase, "MANIFEST_PHASE")
        expected_paths = {
            "capture": row / "chunks" / f"CAPTURE_{chunk:02d}_{phase}_v1.npz",
            "exchange_audit": row / "chunks" / f"EXCHANGE_AUDIT_{chunk:02d}_{phase}_v1.npz",
            "checkpoint_receipt": row / "checkpoints" / f"ITER_{chunk * CP_ITER:06d}" / "CHECKPOINT_RECEIPT_v1.json",
        }
        for kind, raw in expected_paths.items():
            require(record[kind + "_path"] == str(raw), "UNEXPECTED_STORAGE_PATH")
            reader.digest(raw, record[kind + "_sha256"])
        receipt = reader.json(expected_paths["checkpoint_receipt"])
        require(receipt["global_iteration"] == chunk * CP_ITER and receipt["phase"] == phase, "RECEIPT_ITERATION")
        require(receipt["context_steps"] == chunk * CP_ITER * NREP * 100, "RECEIPT_CONTEXT_STEPS")
        # Technical binary/app restart files are not needed for coordinate analysis.
        # The receipt hashes are verified; their binary payloads are not reopened.
        if chunk <= 10:
            continue
        start, end = (chunk - 1) * CP_ITER, chunk * CP_ITER
        keys = list(CAPTURE_KEYS) + ["chunk_index", "global_iteration_start_exclusive", "global_iteration_end_inclusive", "phase"]
        if recovered and chunk >= 30:
            keys += ["recovery_segment", "recovery_local_iteration_start_exclusive", "recovery_local_iteration_end_inclusive"]
        cap = load_npz(reader, expected_paths["capture"], keys)
        audit = load_npz(reader, expected_paths["exchange_audit"], AUDIT_KEYS)
        scalar = lambda k: np.asarray(cap[k]).item()
        require(scalar("chunk_index") == chunk and scalar("global_iteration_start_exclusive") == start
                and scalar("global_iteration_end_inclusive") == end and scalar("phase") == "production", "CAPTURE_BOUNDARY_METADATA")
        if recovered and chunk >= 30:
            require(scalar("recovery_segment") == 1
                    and scalar("recovery_local_iteration_start_exclusive") == start - 290000
                    and scalar("recovery_local_iteration_end_inclusive") == end - 290000, "RECOVERY_LOCAL_GLOBAL_OFFSET")
        stats = validate_audit(audit, start, end)
        if previous_after is not None:
            require(np.array_equal(previous_after, audit["before"][0]), "INTERCHUNK_MAPPING_HANDOFF")
        previous_after = audit["after"][-1].copy()
        current_nsolute = cap["capture_1ps_positions"].shape[-2]
        nsolute = current_nsolute if nsolute is None else nsolute
        require(nsolute == current_nsolute and nsolute > max(max(v) for v in SITES.values()), "SOLUTE_ATOM_COUNT")
        validate_capture(cap, audit, start, end, nsolute)
        if recovered and chunk == 30:
            mapping_segments.append([])
            for tracker in crossings.values():
                tracker.reset_boundary()
        mapping_segments[-1].append(audit["after"].astype(np.uint8))
        proposal += stats["proposed"]
        accepted += stats["accepted"]
        expected_sum += stats["expected_proposed_sum"]
        expected_all += stats["expected_all_sum"]
        contributions += np.bincount(cap["capture_1ps_lambda1_replica"], minlength=NREP)
        for w in range(NREP):
            visitation[w] += np.bincount(audit["after"][:, w], minlength=NREP)
        for site, atoms in SITES.items():
            labels = basin_labels(omega_degrees(cap["capture_10ps_positions"], cap["capture_10ps_box"], atoms))
            crossings[site].update(labels, cap["capture_10ps_mapping"])
            physical_labels[site].append(basin_labels(omega_degrees(cap["capture_1ps_positions"], cap["capture_1ps_box"], atoms)))
        chunk_rows.append({"chunk": chunk, "global_start_exclusive": start, "global_end_inclusive": end,
                           "lambda1_frames": 1000, "all_replica_frames": 100,
                           "recovery_segment": int(recovered and chunk >= 30)})
        if chunk % 10 == 0:
            print(f"[PROGRESS] {name} verified production chunks {chunk - 10}/50", flush=True)
    require(np.all(proposal > 0), "NO_EDGE_PROPOSALS")
    require(contributions.sum() == 50000 and np.all(visitation.sum(axis=1) == 500000), "PRODUCTION_FRAME_COUNTS")
    segments = [np.concatenate(segment, axis=0) for segment in mapping_segments]
    trips = count_roundtrips(segments)
    fractions = contributions / contributions.sum()
    limitations = []
    if np.count_nonzero(contributions) < NREP:
        limitations.append("Not every walker contributed to the physical-state stream; retain all runs/sites.")
    if np.any(np.count_nonzero(visitation, axis=1) < NREP):
        limitations.append("At least one walker did not visit all states; retain and report the limitation.")
    for site, tracker in crossings.items():
        if tracker.walker_counts.sum() < 2:
            limitations.append(site + ": fewer than two sampled committed crossings; no site deletion or extension authorized.")
    blocks, populations = [], {}
    for site in SITES:
        labels = np.concatenate(physical_labels[site])
        require(len(labels) == 50000, "OMEGA_PHYSICAL_FRAME_COUNT")
        counts = np.bincount(labels, minlength=3)
        populations[site] = {"order": ["intermediate", "cis", "trans"], "counts": counts.tolist(),
                             "fractions": (counts / len(labels)).tolist()}
        for block in range(5):
            part = labels[block * 10000:(block + 1) * 10000]
            values = np.bincount(part, minlength=3) / len(part)
            blocks.append({"row": name, "site": site, "production_start_ns": block * 10,
                           "production_end_ns": (block + 1) * 10, "frames": len(part),
                           "intermediate_fraction": float(values[0]), "cis_fraction": float(values[1]),
                           "trans_fraction": float(values[2]), "scientific_endpoint": False})
    return {
        "row": name, "status": "SAMPLING_DIAGNOSTICS_COMPLETE_NOT_SCIENTIFIC_CONCLUSION",
        "solute_atom_count": nsolute, "exchange_events": 500000, "lambda1_frames": 50000,
        "all_replica_frames": 5000, "all_storage_chunk_hashes_verified": 60,
        "technical_NC_read": False, "restart_binary_payloads_read": False,
        "edge_observed": (accepted / proposal).tolist(),
        "edge_expected_on_proposed_events": (expected_sum / proposal).tolist(),
        "edge_expected_on_all_events": (expected_all / 500000).tolist(),
        "edge_proposals": proposal.tolist(), "edge_acceptances": accepted.tolist(),
        "visitation_counts_by_walker": visitation.tolist(),
        "unique_states_by_walker": np.count_nonzero(visitation, axis=1).tolist(),
        "state_entropy_by_walker": norm_entropy(visitation).tolist(),
        "walkers_both_endpoints": int(((visitation[:, 0] > 0) & (visitation[:, -1] > 0)).sum()),
        "roundtrips_by_walker": trips.tolist(), "roundtrips_total": int(trips.sum()),
        "roundtrip_definition": "first endpoint -> opposite -> first; first endpoint may be either; reset at actual recovery",
        "lambda1_counts_by_walker": contributions.tolist(), "lambda1_fraction_by_walker": fractions.tolist(),
        "lambda1_entropy": float(norm_entropy(contributions)),
        "lambda1_walker_inverse_simpson_effective_number": float(1 / np.sum(fractions**2)),
        "walker_effective_number_is_NOT_independent_configuration_ESS": True,
        "cross_stream_max_residual_nm": 0.0,
        "omega_diagnostic_atom_indices": SITES,
        "omega_mapping_authority": "SHA-pinned prior R1 sampling-screen log; not a new M2 atom mapping",
        "omega_committed_crossings": {site: tracker.result() for site, tracker in crossings.items()},
        "sampling_limitations_descriptive_not_pass_fail_gate": limitations,
        "lambda1_omega_populations_diagnostic_only": populations,
        "chunks": chunk_rows, "diagnostic_10ns_blocks": blocks,
        "recovery_boundary_global_iteration": 290000 if recovered else None,
        "original_reporter_tail_excluded": [290001, 295253] if recovered else None,
        "kinetic_continuity_claim": False, "physical_transition_rates_computed": False,
    }


def export_review(output):
    archive = output / "JACS3_SAMPLING_AND_ENDPOINT_REVIEW_v1.tar.gz"
    files = [p for p in sorted(output.rglob("*")) if p.is_file() and p != archive and p.suffix != ".log"]
    with tarfile.open(archive, "w:gz") as tar:
        for path in files:
            tar.add(path, arcname=path.relative_to(output), recursive=False)
    print("REVIEW_ARCHIVE_SHA256=" + sha(archive), flush=True)
    print("UPLOAD_THIS_EXACT_FILE=" + str(archive), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default="/mnt/lab/zn/mem-perm/P0_starter_v1")
    parser.add_argument("--output", required=True)
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args()
    reader = Reader(args.root)
    output = Path(args.output).absolute()
    require(output.resolve().is_relative_to(reader.root / DEV_REL), "OUTPUT_MUST_BE_IN_PROJECT_DEV")
    require(not output.resolve().is_relative_to(reader.root / PROD_REL), "PRODUCTION_OUTPUT_WRITE_FORBIDDEN")
    require(not output.exists(), "OUTPUT_EXISTS_NO_OVERWRITE")
    script_dir = Path(__file__).resolve().parent
    pins = json.loads((script_dir / "SOURCE_PINS_v1.json").read_text(encoding="utf-8"))
    t0 = time.monotonic()
    print("===== JACS3 FOUR-ROW CPU SAMPLING BEGIN =====", flush=True)
    print("VERSION=" + VERSION, flush=True)
    print("MD=False CONTEXT=False GPU=False M1=False M2=False M3=False ROE=False MBAR=False", flush=True)
    try:
        protocol, contracts, manifests, precommits = preflight(reader, pins)
        if args.preflight_only:
            reader.check_unchanged()
            print("[PASS] read-only preflight; no output created", flush=True)
            return 0
        output.mkdir(parents=False, exist_ok=False)
        write_json(output / "EXECUTION_SCOPE_v1.json", {
            "version": VERSION, "sampling_only": True, "rows": list(ROWS),
            "primary_M2_evaluation": False, "ROE_analysis": False, "NMR_guided_sampling_changes": False,
            "admitted_frames": "global 100010..600000, stride 10, physical state 0; only committed CAPTURE chunks 11..60",
            "ROW11_recovery_boundary": 290000, "ROW11_original_reporter_tail_not_read": [290001, 295253],
            "crossing_counters_reset_at_recovery": True,
            "original_frozen_cohort": protocol["cohort"],
            "current_requested_reduced_cohort": ["TIERA_JACS1", "TIERA_JACS3", "TIERA_JACS4"],
            "reduced_cohort_is_not_original_five_peptide_confirmatory_analysis": True,
            "post_results_endpoint_retuning": False, "sampling_diagnostics_trigger_new_MD": False,
            "no_sampling_success_threshold_or_p_value": True,
            "M2_reference_atom_mapping_not_in_uploaded_source_package": True,
        })
        endpoint_inventory = collect_endpoint_sources(reader, output, precommits)
        write_json(output / "ENDPOINT_STAGE_STATUS_v1.json", endpoint_inventory)
        results = []
        for name in ROWS:
            result = process_row(reader, name, manifests[name])
            results.append(result)
            write_json(output / (name + ".sampling_v1.json"), result)
            print(f"[ROW COMPLETE] {name}: 50000 physical frames; edge min={min(result['edge_observed']):.6f}; "
                  f"walker Neff={result['lambda1_walker_inverse_simpson_effective_number']:.4f}", flush=True)
        reader.check_unchanged()
        write_json(output / "INPUT_HASHES_v1.json", reader.digests)
        with (output / "SAMPLING_SUMMARY_v1.tsv").open("x", encoding="utf-8", newline="") as stream:
            fields = ["row", "lambda1_frames", "roundtrips_total", "walkers_both_endpoints",
                      "lambda1_entropy", "lambda1_walker_inverse_simpson_effective_number", "cross_stream_max_residual_nm"]
            writer = csv.DictWriter(stream, fieldnames=fields, delimiter="\t", extrasaction="ignore")
            writer.writeheader()
            writer.writerows(results)
        write_json(output / "RUN_STATUS_v1.json", {
            "status": "SAMPLING_COMPLETE__M2_NOT_YET_EVALUATED", "rows_completed": list(ROWS),
            "wall_seconds": time.monotonic() - t0, "input_files_unchanged": True,
            "production_files_written": 0, "numpy_version": np.__version__,
            "unit_of_scientific_replication_here": "one peptide; two stochastic repeats per arm; not 12 walkers or 50000 frames",
        })
        export_review(output)
        print("[PASS] four-row sampling diagnostics complete; inputs unchanged", flush=True)
        print("[HOLD] M2/M1/M3/ROE and reduced-cohort conclusions await original endpoint-definition review", flush=True)
        return 0
    except Exception as exc:
        if output.is_dir():
            failure = output / "FAILURE_v1.json"
            if not failure.exists():
                write_json(failure, {"status": "FAILED_NOT_COMPLETE", "error": str(exc)})
        print("[HOLD] " + str(exc), flush=True)
        traceback.print_exc()
        return 1
    finally:
        print("===== JACS3 FOUR-ROW CPU SAMPLING END =====", flush=True)


if __name__ == "__main__":
    raise SystemExit(main())
