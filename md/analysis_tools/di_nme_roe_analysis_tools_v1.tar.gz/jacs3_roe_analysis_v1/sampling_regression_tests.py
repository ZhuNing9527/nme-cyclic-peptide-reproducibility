"""Synthetic schema and negative-control tests. No formal trajectory data."""
import contextlib
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import numpy as np
import run_jacs3_sampling_v1 as m


def make_chunk(start=100000, width=200):
    nrep, nsolute = 12, 24
    before, after, proposed, accepted = [], [], [], []
    mapping = np.arange(nrep)
    for t in range(width):
        before.append(mapping.copy())
        prop = np.zeros((nrep, nrep), dtype=np.int64)
        inverse = np.argsort(mapping)
        for i in range(t % 2, nrep - 1, 2):
            j = i + 1
            prop[i, j] = prop[j, i] = 1
            mapping[inverse[i]], mapping[inverse[j]] = j, i
        after.append(mapping.copy())
        proposed.append(prop)
        accepted.append(prop.copy())
    audit = {
        "iteration": np.arange(start + 1, start + width + 1),
        "before": np.asarray(before), "after": np.asarray(after),
        "proposed": np.asarray(proposed), "accepted": np.asarray(accepted),
        "energy": np.zeros((width, nrep, nrep)),
    }
    rng = np.random.default_rng(829)
    xyz = rng.uniform(0, 3, size=(width, nrep, nsolute, 3))
    boxes = np.broadcast_to(np.eye(3) * 10, (width, nrep, 3, 3)).copy()
    i1, i10 = np.arange(9, width, 10), np.arange(99, width, 100)
    rep = np.argmin(audit["after"][i1], axis=1)
    cap = {
        "capture_1ps_iteration": audit["iteration"][i1],
        "capture_1ps_mapping": audit["after"][i1],
        "capture_1ps_lambda1_replica": rep,
        "capture_1ps_positions": xyz[i1, rep],
        "capture_1ps_box": boxes[i1, rep],
        "capture_1ps_energy": audit["energy"][i1].copy(),
        "capture_10ps_iteration": audit["iteration"][i10],
        "capture_10ps_mapping": audit["after"][i10],
        "capture_10ps_positions": xyz[i10],
        "capture_10ps_box": boxes[i10],
    }
    return cap, audit


class SamplingTests(unittest.TestCase):
    def test_actual_schema_zero_energy_exchanges(self):
        cap, audit = make_chunk()
        stats = m.validate_audit(audit, 100000, 100200)
        m.validate_capture(cap, audit, 100000, 100200, 24)
        np.testing.assert_allclose(stats["expected_proposed_sum"], stats["proposed"])
        np.testing.assert_allclose(stats["expected_all_sum"], 200)

    def test_recovery_iterations_already_global(self):
        cap, audit = make_chunk(start=290000)
        m.validate_audit(audit, 290000, 290200)
        m.validate_capture(cap, audit, 290000, 290200, 24)
        audit["iteration"] -= 290000
        with self.assertRaisesRegex(RuntimeError, "GLOBAL_ITERATIONS"):
            m.validate_audit(audit, 290000, 290200)

    def test_duplicate_iteration_rejected(self):
        _, audit = make_chunk()
        audit["iteration"][1] = audit["iteration"][0]
        with self.assertRaisesRegex(RuntimeError, "GLOBAL_ITERATIONS"):
            m.validate_audit(audit, 100000, 100200)

    def test_nonpermutation_mapping_rejected(self):
        _, audit = make_chunk()
        audit["before"][0, :] = 0
        with self.assertRaisesRegex(RuntimeError, "PERMUTATION"):
            m.validate_audit(audit, 100000, 100200)

    def test_mapping_acceptance_mismatch_rejected(self):
        _, audit = make_chunk()
        audit["accepted"][:] = 0
        with self.assertRaisesRegex(RuntimeError, "ACCEPTANCE_INCONSISTENT"):
            m.validate_audit(audit, 100000, 100200)

    def test_matching_parity_rejected(self):
        _, audit = make_chunk()
        audit["proposed"][0, 0, 1] = audit["proposed"][0, 1, 0] = 0
        audit["accepted"][0, 0, 1] = audit["accepted"][0, 1, 0] = 0
        with self.assertRaisesRegex(RuntimeError, "SWAP_NEIGHBORS"):
            m.validate_audit(audit, 100000, 100200)

    def test_nonfinite_energy_rejected(self):
        _, audit = make_chunk()
        audit["energy"][0, 0, 0] = np.nan
        with self.assertRaisesRegex(RuntimeError, "NONFINITE"):
            m.validate_audit(audit, 100000, 100200)

    def test_nontrivial_exchange_probability(self):
        _, audit = make_chunk()
        energy = np.ones_like(audit["energy"])
        for t in range(200):
            energy[t, np.arange(12), audit["before"][t]] = 0
        audit["energy"] = energy
        stats = m.validate_audit(audit, 100000, 100200)
        np.testing.assert_allclose(stats["expected_proposed_sum"] / stats["proposed"], np.exp(-2))

    def test_wrong_physical_walker_rejected(self):
        cap, audit = make_chunk()
        cap["capture_1ps_lambda1_replica"][0] = (cap["capture_1ps_lambda1_replica"][0] + 1) % 12
        with self.assertRaisesRegex(RuntimeError, "PHYSICAL_LAMBDA1"):
            m.validate_capture(cap, audit, 100000, 100200, 24)

    def test_cross_stream_residual_rejected(self):
        cap, audit = make_chunk()
        cap["capture_1ps_positions"][-1, 0, 0] += 0.001
        with self.assertRaisesRegex(RuntimeError, "CROSS_STREAM"):
            m.validate_capture(cap, audit, 100000, 100200, 24)

    def test_energy_temporal_handoff_rejected(self):
        cap, audit = make_chunk()
        cap["capture_1ps_energy"][0, 0, 0] = 1
        with self.assertRaisesRegex(RuntimeError, "ENERGY_AUDIT_HANDOFF"):
            m.validate_capture(cap, audit, 100000, 100200, 24)

    def test_angles_and_committed_thresholds(self):
        theta = np.array([0, 60, 90, 120, 180, -90], dtype=float)
        points = np.zeros((len(theta), 4, 3))
        points[:, 0] = [0, 1, 0]
        points[:, 1] = [0, 0, 0]
        points[:, 2] = [1, 0, 0]
        points[:, 3, 0] = 1
        points[:, 3, 1] = np.cos(np.radians(theta))
        points[:, 3, 2] = np.sin(np.radians(theta))
        boxes = np.broadcast_to(np.eye(3) * 10, (len(theta), 3, 3))
        np.testing.assert_allclose(m.omega_degrees(points, boxes, [0, 1, 2, 3]), theta, atol=1e-12)
        np.testing.assert_array_equal(m.basin_labels(np.array([0, 60, 60.01, 119.99, 120, -180])), [1, 1, 0, 0, 2, 2])
        wrapped = np.mod(points + np.array([9.5, 9.5, 9.5]), 10)
        np.testing.assert_allclose(m.omega_degrees(wrapped, boxes, [0, 1, 2, 3]), theta, atol=1e-11)

    def test_skew_box_requires_review(self):
        points = np.array([[[0, 1, 0], [0, 0, 0], [1, 0, 0], [1, 1, 0]]], dtype=float)
        box = np.eye(3)[None] * 10
        box[0, 1, 0] = 0.1
        with self.assertRaisesRegex(RuntimeError, "SKEW_BOX"):
            m.omega_degrees(points, box, [0, 1, 2, 3])

    def test_degenerate_dihedral_rejected(self):
        points = np.zeros((1, 4, 3))
        with self.assertRaisesRegex(RuntimeError, "DEGENERATE"):
            m.omega_degrees(points, np.eye(3)[None] * 10, [0, 1, 2, 3])

    def test_crossings_remember_chunks_not_restarts(self):
        x = m.Crossings(nrep=2)
        mapping = np.tile([0, 1], (3, 1))
        x.update(np.tile([1, 2], (3, 1)), mapping)
        x.update(np.tile([2, 1], (3, 1)), mapping)
        np.testing.assert_array_equal(x.walker_counts, [1, 1])
        x.reset_boundary()
        x.update(np.tile([1, 2], (3, 1)), mapping)
        np.testing.assert_array_equal(x.walker_counts, [1, 1])

    def test_intermediate_region_not_a_committed_crossing(self):
        x = m.Crossings(nrep=2)
        x.update(np.array([[1, 2], [0, 0], [1, 2], [0, 0], [2, 1]]), np.tile([0, 1], (5, 1)))
        np.testing.assert_array_equal(x.walker_counts, [1, 1])

    def test_roundtrips_reset_at_actual_recovery(self):
        segment1 = np.array([[0, 1], [1, 0]])
        segment2 = np.array([[0, 1]])
        np.testing.assert_array_equal(m.count_roundtrips([np.r_[segment1, segment2]], 2), [1, 1])
        np.testing.assert_array_equal(m.count_roundtrips([segment1, segment2], 2), [0, 0])

    def test_entropy_is_walker_not_configuration_ess(self):
        self.assertAlmostEqual(float(m.norm_entropy(np.ones(12))), 1)
        self.assertAlmostEqual(float(m.norm_entropy(np.r_[10, np.zeros(11)])), 0)

    def test_forbidden_inputs_and_mutation_detection(self):
        with tempfile.TemporaryDirectory() as raw:
            r = m.Reader(raw)
            for path in ("../escape", "/tmp/escape", str(m.PROD_REL / "ROW15_TIERA_JACS4_CONTROL_R2/x.json"), "technical.nc"):
                with self.assertRaises(RuntimeError):
                    r.path(path)
            path = Path(raw) / "input.json"
            path.write_text("{}")
            r.digest("input.json")
            path.write_text("{\"changed\":true}")
            with self.assertRaisesRegex(RuntimeError, "INPUT_CHANGED"):
                r.check_unchanged()

    def test_freeze_paths(self):
        self.assertEqual(m.parse_freeze("a" * 64 + "  local/file.json\n"), [("a" * 64, "local/file.json")])
        with self.assertRaisesRegex(RuntimeError, "DUPLICATE"):
            m.parse_freeze(("a" * 64 + "  local/file.json\n") * 2)

    def test_full_50chunk_normal_and_recovery_processing_synthetic_only(self):
        cap, audit = make_chunk(width=10000)
        identity = np.tile(np.arange(12), (10000, 1))
        audit["before"] = identity
        audit["after"] = identity.copy()
        audit["accepted"][:] = 0
        audit["energy"][:] = 1
        audit["energy"][:, np.arange(12), np.arange(12)] = 0
        cap["capture_1ps_mapping"] = identity[9::10]
        cap["capture_10ps_mapping"] = identity[99::100]
        cap["capture_1ps_lambda1_replica"] = np.zeros(1000, dtype=np.int64)
        cap["capture_1ps_positions"][9::10] = cap["capture_10ps_positions"][:, 0]
        cap["capture_1ps_energy"] = audit["energy"][9::10]

        class FakeReader:
            def digest(self, raw, expected):
                return expected

            def json(self, raw):
                iteration = int(Path(raw).parent.name.split("_")[1])
                return {"global_iteration": iteration, "phase": "equilibration" if iteration <= 100000 else "production",
                        "context_steps": iteration * 12 * 100}

        for name in (m.ROWS[0], m.ROWS[2]):
            row = m.PROD_REL / name
            records = []
            for i in range(1, 61):
                phase = "equilibration" if i <= 10 else "production"
                records.append({"chunk_index": i, "phase": phase,
                    "capture_path": str(row / "chunks" / f"CAPTURE_{i:02d}_{phase}_v1.npz"), "capture_sha256": "a" * 64,
                    "exchange_audit_path": str(row / "chunks" / f"EXCHANGE_AUDIT_{i:02d}_{phase}_v1.npz"), "exchange_audit_sha256": "b" * 64,
                    "checkpoint_receipt_path": str(row / "checkpoints" / f"ITER_{i*10000:06d}" / "CHECKPOINT_RECEIPT_v1.json"),
                    "checkpoint_receipt_sha256": "c" * 64})

            def fake_npz(reader, raw, keys):
                is_audit = Path(raw).name.startswith("EXCHANGE")
                chunk = int(Path(raw).name.split("_")[2 if is_audit else 1])
                start, end = (chunk - 1) * 10000, chunk * 10000
                if is_audit:
                    return dict(audit, iteration=np.arange(start + 1, end + 1))
                return dict(cap, chunk_index=np.array(chunk), phase=np.array("production"),
                    global_iteration_start_exclusive=np.array(start), global_iteration_end_inclusive=np.array(end),
                    capture_1ps_iteration=np.arange(start + 10, end + 1, 10),
                    capture_10ps_iteration=np.arange(start + 100, end + 1, 100), recovery_segment=np.array(1),
                    recovery_local_iteration_start_exclusive=np.array(start - 290000),
                    recovery_local_iteration_end_inclusive=np.array(end - 290000))

            with patch.object(m, "load_npz", side_effect=fake_npz), contextlib.redirect_stdout(io.StringIO()):
                result = m.process_row(FakeReader(), name, {"records": records})
            self.assertEqual(result["lambda1_frames"], 50000)
            self.assertEqual(result["exchange_events"], 500000)
            self.assertEqual(result["lambda1_counts_by_walker"][0], 50000)
            self.assertEqual(result["roundtrips_total"], 0)
            self.assertTrue(result["sampling_limitations_descriptive_not_pass_fail_gate"])
            expected_boundary = 290000 if name == m.ROWS[2] else None
            self.assertEqual(result["recovery_boundary_global_iteration"], expected_boundary)


if __name__ == "__main__":
    unittest.main(verbosity=2)
