#!/usr/bin/env python3
"""Frozen secondary ROE comparison for four closed JACS3 physical-state streams."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import tarfile
import time
import traceback

import numpy as np
import sampling_core_v1 as core
import run_jacs3_m123_v1 as support
import roe_topology_binding_v1 as topology


VERSION = "402EC_JACS3_FROZEN_ROE_ANALYSIS_V1"
PACKAGE = Path(__file__).resolve().parent
DEV = core.DEV_REL
BUILD = support.BUILD_DIR
INPUT_PINS = support.INPUT_PINS
TARGET_DIR = DEV / "16g_post_m4_cyclic_transfer_tiera_roe_source_targets"
TARGET_TABLE = TARGET_DIR / "NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_EXACT152_ROE_DISTANCE_RESTRAINTS_v1.tsv"
TARGET_FREEZE = TARGET_DIR / "NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_SOURCE_TARGET_FREEZE_v1.sha256"
CLOSURE = DEV / "16h_post_m4_cyclic_transfer_tiera_roe_source_target_closure" / "NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_SOURCE_TARGET_FINAL_CLOSURE_FREEZE_v1.sha256"
MAPPING_DIR = DEV / "16i_post_m4_cyclic_transfer_tiera_roe_endpoint_mapping"
MAPPING_FREEZE = MAPPING_DIR / "NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_ENDPOINT_MAPPING_FREEZE_v1.sha256"
MAPPING_TABLE = MAPPING_DIR / "NMEALA_POSTM4_CYCLIC_TRANSFER_TIERA_ROE_ENDPOINT_SEMANTIC_MAPPING_v1.tsv"
M4 = "ROE_M4_restraint_satisfaction_fraction"
M5 = "ROE_M5_mean_absolute_bound_violation_A"
require = core.require
write_json = core.write_json


def asset(relative):
    relative = Path(relative)
    require(not relative.is_absolute() and ".." not in relative.parts, "UNSAFE_ASSET_PATH")
    path = PACKAGE / relative
    require(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(PACKAGE), "MISSING_OR_UNSAFE_ASSET")
    return path


def verify_assets():
    support.verify_assets()
    pins = json.loads(asset("ROE_ASSET_PINS_v1.json").read_text())
    for raw, expected in pins.items():
        require(core.sha(asset(raw)) == expected, "ROE_ASSET_SHA:" + raw)
    return pins


def roe_asset(raw):
    return asset(Path("authority_roe") / raw)


def load_roe_targets(protocol, reader):
    parents = {raw: expected for expected, raw in core.parse_freeze(reader.text(core.CX_REL / "402CX_v2_FINAL_PRODUCTION_PROTOCOL_FREEZE_v1.sha256"))}
    closed = protocol["ROE_secondary_analysis"]
    require(parents[str(CLOSURE)] == closed["source_target_freeze_sha256"]
            == "88ee6f66efcfc3993573629715491df7ee40d668ddee97c789499d007c0b70e1", "ROE_TARGET_PARENT_PIN")
    require(parents[str(MAPPING_FREEZE)] == closed["endpoint_mapping_freeze_sha256"]
            == "1f9035a75bbac1a691a971a02615967da1b067be7d64a1dd6af5af4779f36053", "ROE_MAPPING_PARENT_PIN")
    for raw in (CLOSURE, MAPPING_FREEZE, TARGET_FREEZE):
        for expected, child in core.parse_freeze(roe_asset(raw).read_text()):
            require(core.sha(roe_asset(child)) == expected, "ROE_DIRECT_MEMBER_SHA:" + child)
    mapping = {r["source_label"]: r for r in support.read_tsv(roe_asset(MAPPING_TABLE))}
    expected_rules = {
        "Hα": ("ALPHA_HYDROGEN", "SINGLE_ATOM"),
        "HN": ("AMIDE_HYDROGEN", "SINGLE_ATOM"),
        "Cβ": ("ALA_SIDECHAIN_METHYL_CARBON_PROXY", "SINGLE_CARBON_PROXY_NOT_EXPLICIT_METHYL_H_GROUP"),
        "CN": ("N_METHYL_CARBON_PROXY", "SINGLE_CARBON_PROXY_NOT_EXPLICIT_METHYL_H_GROUP"),
    }
    require(set(mapping) == set(expected_rules), "EXACT_FOUR_FROZEN_LABEL_RULES")
    for label, (coordinate, rule) in expected_rules.items():
        require(mapping[label]["analysis_coordinate"] == coordinate and mapping[label]["group_rule"] == rule,
                "ROE_COORDINATE_RULE_CHANGED")
    rows = support.read_tsv(roe_asset(TARGET_TABLE))
    require(len(rows) == 152, "EXACT152_SOURCE_TABLE")
    rows = [r for r in rows if r["benchmark_id"] == "TIERA_JACS3"]
    require(len(rows) == 26 and [int(r["source_row_rank"]) for r in rows] == list(range(1, 27)), "JACS3_EXACT26_SOURCE_ROWS")
    require(len({r["restraint_id"] for r in rows}) == 26, "RESTRAINT_IDS_NOT_UNIQUE")
    require(all(r["source_compound"] == "3" and r["source_table"] == "10" and r["source_pdf_page"] == "15"
                and r["analysis_target"] == "LOWER_UPPER_BOUNDS_ONLY" for r in rows), "SOURCE_TARGET_IDENTITY")
    lower = np.array([float(r["lower_bound_A"]) for r in rows])
    upper = np.array([float(r["upper_bound_A"]) for r in rows])
    require(np.isfinite(lower).all() and np.isfinite(upper).all() and np.all((lower > 0) & (upper >= lower)), "INVALID_SOURCE_BOUNDS")
    # This printed wide interval is preserved, not reconstructed from a +/-10% rule.
    require(rows[20]["lower_bound_A"] == "1.92" and rows[20]["upper_bound_A"] == "3.35", "LITERAL_ROW21_BOUND_CHANGED")
    return rows, lower, upper, mapping


def resolve_endpoint(endpoint, binding):
    match = re.fullmatch(r"1:(D-)?ALA([1-5]):(Hα|HN|Cβ|CN)", endpoint)
    require(match is not None, "UNSUPPORTED_SOURCE_ENDPOINT:" + endpoint)
    residue = int(match.group(2))
    require(bool(match.group(1)) == (residue == 1), "SOURCE_RESIDUE_CHIRALITY_LABEL")
    key = str(residue) + ":" + match.group(3)
    require(key in binding["semantic_to_atom_index_0based"], "NO_CHEMICALLY_VALID_ATOM:" + endpoint)
    return binding["semantic_to_atom_index_0based"][key]


def runtime_binding(reader, references, geometry, rows):
    inputs = reader.json(INPUT_PINS)["short_md_input_files"]
    xml_bytes = {}
    for arm in ("CONTROL", "TEST"):
        raw = BUILD / (arm + ".xml")
        expected = inputs["systems/TIERA_JACS3/build/" + raw.name]
        reader.digest(raw, expected)
        xml_bytes[arm] = reader.touch(raw).read_bytes()
    methylated = {int(r["residue_index"]) for r in references if r["n_methylated_at_residue"] == "True"}
    binding = topology.bind_both_systems(xml_bytes["CONTROL"], xml_bytes["TEST"], geometry, methylated)
    frozen_local = json.loads(asset("LOCAL_TOPOLOGY_BINDING_AUDIT_v1.json").read_text())
    require(binding == frozen_local, "RUNTIME_TOPOLOGY_BINDING_DIFFERS_FROM_REVIEWED_MAPPING")
    pairs = np.array([[resolve_endpoint(r["source_endpoint_1"], binding), resolve_endpoint(r["source_endpoint_2"], binding)] for r in rows], dtype=np.int64)
    require(pairs.shape == (26, 2) and np.all(pairs[:, 0] != pairs[:, 1]), "ROE_ENDPOINT_PAIR_SHAPE")
    print("[PASS] independent chemical graph binding; both arms share the exact atom order", flush=True)
    print("[PASS] all 26 frozen restraints bound; Halpha/HN proton atoms and Cbeta/CN carbon proxies", flush=True)
    return binding, pairs


def intramolecular_distances_A(positions_nm, boxes_nm, pairs, binding):
    positions = np.asarray(positions_nm, dtype=np.float64)
    boxes = np.asarray(boxes_nm, dtype=np.float64)
    pairs = np.asarray(pairs)
    n = len(positions)
    require(n > 0 and positions.shape == (n, 56, 3) and boxes.shape == (n, 3, 3), "DISTANCE_INPUT_SHAPE")
    require(pairs.shape == (26, 2) and np.issubdtype(pairs.dtype, np.integer)
            and np.all((pairs >= 0) & (pairs < 56)) and np.all(pairs[:, 0] != pairs[:, 1]), "DISTANCE_ATOM_PAIR_SHAPE")
    require(np.isfinite(positions).all() and np.isfinite(boxes).all(), "NONFINITE_DISTANCE_INPUT")
    diagonal = np.zeros_like(boxes)
    diagonal[:, np.arange(3), np.arange(3)] = boxes[:, np.arange(3), np.arange(3)]
    require(np.allclose(boxes, diagonal, atol=1e-12, rtol=0), "SKEW_BOX_NEEDS_EXPLICIT_IMAGE_REVIEW")
    lengths = np.diagonal(boxes, axis1=1, axis2=2)
    require(np.all(lengths > 0), "NONPOSITIVE_BOX_LENGTH")

    def minimum_image(vectors):
        return vectors - np.rint(vectors / lengths[:, None, :]) * lengths[:, None, :]

    unwrapped = np.empty_like(positions)
    unwrapped[:, 0] = positions[:, 0]
    for parent, child in binding["unwrap_tree_parent_child"]:
        vector = positions[:, child] - positions[:, parent]
        vector -= np.rint(vector / lengths) * lengths
        unwrapped[:, child] = unwrapped[:, parent] + vector
    bonds = np.asarray(binding["bonds"], dtype=np.int64)
    original_bonds = minimum_image(positions[:, bonds[:, 1]] - positions[:, bonds[:, 0]])
    restored_bonds = unwrapped[:, bonds[:, 1]] - unwrapped[:, bonds[:, 0]]
    closure_error = float(np.max(np.abs(original_bonds - restored_bonds)))
    require(closure_error <= 1e-8, "MOLECULAR_UNWRAP_RING_CLOSURE")
    vectors = unwrapped[:, pairs[:, 1]] - unwrapped[:, pairs[:, 0]]
    distances = np.linalg.norm(vectors, axis=-1)
    direct = np.linalg.norm(minimum_image(positions[:, pairs[:, 1]] - positions[:, pairs[:, 0]]), axis=-1)
    direct_error = float(np.max(np.abs(distances - direct)))
    require(direct_error <= 1e-8, "INTRAMOLECULAR_AND_PAIR_IMAGE_DISAGREE")
    require(np.isfinite(distances).all() and np.all(distances > 1e-8), "ZERO_OR_NONFINITE_ROE_DISTANCE")
    return 10.0 * distances, {"unwrap_closure_max_residual_nm": closure_error,
                              "direct_minimum_image_distance_max_residual_nm": direct_error}


def combine_moments(moments, frame_counts):
    moments = np.asarray(moments, dtype=np.float64)
    weights = np.asarray(frame_counts, dtype=np.float64)
    require(moments.ndim == 2 and weights.shape == (len(moments),) and np.isfinite(weights).all()
            and np.all(weights > 0), "MOMENT_WEIGHT_SHAPE")
    require(np.isfinite(moments).all() and np.all(moments > 0), "INVALID_RMINUS3_MOMENT")
    return np.average(moments, axis=0, weights=weights)


def evaluate_moments(moment, lower, upper):
    moment, lower, upper = [np.asarray(x, dtype=np.float64) for x in (moment, lower, upper)]
    require(moment.ndim == 1 and moment.shape == lower.shape == upper.shape and len(moment) > 0, "RESTRAINT_VECTOR_SHAPE")
    require(np.isfinite(moment).all() and np.all(moment > 0), "INVALID_EFFECTIVE_DISTANCE_MOMENT")
    require(np.isfinite(lower).all() and np.isfinite(upper).all() and np.all((lower > 0) & (upper >= lower)), "INVALID_ANALYSIS_BOUNDS")
    distance = 1.0 / np.cbrt(moment)
    violation = np.maximum(np.maximum(lower - distance, distance - upper), 0.0)
    satisfied = (distance >= lower) & (distance <= upper)
    summary = {"restraint_count": len(moment), "restraints_satisfied": int(np.count_nonzero(satisfied)),
               M4: float(np.mean(satisfied)), M5: float(np.mean(violation))}
    return summary, distance, violation, satisfied


def restraint_records(rows, moment, lower, upper, context):
    _, distance, violation, satisfied = evaluate_moments(moment, lower, upper)
    records = []
    for index, row in enumerate(rows):
        records.append({**context, "restraint_id": row["restraint_id"], "source_row_rank": int(row["source_row_rank"]),
            "source_endpoint_1": row["source_endpoint_1"], "source_endpoint_2": row["source_endpoint_2"],
            "lower_bound_A": row["lower_bound_A"], "upper_bound_A": row["upper_bound_A"],
            "mean_rminus3_Aminus3": float(moment[index]), "r_eff_A": float(distance[index]),
            "within_source_bounds": bool(satisfied[index]), "absolute_bound_violation_A": float(violation[index])})
    return records


def analyze_row(reader, name, manifest, nsolute, sampling_hashes, previous_hashes, binding, pairs, lower, upper):
    require([r["chunk_index"] for r in manifest["records"]] == list(range(1, 61)), "MANIFEST_GLOBAL_CHUNKS")
    means, minimum, maximum, bounds, frames, errors = [], [], [], [], [], []
    for record in manifest["records"][10:]:
        require(previous_hashes[record["capture_path"]] == record["capture_sha256"], "M123_CAPTURE_INPUT_IDENTITY")
        cap = support.extract_chunk(reader, record, name, nsolute, sampling_hashes)
        distances, error = intramolecular_distances_A(cap["capture_1ps_positions"], cap["capture_1ps_box"], pairs, binding)
        moments = distances ** -3
        require(np.isfinite(moments).all() and np.all(moments > 0), "NONFINITE_INVERSE_CUBE_DISTANCE")
        means.append(np.mean(moments, axis=0)); minimum.append(distances.min(axis=0)); maximum.append(distances.max(axis=0))
        bounds.append([(record["chunk_index"] - 1) * 10000, record["chunk_index"] * 10000])
        frames.append(len(distances)); errors.append(error)
        if record["chunk_index"] % 10 == 0:
            print(f"[PROGRESS] {name} ROE production chunks {record['chunk_index'] - 10}/50", flush=True)
    means, frames, bounds = np.asarray(means), np.asarray(frames, dtype=np.int64), np.asarray(bounds, dtype=np.int32)
    require(means.shape == (50, 26) and np.array_equal(frames, np.full(50, 1000)), "EXACT_50000_PHYSICAL_FRAMES")
    require(np.array_equal(bounds[:, 0], np.arange(100000, 600000, 10000))
            and np.array_equal(bounds[:, 1], np.arange(110000, 600001, 10000)), "GLOBAL_CHUNK_ADMISSION_GRID")
    moment = combine_moments(means, frames)
    summary = evaluate_moments(moment, lower, upper)[0]
    summary.update(row=name, arm=name.rsplit("_", 2)[1], replicate=name.rsplit("_", 1)[1],
                   frames=int(frames.sum()), recovery_boundary_global_iteration=290000 if name == core.ROWS[2] else None)
    blocks, block_moments = [], []
    for i in range(5):
        bm = combine_moments(means[i * 10:(i + 1) * 10], frames[i * 10:(i + 1) * 10])
        b = evaluate_moments(bm, lower, upper)[0]
        b.update(row=name, block_index=i + 1, production_start_ns_exclusive=i * 10,
                 production_end_ns_inclusive=(i + 1) * 10, frames=10000, independent_statistical_replicate=False)
        blocks.append(b); block_moments.append(bm)
    observations = {"global_start_exclusive": bounds[:, 0], "global_end_inclusive": bounds[:, 1],
        "frame_count": frames, "mean_rminus3_Aminus3": means, "minimum_distance_A": np.asarray(minimum),
        "maximum_distance_A": np.asarray(maximum),
        "unwrap_closure_max_residual_nm": np.array([e["unwrap_closure_max_residual_nm"] for e in errors]),
        "direct_minimum_image_distance_max_residual_nm": np.array([e["direct_minimum_image_distance_max_residual_nm"] for e in errors])}
    return summary, moment, blocks, block_moments, observations


def arm_summaries_and_effects(rows, summaries, moments, block_moments, lower, upper):
    arms, effects, arm_moments, arm_blocks = [], [], {}, []
    for arm in ("CONTROL", "TEST"):
        names = [n for n in core.ROWS if f"_{arm}_" in n]
        require([summaries[n]["replicate"] for n in names] == ["R1", "R2"]
                and all(summaries[n]["frames"] == 50000 for n in names), "ARM_EQUAL_LENGTH_REPLICATES")
        moment = np.mean([moments[n] for n in names], axis=0)
        record = evaluate_moments(moment, lower, upper)[0]
        record.update(arm=arm, level="ARM_EQUAL_REPLICATE_MOMENT", frames_per_replicate=50000)
        for metric in (M4, M5):
            record[metric + "_R1"] = summaries[names[0]][metric]
            record[metric + "_R2"] = summaries[names[1]][metric]
            record[metric + "_absolute_R1_R2_difference"] = abs(summaries[names[0]][metric] - summaries[names[1]][metric])
        arms.append(record); arm_moments[arm] = moment
        for i in range(5):
            bm = np.mean([block_moments[n][i] for n in names], axis=0)
            br = evaluate_moments(bm, lower, upper)[0]
            br.update(arm=arm, block_index=i + 1, production_start_ns_exclusive=i * 10,
                      production_end_ns_inclusive=(i + 1) * 10, independent_statistical_replicate=False)
            arm_blocks.append(br)
    for rep in ("R1", "R2"):
        cn = next(n for n in core.ROWS if n.endswith("CONTROL_" + rep))
        tn = next(n for n in core.ROWS if n.endswith("TEST_" + rep))
        effects.append({"level": rep, **{metric + "_TEST_minus_CONTROL": summaries[tn][metric] - summaries[cn][metric] for metric in (M4, M5)}})
    effects.append({"level": "ARM_EQUAL_REPLICATE_MOMENT", **{metric + "_TEST_minus_CONTROL": arms[1][metric] - arms[0][metric] for metric in (M4, M5)}})
    comparisons = []
    cr = restraint_records(rows, arm_moments["CONTROL"], lower, upper, {})
    tr = restraint_records(rows, arm_moments["TEST"], lower, upper, {})
    for c, t in zip(cr, tr):
        comparisons.append({"restraint_id": c["restraint_id"], "source_endpoint_1": c["source_endpoint_1"],
            "source_endpoint_2": c["source_endpoint_2"], "lower_bound_A": c["lower_bound_A"], "upper_bound_A": c["upper_bound_A"],
            "CONTROL_r_eff_A": c["r_eff_A"], "TEST_r_eff_A": t["r_eff_A"],
            "CONTROL_satisfied": c["within_source_bounds"], "TEST_satisfied": t["within_source_bounds"],
            "CONTROL_violation_A": c["absolute_bound_violation_A"], "TEST_violation_A": t["absolute_bound_violation_A"],
            "violation_A_TEST_minus_CONTROL": t["absolute_bound_violation_A"] - c["absolute_bound_violation_A"]})
    return arms, effects, arm_moments, arm_blocks, comparisons


def export_result(output):
    archive = output / "JACS3_FROZEN_ROE_RESULTS_v1.tar.gz"
    with tarfile.open(archive, "x:gz") as tar:
        for path in sorted(output.rglob("*")):
            if path.is_file() and path != archive:
                tar.add(path, arcname=str(path.relative_to(output)), recursive=False)
    print("RESULT_ARCHIVE_SHA256=" + core.sha(archive), flush=True)
    print("UPLOAD_THIS_EXACT_FILE=" + str(archive), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default="/mnt/lab/zn/mem-perm/P0_starter_v1")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    output, reader = Path(args.output).absolute(), core.Reader(args.root)
    own_output = False
    start = time.monotonic()
    print("===== JACS3 FROZEN SECONDARY ROE ANALYSIS BEGIN =====", flush=True)
    print("VERSION=" + VERSION, flush=True)
    print("MD=False CONTEXT=False GPU=False ROE=True M2_REDEFINED=False MBAR=False", flush=True)
    try:
        require(output.parent.name.startswith("236_jacs3_frozen_ROE_v1.") and output.name == "results"
                and output.parent.parent == reader.root / DEV and output.parent.is_dir()
                and output.resolve() == output and not output.is_relative_to(reader.root / core.PROD_REL),
                "OUTPUT_NOT_FRESH_ANALYSIS_SURFACE")
        require(not output.exists(), "ANALYSIS_OUTPUT_EXISTS")
        assets = verify_assets()
        source_pins = json.loads(asset("SOURCE_PINS_v1.json").read_text())
        protocol, contracts, manifests, precommits = core.preflight(reader, source_pins)
        references, _, _, _, geometry, nsolute, sampling_hashes = support.load_runtime_authorities(reader, precommits, source_pins)
        rows, lower, upper, mapping = load_roe_targets(protocol, reader)
        binding, pairs = runtime_binding(reader, references, geometry, rows)
        prior_status = json.loads(asset("prior_m123/RUN_STATUS_v1.json").read_text())
        require(prior_status["status"] == "JACS3_FROZEN_M123_ANALYSIS_COMPLETE" and prior_status["scientific_peptide_units"] == 1,
                "PRIOR_PRIMARY_ANALYSIS_NOT_CLOSED")
        previous_hashes = json.loads(asset("prior_m123/INPUT_HASHES_v1.json").read_text())
        output.mkdir(exist_ok=False)
        own_output = True
        # Freeze the reviewed atom binding in the fresh analysis output BEFORE any coordinate read.
        write_json(output / "ROE_TOPOLOGY_BINDING_AUDIT_v1.json", {**binding,
            "coordinate_reads_before_binding": 0, "restraint_atom_pairs_0based": pairs.tolist(),
            "bound_restraint_ids": [r["restraint_id"] for r in rows]})
        write_json(output / "ANALYSIS_IMPLEMENTATION_SCOPE_v1.json", {
            "version": VERSION, "scientific_peptide_units": 1,
            "existing_frozen_ROE_semantics_not_new_preregistration": True,
            "primary_M2_already_evaluated_before_this_secondary_ROE_stage": True,
            "new_primary_endpoint_or_posthoc_composite": False,
            "prior_primary_Delta_major": prior_status["Delta_major"],
            "ROE_may_override_unfavorable_M2": False,
            "source_target_fields": ["lower_bound_A", "upper_bound_A"],
            "source_Calc_Viol_are_not_targets": True,
            "all_26_source_rows_included_without_filtering": True,
            "methyl_coordinate_proxies": ["Cβ", "CN"], "methyl_H_group_averaging": False,
            "extra_pseudoatom_distance_correction": False,
            "r_eff": "mean(r_A**(-3))**(-1/3)",
            "arm_averaging": "average equal-length R1/R2 inverse-cube moments BEFORE conversion to r_eff and bound evaluation",
            "M4": "fraction of 26 effective distances inside closed source Low/Upp bounds",
            "M5": "mean over all 26 max(Low-r_eff, r_eff-Upp, 0), in Angstrom",
            "literal_source_rows": rows, "frozen_semantic_mapping": mapping,
            "physical_state_index": 0, "frames_per_run": 50000,
            "global_iteration_grid": [100010, 600000, 10], "equilibration_excluded": True,
            "ROW11_admitted_production_segments_ns": [19, 31],
            "ROW11_capture_iterations_already_global": True,
            "original_reporter_tail_never_opened": [290001, 295253],
            "intramolecular_coordinates": "bond-graph unwrapping with ring-closure check and independent pair minimum-image cross-check",
            "skew_boxes": "stop for review, not approximate",
            "fixed_10ns_blocks_are_independent_replicates": False,
            "pooled_frame_or_cohort_p_value": None, "kinetic_continuity_claim": False,
            "study_wide_or_universal_transferability_claim": False,
            "production_files_modified": 0, "other_rows_read": False,
            "script_sha256": core.sha(Path(__file__)),
            "topology_binding_module_sha256": core.sha(Path(topology.__file__)),
            "asset_pins": assets,
        })
        summaries, moments, block_moments, all_blocks, all_restraints = {}, {}, {}, [], []
        for name in core.ROWS:
            summary, moment, blocks, bm, observations = analyze_row(reader, name, manifests[name], nsolute,
                sampling_hashes, previous_hashes, binding, pairs, lower, upper)
            summaries[name], moments[name], block_moments[name] = summary, moment, bm
            all_blocks.extend(blocks)
            restraints = restraint_records(rows, moment, lower, upper, {"row": name})
            all_restraints.extend(restraints)
            write_json(output / (name + ".ROE_v1.json"), {"summary": summary, "restraints": restraints})
            np.savez_compressed(output / (name + ".ROE_CHUNK_MOMENTS_v1.npz"), **observations)
            print(f"[ROW COMPLETE] {name} ROE_M4={summary['restraints_satisfied']}/26 "
                  f"({summary[M4]:.6f}) ROE_M5_mean_violation_A={summary[M5]:.6f}", flush=True)
        arms, effects, arm_moments, arm_blocks, comparisons = arm_summaries_and_effects(rows, summaries, moments, block_moments, lower, upper)
        arm_restraints = []
        for record in arms:
            arm = record["arm"]
            arm_restraints.extend(restraint_records(rows, arm_moments[arm], lower, upper, {"arm": arm}))
            print(f"[ARM COMPLETE] {arm} ROE_M4={record['restraints_satisfied']}/26 "
                  f"ROE_M5_mean_violation_A={record[M5]:.6f}", flush=True)
        reader.check_unchanged()
        support.write_table(output / "TRAJECTORY_ROE_v1.tsv", list(summaries.values()))
        support.write_table(output / "ARM_EQUAL_REPLICATE_MOMENT_ROE_v1.tsv", arms)
        support.write_table(output / "PAIRED_TEST_MINUS_CONTROL_ROE_v1.tsv", effects)
        support.write_table(output / "ALL26_TRAJECTORY_RESTRAINTS_v1.tsv", all_restraints)
        support.write_table(output / "ALL26_ARM_RESTRAINTS_v1.tsv", arm_restraints)
        support.write_table(output / "ALL26_CONTROL_TEST_COMPARISON_v1.tsv", comparisons)
        support.write_table(output / "FIXED_10NS_TRAJECTORY_BLOCKS_ROE_v1.tsv", all_blocks)
        support.write_table(output / "FIXED_10NS_ARM_BLOCKS_ROE_v1.tsv", arm_blocks)
        write_json(output / "RESULTS_ROE_v1.json", {"trajectories": list(summaries.values()), "arms": arms,
            "paired_effects": effects, "trajectory_blocks": all_blocks, "arm_blocks": arm_blocks,
            "arm_restraints": arm_restraints, "all26_control_test_comparison": comparisons})
        write_json(output / "INPUT_HASHES_v1.json", reader.digests)
        write_json(output / "RUN_STATUS_v1.json", {"status": "JACS3_FROZEN_SECONDARY_ROE_COMPLETE",
            "rows_completed": list(core.ROWS), "restraints_per_row": 26, "frames_per_row": 50000,
            "scientific_peptide_units": 1, "Delta_ROE_M4": effects[-1][M4 + "_TEST_minus_CONTROL"],
            "Delta_ROE_M5_A": effects[-1][M5 + "_TEST_minus_CONTROL"],
            "prior_primary_Delta_major": prior_status["Delta_major"], "input_files_unchanged": True,
            "production_files_written": 0, "pooled_frame_p_value": None, "overall_cohort_p_value": None,
            "numpy_version": np.__version__, "wall_seconds": time.monotonic() - start})
        print("DELTA_ROE_M4_TEST_MINUS_CONTROL=" + str(effects[-1][M4 + "_TEST_minus_CONTROL"]), flush=True)
        print("DELTA_ROE_M5_A_TEST_MINUS_CONTROL=" + str(effects[-1][M5 + "_TEST_minus_CONTROL"]), flush=True)
        export_result(output)
        print("[PASS] existing frozen secondary ROE endpoints evaluated; production inputs unchanged", flush=True)
        print("[HOLD] no outcome-driven extension, refit, row deletion, endpoint retuning or study-wide conclusion", flush=True)
        return 0
    except Exception as exc:
        if own_output and not (output / "FAILURE_v1.json").exists():
            write_json(output / "FAILURE_v1.json", {"status": "ROE_ANALYSIS_FAILED_NOT_COMPLETE", "error": str(exc)})
        print("[HOLD] " + str(exc), flush=True)
        traceback.print_exc()
        return 1
    finally:
        print("===== JACS3 FROZEN SECONDARY ROE ANALYSIS END =====", flush=True)


if __name__ == "__main__":
    raise SystemExit(main())
