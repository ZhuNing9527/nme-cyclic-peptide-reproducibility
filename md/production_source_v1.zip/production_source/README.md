# Original production implementation

The formal REST2 worker, its source dependencies and original protocol/start authorities
are preserved byte-for-byte. MANIFEST.json maps the compact bundle to the previous public
files. These sources retain their original lab-path guards. Portable force construction
and parameter checks remain in md/runtime/ and md/code/ of the repository. The 12 formal
run records remain in md/original_run_records_v1.zip. No production job is launched by
the documented numerical reproduction commands.
