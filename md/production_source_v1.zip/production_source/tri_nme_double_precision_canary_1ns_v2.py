from pathlib import Path
import csv
import hashlib
import importlib.util
import json
import math
import shutil
import subprocess
import sys
import time
import traceback

import numpy as np
import openmm as mm
from openmm import unit
from openmmtools import multistate, states


ROOT=Path(
    "/mnt/lab/zn/mem-perm/P0_starter_v1"
).resolve()

DEV=(
    ROOT/
    "07_nmeala_separability_pilot"/
    "13_joint_correction_development"
)

# ------------------------------------------------------------
# CLOSED AUTHORITIES
# ------------------------------------------------------------

DW=DEV/"230a_post_m4_hybrid_hold_alldouble_fallback_adjudication_v2"

DW_SCRIPT=DEV/"run_402DW_R1_hybrid_hold_alldouble_fallback_adjudication_v2.py"

DW_REPORT=(
    DW/
    "402DW_R1_HYBRID_HOLD_ALLDOUBLE_FALLBACK_ADJUDICATION_v2.json"
)

DW_FREEZE=(
    DW/
    "402DW_R1_HYBRID_HOLD_ALLDOUBLE_FALLBACK_ADJUDICATION_FREEZE_v2.sha256"
)

CY_SCRIPT=DEV/"run_402CY_exact_restart_production_engine_validation_v4.py"

CY=DEV/"21o_post_m4_exact_restart_production_engine_validation_v4"

CY_REPORT=CY/"402CY_EXACT_RESTART_VALIDATION_v1.json"
CY_FREEZE=CY/"402CY_RESULTS_FREEZE_v1.sha256"

CX=DEV/"21l_post_m4_final_production_protocol_freeze_v2"

CX_PROTOCOL=CX/"402CX_v2_FINAL_PRODUCTION_PROTOCOL_v1.json"
CX_STARTS=CX/"402CX_v2_PRODUCTION_STARTS_AND_SEEDS_v1.tsv"
CX_FREEZE=CX/"402CX_v2_FINAL_PRODUCTION_PROTOCOL_FREEZE_v1.sha256"

CU=DEV/"21i_post_m4_final_ladder_redesign_precommit_v1"
SRC=CU/"source"

CU_PROTOCOL=SRC/"PROTOCOL_v1.json"
INPUT_PINS=SRC/"INPUT_PINS_v1.json"

CU_SOURCE_FREEZE=(
    CU/
    "402CU_REDESIGN_SOURCE_FREEZE_v1.sha256"
)

SHORT=DEV/"20r_post_m4_dmso_solvation_and_short_md_v1"


# ------------------------------------------------------------
# FRESH 402DX OUTPUT
# ------------------------------------------------------------

OUT=DEV/"231a_post_m4_jacs4_test_alldouble_1ns_production_canary_v2"

PRIMARY=OUT/"primary_1ns"
SPLIT=OUT/"recovery_checkpoint_1ns"
CONT=OUT/"continuous_probe_10ps"
REST=OUT/"restart_probe_10ps"

CONTRACT=OUT/"402DX_CANARY_CONTRACT_v1.json"
PRECOMMIT=OUT/"402DX_CANARY_PRECOMMIT_FREEZE_v1.sha256"

APP=SPLIT/"APPLICATION_CHECKPOINT_1NS_v1.npz"
CTXCHK=SPLIT/"OPENMM_CONTEXT_CHECKPOINT_1NS_v1.chk"
CTX_META=SPLIT/"CHECKPOINT_METADATA_1NS_v1.json"

SPARSE_1PS=PRIMARY/"PRODUCTION_LIKE_1PS_STREAM_v1.npz"
SPARSE_10PS=PRIMARY/"PRODUCTION_LIKE_ALL_REPLICA_10PS_STREAM_v1.npz"
EXCHANGE_AUDIT=PRIMARY/"EXCHANGE_AUDIT_0P1PS_v1.npz"
STORAGE_MANIFEST=PRIMARY/"PRODUCTION_LIKE_STORAGE_MANIFEST_v1.json"

RESULT=OUT/"402DX_ALLDOUBLE_1NS_PRODUCTION_CANARY_v1.json"
FREEZE=OUT/"402DX_ALLDOUBLE_1NS_PRODUCTION_CANARY_FREEZE_v1.sha256"

FAILURE=OUT/"402DX_FAILURE_v1.json"
FAILURE_FREEZE=OUT/"402DX_FAILURE_FREEZE_v1.sha256"


EXPECTED={
    DW_SCRIPT:
        "28057c21fccf7184d4225d29ac4ad188db25fde54d183d28a3e41d1a9f2478a4",

    DW_REPORT:
        "2028993ac6895fce3b5c38dccca64fea286287698a454400f9ed4a5b96b42620",

    DW_FREEZE:
        "cade55a8e8ccc6ab80c3f2ec933189f6d42f3104ca757908e33dc6fb7c4529a3",

    CY_SCRIPT:
        "2193d2d7ed2f6c9fb498e151674bb086cdfc0cf9707169cca3548d42a902c1d9",

    CY_REPORT:
        "53f5511f986dfea1bf5588786edf10f5153b79a773b1b133beba2e0beed73647",

    CY_FREEZE:
        "bc1bf5ece847dded1dd8c210d3dbdfcf511073f71b4a0dc9dbf4f9fb36aec392",

    CX_PROTOCOL:
        "960dc16d81fbd58df2cda17a9d9d91a5dc70c556a08f883a94b704ea38a451ac",

    CX_STARTS:
        "7d62289519fde4a23a2fe8954c13566aca4ba97bef0af7eb839cd7c69e5593fc",

    CX_FREEZE:
        "937c290d1f2b44c1d7e6aa998f4bd8885e5b75d4245c471c340aff7a6a6e917f",

    CU_PROTOCOL:
        "8470178ce1a7f49f9d5a5532f540f667ad81bc2e4266db0e33374585be2e6d93",

    CU_SOURCE_FREEZE:
        "5437a4d7251951ad13e03526a0cfae0d2817a8dadfc146a7552e4ab8b3fd0148",
}


# ------------------------------------------------------------
# CANARY PARAMETERS
# ------------------------------------------------------------

BENCHMARK="TIERA_JACS4"
ARM="TEST"
REPLICATE="R1"

TARGET_GPU_INDEX=0
TARGET_GPU_NAME="NVIDIA GeForce RTX 5090"

N_REPLICAS=12

TIMESTEP_PS=0.001
EXCHANGE_STEPS=100

PRIMARY_ITERATIONS=10000
PROBE_ITERATIONS=100

PRIMARY_PS_PER_REPLICA=(
    PRIMARY_ITERATIONS
    *
    EXCHANGE_STEPS
    *
    TIMESTEP_PS
)

PROBE_PS_PER_REPLICA=(
    PROBE_ITERATIONS
    *
    EXCHANGE_STEPS
    *
    TIMESTEP_PS
)

EXPECTED_PRIMARY_CONTEXT_STEPS=(
    PRIMARY_ITERATIONS
    *
    N_REPLICAS
    *
    EXCHANGE_STEPS
)

EXPECTED_FINAL_CONTEXT_STEPS=(
    (
        PRIMARY_ITERATIONS
        +
        PROBE_ITERATIONS
    )
    *
    N_REPLICAS
    *
    EXCHANGE_STEPS
)

# Fresh technical namespace only.
TECH_INTEGRATOR_SEED=17024601
TECH_EXCHANGE_SEED=17024602

# Production-like storage cadence in exchange iterations.
# 1 iteration = 0.1 ps.
CADENCE_1PS=10
CADENCE_10PS=100
CHECKPOINT_1NS_ITERATION=10000


# ------------------------------------------------------------
# GENERIC HELPERS
# ------------------------------------------------------------

def require(ok,msg):
    if not ok:
        raise RuntimeError(msg)


def sha(path):
    h=hashlib.sha256()

    with Path(path).open("rb") as f:
        for block in iter(
            lambda:f.read(1048576),
            b"",
        ):
            h.update(block)

    return h.hexdigest()


def rel(path):
    return (
        Path(path)
        .resolve()
        .relative_to(ROOT)
        .as_posix()
    )


def read_json(path):
    return json.loads(
        Path(path).read_text()
    )


def write_json(path,data):
    Path(path).write_text(
        json.dumps(
            data,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )+"\n"
    )


def verify_freeze(path,expected_count):

    freeze=Path(path).resolve()
    rows=[]

    for line in freeze.read_text().splitlines():

        if not line.strip():
            continue

        expected,raw=line.split(None,1)

        q=Path(
            raw.strip().lstrip("*")
        )

        if q.is_absolute():
            candidates=[q.resolve()]
        else:
            candidates=[
                (freeze.parent/q).resolve(),
                (ROOT/q).resolve(),
            ]

        resolved=None

        for candidate in candidates:

            if (
                candidate.is_file()
                and
                sha(candidate)==expected
            ):
                resolved=candidate
                break

        require(
            resolved is not None,
            "FROZEN_MEMBER_UNRESOLVED "
            +repr({
                "freeze":str(freeze),
                "raw":raw,
            }),
        )

        rows.append(resolved)

    require(
        len(rows)==expected_count,
        "FREEZE_CARDINALITY "
        +str(path),
    )

    return rows


def load_cy():

    spec=importlib.util.spec_from_file_location(
        "cy_v4_canary_authority",
        CY_SCRIPT,
    )

    require(
        spec is not None
        and
        spec.loader is not None,
        "CY_IMPORT_SPEC",
    )

    module=importlib.util.module_from_spec(
        spec
    )

    spec.loader.exec_module(
        module
    )

    return module


def gpu_inventory():

    text=subprocess.check_output(
        [
            "nvidia-smi",
            "--query-gpu=index,name,uuid,utilization.gpu,memory.used,memory.free,pstate",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    )

    rows={}

    for line in text.strip().splitlines():

        p=[
            x.strip()
            for x in line.split(",")
        ]

        idx=int(p[0])

        rows[idx]={
            "index":idx,
            "name":p[1],
            "uuid":p[2],
            "utilization_percent":int(p[3]),
            "memory_used_MiB":int(p[4]),
            "memory_free_MiB":int(p[5]),
            "pstate":p[6],
        }

    return rows


def compute_processes():

    text=subprocess.check_output(
        [
            "nvidia-smi",
            "--query-compute-apps=gpu_uuid,pid,process_name,used_memory",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    ).strip()

    if not text:
        return []

    rows=[]

    for line in text.splitlines():

        p=[
            x.strip()
            for x in line.split(",")
        ]

        rows.append({
            "gpu_uuid":p[0],
            "pid":int(p[1]),
            "process_name":p[2],
            "used_memory_MiB":int(p[3]),
        })

    return rows


def make_sampler_states(start):

    boxes=np.asarray(
        start["box_nm"],
        dtype=np.float64,
    )

    if boxes.ndim==2:
        boxes=np.repeat(
            boxes[None,:,:],
            N_REPLICAS,
            axis=0,
        )

    return [
        states.SamplerState(
            np.asarray(
                start["positions_nm"][i],
                dtype=np.float64,
            )*unit.nanometer,

            velocities=
                np.asarray(
                    start["velocities_nm_ps"][i],
                    dtype=np.float64,
                )
                *
                unit.nanometer/
                unit.picosecond,

            box_vectors=
                boxes[i]
                *
                unit.nanometer,
        )
        for i in range(N_REPLICAS)
    ]


def context_properties(context):

    platform=context.getPlatform()

    return {
        name:
            platform.getPropertyValue(
                context,
                name,
            )
        for name in (
            "DeviceIndex",
            "DeviceName",
            "Precision",
            "DeterministicForces",
        )
    }


def compare_exact(label,a,b):

    ok=bool(
        np.array_equal(
            np.asarray(a),
            np.asarray(b),
        )
    )

    print(
        label,
        "bitwise_exact =",
        ok,
        flush=True,
    )

    require(
        ok,
        "EXACT_EQUIVALENCE_FAILED_"+label,
    )


def maxabs(a,b):

    a=np.asarray(
        a,
        dtype=np.float64,
    )

    b=np.asarray(
        b,
        dtype=np.float64,
    )

    require(
        a.shape==b.shape,
        "MAXABS_SHAPE",
    )

    return float(
        np.max(
            np.abs(a-b)
        )
    )


# ------------------------------------------------------------
# NO-OP PROPAGATION RECORDER FOR LONG PRIMARY RUN
# ------------------------------------------------------------

class NullRecorder:

    def __init__(self,out):
        self.out=Path(out)
        self.phase="402DX_PRIMARY_1NS"
        self.current_replica=None
        self.current_state=None
        self.moves=0

    def record(self,context,thermodynamic):
        self.moves+=1

    def save(self):
        # Intentionally no file write.
        #
        # pilot_engine calls RECORDER.save() every 10 exchange
        # events.  The production-like canary stores propagation
        # health through explicit sparse streams instead.
        return None


# ------------------------------------------------------------
# PRODUCTION-LIKE SPARSE STORAGE CAPTURE
# ------------------------------------------------------------

class CanarySampler:

    @staticmethod
    def build(cy):

        class Impl(
            cy.pilot_engine.AuditedReplicaExchange
        ):

            def save_exchange_audit(
                self,
                path,
            ):

                path=Path(
                    path
                ).resolve()

                recorder=getattr(
                    cy.pilot_engine,
                    "RECORDER",
                    None,
                )

                if (
                    recorder
                    is not None
                    and
                    hasattr(
                        recorder,
                        "out",
                    )
                ):

                    periodic_sink=(
                        Path(
                            recorder.out
                        )
                        /
                        "EXCHANGE_AUDIT_v1.npz"
                    ).resolve()

                    if path==periodic_sink:

                        # Preserve every audit event in memory, but
                        # suppress pilot-engine's every-10-iteration
                        # full-history NPZ rewrite.  The complete
                        # 10,000-event audit is written exactly once
                        # at the 1-ns canary boundary.
                        return None

                return (
                    super()
                    .save_exchange_audit(
                        path
                    )
                )


            def _report_iteration(self):

                iteration=int(
                    self._iteration
                )

                if (
                    iteration>0
                    and
                    iteration<=PRIMARY_ITERATIONS
                ):

                    mapping=np.asarray(
                        self._replica_thermodynamic_states,
                        dtype=np.int64,
                    ).copy()

                    if iteration%CADENCE_1PS==0:

                        replicas=np.where(
                            mapping==0
                        )[0]

                        require(
                            len(replicas)==1,
                            "LAMBDA1_REPLICA_NOT_UNIQUE",
                        )

                        replica=int(
                            replicas[0]
                        )

                        state=(
                            self._sampler_states[
                                replica
                            ]
                        )

                        pos=np.asarray(
                            state.positions.value_in_unit(
                                unit.nanometer
                            )[
                                :self.canary_nsolute
                            ],
                            dtype=np.float64,
                        )

                        box=np.asarray(
                            state.box_vectors.value_in_unit(
                                unit.nanometer
                            ),
                            dtype=np.float64,
                        )

                        energy=np.asarray(
                            self._energy_thermodynamic_states,
                            dtype=np.float64,
                        ).copy()

                        require(
                            np.all(
                                np.isfinite(pos)
                            ),
                            "NONFINITE_LAMBDA1_POSITIONS",
                        )

                        require(
                            np.all(
                                np.isfinite(energy)
                            ),
                            "NONFINITE_REDUCED_ENERGY_MATRIX",
                        )

                        self.capture_1ps_iteration.append(
                            iteration
                        )

                        self.capture_1ps_lambda1_replica.append(
                            replica
                        )

                        self.capture_1ps_positions.append(
                            pos
                        )

                        self.capture_1ps_box.append(
                            box
                        )

                        self.capture_1ps_mapping.append(
                            mapping
                        )

                        self.capture_1ps_energy.append(
                            energy
                        )

                    if iteration%CADENCE_10PS==0:

                        positions=np.asarray([
                            s.positions.value_in_unit(
                                unit.nanometer
                            )[
                                :self.canary_nsolute
                            ]
                            for s in self._sampler_states
                        ],dtype=np.float64)

                        boxes=np.asarray([
                            s.box_vectors.value_in_unit(
                                unit.nanometer
                            )
                            for s in self._sampler_states
                        ],dtype=np.float64)

                        require(
                            np.all(
                                np.isfinite(positions)
                            ),
                            "NONFINITE_ALL_REPLICA_POSITIONS",
                        )

                        self.capture_10ps_iteration.append(
                            iteration
                        )

                        self.capture_10ps_positions.append(
                            positions
                        )

                        self.capture_10ps_box.append(
                            boxes
                        )

                        self.capture_10ps_mapping.append(
                            mapping
                        )

                    if iteration%1000==0:

                        elapsed=(
                            time.monotonic()
                            -
                            self.canary_wall_start
                        )

                        print(
                            "[402DX PROGRESS]",
                            f"{iteration}/{PRIMARY_ITERATIONS}",
                            "iterations;",
                            f"{iteration*0.1:.1f} ps/replica;",
                            "elapsed_s=",
                            f"{elapsed:.1f}",
                            flush=True,
                        )

                return (
                    super()
                    ._report_iteration()
                )

        return Impl


# ------------------------------------------------------------
# EXCHANGE REPLAY
# ------------------------------------------------------------

def rng_tuple_from_arrays(arrays,index):

    return (
        "MT19937",

        np.asarray(
            arrays["rng_keys"][index],
            dtype=np.uint32,
        ).copy(),

        int(
            arrays["rng_position"][index]
        ),

        int(
            arrays["rng_has_gauss"][index]
        ),

        float(
            arrays["rng_cached_gaussian"][index]
        ),
    )


def replay_one(arrays,index):

    mapping=np.asarray(
        arrays["before"][index],
        dtype=np.int64,
    ).copy()

    energy=np.asarray(
        arrays["energy"][index],
        dtype=np.float64,
    )

    require(
        np.all(np.isfinite(energy)),
        "NONFINITE_EXCHANGE_ENERGY",
    )

    rng=np.random.RandomState()

    rng.set_state(
        rng_tuple_from_arrays(
            arrays,
            index,
        )
    )

    proposed=np.zeros(
        (N_REPLICAS,N_REPLICAS),
        dtype=np.int64,
    )

    accepted=np.zeros(
        (N_REPLICAS,N_REPLICAS),
        dtype=np.int64,
    )

    offset=int(
        rng.randint(2)
    )

    for state_i in range(
        offset,
        N_REPLICAS-1,
        2,
    ):

        state_j=state_i+1

        replica_i=int(
            np.where(
                mapping==state_i
            )[0][0]
        )

        replica_j=int(
            np.where(
                mapping==state_j
            )[0][0]
        )

        logp=float(
            -(
                energy[replica_i,state_j]
                +
                energy[replica_j,state_i]
            )
            +
            energy[replica_i,state_i]
            +
            energy[replica_j,state_j]
        )

        proposed[state_i,state_j]+=1
        proposed[state_j,state_i]+=1

        if logp>=0.0:
            accept=True
        else:
            accept=(
                float(rng.rand())
                <
                math.exp(logp)
            )

        if accept:

            mapping[replica_i]=state_j
            mapping[replica_j]=state_i

            accepted[state_i,state_j]+=1
            accepted[state_j,state_i]+=1

    raw=rng.get_state()

    rng_after=(
        raw[0],
        raw[1].copy(),
        int(raw[2]),
        int(raw[3]),
        float(raw[4]),
    )

    return {
        "after":mapping,
        "proposed":proposed,
        "accepted":accepted,
        "rng_after":rng_after,
    }


def replay_all(
    cy,
    arrays,
    expected_final_rng,
):

    n=len(
        arrays["iteration"]
    )

    failures=0
    rng_failures=0

    for i in range(n):

        r=replay_one(
            arrays,
            i,
        )

        if not (
            np.array_equal(
                r["after"],
                arrays["after"][i],
            )
            and
            np.array_equal(
                r["proposed"],
                arrays["proposed"][i],
            )
            and
            np.array_equal(
                r["accepted"],
                arrays["accepted"][i],
            )
        ):
            failures+=1

        if i+1<n:
            expected=(
                rng_tuple_from_arrays(
                    arrays,
                    i+1,
                )
            )
        else:
            expected=expected_final_rng

        if not cy.rng_equal(
            r["rng_after"],
            expected,
        ):
            rng_failures+=1

    return {
        "events":n,
        "replay_failures":failures,
        "rng_handoff_failures":rng_failures,
    }


# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------

def main():

    print(
        "===== 402DX JACS4 TEST ALL-DOUBLE 1-NS PRODUCTION CANARY =====",
        flush=True,
    )

    require(
        not OUT.exists(),
        "402DX_OUTPUT_ALREADY_EXISTS",
    )

    # --------------------------------------------------------
    print(
        "===== 1. VERIFY CLOSED AUTHORITIES =====",
        flush=True,
    )

    for path,expected in EXPECTED.items():

        require(
            path.is_file(),
            "AUTHORITY_MISSING_"+str(path),
        )

        actual=sha(path)

        print(
            path.name,
            actual,
            flush=True,
        )

        require(
            actual==expected,
            "AUTHORITY_SHA_MISMATCH_"+path.name,
        )

    print(
        "402DW-R1 freeze members =",
        len(
            verify_freeze(
                DW_FREEZE,
                17,
            )
        ),
        flush=True,
    )

    print(
        "402CY freeze members =",
        len(
            verify_freeze(
                CY_FREEZE,
                25,
            )
        ),
        flush=True,
    )

    print(
        "402CX freeze members =",
        len(
            verify_freeze(
                CX_FREEZE,
                15,
            )
        ),
        flush=True,
    )

    print(
        "402CU source freeze members =",
        len(
            verify_freeze(
                CU_SOURCE_FREEZE,
                11,
            )
        ),
        flush=True,
    )

    dw=read_json(
        DW_REPORT
    )

    require(
        dw["final_decision"]
        ==
        "HYBRID_FORMAL_PATH_CLOSED_CURRENT_PROJECT__"
        "CUDA_DOUBLE_RETAINED_AS_FORMAL_EXECUTION_AUTHORITY",
        "DW_EXECUTION_AUTHORITY",
    )

    require(
        dw["formal_execution_authority"]
        ==
        "CUDA_DOUBLE",
        "DW_NOT_DOUBLE",
    )

    require(
        dw["formal_exact20_authorized"]
        is False,
        "EXACT20_ALREADY_AUTHORIZED",
    )

    print(
        "[PASS] CUDA-double is the sole current formal execution authority",
        flush=True,
    )

    # --------------------------------------------------------
    print(
        "===== 2. IMPORT VALIDATED 402CY-v4 ENGINE =====",
        flush=True,
    )

    cy=load_cy()

    required=[
        "RestartAwareOneContextCache",
        "TechnicalRecorder",
        "save_application_checkpoint",
        "restore_application_checkpoint",
        "sampler_arrays",
        "rng_tuple",
        "set_rng_tuple",
        "rng_equal",
        "state_from_app_rng",
        "context_fingerprint",
        "write_technical_trace",
        "sync_reporter",
        "audit_events_to_arrays",
        "all_adjacent_log_ratios",
        "make_states",
        "pilot_engine",
        "LAMBDA",
    ]

    for name in required:

        require(
            hasattr(cy,name),
            "CY_HELPER_MISSING_"+name,
        )

    require(
        len(cy.LAMBDA)==N_REPLICAS,
        "CY_LADDER_LENGTH",
    )

    print(
        "lambda ladder =",
        list(cy.LAMBDA),
        flush=True,
    )

    print(
        "[PASS] validated all-double exact-restart implementation imported",
        flush=True,
    )

    # --------------------------------------------------------
    print(
        "===== 3. GPU0 / START / SEED PRE-RUN GATES =====",
        flush=True,
    )

    inventory=gpu_inventory()

    require(
        TARGET_GPU_INDEX in inventory,
        "GPU0_NOT_VISIBLE",
    )

    gpu=inventory[
        TARGET_GPU_INDEX
    ]

    print(
        "target GPU =",
        gpu,
        flush=True,
    )

    require(
        gpu["name"]
        ==
        TARGET_GPU_NAME,
        "GPU0_MODEL",
    )

    active=[
        p
        for p in compute_processes()
        if p["gpu_uuid"]==gpu["uuid"]
    ]

    print(
        "target GPU compute processes =",
        active,
        flush=True,
    )

    require(
        not active,
        "GPU0_HAS_ACTIVE_COMPUTE_PROCESS",
    )

    require(
        gpu["utilization_percent"]<=20,
        "GPU0_BUSY",
    )

    with CX_STARTS.open() as f:

        rows=list(
            csv.DictReader(
                f,
                delimiter="\t",
            )
        )

    formal_seeds=set()

    for row in rows:

        for key in (
            "initial_velocity_seed",
            "integrator_seed",
            "exchange_seed",
        ):

            formal_seeds.add(
                int(row[key])
            )

    require(
        TECH_INTEGRATOR_SEED
        not in formal_seeds,
        "TECH_INTEGRATOR_SEED_COLLISION",
    )

    require(
        TECH_EXCHANGE_SEED
        not in formal_seeds,
        "TECH_EXCHANGE_SEED_COLLISION",
    )

    selected=[
        row
        for row in rows
        if (
            row["benchmark"]==BENCHMARK
            and
            row["arm"]==ARM
            and
            row["replicate"]==REPLICATE
        )
    ]

    require(
        len(selected)==1,
        "START_SELECTION",
    )

    start_row=selected[0]

    start_path=ROOT/(
        start_row[
            "production_start_authority"
        ]
    )

    require(
        start_path.is_file(),
        "START_MISSING",
    )

    require(
        sha(start_path)
        ==
        start_row[
            "production_start_sha256"
        ],
        "START_SHA",
    )

    physical_path=(
        SHORT/
        "systems"/
        BENCHMARK/
        "build"/
        f"{ARM}.xml"
    )

    build_path=(
        SHORT/
        "systems"/
        BENCHMARK/
        "build"/
        "BUILD_REPORT_v1.json"
    )

    pins=read_json(
        INPUT_PINS
    )

    pin_key=str(
        physical_path.relative_to(
            SHORT
        )
    )

    require(
        pin_key
        in
        pins["short_md_input_files"],
        "PHYSICAL_NOT_PINNED",
    )

    require(
        sha(physical_path)
        ==
        pins[
            "short_md_input_files"
        ][pin_key],
        "PHYSICAL_SHA",
    )

    build=read_json(
        build_path
    )

    nsolute=int(
        build["solute_atoms"]
    )

    require(
        nsolute==59,
        "JACS4_SOLUTE_ATOMS_CHANGED",
    )

    print(
        "benchmark =",
        BENCHMARK,
        ARM,
        flush=True,
    )

    print(
        "primary canary ps/replica =",
        PRIMARY_PS_PER_REPLICA,
        flush=True,
    )

    print(
        "restart comparison probe ps/replica =",
        PROBE_PS_PER_REPLICA,
        flush=True,
    )

    print(
        "technical seeds =",
        TECH_INTEGRATOR_SEED,
        TECH_EXCHANGE_SEED,
        flush=True,
    )

    print(
        "[PASS] GPU0 reserved; formal seeds untouched",
        flush=True,
    )

    # --------------------------------------------------------
    print(
        "===== 4. FREEZE 402DX CANARY CONTRACT BEFORE MD =====",
        flush=True,
    )

    OUT.mkdir(
        parents=True,
        exist_ok=False,
    )

    PRIMARY.mkdir()
    SPLIT.mkdir()
    CONT.mkdir()
    REST.mkdir()

    configuration_budget=float(
        read_json(CY_REPORT)[
            "inherited_configuration_log_weight_budget"
        ]
    )

    exchange_budget=float(
        read_json(CY_REPORT)[
            "inherited_exchange_log_ratio_budget"
        ]
    )

    require(
        configuration_budget==0.001,
        "CONFIGURATION_BUDGET",
    )

    require(
        exchange_budget==0.001,
        "EXCHANGE_BUDGET",
    )

    contract={
        "status":
            "FROZEN_BEFORE_402DX_TECHNICAL_MD",

        "scope":
            "non-formal CUDA-double production-like canary; no NMR",

        "benchmark":
            BENCHMARK,

        "arm":
            ARM,

        "gpu_index":
            TARGET_GPU_INDEX,

        "precision":
            "CUDA double",

        "cache_semantics":
            "single RestartAwareOneContextCache shared by sampler and energy",

        "replicas":
            N_REPLICAS,

        "lambda_ladder":
            list(cy.LAMBDA),

        "timestep_ps":
            TIMESTEP_PS,

        "exchange_steps":
            EXCHANGE_STEPS,

        "primary_iterations":
            PRIMARY_ITERATIONS,

        "primary_ps_per_replica":
            PRIMARY_PS_PER_REPLICA,

        "restart_probe_iterations":
            PROBE_ITERATIONS,

        "restart_probe_ps_per_replica":
            PROBE_PS_PER_REPLICA,

        "technical_integrator_seed":
            TECH_INTEGRATOR_SEED,

        "technical_exchange_seed":
            TECH_EXCHANGE_SEED,

        "production_like_storage":{
            "exchange_mapping_proposal_acceptance_ps":
                0.1,

            "full_reduced_energy_matrix_ps":
                1.0,

            "lambda1_solute_coordinates_box_ps":
                1.0,

            "all_replica_solute_coordinates_ps":
                10.0,

            "exact_recovery_checkpoint_ps":
                1000.0,

            "logical_10ns_commit":
                "not coverable by 1-ns canary",
        },

        "hard_gates":[
            "GPU0 CUDA-double deterministic context",
            "single shared sampler/energy Context cache",
            "10000 primary iterations complete",
            "primary Context step count exact",
            "10000 exchange audit events",
            "all primary exchange events replay exactly",
            "all primary exchange RNG handoffs exact",
            "1000 one-ps storage frames",
            "100 all-replica ten-ps storage frames",
            "1-ns application checkpoint exists",
            "1-ns OpenMM binary Context checkpoint exists",
            "checkpoint immediate restore physical state exact",
            "post-checkpoint continuous-vs-restart 10-ps discrete exchange exact",
            "post-checkpoint lambda1 physical trajectory exact",
            "post-checkpoint final full sampler states exact",
            "post-checkpoint exchange RNG exact",
            "floating energy/log-ratio residuals <= inherited 0.001 budgets",
        ],

        "sampling_scientific_gate":
            "none; this is engineering canary only",

        "formal_production":
            False,

        "nmr_evaluation":
            False,

        "formal_exact20_authorized_on_success":
            False,

        "authorized_after_success":
            "cross-server CUDA-double execution-equivalence smoke before exact20 deployment",
    }

    write_json(
        CONTRACT,
        contract,
    )

    precommit_members=[
        Path(__file__).resolve(),

        DW_REPORT,
        DW_FREEZE,

        CY_SCRIPT,
        CY_REPORT,
        CY_FREEZE,

        CX_PROTOCOL,
        CX_STARTS,
        CX_FREEZE,

        CU_PROTOCOL,
        CU_SOURCE_FREEZE,

        CONTRACT,
    ]

    PRECOMMIT.write_text(
        "".join(
            f"{sha(p)}  {rel(p)}\n"
            for p in precommit_members
        )
    )

    print(
        "402DX contract SHA256 =",
        sha(CONTRACT),
        flush=True,
    )

    print(
        "402DX precommit entries =",
        len(precommit_members),
        flush=True,
    )

    print(
        "402DX precommit SHA256 =",
        sha(PRECOMMIT),
        flush=True,
    )

    print(
        "[PASS] canary gates frozen before MD",
        flush=True,
    )

    # Patch 402CY helper destinations.
    cy.OUT=OUT
    cy.SPLIT=SPLIT
    cy.CONT=CONT
    cy.REST=REST

    cy.APP=APP
    cy.CTXCHK=CTXCHK
    cy.CTX_META=CTX_META

    # --------------------------------------------------------
    print(
        "===== 5. BUILD ALL-DOUBLE PRIMARY CANARY =====",
        flush=True,
    )

    source=(
        mm.XmlSerializer
        .deserialize(
            physical_path.read_text()
        )
    )

    thermodynamic_states,_=(
        cy.make_states(
            source,
            nsolute,
            list(cy.LAMBDA),
        )
    )

    require(
        len(thermodynamic_states)
        ==
        N_REPLICAS,
        "THERMO_COUNT",
    )

    start=np.load(
        start_path,
        allow_pickle=False,
    )

    sampler_states=(
        make_sampler_states(
            start
        )
    )

    move=(
        cy.pilot_engine
        .AuditedLangevinMove(
            seed=
                TECH_INTEGRATOR_SEED,

            timestep=
                TIMESTEP_PS
                *
                unit.picosecond,

            collision_rate=
                1/
                unit.picosecond,

            n_steps=
                EXCHANGE_STEPS,

            reassign_velocities=
                False,

            constraint_tolerance=
                1e-6,

            n_restart_attempts=
                0,
        )
    )

    cu=read_json(
        CU_PROTOCOL
    )

    properties=dict(
        cu["cuda_properties"]
    )

    properties["DeviceIndex"]=str(
        TARGET_GPU_INDEX
    )

    properties["Precision"]="double"
    properties["DeterministicForces"]="true"

    platform=(
        mm.Platform
        .getPlatformByName(
            "CUDA"
        )
    )

    cache_cont=(
        cy.RestartAwareOneContextCache(
            platform=platform,
            platform_properties=properties,
        )
    )

    warm_requested_integrator=(
        move._get_integrator(
            thermodynamic_states[0]
        )
    )

    warm_requested_id=(
        cache_cont
        ._generate_integrator_id(
            warm_requested_integrator
        )
    )

    warm_context,warm_bound_integrator=(
        cache_cont.get_context(
            thermodynamic_states[0],
            warm_requested_integrator,
        )
    )

    warm_bound_id=(
        cache_cont
        ._generate_integrator_id(
            warm_bound_integrator
        )
    )

    require(
        warm_requested_id
        ==
        warm_bound_id
        ==
        cache_cont.initial_integrator_id,
        "PREWARM_INTEGRATOR_ID",
    )

    require(
        len(
            cache_cont.context_ids
        )==1,
        "PREWARM_CONTEXT_COUNT",
    )

    require(
        warm_context.getStepCount()==0,
        "PREWARM_STEP",
    )

    props=(
        context_properties(
            warm_context
        )
    )

    print(
        "Context properties =",
        props,
        flush=True,
    )

    require(
        props["DeviceIndex"]
        ==
        str(TARGET_GPU_INDEX),
        "CONTEXT_DEVICE",
    )

    require(
        props["Precision"]
        ==
        "double",
        "CONTEXT_PRECISION",
    )

    require(
        props["DeterministicForces"]
        ==
        "true",
        "CONTEXT_DETERMINISM",
    )

    cy.pilot_engine.RECORDER=(
        NullRecorder(
            PRIMARY/
            "periodic_audit_sink"
        )
    )

    reporter_cont=(
        multistate.MultiStateReporter(
            str(
                CONT/
                "technical.nc"
            ),

            checkpoint_interval=
                PRIMARY_ITERATIONS,

            analysis_particle_indices=
                tuple(
                    range(
                        nsolute
                    )
                ),

            velocity_interval=
                PRIMARY_ITERATIONS,
        )
    )

    SamplerClass=(
        CanarySampler.build(
            cy
        )
    )

    simulation_cont=(
        SamplerClass(
            mcmc_moves=
                move,

            number_of_iterations=
                PRIMARY_ITERATIONS
                +
                PROBE_ITERATIONS,

            replica_mixing_scheme=
                "swap-neighbors",

            online_analysis_interval=
                None,

            locality=
                None,
        )
    )

    # Authoritative all-double architecture:
    # one shared cache/context for propagation AND energy.
    simulation_cont.sampler_context_cache=(
        cache_cont
    )

    simulation_cont.energy_context_cache=(
        cache_cont
    )

    simulation_cont.canary_nsolute=(
        nsolute
    )

    simulation_cont.capture_1ps_iteration=[]
    simulation_cont.capture_1ps_lambda1_replica=[]
    simulation_cont.capture_1ps_positions=[]
    simulation_cont.capture_1ps_box=[]
    simulation_cont.capture_1ps_mapping=[]
    simulation_cont.capture_1ps_energy=[]

    simulation_cont.capture_10ps_iteration=[]
    simulation_cont.capture_10ps_positions=[]
    simulation_cont.capture_10ps_box=[]
    simulation_cont.capture_10ps_mapping=[]

    np.random.seed(
        TECH_EXCHANGE_SEED
    )

    simulation_cont.create(
        thermodynamic_states,
        sampler_states,
        reporter_cont,

        initial_thermodynamic_states=
            list(
                range(
                    N_REPLICAS
                )
            ),
    )

    require(
        simulation_cont.sampler_context_cache
        is
        simulation_cont.energy_context_cache,
        "SAMPLER_ENERGY_CACHE_NOT_SHARED",
    )

    print(
        "[PASS] single CUDA-double Context cache shared by sampler and energy",
        flush=True,
    )

    # --------------------------------------------------------
    print(
        "===== 6. RUN PRIMARY 1-NS CANARY =====",
        flush=True,
    )

    simulation_cont.canary_wall_start=(
        time.monotonic()
    )

    t0=time.monotonic()

    simulation_cont.run(
        n_iterations=
            PRIMARY_ITERATIONS
    )

    primary_wall_seconds=(
        time.monotonic()
        -
        t0
    )

    require(
        int(
            simulation_cont.iteration
        )
        ==
        PRIMARY_ITERATIONS,
        "PRIMARY_ITERATION_COUNT",
    )

    require(
        cache_cont.last_context
        is not None,
        "PRIMARY_CONTEXT_MISSING",
    )

    primary_context_steps=(
        cache_cont
        .last_context
        .getStepCount()
    )

    print(
        "primary Context steps =",
        primary_context_steps,
        flush=True,
    )

    require(
        primary_context_steps
        ==
        EXPECTED_PRIMARY_CONTEXT_STEPS,
        "PRIMARY_CONTEXT_STEP_COUNT",
    )

    primary_wall_per_iteration=(
        primary_wall_seconds/
        PRIMARY_ITERATIONS
    )

    projected_formal_days=(
        primary_wall_per_iteration
        *
        600000
        /
        86400.0
    )

    print(
        "primary wall seconds =",
        primary_wall_seconds,
        flush=True,
    )

    print(
        "wall seconds / exchange iteration =",
        primary_wall_per_iteration,
        flush=True,
    )

    print(
        "projected 60-ns formal run days at current canary rate =",
        projected_formal_days,
        flush=True,
    )

    # --------------------------------------------------------
    print(
        "===== 7. VERIFY / WRITE PRODUCTION-LIKE STORAGE STREAMS =====",
        flush=True,
    )

    oneps_iteration=np.asarray(
        simulation_cont.capture_1ps_iteration,
        dtype=np.int64,
    )

    tenps_iteration=np.asarray(
        simulation_cont.capture_10ps_iteration,
        dtype=np.int64,
    )

    require(
        len(oneps_iteration)==1000,
        "ONEPS_FRAME_COUNT",
    )

    require(
        len(tenps_iteration)==100,
        "TENPS_FRAME_COUNT",
    )

    require(
        np.array_equal(
            oneps_iteration,
            np.arange(
                10,
                PRIMARY_ITERATIONS+1,
                10,
                dtype=np.int64,
            ),
        ),
        "ONEPS_ITERATION_CADENCE",
    )

    require(
        np.array_equal(
            tenps_iteration,
            np.arange(
                100,
                PRIMARY_ITERATIONS+1,
                100,
                dtype=np.int64,
            ),
        ),
        "TENPS_ITERATION_CADENCE",
    )

    np.savez_compressed(
        SPARSE_1PS,

        iteration=
            oneps_iteration,

        lambda1_replica=
            np.asarray(
                simulation_cont
                .capture_1ps_lambda1_replica,
                dtype=np.int64,
            ),

        lambda1_positions_nm=
            np.asarray(
                simulation_cont
                .capture_1ps_positions,
                dtype=np.float64,
            ),

        lambda1_box_nm=
            np.asarray(
                simulation_cont
                .capture_1ps_box,
                dtype=np.float64,
            ),

        mapping=
            np.asarray(
                simulation_cont
                .capture_1ps_mapping,
                dtype=np.int64,
            ),

        reduced_energy_matrix=
            np.asarray(
                simulation_cont
                .capture_1ps_energy,
                dtype=np.float64,
            ),
    )

    np.savez_compressed(
        SPARSE_10PS,

        iteration=
            tenps_iteration,

        positions_nm=
            np.asarray(
                simulation_cont
                .capture_10ps_positions,
                dtype=np.float64,
            ),

        box_nm=
            np.asarray(
                simulation_cont
                .capture_10ps_box,
                dtype=np.float64,
            ),

        mapping=
            np.asarray(
                simulation_cont
                .capture_10ps_mapping,
                dtype=np.int64,
            ),
    )

    # Exchange audit at every 0.1 ps.
    require(
        len(
            simulation_cont.audit_events
        )
        ==
        PRIMARY_ITERATIONS,
        "PRIMARY_AUDIT_EVENT_COUNT",
    )

    simulation_cont.save_exchange_audit(
        EXCHANGE_AUDIT
    )

    primary_audit_arrays=(
        cy.audit_events_to_arrays(
            simulation_cont.audit_events
        )
    )

    require(
        len(
            primary_audit_arrays[
                "iteration"
            ]
        )
        ==
        PRIMARY_ITERATIONS,
        "PRIMARY_AUDIT_ARRAY_COUNT",
    )

    print(
        "1-ps frames =",
        len(oneps_iteration),
        flush=True,
    )

    print(
        "10-ps all-replica frames =",
        len(tenps_iteration),
        flush=True,
    )

    print(
        "0.1-ps exchange events =",
        PRIMARY_ITERATIONS,
        flush=True,
    )

    # --------------------------------------------------------
    print(
        "===== 8. SAVE EXACT 1-NS RECOVERY CHECKPOINT =====",
        flush=True,
    )

    split_rng=(
        cy.save_application_checkpoint(
            simulation_cont,
            cache_cont,
        )
    )

    cy.sync_reporter(
        reporter_cont
    )

    require(
        APP.is_file()
        and
        APP.stat().st_size>0,
        "APPLICATION_CHECKPOINT_MISSING",
    )

    require(
        CTXCHK.is_file()
        and
        CTXCHK.stat().st_size>0,
        "BINARY_CONTEXT_CHECKPOINT_MISSING",
    )

    require(
        CTX_META.is_file(),
        "CHECKPOINT_METADATA_MISSING",
    )

    meta=read_json(
        CTX_META
    )

    require(
        sha(APP)
        ==
        meta[
            "application_checkpoint_sha256"
        ],
        "APPLICATION_CHECKPOINT_SELF_SHA",
    )

    require(
        sha(CTXCHK)
        ==
        meta[
            "openmm_binary_checkpoint_sha256"
        ],
        "BINARY_CHECKPOINT_SELF_SHA",
    )

    print(
        "application checkpoint SHA256 =",
        sha(APP),
        flush=True,
    )

    print(
        "binary Context checkpoint SHA256 =",
        sha(CTXCHK),
        flush=True,
    )

    # Replay full primary exchange history.
    replay=(
        replay_all(
            cy,
            primary_audit_arrays,
            split_rng,
        )
    )

    print(
        "primary exchange replay =",
        replay,
        flush=True,
    )

    require(
        replay[
            "replay_failures"
        ]==0,
        "PRIMARY_REPLAY_FAILURE",
    )

    require(
        replay[
            "rng_handoff_failures"
        ]==0,
        "PRIMARY_RNG_HANDOFF_FAILURE",
    )

    # Native reporter copy frozen at exactly 1 ns before
    # uninterrupted continuation changes CONT files.
    restart_nc=REST/"technical.nc"
    restart_checkpoint_nc=REST/"technical_checkpoint.nc"

    shutil.copy2(
        CONT/"technical.nc",
        restart_nc,
    )

    shutil.copy2(
        CONT/"technical_checkpoint.nc",
        restart_checkpoint_nc,
    )

    require(
        restart_nc.is_file(),
        "RESTART_REPORTER_COPY_MISSING",
    )

    require(
        restart_checkpoint_nc.is_file(),
        "RESTART_CHECKPOINT_REPORTER_COPY_MISSING",
    )

    # Storage receipt.
    write_json(
        STORAGE_MANIFEST,
        {
            "exchange_audit_cadence_ps":
                0.1,

            "exchange_events":
                PRIMARY_ITERATIONS,

            "one_ps_stream_cadence_ps":
                1.0,

            "one_ps_frames":
                len(oneps_iteration),

            "ten_ps_all_replica_cadence_ps":
                10.0,

            "ten_ps_all_replica_frames":
                len(tenps_iteration),

            "recovery_checkpoint_cadence_ps":
                1000.0,

            "application_checkpoint_sha256":
                sha(APP),

            "binary_context_checkpoint_sha256":
                sha(CTXCHK),

            "native_analysis_reporter_bytes_at_1ns":
                (
                    CONT/
                    "technical.nc"
                ).stat().st_size,

            "native_checkpoint_reporter_bytes_at_1ns":
                (
                    CONT/
                    "technical_checkpoint.nc"
                ).stat().st_size,

            "sparse_1ps_bytes":
                SPARSE_1PS.stat().st_size,

            "sparse_10ps_bytes":
                SPARSE_10PS.stat().st_size,

            "exchange_audit_bytes":
                EXCHANGE_AUDIT.stat().st_size,
        },
    )

    print(
        "[PASS] 1-ns production-like storage + recovery checkpoint materialized",
        flush=True,
    )

    # --------------------------------------------------------
    print(
        "===== 9. UNINTERRUPTED +10-PS CONTINUATION PROBE =====",
        flush=True,
    )

    # Discard primary audit log from comparison memory only.
    simulation_cont.audit_events=[]

    recorder_cont=(
        cy.TechnicalRecorder(
            CONT/"probe_trace",
            nsolute,
        )
    )

    cy.pilot_engine.RECORDER=(
        recorder_cont
    )

    # Ensure exact exchange RNG split state.
    cy.set_rng_tuple(
        split_rng
    )

    simulation_cont.run(
        n_iterations=
            PROBE_ITERATIONS
    )

    require(
        int(
            simulation_cont.iteration
        )
        ==
        PRIMARY_ITERATIONS
        +
        PROBE_ITERATIONS,
        "CONT_FINAL_ITERATION",
    )

    require(
        cache_cont
        .last_context
        .getStepCount()
        ==
        EXPECTED_FINAL_CONTEXT_STEPS,
        "CONT_FINAL_CONTEXT_STEP",
    )

    continuous_rng_final=(
        cy.rng_tuple()
    )

    continuous_final=(
        cy.sampler_arrays(
            simulation_cont
        )
    )

    continuous_events=list(
        simulation_cont.audit_events
    )

    require(
        len(
            continuous_events
        )
        ==
        PROBE_ITERATIONS,
        "CONT_PROBE_EVENT_COUNT",
    )

    cont_trace=(
        cy.write_technical_trace(
            CONT/
            "PROBE_LAMBDA1_TRACE_v1.npz",
            recorder_cont,
        )
    )

    require(
        len(
            cont_trace["replica"]
        )
        ==
        PROBE_ITERATIONS,
        "CONT_PROBE_TRACE_COUNT",
    )

    cy.sync_reporter(
        reporter_cont
    )

    reporter_cont.close()

    print(
        "[PASS] uninterrupted +10-ps branch completed",
        flush=True,
    )

    # --------------------------------------------------------
    print(
        "===== 10. RESTART FROM REAL 1-NS CHECKPOINT =====",
        flush=True,
    )

    recorder_restart=(
        cy.TechnicalRecorder(
            REST/"probe_trace",
            nsolute,
        )
    )

    cy.pilot_engine.RECORDER=(
        recorder_restart
    )

    simulation_restart=(
        cy.pilot_engine
        .AuditedReplicaExchange
        .from_storage(
            str(
                restart_nc
            )
        )
    )

    require(
        int(
            simulation_restart.iteration
        )
        ==
        PRIMARY_ITERATIONS,
        "NATIVE_RESTORE_ITERATION",
    )

    app=np.load(
        APP,
        allow_pickle=False,
    )

    cy.restore_application_checkpoint(
        simulation_restart,
        app,
    )

    compare_exact(
        "split_mapping",
        simulation_restart
        ._replica_thermodynamic_states,
        app["thermodynamic_state"],
    )

    compare_exact(
        "split_energy_matrix",
        simulation_restart
        ._energy_thermodynamic_states,
        app["energy_reduced"],
    )

    compare_exact(
        "split_neighborhoods",
        simulation_restart
        ._neighborhoods,
        app["neighborhoods"],
    )

    compare_exact(
        "split_accepted",
        simulation_restart
        ._n_accepted_matrix,
        app["accepted_matrix"],
    )

    compare_exact(
        "split_proposed",
        simulation_restart
        ._n_proposed_matrix,
        app["proposed_matrix"],
    )

    cache_restart=(
        cy.RestartAwareOneContextCache(
            platform=platform,
            platform_properties=properties,
        )
    )

    restored_move=(
        simulation_restart
        ._mcmc_moves[0]
    )

    restart_integrator=(
        restored_move
        ._get_integrator(
            simulation_restart
            ._thermodynamic_states[0]
        )
    )

    context,bound_integrator=(
        cache_restart
        .get_context(
            simulation_restart
            ._thermodynamic_states[0],
            restart_integrator,
        )
    )

    context.loadCheckpoint(
        CTXCHK.read_bytes()
    )

    fp=(
        cy.context_fingerprint(
            context
        )
    )

    compare_exact(
        "checkpoint_positions",
        fp["positions_nm"],
        app["context_positions_nm"],
    )

    compare_exact(
        "checkpoint_velocities",
        fp["velocities_nm_ps"],
        app["context_velocities_nm_ps"],
    )

    compare_exact(
        "checkpoint_box",
        fp["box_nm"],
        app["context_box_nm"],
    )

    require(
        int(fp["step_count"])
        ==
        EXPECTED_PRIMARY_CONTEXT_STEPS,
        "RESTART_CONTEXT_STEP",
    )

    restart_props=(
        context_properties(
            context
        )
    )

    print(
        "restart Context properties =",
        restart_props,
        flush=True,
    )

    require(
        restart_props["Precision"]
        ==
        "double",
        "RESTART_NOT_DOUBLE",
    )

    require(
        restart_props["DeviceIndex"]
        ==
        str(TARGET_GPU_INDEX),
        "RESTART_WRONG_GPU",
    )

    cache_restart.activate_exact_recovery()

    # Same authoritative all-double one-cache architecture.
    simulation_restart.sampler_context_cache=(
        cache_restart
    )

    simulation_restart.energy_context_cache=(
        cache_restart
    )

    require(
        simulation_restart.sampler_context_cache
        is
        simulation_restart.energy_context_cache,
        "RESTART_CACHE_NOT_SHARED",
    )

    simulation_restart.audit_events=[]

    restart_rng=(
        cy.state_from_app_rng(
            app
        )
    )

    cy.set_rng_tuple(
        restart_rng
    )

    require(
        cy.rng_equal(
            cy.rng_tuple(),
            split_rng,
        ),
        "RESTART_RNG_AT_SPLIT",
    )

    # Critical: do not recompute energies before first restarted mix.
    compare_exact(
        "pre_first_mix_energy_matrix",
        simulation_restart
        ._energy_thermodynamic_states,
        app["energy_reduced"],
    )

    simulation_restart.run(
        n_iterations=
            PROBE_ITERATIONS
    )

    require(
        int(
            simulation_restart.iteration
        )
        ==
        PRIMARY_ITERATIONS
        +
        PROBE_ITERATIONS,
        "RESTART_FINAL_ITERATION",
    )

    require(
        cache_restart
        .last_context
        .getStepCount()
        ==
        EXPECTED_FINAL_CONTEXT_STEPS,
        "RESTART_FINAL_CONTEXT_STEP",
    )

    restart_rng_final=(
        cy.rng_tuple()
    )

    restart_final=(
        cy.sampler_arrays(
            simulation_restart
        )
    )

    restart_events=list(
        simulation_restart.audit_events
    )

    require(
        len(
            restart_events
        )
        ==
        PROBE_ITERATIONS,
        "RESTART_PROBE_EVENT_COUNT",
    )

    rest_trace=(
        cy.write_technical_trace(
            REST/
            "PROBE_LAMBDA1_TRACE_v1.npz",
            recorder_restart,
        )
    )

    require(
        len(
            rest_trace["replica"]
        )
        ==
        PROBE_ITERATIONS,
        "RESTART_PROBE_TRACE_COUNT",
    )

    cy.sync_reporter(
        simulation_restart._reporter
    )

    simulation_restart._reporter.close()

    print(
        "[PASS] checkpoint restart +10-ps branch completed",
        flush=True,
    )

    # --------------------------------------------------------
    print(
        "===== 11. CONTINUOUS-vs-RESTART EXACTNESS GATE =====",
        flush=True,
    )

    cont_arrays=(
        cy.audit_events_to_arrays(
            continuous_events
        )
    )

    rest_arrays=(
        cy.audit_events_to_arrays(
            restart_events
        )
    )

    exact_event_fields=[
        "phase",
        "iteration",
        "before",
        "after",
        "rng_keys",
        "rng_position",
        "rng_has_gauss",
        "rng_cached_gaussian",
        "proposed",
        "accepted",
    ]

    for key in exact_event_fields:

        compare_exact(
            "exchange_"+key,
            cont_arrays[key],
            rest_arrays[key],
        )

    exchange_energy_residual=maxabs(
        cont_arrays["energy"],
        rest_arrays["energy"],
    )

    cont_log=(
        cy.all_adjacent_log_ratios(
            cont_arrays["before"],
            cont_arrays["energy"],
        )
    )

    rest_log=(
        cy.all_adjacent_log_ratios(
            rest_arrays["before"],
            rest_arrays["energy"],
        )
    )

    log_residual=maxabs(
        cont_log,
        rest_log,
    )

    print(
        "post-checkpoint exchange-energy max abs =",
        exchange_energy_residual,
        flush=True,
    )

    print(
        "post-checkpoint adjacent log-ratio max abs =",
        log_residual,
        flush=True,
    )

    require(
        exchange_energy_residual
        <=
        configuration_budget,
        "EXCHANGE_ENERGY_BUDGET",
    )

    require(
        log_residual
        <=
        exchange_budget,
        "LOG_RATIO_BUDGET",
    )

    for key in (
        "replica",
        "positions_nm",
        "velocities_nm_ps",
        "box_nm",
        "context_step",
    ):

        compare_exact(
            "lambda1_"+key,
            cont_trace[key],
            rest_trace[key],
        )

    for key in (
        "positions_nm",
        "velocities_nm_ps",
        "box_nm",
        "thermodynamic_state",
        "neighborhoods",
        "accepted_matrix",
        "proposed_matrix",
    ):

        compare_exact(
            "final_"+key,
            continuous_final[key],
            restart_final[key],
        )

    final_energy_residual=maxabs(
        continuous_final["energy_reduced"],
        restart_final["energy_reduced"],
    )

    print(
        "final reduced-energy residual =",
        final_energy_residual,
        flush=True,
    )

    require(
        final_energy_residual
        <=
        configuration_budget,
        "FINAL_ENERGY_BUDGET",
    )

    require(
        cy.rng_equal(
            continuous_rng_final,
            restart_rng_final,
        ),
        "FINAL_EXCHANGE_RNG",
    )

    print(
        "final exchange RNG exact = True",
        flush=True,
    )

    # --------------------------------------------------------
    print(
        "===== 12. STORAGE / RESOURCE RECEIPT =====",
        flush=True,
    )

    manifest=read_json(
        STORAGE_MANIFEST
    )

    for path in (
        SPARSE_1PS,
        SPARSE_10PS,
        EXCHANGE_AUDIT,
        APP,
        CTXCHK,
        CTX_META,
        STORAGE_MANIFEST,
    ):

        require(
            path.is_file()
            and
            path.stat().st_size>0,
            "CANARY_ARTIFACT_MISSING_"+path.name,
        )

        print(
            path.name,
            "bytes =",
            path.stat().st_size,
            "SHA256 =",
            sha(path),
            flush=True,
        )

    native_total=(
        int(
            manifest[
                "native_analysis_reporter_bytes_at_1ns"
            ]
        )
        +
        int(
            manifest[
                "native_checkpoint_reporter_bytes_at_1ns"
            ]
        )
    )

    sparse_total=(
        SPARSE_1PS.stat().st_size
        +
        SPARSE_10PS.stat().st_size
        +
        EXCHANGE_AUDIT.stat().st_size
    )

    print(
        "native reporter bytes at 1 ns =",
        native_total,
        flush=True,
    )

    print(
        "production-like sparse stream bytes at 1 ns =",
        sparse_total,
        flush=True,
    )

    # --------------------------------------------------------
    print(
        "===== 13. WRITE / FREEZE 402DX PASS =====",
        flush=True,
    )

    result={
        "status":
            "ALLDOUBLE_1NS_PRODUCTION_CANARY_PASS",

        "benchmark":
            BENCHMARK,

        "arm":
            ARM,

        "gpu_index":
            TARGET_GPU_INDEX,

        "precision":
            "double",

        "shared_sampler_energy_cache":
            True,

        "primary_ps_per_replica":
            PRIMARY_PS_PER_REPLICA,

        "primary_iterations":
            PRIMARY_ITERATIONS,

        "primary_context_steps":
            primary_context_steps,

        "primary_wall_seconds":
            primary_wall_seconds,

        "wall_seconds_per_exchange_iteration":
            primary_wall_per_iteration,

        "projected_60ns_formal_run_days_at_canary_rate":
            projected_formal_days,

        "production_like_storage":{
            "exchange_events":
                PRIMARY_ITERATIONS,

            "one_ps_frames":
                len(oneps_iteration),

            "ten_ps_all_replica_frames":
                len(tenps_iteration),

            "checkpoint_at_1ns":
                True,

            "application_checkpoint_sha256":
                sha(APP),

            "binary_context_checkpoint_sha256":
                sha(CTXCHK),

            "native_reporter_bytes_at_1ns":
                native_total,

            "sparse_stream_bytes_at_1ns":
                sparse_total,
        },

        "primary_exchange_replay":
            replay,

        "checkpoint_immediate_restore_exact":
            True,

        "restart_probe_ps_per_replica":
            PROBE_PS_PER_REPLICA,

        "post_checkpoint_discrete_exchange_exact":
            True,

        "post_checkpoint_lambda1_physical_trajectory_exact":
            True,

        "post_checkpoint_final_full_sampler_states_exact":
            True,

        "post_checkpoint_final_exchange_rng_exact":
            True,

        "post_checkpoint_exchange_energy_max_abs_reduced":
            exchange_energy_residual,

        "post_checkpoint_exchange_log_ratio_max_abs":
            log_residual,

        "post_checkpoint_final_energy_max_abs_reduced":
            final_energy_residual,

        "inherited_configuration_budget":
            configuration_budget,

        "inherited_exchange_log_ratio_budget":
            exchange_budget,

        "formal_production_MD":
            False,

        "formal_seeds_consumed":
            False,

        "nmr_evaluation":
            False,

        "formal_exact20_authorized":
            False,

        "logical_10ns_commit_tested":
            False,

        "scientific_protocol_changed":
            False,

        "authorized_next":
            "cross-server CUDA-double execution-equivalence smoke on "
            "destination RTX5090 servers/GPUs before formal exact20 deployment",
    }

    write_json(
        RESULT,
        result,
    )

    artifact_files=sorted(
        p
        for p in OUT.rglob("*")
        if (
            p.is_file()
            and
            p!=FREEZE
            and
            p!=FAILURE_FREEZE
            and
            p.suffix!=".pyc"
            and
            "__pycache__" not in p.parts
        )
    )

    members=[
        Path(__file__).resolve(),

        DW_REPORT,
        DW_FREEZE,

        CY_SCRIPT,
        CY_REPORT,
        CY_FREEZE,

        CX_PROTOCOL,
        CX_STARTS,
        CX_FREEZE,

        CU_PROTOCOL,
        CU_SOURCE_FREEZE,
    ]+artifact_files

    unique=[]
    seen=set()

    for p in members:

        p=Path(p).resolve()

        if p in seen:
            continue

        seen.add(p)
        unique.append(p)

    FREEZE.write_text(
        "".join(
            f"{sha(p)}  {rel(p)}\n"
            for p in unique
        )
    )

    print(
        "402DX result SHA256 =",
        sha(RESULT),
        flush=True,
    )

    print(
        "402DX freeze entries =",
        len(unique),
        flush=True,
    )

    print(
        "402DX freeze SHA256 =",
        sha(FREEZE),
        flush=True,
    )

    # --------------------------------------------------------
    print(
        "===== 14. FINAL 402DX STATE =====",
        flush=True,
    )

    print(
        "[PASS] JACS4 TEST completed 1 ns/replica on GPU0",
        flush=True,
    )

    print(
        "[PASS] authoritative single-cache CUDA-double architecture retained",
        flush=True,
    )

    print(
        "[PASS] 0.1-ps exchange audit cadence covered",
        flush=True,
    )

    print(
        "[PASS] 1-ps lambda1/reduced-energy storage cadence covered",
        flush=True,
    )

    print(
        "[PASS] 10-ps all-replica coordinate storage cadence covered",
        flush=True,
    )

    print(
        "[PASS] real 1-ns exact recovery checkpoint created and restored",
        flush=True,
    )

    print(
        "[PASS] all 10000 primary exchange events independently replay exactly",
        flush=True,
    )

    print(
        "[PASS] 10-ps continuous-vs-restart post-checkpoint trajectory exact",
        flush=True,
    )

    print(
        "[PASS] formal seeds untouched",
        flush=True,
    )

    print(
        "[PASS] no NMR/experimental endpoint accessed",
        flush=True,
    )

    print(
        "[HOLD] 10-ns logical segment-commit layer not covered by 1-ns canary",
        flush=True,
    )

    print(
        "[HOLD] formal exact20 pending cross-server execution-equivalence smoke",
        flush=True,
    )

    print(
        "[AUTHORIZED-NEXT] deploy frozen CUDA-double stack to destination servers for cross-server smoke",
        flush=True,
    )

    print(
        "===== 402DX JACS4 TEST ALL-DOUBLE 1-NS PRODUCTION CANARY END =====",
        flush=True,
    )

    return 0


if __name__=="__main__":

    try:
        rc=main()

    except Exception:

        if OUT.is_dir():

            write_json(
                FAILURE,
                {
                    "status":
                        "402DX_CANARY_FAILED_EVIDENCE_PRESERVED",

                    "traceback":
                        traceback.format_exc(),

                    "formal_production_MD":
                        False,

                    "formal_seeds_consumed":
                        False,

                    "nmr_evaluation":
                        False,

                    "formal_exact20_authorized":
                        False,
                },
            )

            current=sorted(
                p
                for p in OUT.rglob("*")
                if (
                    p.is_file()
                    and
                    p!=FAILURE_FREEZE
                    and
                    p.suffix!=".pyc"
                )
            )

            members=[
                Path(__file__).resolve(),

                DW_REPORT,
                DW_FREEZE,

                CY_SCRIPT,
                CY_REPORT,
                CY_FREEZE,

                CX_PROTOCOL,
                CX_STARTS,
                CX_FREEZE,
            ]+current

            unique=[]
            seen=set()

            for p in members:

                p=Path(p).resolve()

                if p in seen:
                    continue

                seen.add(p)
                unique.append(p)

            FAILURE_FREEZE.write_text(
                "".join(
                    f"{sha(p)}  {rel(p)}\n"
                    for p in unique
                )
            )

            print(
                "402DX failure freeze SHA256 =",
                sha(FAILURE_FREEZE),
                flush=True,
            )

        raise

    sys.exit(rc)
