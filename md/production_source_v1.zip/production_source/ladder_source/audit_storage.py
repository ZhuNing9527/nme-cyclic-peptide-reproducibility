"""Independent NetCDF, checkpoint, replica-label and lambda=1 output checks.

402CO repair: iteration-zero energies are independently recomputed by native
MultiStateSampler.run() after the pre-run snapshot. Therefore the two matrices
are compared against the already-frozen reduced log-weight budget instead of
requiring bitwise identity. Final energies remain a bitwise identity gate.
"""
import json
from pathlib import Path
import numpy as np
import netCDF4
from common import require,read_json,write_json

def audit(base):
    base=Path(base)
    request=read_json(base/'PRE_CONTEXT_v1.json')
    p=request['protocol']
    n=p['replicas']
    iterations=p['pilot_iterations']

    start=np.load(base/'PILOT_START_REPLICAS_v1.npz')
    final=np.load(base/'FINAL_REPLICAS_v1.npz')
    trace=np.load(base/'SOLUTE_ALL_REPLICAS_v1.npz')
    physical=np.load(base/'LAMBDA1_SOLUTE_v1.npz')
    health=read_json(base/'HEALTH_v1.json')

    journal=[
        json.loads(l)
        for l in (base/'HEALTH_JOURNAL_v1.jsonl').read_text().splitlines()
    ]

    require(journal==health,'HEALTH_JOURNAL_DIFFERENCE')
    require(
        len(health)==n*(p['equilibration_iterations']+iterations),
        'HEALTH_COVERAGE'
    )

    selected=np.where(
        (trace['phase']=='pilot')
        &
        (trace['thermodynamic_state']==0)
    )[0]

    require(
        np.array_equal(selected,physical['source_health_row'])
        and len(selected)==iterations,
        'LAMBDA1_SELECTION'
    )

    require(
        np.array_equal(
            trace['positions_nm'][selected],
            physical['positions_nm']
        )
        and
        np.array_equal(
            trace['replica'][selected],
            physical['replica']
        ),
        'LAMBDA1_TRACE_DIFFERENCE'
    )

    max_position_error=0.

    with netCDF4.Dataset(base/'pilot.nc') as data:

        require(
            int(data.variables['last_iteration'][0])==iterations,
            'NETCDF_LAST_ITERATION'
        )

        labels=np.asarray(data.variables['states'][:])
        energies=np.asarray(data.variables['energies'][:])

        require(
            np.array_equal(
                labels[0],
                start['thermodynamic_state']
            )
            and
            np.array_equal(
                labels[-1],
                final['thermodynamic_state']
            ),
            'STORED_REPLICA_LABEL_MISMATCH'
        )

        start_energy_delta=float(
            np.max(
                np.abs(
                    energies[0]
                    -
                    start['energy_reduced']
                )
            )
        )

        start_energy_budget=float(
            p['reference_configuration_log_weight_error_budget']
        )

        require(
            np.isfinite(start_energy_delta)
            and start_energy_delta<=start_energy_budget,
            'ITERATION_ZERO_ENERGY_LOG_WEIGHT_BUDGET'
        )

        require(
            np.array_equal(
                energies[-1],
                final['energy_reduced']
            ),
            'FINAL_STORED_ENERGY_MATRIX_MISMATCH'
        )

        for iteration in range(iterations):

            rows=np.where(
                trace['phase']=='pilot'
            )[0][
                iteration*n:
                (iteration+1)*n
            ]

            require(
                np.array_equal(
                    trace['replica'][rows],
                    np.arange(n)
                ),
                'PROPAGATION_ORDER'
            )

            require(
                np.array_equal(
                    trace['thermodynamic_state'][rows],
                    labels[iteration+1]
                ),
                'HEALTH_VS_REPORTER_LABELS'
            )

            x=np.asarray(
                data.variables['positions'][iteration+1]
            )

            ref=trace['positions_nm'][rows]

            for replica in range(n):

                box=trace['box_nm'][rows[replica]]
                delta=x[replica]-ref[replica]

                f=delta@np.linalg.inv(box)
                delta=(f-np.round(f))@box

                max_position_error=max(
                    max_position_error,
                    float(abs(delta).max())
                )

        require(
            max_position_error<2e-6,
            'ANALYSIS_COORDINATE_STORAGE_ERROR'
        )

    with netCDF4.Dataset(base/'pilot_checkpoint.nc') as checkpoint:

        for index,state in [(0,start),(-1,final)]:

            for nc,key in [
                ('positions','positions_nm'),
                ('velocities','velocities_nm_ps'),
                ('box_vectors','box_nm')
            ]:

                actual=np.asarray(
                    checkpoint.variables[nc][index]
                )

                expected=np.asarray(
                    state[key],
                    dtype=actual.dtype
                )

                require(
                    np.array_equal(actual,expected),
                    'CHECKPOINT_ARRAY_MISMATCH '+nc
                )

    result={
        'status':'PASS',

        'iteration_zero_labels_synchronized':
            True,

        'iteration_zero_energy_recomputation_max_abs_delta_reduced':
            start_energy_delta,

        'iteration_zero_energy_frozen_log_weight_budget':
            start_energy_budget,

        'iteration_zero_energy_within_frozen_log_weight_budget':
            True,

        'final_energy_matrix_bitwise_exact':
            True,

        'final_checkpoint_arrays_match_float32_storage':
            True,

        'lambda1_frames':
            len(selected),

        'lambda1_selection_uses_thermodynamic_state':
            True,

        'max_analysis_position_error_after_periodic_translation_nm':
            max_position_error,

        'checkpoint_precision':
            'Native reporter float32; double-precision start/final NPZ '
            'and solute traces retained separately',
    }

    write_json(
        base/'STORAGE_AUDIT_v2.json',
        result
    )

    return result
