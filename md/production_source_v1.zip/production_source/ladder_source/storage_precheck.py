"""Read-only checks of native iteration-zero records, before further MD."""
import numpy as np
from openmm import unit
from common import require,write_json

def check(reporter,simulation,out,label):
    require(simulation.iteration==0,'STORAGE_PRECHECK_ITERATION')
    data=reporter._storage_analysis;cp=reporter._storage_checkpoint
    require(data is not None and cp is not None and data.isopen() and cp.isopen(),'REPORTER_FILES_NOT_OPEN')
    n=simulation.n_replicas
    for d in [data,cp]:
        require(len(d.dimensions['iteration'])==1 and len(d.dimensions['replica'])==n,'INITIAL_STORAGE_DIMENSIONS')
    require(int(data.variables['last_iteration'][0])==0,'INITIAL_LAST_ITERATION')
    require(np.array_equal(data.variables['states'][0],simulation._replica_thermodynamic_states),'INITIAL_STORAGE_LABELS')
    require(np.array_equal(data.variables['energies'][0],simulation._energy_thermodynamic_states),'INITIAL_STORAGE_ENERGIES')
    require(all(k in data.variables for k in ['accepted','proposed','timestamp','positions','box_vectors']),'INITIAL_STORAGE_VARIABLES')
    require(bool(str(data.variables['timestamp'][0]).strip()),'INITIAL_STORAGE_TIMESTAMP')
    for name,attr,u in [('positions','positions',unit.nanometer),('velocities','velocities',unit.nanometer/unit.picosecond),('box_vectors','box_vectors',unit.nanometer)]:
        expected=np.asarray([getattr(s,attr).value_in_unit(u) for s in simulation._sampler_states],dtype=cp.variables[name].dtype)
        require(np.array_equal(cp.variables[name][0],expected),'INITIAL_CHECKPOINT_'+name.upper())
        if name=='positions':
            chosen=expected[:,list(reporter.analysis_particle_indices),:]
            require(np.array_equal(data.variables[name][0],chosen),'INITIAL_ANALYSIS_POSITIONS')
    result={'status':'PASS','label':label,'iteration':0,'replicas':n,'checks':'Native labels, energies, timestamp, analysis positions and full checkpoint arrays match current sampler states; no writes or MD performed by this checker'}
    write_json(out/('STORAGE_PRECHECK_'+label+'_v1.json'),result)
    return result
