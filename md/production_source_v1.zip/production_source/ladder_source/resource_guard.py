"""Unchanged resource functions extracted from the completed 402BW runner."""
import json, os, signal, subprocess, time
from pathlib import Path
from common import sha, write_json, protocol

def memory_status(pgid=None, procroot=Path('/proc')):
    mem={}
    for line in (procroot/'meminfo').read_text().splitlines():
        key,value=line.split(':',1);mem[key]=int(value.split()[0])*1024
    rss=swap=0;pids=[]
    if pgid is not None:
        for p in procroot.iterdir():
            if not p.name.isdigit():continue
            try:
                stat=(p/'stat').read_text();fields=stat[stat.rfind(')')+2:].split()
                if int(fields[2])!=pgid:continue
                pids.append(int(p.name))
                for line in (p/'status').read_text().splitlines():
                    if line.startswith('VmRSS:'):rss+=int(line.split()[1])*1024
                    if line.startswith('VmSwap:'):swap+=int(line.split()[1])*1024
            except (FileNotFoundError,ProcessLookupError,PermissionError,ValueError):continue
    return {'host_available_bytes':mem['MemAvailable'],'group_rss_bytes':rss,'group_swap_bytes':swap,'pids':pids}

def stop_process(p):
    try:os.killpg(p.pid,signal.SIGTERM)
    except ProcessLookupError:
        try:p.terminate()
        except ProcessLookupError:pass
    try:p.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:os.killpg(p.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        try:p.kill()
        except ProcessLookupError:pass
        p.wait(timeout=5)

def guarded(command, job, gpu_uuid, limits=None):
    limits=limits or protocol()['resource_limits']
    job=Path(job);job.mkdir(parents=True,exist_ok=False)
    env=os.environ.copy();env.update({'PYTHONUNBUFFERED':'1','PYTHONDONTWRITEBYTECODE':'1',
          'OPENMM_CPU_THREADS':'2','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
    if gpu_uuid is not None:env['CUDA_VISIBLE_DEVICES']=gpu_uuid
    write_json(job/'request.json',{'argv':list(map(str,command)),'cuda_visible_devices':gpu_uuid,
       'source_script_sha256':sha(command[1]),'limits':limits})
    start=time.monotonic();reason=None;peak=0;maxswap=0;minavail=2**63;last_print=start;last_seen=start
    with (job/'worker.log').open('w') as log,(job/'resources.jsonl').open('w') as trace:
        p=subprocess.Popen(list(map(str,command)),stdout=log,stderr=subprocess.STDOUT,
                           env=env,start_new_session=True)
        try:
            while True:
                m=memory_status(p.pid);elapsed=time.monotonic()-start
                if m['pids']:last_seen=time.monotonic()
                peak=max(peak,m['group_rss_bytes']);maxswap=max(maxswap,m['group_swap_bytes']);minavail=min(minavail,m['host_available_bytes'])
                trace.write(json.dumps({'elapsed_seconds':elapsed,**m})+'\n');trace.flush()
                if m['group_rss_bytes']>limits['process_group_rss_bytes']:reason='PROCESS_GROUP_RSS_LIMIT'
                elif m['group_swap_bytes']>limits['process_group_swap_bytes']:reason='PROCESS_GROUP_SWAP_LIMIT'
                elif m['host_available_bytes']<limits['minimum_host_available_bytes']:reason='HOST_AVAILABLE_MEMORY_LIMIT'
                elif elapsed>limits['job_timeout_seconds']:reason='JOB_TIMEOUT'
                elif p.poll() is None and time.monotonic()-last_seen>5:reason='PROCESS_GROUP_MONITOR_UNAVAILABLE'
                if reason:stop_process(p);break
                if p.poll() is not None:break
                if time.monotonic()-last_print>=30:
                    print(f'[RUNNING] {job.name}: {elapsed:.0f} s; RSS {m["group_rss_bytes"]/2**30:.3f} GiB',flush=True);last_print=time.monotonic()
                time.sleep(limits['poll_seconds'])
        except BaseException:
            stop_process(p);raise
    rc=p.wait()
    result={'returncode':rc,'termination_reason':reason,'elapsed_seconds':time.monotonic()-start,
            'peak_sampled_group_rss_bytes':peak,'max_sampled_group_swap_bytes':maxswap,'min_sampled_host_available_bytes':minavail}
    write_json(job/'outcome.json',result)
    if rc!=0 or reason:
        print((job/'worker.log').read_text()[-9000:],flush=True)
        raise RuntimeError('JOB_FAILED: '+job.name+' '+str(result))
    print('[PASS] '+job.name,flush=True)
    return result
