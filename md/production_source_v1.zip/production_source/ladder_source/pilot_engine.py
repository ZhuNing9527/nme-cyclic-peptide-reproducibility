"""Auditing hooks around the unmodified openmmtools move and exchange algorithms."""
import math
from pathlib import Path
import numpy as np
import openmm as mm
from openmm import unit
from openmmtools import mcmc,multistate
from common import require,write_json

RECORDER=None

def scalar_replica_index(value,n_replicas):
    """Normalize a unique np.where result before entering native swap algebra."""
    if isinstance(value,tuple):
        require(len(value)==1,'EXPECTED_ONE_DIMENSIONAL_REPLICA_LOOKUP')
        value=value[0]
    array=np.asarray(value)
    require(array.size==1 and array.dtype.kind in 'iu','EXPECTED_ONE_INTEGER_REPLICA_INDEX')
    index=int(array.item())
    require(0<=index<n_replicas,'REPLICA_INDEX_OUT_OF_RANGE')
    return index

class HealthRecorder:
    def __init__(self,system,initial,geometry,protocol,out):
        self.p=protocol;self.out=Path(out);self.initial=initial;self.geometry=geometry
        self.n=max(max(g['chirality_atoms']) for g in geometry)+1
        self.masses=np.array([system.getParticleMass(i).value_in_unit(unit.dalton) for i in range(system.getNumParticles())])
        self.constraints=np.array([[int(a),int(b),d.value_in_unit(unit.nanometer)] for a,b,d in (system.getConstraintParameters(i) for i in range(system.getNumConstraints()))])
        self.dof=3*len(self.masses)-len(self.constraints)-3
        self.phase='equilibration';self.current_replica=None;self.current_state=None;self.rows=[];self.solute=[];self.chiralities=[];self.boxes=[]
        self.signs=np.sign(self.chirality(initial['positions_nm']));self.moves=0
    def chirality(self,x):
        return np.array([np.dot(np.cross(x[g['chirality_atoms'][1]]-x[g['chirality_atoms'][0]],x[g['chirality_atoms'][2]]-x[g['chirality_atoms'][0]]),x[g['chirality_atoms'][3]]-x[g['chirality_atoms'][0]]) for g in self.geometry])
    def record(self,context,thermodynamic):
        require(self.current_replica is not None,'MISSING_REPLICA_ID')
        value=float(context.getParameter('rest2_lambda'));require(abs(value-thermodynamic.rest2_lambda)<1e-14,'PROPAGATION_STATE_MISMATCH')
        require(abs(value-self.p['ladder_lambda'][self.current_state])<1e-14,'PROPAGATION_LABEL_MISMATCH')
        st=context.getState(getEnergy=True,getPositions=True,getVelocities=True,getForces=True)
        x=st.getPositions(asNumpy=True).value_in_unit(unit.nanometer);v=st.getVelocities(asNumpy=True).value_in_unit(unit.nanometer/unit.picosecond)
        box=st.getPeriodicBoxVectors(asNumpy=True).value_in_unit(unit.nanometer);f=st.getForces(asNumpy=True).value_in_unit(unit.kilojoule_per_mole/unit.nanometer)
        pe=st.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole);ke=st.getKineticEnergy().value_in_unit(unit.kilojoule_per_mole)
        require(all(np.isfinite(a).all() for a in (x,v,box,f)) and math.isfinite(pe) and math.isfinite(ke),'NONFINITE_PILOT_STATE')
        require(np.array_equal(box,self.initial['box_nm']),'NVT_BOX_CHANGED');l=self.p['health_limits']
        d=x[self.constraints[:,0].astype(int)]-x[self.constraints[:,1].astype(int)];s=d@np.linalg.inv(box);d=(s-np.round(s))@box
        ce=float(abs(np.linalg.norm(d,axis=1)-self.constraints[:,2]).max());fm=float(np.linalg.norm(f,axis=1).max());ch=self.chirality(x)
        require(ce<l['max_constraint_abs_error_nm'] and fm<l['max_force_kj_mol_nm'],'PILOT_FORCE_OR_CONSTRAINT_LIMIT')
        require(np.all(np.sign(ch)==self.signs) and abs(ch).min()>l['minimum_abs_chirality_volume_nm3'],'PILOT_CHIRALITY_FAILURE')
        temperature=2*ke/(self.dof*.00831446261815324);lo,hi=l['temperature_range_K'];require(lo<temperature<hi,'PILOT_TEMPERATURE_LIMIT')
        self.moves+=1;self.rows.append({'phase':self.phase,'move':self.moves,'replica':int(self.current_replica),'thermodynamic_state':int(self.current_state),
          'lambda':value,'context_step':context.getStepCount(),'potential_kj_mol':pe,'kinetic_kj_mol':ke,'temperature_K':temperature,
          'max_force_kj_mol_nm':fm,'max_constraint_error_nm':ce,'minimum_chirality_abs_nm3':float(abs(ch).min())})
        import json
        with (self.out/'HEALTH_JOURNAL_v1.jsonl').open('a') as journal:journal.write(json.dumps(self.rows[-1],allow_nan=False)+'\n')
        self.solute.append(x[:self.p['solute_atoms']].copy());self.chiralities.append(ch);self.boxes.append(box)
    def save(self):
        write_json(self.out/'HEALTH_v1.json',self.rows)
        np.savez_compressed(self.out/'SOLUTE_ALL_REPLICAS_v1.npz',positions_nm=self.solute,box_nm=self.boxes,chirality_volume_nm3=self.chiralities,
          replica=[r['replica'] for r in self.rows],thermodynamic_state=[r['thermodynamic_state'] for r in self.rows],
          phase=[r['phase'] for r in self.rows],move=[r['move'] for r in self.rows])

class AuditedLangevinMove(mcmc.LangevinDynamicsMove):
    def __init__(self,seed=0,**kwargs):super().__init__(**kwargs);self.seed=int(seed)
    def _get_integrator(self,state):
        integrator=super()._get_integrator(state);integrator.setRandomNumberSeed(self.seed);return integrator
    def _after_integration(self,context,state):
        require(RECORDER is not None,'HEALTH_RECORDER_MISSING');RECORDER.record(context,state)
    def __getstate__(self):
        result=super().__getstate__();result['seed']=self.seed;return result
    def __setstate__(self,serialization):
        super().__setstate__(serialization);self.seed=serialization['seed']

class AuditedReplicaExchange(multistate.ReplicaExchangeSampler):
    def _attempt_swap(self,replica_i,replica_j):
        # openmmtools 0.26 passes np.where tuples to this method. Scalar indices
        # keep its unchanged native acceptance formula compatible with NumPy 2.4.
        i=scalar_replica_index(replica_i,self.n_replicas)
        j=scalar_replica_index(replica_j,self.n_replicas)
        return super()._attempt_swap(i,j)
    def _propagate_replica(self,replica_id):
        RECORDER.current_replica=int(replica_id);RECORDER.current_state=int(self._replica_thermodynamic_states[replica_id])
        try:return super()._propagate_replica(replica_id)
        finally:RECORDER.current_replica=None;RECORDER.current_state=None
    def _mix_replicas(self):
        if not hasattr(self,'audit_events'):self.audit_events=[]
        rng=np.random.get_state();before=self._replica_thermodynamic_states.copy();energy=self._energy_thermodynamic_states.copy()
        after=super()._mix_replicas()
        self.audit_events.append({'phase':RECORDER.phase,'iteration':int(self._iteration),'before':before,'after':after.copy(),'energy':energy,
          'rng_keys':rng[1].copy(),'rng_position':rng[2],'rng_has_gauss':rng[3],'rng_cached_gaussian':rng[4],
          'proposed':self._n_proposed_matrix.copy(),'accepted':self._n_accepted_matrix.copy()})
        if len(self.audit_events)%10==0:
            RECORDER.save();self.save_exchange_audit(RECORDER.out/'EXCHANGE_AUDIT_v1.npz')
        return after
    def save_exchange_audit(self,path):
        events=getattr(self,'audit_events',[])
        if events:np.savez_compressed(path,**{k:np.array([e[k] for e in events]) for k in events[0]})

def reconstruct_exchanges(path):
    """Independent NumPy replay from saved pre-swap energies and RNG states."""
    d=np.load(path);n=d['before'].shape[1];counts=np.zeros((n,n),int);accepted=np.zeros((n,n),int);history=[]
    for z in range(len(d['phase'])):
        rng=np.random.RandomState();rng.set_state(('MT19937',d['rng_keys'][z],int(d['rng_position'][z]),int(d['rng_has_gauss'][z]),float(d['rng_cached_gaussian'][z])))
        mapping=d['before'][z].copy();u=d['energy'][z];require(np.isfinite(u).all(),'NONFINITE_EXCHANGE_ENERGY')
        proposed=np.zeros((n,n),int);acc=np.zeros((n,n),int)
        for i in range(int(rng.randint(2)),n-1,2):
            j=i+1;a=int(np.where(mapping==i)[0][0]);b=int(np.where(mapping==j)[0][0])
            logp=float(-(u[a,j]+u[b,i])+u[a,i]+u[b,j]);proposed[i,j]+=1;proposed[j,i]+=1
            if logp>=0 or float(rng.rand())<math.exp(logp):
                mapping[a],mapping[b]=j,i;acc[i,j]+=1;acc[j,i]+=1
        require(np.array_equal(mapping,d['after'][z]) and np.array_equal(proposed,d['proposed'][z]) and np.array_equal(acc,d['accepted'][z]),'EXCHANGE_REPLAY_MISMATCH')
        if str(d['phase'][z])=='pilot':counts+=proposed;accepted+=acc;history.append(mapping.copy())
    edges=[{'lower_state':i,'upper_state':i+1,'proposed':int(counts[i,i+1]),'accepted':int(accepted[i,i+1]),
            'acceptance_fraction':float(accepted[i,i+1]/counts[i,i+1]) if counts[i,i+1] else None} for i in range(n-1)]
    histories=np.asarray(history);roundtrips=[]
    for walker in range(n):
        anchor=None;opposite_seen=False;trips=0
        for state in histories[:,walker]:
            if state not in (0,n-1):continue
            if anchor is None:anchor=int(state)
            elif state!=anchor:opposite_seen=True
            elif opposite_seen:trips+=1;opposite_seen=False
        roundtrips.append(trips)
    return {'exchange_events_replayed':len(d['phase']),'pilot_exchange_events':len(history),'edges':edges,'endpoint_roundtrips_by_walker':roundtrips,
      'definition':'A full return to the first visited endpoint after visiting the opposite endpoint; pilot stage only',
      'ladder_decision':'REVIEW_REQUIRED_NO_AUTOMATIC_ADAPTATION','nmr_evaluation':False,'production':False}
