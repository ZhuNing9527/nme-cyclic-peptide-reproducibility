"""Short candidate-ladder run, gated by separately completed state/cache checks."""
import argparse,copy,json,logging,sys,time,traceback
from pathlib import Path
import numpy as np
import openmm as mm
from openmm import unit
from openmmtools import states,multistate
import mpiplus
from common import HERE,SYSTEMS,ARMS,require,sha,read_json,write_json,protocol,pins
from state_adapter import make_states,OneContextCache
import pilot_engine as engine

def run(a):
    p=protocol();out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
    require(a.benchmark in SYSTEMS and a.arm in ARMS,'SYSTEM_ID')
    if not a.development:require(sys.version_info[:2]==(3,11) and a.platform=='CUDA','SERVER_RUNTIME')
    comm=mpiplus.get_mpicomm();require(comm is None or comm.size==1,'MPI_MULTIRANK_NOT_AUTHORIZED')
    if a.development or a.smoke:p.update(p['smoke_protocol'])
    base=Path(a.short)/'systems'/a.benchmark;physical_path=base/'build'/f'{a.arm}.xml';parent=base/'PARENT/final_state.npz'
    for path in (physical_path,parent):require(sha(path)==pins()['short_md_input_files'][str(path.relative_to(Path(a.short)))],'PILOT_INPUT_CHANGED')
    source=mm.XmlSerializer.deserialize(physical_path.read_text());build=read_json(base/'build/BUILD_REPORT_v1.json');n=build['solute_atoms'];p['solute_atoms']=n
    initial=dict(np.load(parent));geometry=read_json(base/'build/SOLUTE_GEOMETRY_v1.json');seed=p['seed_base']+SYSTEMS.index(a.benchmark)
    np.random.seed(seed);thermos,audit=make_states(source,n,p['ladder_lambda'])
    props=p['cuda_properties'] if a.platform=='CUDA' else {};cache=OneContextCache(platform=mm.Platform.getPlatformByName(a.platform),platform_properties=props)
    move=engine.AuditedLangevinMove(seed=seed,timestep=.001*unit.picosecond,collision_rate=1/unit.picosecond,n_steps=p['exchange_steps'],
      reassign_velocities=False,constraint_tolerance=1e-6,n_restart_attempts=0)
    integrator=move._get_integrator(thermos[0]);(out/'initial_integrator.xml').write_text(mm.XmlSerializer.serialize(integrator))
    np.savez_compressed(out/'INITIAL_REPLICAS_v1.npz',positions_nm=np.repeat(initial['positions_nm'][None],p['replicas'],axis=0),
      velocities_nm_ps=np.repeat(initial['velocities_nm_ps'][None],p['replicas'],axis=0),box_nm=initial['box_nm'])
    write_json(out/'PRE_CONTEXT_v1.json',{'benchmark':a.benchmark,'arm':a.arm,'physical_sha256':sha(physical_path),'parent_sha256':sha(parent),
      'source_adapter_sha256':sha(HERE/'state_adapter.py'),'source_engine_sha256':sha(HERE/'pilot_engine.py'),'seed':seed,
      'platform':a.platform,'properties':props,'protocol':p,'development_only':a.development,'smoke_only':a.smoke,'contexts_authorized':1,'audit':audit})
    engine.RECORDER=engine.HealthRecorder(source,initial,geometry,p,out)
    # Prime with the exact propagation integrator, so energy requests also reuse
    # this Context and cannot first create a different default integrator.
    context,bound=cache.get_context(thermos[0],integrator)
    actual_platform=context.getPlatform();actual_properties={k:actual_platform.getPropertyValue(context,k) for k in actual_platform.getPropertyNames()}
    require(actual_platform.getName()==a.platform,'ACTUAL_PILOT_PLATFORM')
    if not a.development:require(actual_properties['Precision']=='double' and actual_properties['DeterministicForces']=='true','ACTUAL_PILOT_PRECISION')
    import inspect,hashlib,platform
    write_json(out/'CONTEXT_FACTS_v1.json',{'platform':actual_platform.getName(),'actual_properties':actual_properties,
      'python':platform.python_version(),'numpy':np.__version__,'context_initial_step':context.getStepCount(),
      'native_replicaexchange_source_sha256':sha(Path(inspect.getsourcefile(multistate.ReplicaExchangeSampler))),
      'native_reporter_source_sha256':sha(Path(inspect.getsourcefile(multistate.MultiStateReporter))),
      'native_sampler_source_sha256':sha(Path(inspect.getsourcefile(multistate.MultiStateSampler)))})
    (out/'system_actual_context.xml').write_text(mm.XmlSerializer.serialize(context.getSystem()))
    (out/'integrator_actual_context.xml').write_text(mm.XmlSerializer.serialize(bound))
    sampler_states=[states.SamplerState(initial['positions_nm']*unit.nanometer,velocities=initial['velocities_nm_ps']*unit.nanometer/unit.picosecond,
        box_vectors=initial['box_nm']*unit.nanometer) for _ in range(p['replicas'])]
    reporter=multistate.MultiStateReporter(str(out/'pilot.nc'),checkpoint_interval=p['checkpoint_interval'],analysis_particle_indices=tuple(range(n)),velocity_interval=0)
    simulation=engine.AuditedReplicaExchange(mcmc_moves=move,number_of_iterations=p['pilot_iterations'],replica_mixing_scheme='swap-neighbors',online_analysis_interval=None)
    simulation.energy_context_cache=cache;simulation.sampler_context_cache=cache
    start=time.monotonic()
    try:
        simulation.create(thermos,sampler_states,reporter)
        require(simulation.energy_context_cache is cache and simulation.sampler_context_cache is cache,'SAMPLER_REPLACED_CACHE')
        from storage_precheck import check as storage_precheck
        storage_precheck(reporter,simulation,out,'CREATED')
        simulation.equilibrate(p['equilibration_iterations'])
        engine.RECORDER.phase='pilot'
        # equilibrate() updates stored positions at iteration zero but does not
        # synchronize every iteration-zero label/energy field. Write a complete
        # start record with the inherited reporting method before recorded runs.
        simulation._compute_energies()
        simulation._n_accepted_matrix[:]=0;simulation._n_proposed_matrix[:]=0
        simulation._report_iteration()
        storage_precheck(reporter,simulation,out,'EQUILIBRATED')
        start_states=simulation._sampler_states
        np.savez_compressed(out/'PILOT_START_REPLICAS_v1.npz',positions_nm=[s.positions.value_in_unit(unit.nanometer) for s in start_states],
          velocities_nm_ps=[s.velocities.value_in_unit(unit.nanometer/unit.picosecond) for s in start_states],box_nm=[s.box_vectors.value_in_unit(unit.nanometer) for s in start_states],
          thermodynamic_state=simulation._replica_thermodynamic_states.copy(),energy_reduced=simulation._energy_thermodynamic_states.copy())
        simulation.run()
        require(simulation.iteration==p['pilot_iterations'],'PILOT_ITERATION_COUNT')
        expected=p['replicas']*(p['equilibration_iterations']+p['pilot_iterations']);require(engine.RECORDER.moves==expected,'MOVE_COUNT')
        require(context.getStepCount()==expected*p['exchange_steps'],'CONTEXT_STEP_COUNT')
        final=simulation._sampler_states
        np.savez_compressed(out/'FINAL_REPLICAS_v1.npz',positions_nm=[s.positions.value_in_unit(unit.nanometer) for s in final],
          velocities_nm_ps=[s.velocities.value_in_unit(unit.nanometer/unit.picosecond) for s in final],box_nm=[s.box_vectors.value_in_unit(unit.nanometer) for s in final],
          thermodynamic_state=simulation._replica_thermodynamic_states,energy_reduced=simulation._energy_thermodynamic_states)
        simulation.save_exchange_audit(out/'EXCHANGE_AUDIT_v1.npz');engine.RECORDER.save()
        diagnostic=engine.reconstruct_exchanges(out/'EXCHANGE_AUDIT_v1.npz')
        # Sampling-stage health labels must select exactly one lambda=1 walker
        # per propagation sweep. Save that selection explicitly.
        h=engine.RECORDER.rows;selected=[i for i,r in enumerate(h) if r['phase']=='pilot' and r['thermodynamic_state']==0]
        require(len(selected)==p['pilot_iterations'],'PHYSICAL_STATE_SELECTION_COUNT')
        np.savez_compressed(out/'LAMBDA1_SOLUTE_v1.npz',positions_nm=np.asarray(engine.RECORDER.solute)[selected],
          replica=[h[i]['replica'] for i in selected],source_health_row=selected,box_nm=np.asarray(engine.RECORDER.boxes)[selected])
        result={'status':'SHORT_LADDER_PILOT_COMPLETED','benchmark':a.benchmark,'arm':a.arm,'contexts_created':len(cache.context_ids),'cache_requests':cache.requests,
          'md_steps':expected*p['exchange_steps'],'equilibration_ps_per_replica':p['equilibration_iterations']*p['exchange_steps']*.001,
          'pilot_ps_per_replica':p['pilot_iterations']*p['exchange_steps']*.001,'replicas':p['replicas'],'lambda_values':p['ladder_lambda'],
          'diagnostic':diagnostic,'wall_seconds':time.monotonic()-start,'development_only':a.development,'smoke_only':a.smoke,'production':False,'nmr_evaluation':False,
          'maximum_constraint_error_nm':max(r['max_constraint_error_nm'] for r in h),'minimum_abs_chirality_nm3':min(r['minimum_chirality_abs_nm3'] for r in h),
          'peak_recorded_force_kj_mol_nm':max(r['max_force_kj_mol_nm'] for r in h)}
    finally:
        engine.RECORDER.save();simulation.save_exchange_audit(out/'EXCHANGE_AUDIT_v1.npz');reporter.close()
    from audit_storage import audit as audit_storage
    result['storage_audit']=audit_storage(out)
    write_json(out/'RESULT_v1.json',result);print('PILOT PASS',a.benchmark,a.arm,'MD steps',result['md_steps'],'contexts',result['contexts_created'],flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--short',required=True);p.add_argument('--out',required=True);p.add_argument('--benchmark',required=True);p.add_argument('--arm',required=True)
    p.add_argument('--platform',choices=['Reference','CUDA'],required=True);p.add_argument('--development',action='store_true');p.add_argument('--smoke',action='store_true');a=p.parse_args()
    logging.getLogger('openmmtools').setLevel(logging.WARNING)
    try:run(a)
    except BaseException:
        if Path(a.out).is_dir():write_json(Path(a.out)/'FAILURE_v1.json',{'traceback':traceback.format_exc()})
        raise
