from pathlib import Path
import argparse
import ast
import csv
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

import numpy as np
import openmm as mm
from openmm import unit
from openmmtools import multistate


ROOT=Path(
    "/mnt/lab/zn/mem-perm/P0_starter_v1"
).resolve()

DEV=(
    ROOT/
    "07_nmeala_separability_pilot"/
    "13_joint_correction_development"
)

CX=DEV/"21l_post_m4_final_production_protocol_freeze_v2"

PROTOCOL=CX/"402CX_v2_FINAL_PRODUCTION_PROTOCOL_v1.json"
STARTS=CX/"402CX_v2_PRODUCTION_STARTS_AND_SEEDS_v1.tsv"
CX_FREEZE=CX/"402CX_v2_FINAL_PRODUCTION_PROTOCOL_FREEZE_v1.sha256"

EA=DEV/"231aq_original_server_independent_formal_authorization_R1_v1"
EA_AMENDMENT=EA/"402EA_R1_ORIGINAL_SERVER_DEPLOYMENT_AMENDMENT_v1.json"
EA_FREEZE=EA/"402EA_R1_PRELAUNCH_FREEZE_v1.sha256"

MAT=DEV/"231as_formal_exact20_materialized_starts_v1"
MAT_CONTRACT=MAT/"402EC_FORMAL_START_MATERIALIZATION_CONTRACT_v1.json"
MAT_MANIFEST=MAT/"402EC_FORMAL_START_MANIFEST_v1.json"
MAT_FREEZE=MAT/"402EC_FORMAL_START_MATERIALIZATION_FREEZE_v1.sha256"

DX_SCRIPT=DEV/"run_402DX_jacs4_test_alldouble_1ns_production_canary_v2.py"

SHORT=DEV/"20r_post_m4_dmso_solvation_and_short_md_v1"

INPUT_PINS=(
    DEV/
    "21i_post_m4_final_ladder_redesign_precommit_v1"/
    "source"/
    "INPUT_PINS_v1.json"
)

PROD_ROOT=DEV/"232e_formal_exact20_production_v5"


EXPECTED={
    PROTOCOL:
        "960dc16d81fbd58df2cda17a9d9d91a5dc70c556a08f883a94b704ea38a451ac",

    STARTS:
        "7d62289519fde4a23a2fe8954c13566aca4ba97bef0af7eb839cd7c69e5593fc",

    CX_FREEZE:
        "937c290d1f2b44c1d7e6aa998f4bd8885e5b75d4245c471c340aff7a6a6e917f",

    EA_AMENDMENT:
        "d61ca6b94faa29a7764b0e2d1db4f39aff6339ff79c4ea4d0b657a88ee26cdcf",

    EA_FREEZE:
        "6e9348347a8e25ff29a320d282dbe1e3644508d7a698fcb2f3fd9b0c9cf78ce3",

    DX_SCRIPT:
        "ada7e16e6185eb781bef48dfa0156b254d5b010a5881ed3ba1a2400c42b4bc39",
}


N_REPLICAS=12

TIMESTEP_PS=0.001

EXCHANGE_STEPS=100

ITERATION_PS=(
    TIMESTEP_PS
    *
    EXCHANGE_STEPS
)

EQUILIBRATION_NS=10.0

PRODUCTION_NS=50.0

EQUIL_ITERATIONS=100000

PRODUCTION_ITERATIONS=500000

TOTAL_ITERATIONS=600000

CHECKPOINT_ITERATIONS=10000

SEGMENT_ITERATIONS=100000

CADENCE_1PS=10

CADENCE_10PS=100


def require(ok,msg):
    if not ok:
        raise RuntimeError(msg)


def sha(path):
    h=hashlib.sha256()

    with Path(path).open(
        "rb"
    ) as f:

        for b in iter(
            lambda:f.read(1048576),
            b"",
        ):
            h.update(b)

    return h.hexdigest()


def rel(path):
    return str(
        Path(path)
        .resolve()
        .relative_to(ROOT)
    )


def write_json(path,obj):
    Path(path).write_text(
        json.dumps(
            obj,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )+"\n",
        encoding="utf-8",
    )


def atomic_json(path,obj):
    path=Path(path)

    tmp=path.with_suffix(
        path.suffix+".tmp"
    )

    write_json(
        tmp,
        obj,
    )

    os.replace(
        tmp,
        path,
    )


def verify_freeze(path):

    count=0

    for line in Path(path).read_text(
        encoding="utf-8"
    ).splitlines():

        if not line.strip():
            continue

        expected,raw=line.split(
            None,
            1,
        )

        p=Path(raw)

        if not p.is_absolute():
            p=ROOT/p

        require(
            p.is_file(),
            "FREEZE_MEMBER_MISSING_"
            +
            str(p),
        )

        require(
            sha(p)==expected,
            "FREEZE_MEMBER_CHANGED_"
            +
            str(p),
        )

        count+=1

    return count


def load_dx():

    spec=(
        importlib.util
        .spec_from_file_location(
            "dx_formal_engine",
            DX_SCRIPT,
        )
    )

    require(
        spec is not None
        and
        spec.loader is not None,
        "DX_IMPORT_SPEC",
    )

    module=(
        importlib.util
        .module_from_spec(
            spec
        )
    )

    spec.loader.exec_module(
        module
    )

    return module


def capture_attribute_names():

    text=DX_SCRIPT.read_text(
        encoding="utf-8"
    )

    tree=ast.parse(
        text
    )

    result=set()

    for node in ast.walk(
        tree
    ):

        if (
            isinstance(
                node,
                ast.Attribute,
            )
            and
            node.attr.startswith(
                "capture_"
            )
        ):

            result.add(
                node.attr
            )

    require(
        len(result)>0,
        "NO_CAPTURE_FIELDS",
    )

    return sorted(
        result
    )


def numeric_array(value):

    seq=list(
        value
    )

    if not seq:
        return np.empty(
            (0,),
            dtype=np.float64,
        )

    arr=np.asarray(
        seq
    )

    if arr.dtype==object:

        arr=np.stack(
            [
                np.asarray(x)
                for x in seq
            ],
            axis=0,
        )

    require(
        arr.dtype!=object,
        "OBJECT_CAPTURE_ARRAY",
    )

    if np.issubdtype(
        arr.dtype,
        np.floating,
    ):

        require(
            np.isfinite(
                arr
            ).all(),
            "NONFINITE_CAPTURE_ARRAY",
        )

    return arr


def gpu_status(index):

    text=subprocess.check_output(
        [
            "nvidia-smi",
            "--query-gpu=index,uuid,name,driver_version,utilization.gpu,memory.used,memory.free,pstate",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    )

    target=None

    for line in text.splitlines():

        p=[
            x.strip()
            for x in line.split(",")
        ]

        if int(p[0])==index:

            target={
                "index":
                    index,

                "uuid":
                    p[1],

                "name":
                    p[2],

                "driver_version":
                    p[3],

                "utilization_percent":
                    int(float(p[4])),

                "memory_used_MiB":
                    int(float(p[5])),

                "memory_free_MiB":
                    int(float(p[6])),

                "pstate":
                    p[7],
            }

            break

    require(
        target is not None,
        "PHYSICAL_GPU_NOT_FOUND",
    )


    process_text=subprocess.check_output(
        [
            "nvidia-smi",
            "--query-compute-apps=gpu_uuid,pid,process_name,used_memory",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    )


    processes=[]

    for line in process_text.splitlines():

        if not line.strip():
            continue

        p=[
            x.strip()
            for x in line.split(",")
        ]

        if p[0]==target["uuid"]:
            processes.append(p)


    target[
        "compute_processes"
    ]=processes

    return target


def write_segment_commit(
    path,
    kind,
    global_iteration,
    checkpoint_receipt,
    recent_storage,
):

    write_json(
        path,
        {
            "status":
                "FORMAL_SEGMENT_COMMITTED",

            "kind":
                kind,

            "global_iteration":
                global_iteration,

            "total_simulated_ns_per_replica":
                global_iteration
                *
                ITERATION_PS
                /
                1000.0,

            "recorded_production_ns_per_replica":
                max(
                    0.0,
                    (
                        global_iteration
                        -
                        EQUIL_ITERATIONS
                    )
                    *
                    ITERATION_PS
                    /
                    1000.0,
                ),

            "checkpoint_receipt":
                rel(
                    checkpoint_receipt
                ),

            "checkpoint_receipt_sha256":
                sha(
                    checkpoint_receipt
                ),

            "recent_storage":
                recent_storage,

            "restart_performed":
                False,
        },
    )


def main():

    ap=argparse.ArgumentParser()

    ap.add_argument(
        "--row-index",
        type=int,
        required=True,
    )

    ap.add_argument(
        "--physical-gpu-index",
        type=int,
        required=True,
    )

    ap.add_argument(
        "--preflight-only",
        action="store_true",
    )

    a=ap.parse_args()


    print(
        "===== 402EC FORMAL EXACT20 WORKER =====",
        flush=True,
    )


    require(
        1<=a.row_index<=20,
        "ROW_INDEX_RANGE",
    )


    print(
        "===== 1. VERIFY AUTHORITIES =====",
        flush=True,
    )


    for path,expected in EXPECTED.items():

        require(
            path.is_file(),
            "MISSING_"+str(path),
        )

        actual=sha(path)

        print(
            path.name,
            actual,
            flush=True,
        )

        require(
            actual==expected,
            "SHA_CHANGED_"+path.name,
        )


    require(
        MAT_CONTRACT.is_file()
        and
        MAT_MANIFEST.is_file()
        and
        MAT_FREEZE.is_file(),
        "FORMAL_START_MATERIALIZATION_MISSING",
    )


    mat_entries=verify_freeze(
        MAT_FREEZE
    )


    print(
        "formal-start freeze entries =",
        mat_entries,
        flush=True,
    )


    protocol=json.loads(
        PROTOCOL.read_text(
            encoding="utf-8"
        )
    )


    require(
        protocol[
            "run_schedule"
        ][
            "per_run_equilibration_ns"
        ]
        ==
        EQUILIBRATION_NS,
        "FORMAL_EQUILIBRATION_CHANGED",
    )

    require(
        protocol[
            "run_schedule"
        ][
            "per_run_recorded_production_ns"
        ]
        ==
        PRODUCTION_NS,
        "FORMAL_PRODUCTION_CHANGED",
    )

    require(
        protocol[
            "storage"
        ][
            "checkpoint_interval_ns"
        ]
        ==
        1.0,
        "CHECKPOINT_INTERVAL_CHANGED",
    )

    require(
        protocol[
            "rest2"
        ][
            "exchange_interval_steps"
        ]
        ==
        EXCHANGE_STEPS,
        "EXCHANGE_INTERVAL_CHANGED",
    )


    with STARTS.open(
        "r",
        encoding="utf-8",
        newline="",
    ) as f:

        rows=list(
            csv.DictReader(
                f,
                delimiter="\t",
            )
        )


    require(
        len(rows)==20,
        "START_ROW_COUNT",
    )


    row=rows[
        a.row_index-1
    ]


    manifest=json.loads(
        MAT_MANIFEST.read_text(
            encoding="utf-8"
        )
    )


    mapped=manifest[
        "run_rows"
    ][
        str(
            a.row_index
        )
    ]


    for key in (
        "benchmark",
        "arm",
        "replicate",
    ):

        require(
            row[key]
            ==
            mapped[key],
            "MATERIALIZED_ROW_MISMATCH_"+key,
        )


    formal_start=(
        ROOT/
        mapped[
            "formal_start_path"
        ]
    )


    require(
        formal_start.is_file(),
        "FORMAL_START_MISSING",
    )

    require(
        sha(formal_start)
        ==
        mapped[
            "formal_start_sha256"
        ],
        "FORMAL_START_SHA",
    )


    benchmark=row[
        "benchmark"
    ]

    arm=row[
        "arm"
    ]

    replicate=row[
        "replicate"
    ]

    velocity_seed=int(
        row[
            "initial_velocity_seed"
        ]
    )

    integrator_seed=int(
        row[
            "integrator_seed"
        ]
    )

    exchange_seed=int(
        row[
            "exchange_seed"
        ]
    )


    print(
        "formal row =",
        a.row_index,
        benchmark,
        arm,
        replicate,
        flush=True,
    )

    print(
        "formal seeds =",
        velocity_seed,
        integrator_seed,
        exchange_seed,
        flush=True,
    )

    print(
        "formal start SHA256 =",
        sha(formal_start),
        flush=True,
    )


    physical_path=(
        SHORT/
        "systems"/
        benchmark/
        "build"/
        f"{arm}.xml"
    )

    build_path=(
        SHORT/
        "systems"/
        benchmark/
        "build"/
        "BUILD_REPORT_v1.json"
    )


    require(
        physical_path.is_file()
        and
        build_path.is_file()
        and
        INPUT_PINS.is_file(),
        "FORMAL_PHYSICAL_INPUT_MISSING",
    )


    pins=json.loads(
        INPUT_PINS.read_text(
            encoding="utf-8"
        )
    )


    pin_key=str(
        physical_path.relative_to(
            SHORT
        )
    )


    require(
        pin_key
        in
        pins[
            "short_md_input_files"
        ],
        "PHYSICAL_NOT_PINNED",
    )

    require(
        sha(physical_path)
        ==
        pins[
            "short_md_input_files"
        ][
            pin_key
        ],
        "PHYSICAL_SHA",
    )


    build=json.loads(
        build_path.read_text(
            encoding="utf-8"
        )
    )

    nsolute=int(
        build[
            "solute_atoms"
        ]
    )


    dx=load_dx()

    cy=dx.load_cy()


    require(
        len(
            cy.LAMBDA
        )
        ==
        N_REPLICAS,
        "LADDER_COUNT",
    )

    require(
        list(
            cy.LAMBDA
        )
        ==
        protocol[
            "rest2"
        ][
            "lambda_values"
        ],
        "LADDER_CHANGED",
    )


    capture_names=(
        capture_attribute_names()
    )


    print(
        "capture fields =",
        capture_names,
        flush=True,
    )


    if a.preflight_only:

        print(
            "[PASS] formal worker preflight only",
            flush=True,
        )

        print(
            "[PASS] zero Context / zero MD / no formal seed consumed",
            flush=True,
        )

        print(
            "===== 402EC FORMAL EXACT20 WORKER PREFLIGHT END =====",
            flush=True,
        )

        return 0


    print(
        "===== 2. PHYSICAL GPU PRE-RUN GATE =====",
        flush=True,
    )


    visible=os.environ.get(
        "CUDA_VISIBLE_DEVICES",
        "",
    ).strip()


    require(
        visible
        ==
        str(
            a.physical_gpu_index
        ),
        "CUDA_VISIBLE_DEVICES_MUST_EQUAL_PHYSICAL_GPU_INDEX",
    )


    gpu=gpu_status(
        a.physical_gpu_index
    )


    print(
        "physical GPU =",
        gpu,
        flush=True,
    )


    require(
        "RTX 5090"
        in
        gpu[
            "name"
        ],
        "UNQUALIFIED_GPU_MODEL",
    )

    require(
        not gpu[
            "compute_processes"
        ],
        "GPU_ALREADY_HAS_COMPUTE_PROCESS",
    )

    require(
        gpu[
            "utilization_percent"
        ]
        <=
        20,
        "GPU_BUSY",
    )

    require(
        gpu[
            "memory_free_MiB"
        ]
        >=
        8192,
        "GPU_FREE_MEMORY",
    )


    run_id=(
        f"ROW{a.row_index:02d}_"
        f"{benchmark}_"
        f"{arm}_"
        f"{replicate}"
    )


    RUN=(
        PROD_ROOT/
        run_id
    )


    require(
        not RUN.exists(),
        "FORMAL_RUN_OUTPUT_ALREADY_EXISTS",
    )


    RUN.mkdir(
        parents=True,
        exist_ok=False,
    )


    CHUNKS=RUN/"chunks"
    CHECKPOINTS=RUN/"checkpoints"
    SEGMENTS=RUN/"segment_commits"

    CHUNKS.mkdir()
    CHECKPOINTS.mkdir()
    SEGMENTS.mkdir()


    CONTRACT=RUN/"FORMAL_RUN_CONTRACT_v1.json"
    PRECOMMIT=RUN/"FORMAL_RUN_PRECOMMIT_v1.sha256"
    PROGRESS=RUN/"FORMAL_RUN_PROGRESS_v1.json"
    STORAGE_MANIFEST=RUN/"FORMAL_RUN_STORAGE_MANIFEST_v1.json"
    RESULT=RUN/"FORMAL_RUN_RESULT_v1.json"
    FREEZE=RUN/"FORMAL_RUN_FINAL_FREEZE_v1.sha256"


    run_contract={
        "status":
            "FORMAL_RUN_PRECOMMITTED_BEFORE_CONTEXT",

        "row_index":
            a.row_index,

        "benchmark":
            benchmark,

        "arm":
            arm,

        "replicate":
            replicate,

        "formal_start_path":
            rel(
                formal_start
            ),

        "formal_start_sha256":
            sha(
                formal_start
            ),

        "initial_velocity_seed":
            velocity_seed,

        "integrator_seed":
            integrator_seed,

        "exchange_seed":
            exchange_seed,

        "physical_xml":
            rel(
                physical_path
            ),

        "physical_xml_sha256":
            sha(
                physical_path
            ),

        "physical_gpu_index":
            a.physical_gpu_index,

        "CUDA_VISIBLE_DEVICES":
            visible,

        "openmm_logical_DeviceIndex":
            0,

        "precision":
            "double",

        "DeterministicForces":
            True,

        "replicas":
            N_REPLICAS,

        "timestep_ps":
            TIMESTEP_PS,

        "exchange_steps":
            EXCHANGE_STEPS,

        "exchange_interval_ps":
            ITERATION_PS,

        "mixing_scheme":
            "swap-neighbors",

        "online_analysis":
            None,

        "equilibration_ns":
            EQUILIBRATION_NS,

        "recorded_production_ns":
            PRODUCTION_NS,

        "equilibration_iterations":
            EQUIL_ITERATIONS,

        "production_iterations":
            PRODUCTION_ITERATIONS,

        "total_iterations":
            TOTAL_ITERATIONS,

        "checkpoint_interval_ns":
            1.0,

        "checkpoint_iterations":
            CHECKPOINT_ITERATIONS,

        "production_segment_ns":
            10.0,

        "production_segment_iterations":
            SEGMENT_ITERATIONS,

        "continuous_normal_execution":
            True,

        "forced_restart_between_segments":
            False,

        "technical_restart_only_after_interruption":
            True,

        "equilibration_frames_admitted_to_final_analysis":
            False,

        "NMR_guided_extension":
            False,

        "formal_protocol_sha256":
            sha(
                PROTOCOL
            ),

        "formal_start_materialization_manifest_sha256":
            sha(
                MAT_MANIFEST
            ),

        "runner_sha256":
            sha(
                Path(
                    __file__
                )
            ),
    }


    write_json(
        CONTRACT,
        run_contract,
    )


    pre_members=[
        Path(__file__).resolve(),
        PROTOCOL,
        STARTS,
        CX_FREEZE,
        EA_AMENDMENT,
        EA_FREEZE,
        MAT_CONTRACT,
        MAT_MANIFEST,
        MAT_FREEZE,
        formal_start,
        physical_path,
        build_path,
        INPUT_PINS,
        CONTRACT,
    ]


    PRECOMMIT.write_text(
        "".join(
            f"{sha(p)}  {rel(p)}\n"
            for p in pre_members
        ),
        encoding="utf-8",
    )


    print(
        "formal contract SHA256 =",
        sha(CONTRACT),
        flush=True,
    )

    print(
        "formal precommit entries =",
        len(pre_members),
        flush=True,
    )

    print(
        "formal precommit SHA256 =",
        sha(PRECOMMIT),
        flush=True,
    )

    print(
        "[PASS] formal run frozen before Context creation",
        flush=True,
    )


    print(
        "===== 3. BUILD FORMAL CUDA-DOUBLE REST2 RUN =====",
        flush=True,
    )


    dx.N_REPLICAS=N_REPLICAS
    dx.PRIMARY_ITERATIONS=TOTAL_ITERATIONS
    dx.CADENCE_1PS=CADENCE_1PS
    dx.CADENCE_10PS=CADENCE_10PS


    source=(
        mm.XmlSerializer
        .deserialize(
            physical_path.read_text()
        )
    )


    thermodynamic_states,_=(
        cy.make_states(
            source,
            nsolute,
            list(
                cy.LAMBDA
            ),
        )
    )


    require(
        len(
            thermodynamic_states
        )
        ==
        N_REPLICAS,
        "THERMODYNAMIC_STATE_COUNT",
    )


    with np.load(
        formal_start,
        allow_pickle=False,
    ) as z:

        start={
            key:
                np.asarray(
                    z[key]
                ).copy()

            for key in z.files
        }


    sampler_states=(
        dx.make_sampler_states(
            start
        )
    )


    require(
        len(
            sampler_states
        )
        ==
        N_REPLICAS,
        "SAMPLER_STATE_COUNT",
    )


    move=(
        cy.pilot_engine
        .AuditedLangevinMove(

            seed=
                integrator_seed,

            timestep=
                TIMESTEP_PS
                *
                unit.picosecond,

            collision_rate=
                1/
                unit.picosecond,

            n_steps=
                EXCHANGE_STEPS,
        )
    )


    props={
        "DeviceIndex":
            "0",

        "Precision":
            "double",

        "DeterministicForces":
            "true",
    }


    platform=(
        mm.Platform
        .getPlatformByName(
            "CUDA"
        )
    )


    cache=(
        cy.RestartAwareOneContextCache(
            platform=platform,
            platform_properties=props,
        )
    )


    cy.pilot_engine.RECORDER=(
        dx.NullRecorder(
            RUN/
            "periodic_audit_sink"
        )
    )


    reporter=(
        multistate.MultiStateReporter(

            str(
                RUN/
                "technical.nc"
            ),

            checkpoint_interval=
                CHECKPOINT_ITERATIONS,

            analysis_particle_indices=
                tuple(
                    range(
                        nsolute
                    )
                ),

            velocity_interval=
                CHECKPOINT_ITERATIONS,
        )
    )


    SamplerClass=(
        dx.CanarySampler.build(
            cy
        )
    )


    simulation=(
        SamplerClass(

            mcmc_moves=
                move,

            number_of_iterations=
                TOTAL_ITERATIONS,

            replica_mixing_scheme=
                "swap-neighbors",

            online_analysis_interval=
                None,

            locality=
                None,
        )
    )


    simulation.sampler_context_cache=cache
    simulation.energy_context_cache=cache


    # --------------------------------------------------------
    # 402CY-v3/v4 validated lifecycle prewarm.
    #
    # This is NOT an MD propagation step.
    # It binds the unique CUDA Context to the actual production
    # AuditedLangevinMove integrator before iteration-zero energy
    # evaluation, preserving the strict OneContextCache identity gate.
    # --------------------------------------------------------

    warm_requested_integrator=(
        move._get_integrator(
            thermodynamic_states[0]
        )
    )

    warm_requested_id=(
        cache._generate_integrator_id(
            warm_requested_integrator
        )
    )

    warm_context,warm_bound_integrator=(
        cache.get_context(
            thermodynamic_states[0],
            warm_requested_integrator,
        )
    )

    warm_bound_id=(
        cache._generate_integrator_id(
            warm_bound_integrator
        )
    )

    require(
        cache.requests==1,
        "PREWARM_REQUEST_COUNT",
    )

    require(
        len(
            cache.context_ids
        )==1,
        "PREWARM_CONTEXT_COUNT",
    )

    require(
        warm_requested_id
        ==
        warm_bound_id
        ==
        cache.initial_integrator_id,
        "PREWARM_INTEGRATOR_IDENTITY",
    )

    require(
        warm_context.getStepCount()==0,
        "PREWARM_MUST_BE_ZERO_STEP",
    )

    print(
        "[PASS] unique Context prewarmed at zero steps with production Langevin integrator",
        flush=True,
    )


    for name in capture_names:
        setattr(
            simulation,
            name,
            [],
        )


    np.random.seed(
        exchange_seed
    )


    simulation.create(
        thermodynamic_states,
        sampler_states,
        reporter,

        initial_thermodynamic_states=
            list(
                range(
                    N_REPLICAS
                )
            ),
    )

    # --------------------------------------------------------
    # 402EC-R3: complete external CanarySampler state closure.
    # Automatically recovered from the SHA-pinned 402DX-v2
    # main() implementation.  No canary_* field is guessed.
    # --------------------------------------------------------

    # authoritative external field: canary_nsolute
    simulation.canary_nsolute=(
            nsolute
        )

    # authoritative external field: canary_wall_start
    simulation.canary_wall_start=(
            time.monotonic()
        )



    simulation.canary_wall_start=(
        time.monotonic()
    )


    print(
        "[PASS] formal simulation created",
        flush=True,
    )

    print(
        "[PASS] CUDA double / DeterministicForces / swap-neighbors",
        flush=True,
    )


    print(
        "===== 4. RUN CONTINUOUS 10NS EQUIL + 50NS PRODUCTION =====",
        flush=True,
    )


    t0=time.monotonic()

    storage_records=[]


    for chunk_index in range(
        1,
        61,
    ):

        expected_start=(
            (
                chunk_index-1
            )
            *
            CHECKPOINT_ITERATIONS
        )

        expected_end=(
            chunk_index
            *
            CHECKPOINT_ITERATIONS
        )


        require(
            int(
                simulation.iteration
            )
            ==
            expected_start,
            "CHUNK_START_ITERATION",
        )


        simulation.run(
            n_iterations=
                CHECKPOINT_ITERATIONS
        )


        require(
            int(
                simulation.iteration
            )
            ==
            expected_end,
            "CHUNK_END_ITERATION",
        )


        require(
            cache.last_context
            is not None,
            "FORMAL_CONTEXT_MISSING",
        )


        expected_context_steps=(
            expected_end
            *
            N_REPLICAS
            *
            EXCHANGE_STEPS
        )


        actual_context_steps=(
            cache
            .last_context
            .getStepCount()
        )


        require(
            actual_context_steps
            ==
            expected_context_steps,
            "FORMAL_CONTEXT_STEP_COUNT",
        )


        phase=(
            "equilibration"
            if
            expected_end
            <=
            EQUIL_ITERATIONS
            else
            "production"
        )


        capture_payload={
            "chunk_index":
                np.asarray(
                    chunk_index,
                    dtype=np.int64,
                ),

            "global_iteration_start_exclusive":
                np.asarray(
                    expected_start,
                    dtype=np.int64,
                ),

            "global_iteration_end_inclusive":
                np.asarray(
                    expected_end,
                    dtype=np.int64,
                ),

            "phase":
                np.asarray(
                    phase
                ),
        }


        for name in capture_names:

            capture_payload[name]=(
                numeric_array(
                    getattr(
                        simulation,
                        name,
                    )
                )
            )


        capture_path=(
            CHUNKS/
            (
                f"CAPTURE_"
                f"{chunk_index:02d}_"
                f"{phase}_v1.npz"
            )
        )


        np.savez_compressed(
            capture_path,
            **capture_payload,
        )


        audit_arrays=(
            cy.audit_events_to_arrays(
                simulation.audit_events
            )
        )


        require(
            len(
                audit_arrays[
                    "iteration"
                ]
            )
            ==
            CHECKPOINT_ITERATIONS,
            "CHUNK_AUDIT_EVENT_COUNT",
        )


        for key,value in audit_arrays.items():

            arr=np.asarray(
                value
            )

            if np.issubdtype(
                arr.dtype,
                np.floating,
            ):

                require(
                    np.isfinite(
                        arr
                    ).all(),
                    "NONFINITE_AUDIT_"
                    +
                    key,
                )


        audit_path=(
            CHUNKS/
            (
                f"EXCHANGE_AUDIT_"
                f"{chunk_index:02d}_"
                f"{phase}_v1.npz"
            )
        )


        np.savez_compressed(
            audit_path,
            run_phase=
                np.asarray(
                    phase
                ),

            **audit_arrays,
        )


        cp_dir=(
            CHECKPOINTS/
            f"ITER_{expected_end:06d}"
        )

        cp_dir.mkdir(
            parents=False,
            exist_ok=False,
        )


        cy.SPLIT=cp_dir
        cy.CONT=RUN
        cy.REST=RUN

        cy.APP=(
            cp_dir/
            "APPLICATION_CHECKPOINT_v1.npz"
        )

        cy.CTXCHK=(
            cp_dir/
            "OPENMM_CONTEXT_CHECKPOINT_v1.chk"
        )

        cy.CTX_META=(
            cp_dir/
            "CHECKPOINT_METADATA_v1.json"
        )


        cy.save_application_checkpoint(
            simulation,
            cache,
        )


        cy.sync_reporter(
            reporter
        )


        require(
            cy.APP.is_file()
            and
            cy.APP.stat().st_size>0,
            "APPLICATION_CHECKPOINT_MISSING",
        )

        require(
            cy.CTXCHK.is_file()
            and
            cy.CTXCHK.stat().st_size>0,
            "CONTEXT_CHECKPOINT_MISSING",
        )

        require(
            cy.CTX_META.is_file(),
            "CHECKPOINT_METADATA_MISSING",
        )


        cp_receipt=(
            cp_dir/
            "CHECKPOINT_RECEIPT_v1.json"
        )


        write_json(
            cp_receipt,
            {
                "global_iteration":
                    expected_end,

                "phase":
                    phase,

                "total_ns_per_replica":
                    expected_end
                    *
                    ITERATION_PS
                    /
                    1000.0,

                "production_ns_per_replica":
                    max(
                        0.0,
                        (
                            expected_end
                            -
                            EQUIL_ITERATIONS
                        )
                        *
                        ITERATION_PS
                        /
                        1000.0,
                    ),

                "context_steps":
                    actual_context_steps,

                "application_checkpoint_sha256":
                    sha(
                        cy.APP
                    ),

                "openmm_context_checkpoint_sha256":
                    sha(
                        cy.CTXCHK
                    ),

                "checkpoint_metadata_sha256":
                    sha(
                        cy.CTX_META
                    ),
            },
        )


        record={
            "chunk_index":
                chunk_index,

            "phase":
                phase,

            "capture_path":
                rel(
                    capture_path
                ),

            "capture_sha256":
                sha(
                    capture_path
                ),

            "exchange_audit_path":
                rel(
                    audit_path
                ),

            "exchange_audit_sha256":
                sha(
                    audit_path
                ),

            "checkpoint_receipt_path":
                rel(
                    cp_receipt
                ),

            "checkpoint_receipt_sha256":
                sha(
                    cp_receipt
                ),
        }


        storage_records.append(
            record
        )


        for name in capture_names:
            getattr(
                simulation,
                name,
            ).clear()


        simulation.audit_events.clear()


        if chunk_index==10:

            commit=(
                SEGMENTS/
                "EQUILIBRATION_10NS_COMMIT_v1.json"
            )

            write_segment_commit(
                commit,
                "EQUILIBRATION_BOUNDARY",
                expected_end,
                cp_receipt,
                storage_records[-10:],
            )


        elif (
            chunk_index>10
            and
            chunk_index%10==0
        ):

            segment=(
                chunk_index-10
            )//10

            commit=(
                SEGMENTS/
                (
                    f"PRODUCTION_SEGMENT_"
                    f"{segment}_"
                    f"10NS_COMMIT_v1.json"
                )
            )

            write_segment_commit(
                commit,
                (
                    "PRODUCTION_SEGMENT_"
                    +
                    str(segment)
                ),
                expected_end,
                cp_receipt,
                storage_records[-10:],
            )


        elapsed=(
            time.monotonic()
            -
            t0
        )


        atomic_json(
            PROGRESS,
            {
                "status":
                    "FORMAL_RUN_IN_PROGRESS",

                "row_index":
                    a.row_index,

                "benchmark":
                    benchmark,

                "arm":
                    arm,

                "replicate":
                    replicate,

                "completed_global_iteration":
                    expected_end,

                "completed_total_ns_per_replica":
                    expected_end
                    *
                    ITERATION_PS
                    /
                    1000.0,

                "completed_production_ns_per_replica":
                    max(
                        0.0,
                        (
                            expected_end
                            -
                            EQUIL_ITERATIONS
                        )
                        *
                        ITERATION_PS
                        /
                        1000.0,
                    ),

                "phase":
                    phase,

                "last_complete_checkpoint_receipt":
                    rel(
                        cp_receipt
                    ),

                "wall_seconds":
                    elapsed,
            },
        )


        print(
            "[402EC FORMAL COMMIT]",
            f"chunk={chunk_index}/60",
            f"iteration={expected_end}",
            (
                f"total_ns="
                f"{expected_end*ITERATION_PS/1000.0:.1f}"
            ),
            (
                f"production_ns="
                f"{max(0.0,(expected_end-EQUIL_ITERATIONS)*ITERATION_PS/1000.0):.1f}"
            ),
            f"phase={phase}",
            flush=True,
        )


    require(
        int(
            simulation.iteration
        )
        ==
        TOTAL_ITERATIONS,
        "FINAL_ITERATION_COUNT",
    )


    require(
        cache
        .last_context
        .getStepCount()
        ==
        TOTAL_ITERATIONS
        *
        N_REPLICAS
        *
        EXCHANGE_STEPS,
        "FINAL_CONTEXT_STEP_COUNT",
    )


    cy.sync_reporter(
        reporter
    )


    reporter.close()


    total_wall=(
        time.monotonic()
        -
        t0
    )


    write_json(
        STORAGE_MANIFEST,
        {
            "status":
                "FORMAL_STORAGE_COMPLETE",

            "row_index":
                a.row_index,

            "records":
                storage_records,

            "record_count":
                len(
                    storage_records
                ),

            "equilibration_chunk_count":
                10,

            "production_chunk_count":
                50,

            "checkpoint_count":
                60,

            "production_segment_count":
                5,

            "normal_execution_restarts":
                0,
        },
    )


    result={
        "status":
            "FORMAL_EXACT20_RUN_COMPLETE",

        "row_index":
            a.row_index,

        "benchmark":
            benchmark,

        "arm":
            arm,

        "replicate":
            replicate,

        "equilibration_ns_per_replica":
            EQUILIBRATION_NS,

        "recorded_production_ns_per_replica":
            PRODUCTION_NS,

        "total_ns_per_replica":
            EQUILIBRATION_NS
            +
            PRODUCTION_NS,

        "replicas":
            N_REPLICAS,

        "final_iteration":
            int(
                simulation.iteration
            ),

        "final_context_steps":
            int(
                cache
                .last_context
                .getStepCount()
            ),

        "wall_seconds":
            total_wall,

        "formal_start_sha256":
            sha(
                formal_start
            ),

        "physical_xml_sha256":
            sha(
                physical_path
            ),

        "initial_velocity_seed":
            velocity_seed,

        "integrator_seed":
            integrator_seed,

        "exchange_seed":
            exchange_seed,

        "normal_execution_restarts":
            0,

        "NMR_evaluation":
            False,

        "M2_evaluation_during_run":
            False,

        "ROE_evaluation_during_run":
            False,

        "scientific_extension":
            False,
    }


    write_json(
        RESULT,
        result,
    )


    final_members=[
        Path(__file__).resolve(),
        CONTRACT,
        PRECOMMIT,
        STORAGE_MANIFEST,
        RESULT,
        PROGRESS,
    ]


    for path in sorted(
        SEGMENTS.glob(
            "*.json"
        )
    ):
        final_members.append(
            path
        )


    FREEZE.write_text(
        "".join(
            f"{sha(p)}  {rel(p)}\n"
            for p in final_members
        ),
        encoding="utf-8",
    )


    print(
        "===== 5. FINAL FORMAL RUN STATE =====",
        flush=True,
    )

    print(
        "result SHA256 =",
        sha(RESULT),
        flush=True,
    )

    print(
        "storage manifest SHA256 =",
        sha(STORAGE_MANIFEST),
        flush=True,
    )

    print(
        "final freeze SHA256 =",
        sha(FREEZE),
        flush=True,
    )

    print(
        "[PASS] 10 ns equilibration completed and excluded from formal analysis",
        flush=True,
    )

    print(
        "[PASS] 50 ns recorded production completed",
        flush=True,
    )

    print(
        "[PASS] 60 one-ns recovery checkpoints materialized",
        flush=True,
    )

    print(
        "[PASS] five 10-ns production segment commits materialized",
        flush=True,
    )

    print(
        "[PASS] normal trajectory remained continuous; no forced segment restart",
        flush=True,
    )

    print(
        "===== 402EC FORMAL EXACT20 WORKER END =====",
        flush=True,
    )

    return 0


if __name__=="__main__":
    raise SystemExit(
        main()
    )
